---
title: 主机 CPU 使用率过高-OceanBase
description: 本文提供关于主机 CPU 使用率过高的相关内容，方便用户更好的应用OB Cloud 云数据库
keywords: 主机 CPU 使用率过高,运维管理,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-28T09:31:41.000+00:00
---

# 主机 CPU 使用率过高

主机 CPU 使用率过高是数据库运维中常见的问题，通常由业务 SQL 触发。CPU 资源耗尽会导致业务响应时间变长甚至服务不可用，因此需要快速定位问题并解决。本文将介绍在公有云环境下，当业务 SQL 导致主机 CPU 使用率过高时，如何快速确认问题并定位关键 SQL。

## 问题确认

您可以通过如下两种方式确认哪台主机的 CPU 使用率过高：

* 配置告警

  在 OB Cloud 云数据库控制台上，配置 **OB 节点 CPU 使用率** 告警，以便 OB Cloud 及时通知您哪台主机（即 OB 节点）的 CPU 使用率过高。关于配置告警的方法，请参见 [告警管理](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000000670888)。
* 查看主机监控数据

  在 OB Cloud 云数据库控制台上，查看各主机的 **CPU 使用率** 监控数据。如果 CPU 使用率持续稳定在 95% 左右，表明 CPU 资源已耗尽。关于查看主机监控数据的方法，请参见 [集群主机性能监控](https://www.oceanbase.com/docs/common-oceanbase-cloud-10000000001780094)。

  ![1](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/best_practices/oas-host-cpu.png)

## 问题定位

主机 CPU 使用率过高通常由业务 SQL 引起，排查时应优先考虑 SQL 问题。

## 问题分析

### 自动分析

系统提供异常事件的根因分析功能，自动分析异常时段内 CPU 占比过高的 SQL，并提供优化建议。关于查看根因分析功能的方法，请参见 [查看异常事件](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000002026530)。

![4](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/best_practices/root-cause.png)

### 人工分析

对于单租户集群，使用租户级 Top SQL 功能即可定位出消耗 CPU 最多的 SQL。对于多租户集群，可以使用集群级 Top SQL 功能，快速定位问题 SQL。

#### 操作步骤

1. 登录 [OceanBase 云服务控制台](https://console-cn.oceanbase.com)。
2. 在左侧导航栏中，单击 **实例列表**。
3. 在实例列表中找到目标实例，单击实例名称，进入 **实例工作台**。
4. 在左侧导航栏中单击 **诊断**，然后在 **诊断** 页面选择 **实时诊断** 页签。
5. 在 **实时诊断** 页面中部，选择租户。

   * 对于单租户集群，系统默认显示当前租户，无需选择。
   * 对于多租户集群，选择 **全部租户**。
6. 在 **SQL** 页签上，通过 **节点** 下拉列表选择目标节点，通过 **时间范围** 筛选框选择 CPU 异常的时段（建议选择异常开始的一段时间，以确保数据准确性），然后单击 **查询** 按钮。
7. 在 **Top SQL** 页签上，选择 **CPU 占比 (%)** 并按倒序排列。

   ![2](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/best_practices/oas-cpu-percentage.png)

   #### 说明

   **CPU 占比 (%)** 表示该 SQL 的总 CPU 时间占所有 SQL 总 CPU 时间的百分比。CPU 占比越大，表明其消耗的 CPU 资源越多。

8. 找到目标 SQL 后，单击 **SQL 文本** 列的链接跳转到 SQL 详情页面，确认是否存在以下问题，并采取相应措施：

   | 问题 | 确认方式 | 处理建议 |
   | --- | --- | --- |
   | 计划恶化 | * 确认目标 SQL 是否为可疑 SQL（详见 [可疑 SQL](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000002026524)）。 * 查看目标 SQL 的执行计划列表，结合 SQL 历史趋势分析计划变化时间点。 | * 刷新该 SQL 的 Plan Cache。 * 固定执行计划。 * 限流。 |
   | 请求量突增 | 查看 CPU 异常时段内目标 SQL 的 **总执行次数** 是否呈现出突增的趋势（详见 [Top SQL](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000002026522)）。 | * 全面优化索引。 * 限流。 |
   | 性能下降 | 查看 CPU 异常时段内目标 SQL 的 **CPU 时间** 是否呈现出上涨的趋势（详见 [Top SQL](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000002026522)）。 | * 刷新该 SQL 的 Plan Cache。 * 全面优化索引。 * 限流。 |

## 常见问题

### 1. CPU 时间是如何计算的？

目前 OBServer 没有 SQL 消耗 CPU 资源的指标，OAS 使用以下公式计算 SQL 执行过程中消耗的 CPU 时间：

v$ob\_sql\_audit.execute\_time + v$ob\_sql\_audit.get\_plan\_time - v$ob\_sql\_audit.total\_wait\_time\_micro

#### 说明

* execute\_time：计划的执行时间。
* get\_plan\_time：生成执行计划的时间。
* total\_wait\_time\_micro：执行过程所有等待的总时间。

关于监控指标的详细说明，请参见 [SQL Audit](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000002013517)。

### 2. 为什么使用 CPU 时间而非响应时间（v$ob\_sql\_audit.elapsed\_time）排序？

下图是 OBServer SQL 执行时大致的时间模型。

![3](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/best_practices/sql-time-model.png)

#### 注意

* 与 OBServer 有所不同，OAS 将获取执行计划的时间加入了 CPU 时间。
* 由于 SQL 解析时间通常比较短，所以没有包含在 CPU 时间内。

由上图可知，SQL 在执行前会在 SQL 队列中等待资源（一般是空闲线程），等待过程中基本不消耗 CPU 资源。

当 CPU 使用率过高时，SQL 队列会积压，导致 SQL 的排队时间变长，响应时间（v$ob\_sql\_audit.elapsed\_time）无法准确反映 SQL 消耗的 CPU 资源。

因此，在 CPU 使用率过高时，应主要参考 CPU 时间排序。