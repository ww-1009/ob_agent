---
title: 跨云双活实现高可用最佳实践-OceanBase
description: 本文提供关于跨云双活实现高可用最佳实践的相关内容，方便用户更好的应用OB Cloud 云数据库
keywords: 跨云双活实现高可用,高可用,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-28T09:31:41.000+00:00
---

# 跨云双活实现高可用最佳实践

OB Cloud 云数据库的迁移功能和跨区域同步能力，可以高效实现跨云双活和高可用架构。

#### 说明

跨云厂商数据同步迁移功能为白名单功能，如需使用，请联系 OB Cloud 技术支持人员。

## 原理介绍

OB Cloud 云数据库支持在不同的云服务商之间部署相同的数据和服务。每个云环境都处于活跃状态，同时处理业务请求，并通过实时数据同步技术保持数据的一致性。 当其中一个云环境发生故障时，另一个云环境可以无缝接管所有业务流量，确保服务不中断。这种架构不仅提高了系统的容错能力，还减少了对单一云服务商的依赖，增强了整体系统的可靠性和稳定性，更多内容参见 [跨云双活实现高可用](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000001755592)。

## 场景介绍

将商城业务部署在不同云厂商，客户分别在阿里云和腾讯云下单后，两端的数据库通过实时的跨云双活复制链路保持实时同步，详细内容参见 [跨云双活高可用 Demo](https://www.oceanbase.com/demo/cross-cloud-bidirectional-synchronization)。本最佳实践为您介绍在 OB Cloud 云数据库控制台如何实现跨云双活操作。

## 前提条件

* 以腾讯云和阿里云实例为例，已完成事务型实例创建，分别为实例 A 和实例 B，实例 A 为源端，实例 B 为目标端。
* 仅项目角色为项目所有者、项目管理员或数据服务管理员的用户支持创建数据迁移任务。
* 源端数据库的操作限制，请勿在结构迁移和全量迁移阶段执行库或表结构变更的 DDL 操作，否则可能造成数据迁移任务中断。
* 仅支持 OceanBase 数据库同类型租户之间的数据迁移。即支持迁移 OceanBase 数据库 MySQL 兼容模式租户的数据至 OceanBase 数据库 MySQL 兼容模式租户、迁移 OceanBase 数据库 Oracle 兼容模式租户的数据至 OceanBase 数据库 Oracle 兼容模式租户。
* 数据迁移仅支持迁移库名、表名和列名为 ASCII 码且不包含特殊字符（包括 .|"'`()=;/& 和换行）的对象。
* 数据迁移不支持大小写敏感模式。如果目标端存在同名仅大小写不一致的库或表，预检查会报错。
* 目标端是数据库的情况下，数据迁移不支持目标端存在触发器（Trigger）。如果存在，可能导致数据迁移失败。

## 操作步骤

以下通过 OceanBase Cloud 的迁移功能和同步机制，构建跨云双活、高可用的数据库架构。

### 创建租户及账号

分别为实例 A 和实例 B 创建租户、数据库和数据库账号，并保存数据库账号密码。

1. 在实例工作台单击 **新建租户**，创建 MySQL 租户。具体操作参见 [新建租户](https://www.oceanbase.com/docs/common-oceanbase-cloud-10000000001780107)。
2. 单击 **创建数据库**，并单击 **创建**。
3. 单击 **账号管理**，进入账号管理页面，单击 **创建账号**。在弹出框中填写账号名称，选择账号类型等操作，具体操作参见 [创建并管理账号](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000001018091)。
4. 执行如下语句，在实例 A 的数据库中创建 `student` 表格。

   ```
   CREATE TABLE `student` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `name` varchar(50) NOT NULL,
   `age` int(11) NOT NULL,
   `gender` enum('male','female') NOT NULL,
   `enrollment_date` date NOT NULL,
   PRIMARY KEY (`id`)
   )
   ```

### 新建数据迁移任务

![oms-domestic-73](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/oms/oceanbase-cloud/oms-domestic-73.png)

1. 登录 [OB Cloud 云数据库控制台](https://console-cn.oceanbase.com/)。
2. 在左侧导航栏，单击 **数据服务** > **数据迁移**。
3. 在 **数据迁移** 页面，单击 **数据迁移** 页签。
4. 在 **数据迁移** 页签，单击右上角的 **新建迁移任务**。
5. 在 **源端** 区域，配置各项参数。

   | 参数 | 描述 |
   | --- | --- |
   | 云厂商 | 选择 **腾讯云**。 |
   | 数据库类型 | 选择源端为 **OceanBase MySQL Mode**。 |
   | 实例类型 | 选择集群实例（事务型）。 |
   | 地域 | 选择源端数据库所在地域。 |
   | 实例 | 选择实例 A。 |
   | 数据库账号 | 用于数据迁移的 OB Cloud MySQL 数据库的用户名称。 |
   | 密码 | 数据库用户的密码。 |
6. 在 **目标端** 区域，配置各项参数。

   | 参数 | 描述 |
   | --- | --- |
   | 云厂商 | 选择 **阿里云**。 |
   | 数据库类型 | 选择源端为 **OceanBase MySQL Mode**。 |
   | 实例类型 | 选择集群实例（事务型）。 |
   | 地域 | 选择源端数据库所在地域。 |
   | 实例 | 选择实例 B。 |
   | 数据库账号 | 用于数据迁移的 OB Cloud MySQL 数据库的用户名称。 |
   | 密码 | 数据库用户的密码。 |

   ![oms-domestic-92](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/0707.png)
7. 单击 **测试连接并进入下一步**，配置双向同步。

### 配置双向同步

1. 同步拓扑为双向同步时，支持的迁移类型包括 **结构迁移**、**全量迁移**、**增量同步** 和 **全量校验**。

   | 参数 | 描述 |
   | --- | --- |
   | 结构迁移 | 结构迁移需要自行定义字符集的映射关系，数据迁移只会将源库的数据（结构）复制一份至目标数据库，不会对源数据（结构）造成影响。 |
   | 全量迁移 | 全量迁移任务开始后，数据迁移服务会迁移源库表的存量数据至目标端数据库对应的表中。 |
   | 增量同步 | 增量同步任务开始后，数据迁移会同步源端数据库发生变化的数据（新增、修改或删除）至目标端数据库对应的表中。**增量同步** 包括 **DML 同步** 和 **DDL 同步**，您可以根据需求进行自定义配置。详情请参见 [自定义配置 DML/DDL](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000000700021)。 |
   | 全量校验 | 在全量迁移完成、增量数据同步至目标端并与源端基本追平后，数据迁移会自动发起一轮针对源库配置的数据表和目标表的全量数据校验任务。 数据迁移仅支持对唯一键表（指具有主键或者非空唯一键的表）进行全量数据校验。 |
2. 在 **选择迁移对象** 区域，配置选择迁移对象的方式。您可以通过 **指定对象** 和 **匹配规则** 两种方式选择迁移对象。在 **选择迁移范围** 区域，选择需要迁移的对象，选择目标数据库下的 `student` 表格。更多详细内容参见 [配置双向同步任务](https://www.oceanbase.com/docs/common-oceanbase-cloud-1000000002399052)。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070717.png)
3. 确认迁移选项信息。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070703.png)
4. 单击 **下一步**，系统对正向任务进行预检查。

   在 **预检查** 环节，数据迁移会检查数据库用户的读写权限、数据库的网络连接等是否符合要求。全部检查任务均通过后才能启动数据迁移任务。如果预检查报错：

   * 您可以排查并处理问题后，重新执行预检查，直至预检查成功。
   * 您也可以单击失败预检查项操作列中的 **跳过**，会弹出对话框提示您跳过本操作的具体影响，确认可以跳过后，请单击对话框中的 **确定**。
5. 预检查成功后，单击 **购买**，前往 **购买数据迁移实例** 页面进行购买。
6. 购买成功后，返回数据迁移页面，查看任务进展。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070707.png)
7. 待正向任务处于 **监控中** 的增量同步阶段且任务状态为 **运行中** 时，单击反向任务后的 **配置** 按钮，确认源端和目标端信息，单击 **下一步** 配置反向任务。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070718.png)
8. 完成预检查并 **购买**，前往 **购买数据迁移实例** 页面进行购买。
9. 返回数据迁移页面，查看双向任务进展。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070706.png)

## 数据同步及验证

1. 双向任务配置成功后，在实例 B 中查看 `student` 表格的初始数据，验证从实例 A 到实例 B 的数据同步。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070710.png)
2. 在实例 B 中，增加 `student` 表格的数据。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070709.png)
3. 在实例 A 中，查看表格中的数据，验证从实例 B 到实例 A 的数据同步。

   ![](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/cloud/25V2/070711.png)