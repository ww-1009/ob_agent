# 叶子索引：高可用

> 位置：> 位置：[ob_wiki](../../../index.md) / [OceanBase 最佳实践](../../index.md) / [高可用](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [高可用最佳实践-OceanBase.md](./高可用最佳实践-OceanBase.md) | 本文提供关于高可用最佳实践的相关内容 | 高可用,高可用,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
