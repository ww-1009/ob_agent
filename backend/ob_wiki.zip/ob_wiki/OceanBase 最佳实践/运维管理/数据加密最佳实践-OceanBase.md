---
title: 数据加密最佳实践-OceanBase
description: 本文提供关于数据加密最佳实践的相关内容
keywords: 数据加密,运维管理,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-28T09:31:41.000+00:00
---

# 数据加密最佳实践

在全球范围内高度重视数据安全治理的背景下，数据库作为存储组织关键数据资产的基础软件，如何保障数据库安全已经成为数据库厂商和广大用户需要共同解决的一个重要课题。OceanBase 作为一家数据库厂商，多年来高度重视产品安全性，积极贯彻监管要求，建立安全管理体系，致力于打造稳定、可靠、安全、开放的数据基础设施。OceanBase 希望通过技术创新，帮助用户保障数据的机密性、完整性和可用性，成为客户值得信赖的基础软件供应商。当然保障数据库安全不仅需要厂商的投入，更需要厂商和用户的通力协作。

数据库系统的重要指标之一是要确保系统安全，通过数据库管理系统防止非授权使用数据库，保护数据库的文件和数据。

本文主要讲解数据加密的最佳实践操作。

## MySQL 模式租户

### 启用 TLS 数据传输加密

OceanBase 支持通信加密，以确保各个节点之间的通信流量不会被监听或篡改。

#### 相关操作

* 自检操作

  obclient 登陆以后，执行 \s 查看 observer 的 SSL 字段判断是否开启 SSL，如果没有开启则会显示 `Not in use`。

  ```
  obclient> \s
  ```

  返回结果如下：

  ```
  obclient  Ver 2.2.6 Distrib 10.4.18-MariaDB, for Linux (x86_64) using readline 5.1

  Connection id:          3221487667
  Current database:       oceanbase
  Current user:           root@100.88.114.135
  SSL:                    Not in use
  Current pager:          stdout
  Using outfile:          ''
  Using delimiter:        ;
  Server version:         OceanBase 4.3.2.1 (r201000012024080617-2ecfa3a5c430a582c4884b287b9234a9a8553bf7) (Built Aug  6 2024 18:01:40)
  Protocol version:       10
  Connection:             xxx.xxx.xxx.xxx TCP/IP
  Server characterset:    utf8mb4
  Db     characterset:    utf8mb4
  Client characterset:    utf8mb4
  Conn.  characterset:    utf8mb4
  TCP port:               2881
  Protocol:               Compressed
  Active                  --------------
  ```
* 加固操作

  此处可参考官网文档 [OBServer 传输加密](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000218259)。

### 启用 TDE 透明加密

OceanBase 支持以 tablespace 为粒度启用透明加密，实现数据的安全存储。

#### 功能适用性

该内容仅适用于 OceanBase 数据库企业版。

#### 相关操作

* 自检操作

  MySQL 租户使用如下语句：

  ```
  obclient> SELECT table_name,encryptionalg,encrypted FROM oceanbase.V$OB_ENCRYPTED_TABLES;
  ```
* 加固操作

  此处可参考官网文档 [MySQL 模式下的数据透明加密](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000218715)。

## Oracle 模式租户

### 启用 TLS 数据传输加密

OceanBase 支持通信加密，以确保各个节点之间的通信流量不会被监听或篡改。

#### 相关操作

* 自检操作

  obclient 登陆以后，执行 `\s` 命令查看，通过 SSL 字段判断是否开始 TLS，如果没有开启则会显示 `Not in use`。

  ```
  obclient> \s
  ```

  返回结果如下：

  ```
  obclient  Ver 2.2.6 Distrib 10.4.18-MariaDB, for Linux (x86_64) using readline 5.1

  Connection id:          3221487669
  Current database:       SYS
  Current user:           SYS
  SSL:                    Not in use
  Current pager:          stdout
  Using outfile:          ''
  Using delimiter:        ;
  Server version:         OceanBase 4.3.2.1 (r201000012024080617-2ecfa3a5c430a582c4884b287b9234a9a8553bf7) (Built Aug  6 2024 18:01:40)
  Protocol version:       10
  Connection:             xxx.xxx.xxx.xxx via TCP/IP
  Server characterset:    utf8mb4
  Db     characterset:    utf8mb4
  Client characterset:    utf8mb4
  Conn.  characterset:    utf8mb4
  TCP port:               2881
  Protocol:               Compressed
  Active                  --------------
  ```
* 加固操作

  此处可参考官网文档 [OBServer 传输加密](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000218259)。

### 启用 TDE 透明加密

OceanBase 支持以 tablespace 为粒度启用透明加密，实现数据的安全存储。

#### 相关操作

* 自检操作

  Oracle 租户使用如下语句：

  ```
  obclient> SELECT table_name,encryptionalg,encrypted FROM V$OB_ENCRYPTED_TABLES;
  ```

  若 ENCRYPTED 字段为 YES，表示已启用透明加密。
* 加固操作

  此处可参考官网文档 [Oracle 模式下的数据透明加密](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000218713)。