# 叶子索引：路由

> 位置：> 位置：[ob_wiki](../../../index.md) / [OceanBase 最佳实践](../../index.md) / [路由](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [ODP 路由最佳实践-OceanBase.md](./ODP 路由最佳实践-OceanBase.md) | 本文提供关于ODP 路由最佳实践的相关内容 | ODP 路由,路由,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
