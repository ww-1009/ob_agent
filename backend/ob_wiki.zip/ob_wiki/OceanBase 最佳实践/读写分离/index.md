# 叶子索引：读写分离

> 位置：> 位置：[ob_wiki](../../../index.md) / [OceanBase 最佳实践](../../index.md) / [读写分离](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OceanBase 读写分离最佳实践-OceanBase.md](./OceanBase 读写分离最佳实践-OceanBase.md) | 本文提供关于OceanBase 读写分离最佳实践的相关内容 | OceanBase 读写分离,安装部署,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
| [OceanBase AP 场景下读写分离配置指南-OceanBase.md](./OceanBase AP 场景下读写分离配置指南-OceanBase.md) | 本文提供关于OceanBase AP 场景下读写分离配置指南的相关内容 | OceanBase AP 场景下读写分离配置指南,安装部署,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
