# 分类索引：OceanBase 最佳实践

> 位置：[ob_wiki](../index.md) / OceanBase 最佳实践 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **读写分离** | 涵盖 OceanBase 读写分离最佳实践-OceanBase、OceanBase AP 场景下读写分离配置指南-OceanBase。 | `读写分离` | [进入目录](./读写分离/index.md) |
| **高可用** | 涵盖 高可用最佳实践-OceanBase。 | `高可用` `高可用最佳实践-OceanBase` | [进入目录](./高可用/index.md) |
| **开发** | 涵盖 Java 应用与 OceanBase 数据库连接配置最佳实践-OceanBase、配置 JDBC 和 OBServer 实现 Batch DML 最佳性能的最佳实践-OceanBase、Spark Catalog 与 OceanBase 集成最佳实践-OceanBase、OceanBase 数据库批量数据清理策略最佳实践-OceanBase 等 10 项。 | `开发` | [进入目录](./开发/index.md) |
| **路由** | 涵盖 ODP 路由最佳实践-OceanBase。 | `路由` `ODP 路由最佳实践-OceanBase` | [进入目录](./路由/index.md) |
| **数据表设计** | 涵盖 大表创建索引的最佳实践-OceanBase、数据库开发规范最佳实践-OceanBase、OceanBase 数据表设计与索引优化最佳实践指南-OceanBase。 | `数据表设计` `大表创建索引的最佳实践-OceanBase` `数据库开发规范最佳实践-OceanBase` | [进入目录](./数据表设计/index.md) |
| **数据迁移和导入** | 涵盖 OMS 海量数据迁移策略-OceanBase、数据迁移概览-OceanBase、OceanBase 数据流转方案-OceanBase、数据文件导入 OceanBase 最佳实践-OceanBase 等 7 项。 | `数据迁移和导入` `OMS 海量数据迁移策略-OceanBase` `数据迁移概览-OceanBase` | [进入目录](./数据迁移和导入/index.md) |
| **性能调优** | 涵盖 解决慢查询的最佳实践-OceanBase、收集统计信息生成高效执行计划的最佳实践-OceanBase、热点行更新的最佳实践-OceanBase、大对象存储性能最佳实践-OceanBase 等 6 项。 | `性能调优` `解决慢查询的最佳实践-OceanBase` `热点行更新的最佳实践-OceanBase` `大对象存储性能最佳实践-OceanBase` | [进入目录](./性能调优/index.md) |
| **云** | 涵盖 跨云双活实现高可用最佳实践-OceanBase、主机 CPU 使用率过高-OceanBase、OB Cloud 云数据库读写分离最佳实践-OceanBase、通过跨云主备库实现的高可用-OceanBase。 | `云` `主机 CPU 使用率过高-OceanBase` | [进入目录](./云/index.md) |
| **运维管理** | 涵盖 数据加密最佳实践-OceanBase、安全认证最佳实践-OceanBase、资源限流最佳实践-OceanBase、访问控制最佳实践-OceanBase 等 5 项。 | `运维管理` `数据加密最佳实践-OceanBase` `安全认证最佳实践-OceanBase` `资源限流最佳实践-OceanBase` | [进入目录](./运维管理/index.md) |
| **诊断** | 涵盖 使用 obdiag 收集火焰图和扁鹊图最佳实践-OceanBase、使用 obdiag 一键收集并行 SQL_慢 SQL 诊断信息最佳实践-OceanBase、OceanBase 系统性能问题排查最佳实践-OceanBase、常见问题场景日志解读最佳实践-OceanBase 等 5 项。 | `诊断` `全链路追踪最佳实践-OceanBase` | [进入目录](./诊断/index.md) |
