# 叶子索引：数据表设计

> 位置：> 位置：[ob_wiki](../../../index.md) / [OceanBase 最佳实践](../../index.md) / [数据表设计](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [大表创建索引的最佳实践-OceanBase.md](./大表创建索引的最佳实践-OceanBase.md) | 本文提供关于大表创建索引的最佳实践的相关内容 | 大表创建索引的,数据表设计,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
| [数据库开发规范最佳实践-OceanBase.md](./数据库开发规范最佳实践-OceanBase.md) | 本文提供关于数据库开发规范最佳实践的相关内容,OB Cloud 云数据库 | 数据库开发规范,数据表设计,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
| [OceanBase 数据表设计与索引优化最佳实践指南-OceanBase.md](./OceanBase 数据表设计与索引优化最佳实践指南-OceanBase.md) | 本文提供关于OceanBase 数据表设计与索引优化最佳实践指南的相关内容,OB Cloud 云数据库 | OceanBase 数据表设计与索引优化最佳实践指南,数据表设计,OceanBase 最佳实践,配置,文档,使用帮助,OceanBase,分布式,数据库 |
