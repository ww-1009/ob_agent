---
title: （可选）部署 OBProxy
description: 提供关于（可选）部署 OBProxy的相关内容，
keywords: （可选）部署 OBProxy,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,使用命令行部署,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# （可选）部署 OBProxy

OceanBase 数据库代理（OceanBase Database Proxy，简称：ODP，又称 OBProxy）是OceanBase 提供的一种数据库代理中间件，它可以用于连接池管理、负载均衡、故障转移等功能。OBProxy 是一个可选的组件，它的部署与否取决于您的应用需求和场景。

本节主要介绍通过使用 RPM 包安装 OBProxy。

#### 注意

* OBProxy 在任何一个机器上部署后，通过向外暴露一个 `ip:port` 来提供 OceanBase 的代理服务。用户可以像访问 MySQL 数据库一样通过该 `ip:port` 即可访问 OceanBase 数据库，一般推荐部署在 OBServer 节点上。
* 建议一台机器上只部署一个 OBProxy 服务，并且使用约定的 `2883` 端口。当同一台机器上部署多个 OBProxy 服务时，需要指定不同端口和不同的配置文件路径予以区分，端口可以自定义为 `3306` 或 `1521`、或者其他端口。

## 操作步骤

### 步骤一：安装 OBProxy RPM 包

其中 `$rpm_dir` 表示存放 RPM 包的目录，`$rpm_name` 表示 RPM 包的名称。

```
[root@xxx /]# cd $rpm_dir
[root@xxx $rpm_dir]# rpm -ivh $rpm_name
```

#### 说明

OBProxy 软件会默认安装在目录 `/opt/taobao/install` 下。如果需要指定其他目录，可以通过设置 `--prefix` 参数来指定，例如安装在 `/home/admin` 目录下：`rpm -ivh --prefix=/home/admin $rpm_name`。

示例如下：

```
[root@xxx admin]# rpm -ivh obproxy-4.0.0-20230109154442.el7.x86_64.rpm
Preparing...                          ################################# [100%]
Updating / installing...
   1:obproxy-4.0.0-20230109154442.el7 ################################# [100%]
```

### 步骤二：配置目录

1. （可选）创建到 obproxy 的软链接。

   #### 说明

   创建到 obproxy 的软链接可以隐藏掉版本信息，方便后期操作。

   obproxy 安装目录在 `/opt/taobao/install` 下。obproxy 进程 home 目录是 `/opt/taobao/install/obproxy`，这是一个软链接，实际指向相应的 obproxy 版本软件目录。

   ```
   [root@xxx admin]# su - admin
   -bash-4.2$ cd /opt/taobao/install
   -bash-4.2$ ls
   ajdk-8.3.6-b129  obproxy-4.0.0
   #创建到 obproxy 的软链接
   -bash-4.2$ sudo ln -s obproxy-4.0.0 obproxy
   [sudo] password for admin:
   -bash-4.2$ ll
   total 8
   drwxr-xr-x 9 root  root  4096 Sep 26 15:24 ajdk-8.3.6-b129
   lrwxrwxrwx 1 root  root    13 Jan 29 16:51 obproxy -> obproxy-4.0.0
   drwxr-xr-x 5 admin admin 4096 Jan 29 16:42 obproxy-4.0.0

   --把 obproxy 的所有者和所属组都改为 admin。
   [root@xxx install]# chown -R admin:admin obproxy
   [root@xxx install]# ll
   total 8
   drwxr-xr-x 9 root  root  4096 Sep 26 15:24 ajdk-8.3.6-b129
   lrwxrwxrwx 1 admin admin   13 Jan 29 16:51 obproxy -> obproxy-4.0.0
   drwxr-xr-x 5 admin admin 4096 Jan 29 16:42 obproxy-4.0.0
   ```
2. 建立 obproxy 进程运行日志目录。

   obproxy 进程的运行日志目录通过软链接指向 `/home/admin/logs/obproxy/log`。

   ```
   [root@xxx admin]# su - admin
   #创建日志目录
   -bash-4.2$ mkdir -p /home/admin/logs/obproxy/log
   #查看 obproxy 进程目录情况
   -bash-4.2$ tree /opt/taobao/install/obproxy
   /opt/taobao/install/obproxy
   |-- bin
   |   |-- obp_xflush.py
   |   |-- obproxy
   |   |-- obproxyd.sh
   |   `-- unzip.py
   |-- lib
   |   |-- libgpr.so.7
   |   |-- libgrpc++.so.1
   |   |-- libgrpc++_cronet.so.1
   |   |-- libgrpc.so.7
   |   |-- libgrpc_cronet.so.7
   |   |-- libobproxy_so.so
   |   |-- libprotobuf.so.18
   |   `-- libstdc++.so.6
   |-- log -> /home/admin/logs/obproxy/log
   |-- minidump -> /home/admin/logs/obproxy/minidump
   |-- start_obproxy.sh
   `-- tools
      |-- dump_syms
      |-- log4cplus.conf
      |-- minidump.sh
      |-- minidump_stackwalk
      `-- obproxy.sym

   3 directories, 20 files
   ```

### 步骤三：初始化 OBProxy 账户

OBProxy 需要跟后端 OBServer 节点保持通信。所以需要提前在 OceanBase 集群的 sys 租户下为 OBProxy 创建连接用户（proxyro）和密码。后续在启动 OBProxy 时可通过设置 proxy 启动参数的方式来告知 proxy。

#### 说明

proxyro 用户是 OBProxy 访问 OceanBase 集群的用户。一个 OceanBase 集群对应一个 proxyro 账号。

示例如下：

创建 proxyro 用户并授予 `SELECT` 权限。

```
$obclient -hxxx.xxx.xxx.1 -P2881 -uroot@sys -p******

obclient [(none)]> CREATE USER proxyro IDENTIFIED BY '******';
Query OK, 0 rows affected

obclient [(none)]> GRANT SELECT ON *.* TO proxyro;
Query OK, 0 rows affected

obclient [(none)]> SHOW GRANTS FOR proxyro;
+----------------------------------+
| Grants for proxyro@%             |
+----------------------------------+
| GRANT SELECT ON *.* TO 'proxyro' |
+----------------------------------+
1 row in set
```

### 步骤四：启动 OBProxy

#### 注意

启动 OBProxy 时，请在 admin 用户下并在 OBProxy 软件的 home 目录。其他用户或者其他目录下启动都可能带来问题。

1. OBProxy 启动时需要知道 OceanBase 集群在哪里，这是通过参数 rootservice\_list 指定。

   启动代码如下：

   ```
   cd /opt/taobao/install/obproxy && bin/obproxy -r "xxx.xxx.xxx.1:2881;xxx.xxx.xxx.2:2881;xxx.xxx.xxx.3:2881" -p 2883 -o "observer_sys_password=$sha1_value,enable_strict_kernel_release=false,enable_cluster_checkout=false,enable_metadb_used=false" -c cluster_name
   ```

   #### 说明

   * `$sha1_value` 应根据实际设置密码替换。设置 proxy 启动参数方式，设置的密码是 sha1 后的值，而不是原始值。例如：proxyro 用户设置的密码是 `123456`，则需要设置 `observer_sys_password` 的值是 `7c4a8d09ca3762af61e59520943dc26494f8941b`。
   * 示例 IP 做了脱敏处理，这不是安装需求。在启动时应根据自己机器真实 IP 填写。

   参数解释：

   | **参数** | **说明** |
   | --- | --- |
   | `-r` | 指定 OBServer 节点 IP 和端口。 |
   | `-p` | 指定服务端口号，一般指定为 `2883`。 |
   | `-c` | 指定集群名称。 |
   | `-o` | 指定硬件或者内核参数配置。 |

   示例如下：

   ```
   [root@xxx admin]# su - admin
   -bash-4.2$ cd /opt/taobao/install/obproxy && bin/obproxy -r "xxx.xxx.xxx.1:2881" -p 2883 -o "observer_sys_password=7c4a8d09ca3762af61e59520943dc26494f8941b,enable_strict_kernel_release=false,enable_cluster_checkout=false,enable_metadb_used=false" -c test3241
   bin/obproxy -r xxx.xxx.xxx.1:2881 -p 2883 -o observer_sys_password=7c4a8d09ca3762af61e59520943dc26494f8941b,enable_strict_kernel_release=false,enable_cluster_checkout=false,enable_metadb_used=false -c test3241
   rs list: xxx.xxx.xxx.1:2881
   listen port: 2883
   optstr: observer_sys_password=7c4a8d09ca3762af61e59520943dc26494f8941b,enable_strict_kernel_release=false,enable_cluster_checkout=false,enable_metadb_used=false
   cluster_name: test3241
   ```
2. 启动之后，可以检查进程是否存在。

   ```
   ps -ef|grep obproxy
   ```

   示例如下：

   ```
   [root@xxx admin]# ps -ef|grep obproxy
   admin     79111      0  6 17:32 ?        00:00:58 bin/obproxy -r xxx.xxx.xxx.1:2881 -p 2883 -o observer_sys_password=7c4a8d09ca3762af61e59520943dc26494f8941b,enable_strict_kernel_release=false,enable_cluster_checkout=false,enable_metadb_used=false -c test3241
   ```

## 后续操作

### 连接 OceanBase 数据库

通过 OBProxy 连接时，用户名的格式需要包含用户名、租户名和集群名。格式为： **用户名@租户名#集群名** 或 **集群名:租户名:用户名**。

示例如下：

* **用户名@租户名#集群名** 连接 OceanBase 数据库。

  ```
  [admin@xxx /home/admin]
  $obclient -hxxx.xxx.xxx.1 -P2883 -uroot@sys#test3241 -p******
  Welcome to the OceanBase.  Commands end with ; or \g.
  ...
  Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

  obclient [(none)]>
  ```
* **集群名:租户名:用户名** 连接 OceanBase 数据库。

  ```
  [admin@xxx /home/admin]
  $obclient -hxxx.xxx.xxx.1 -P2883 -utest3241:sys:root -p******
  Welcome to the OceanBase.  Commands end with ; or \g.
  ......
  Copyright (c) 2000, 2018, OceanBase and/or its affiliates. All rights reserved.

  Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

  obclient [(none)]>
  ```

### （可选）调整 OBProxy 参数

可以根据自己服务器的实际情况，通过调整 OBProxy 参数的数值来设置运行日志量或 CPU 消耗等信息。

示例如下：

下面是 OBProxy 的一些参数配置用于减少运行日志量或降低 CPU 消耗。

```
obclient [(none)]> ALTER PROXYCONFIG SET slow_proxy_process_time_threshold='1000ms';
Query OK, 0 rows affected

obclient [(none)]> ALTER PROXYCONFIG SET xflush_log_level=ERROR;
Query OK, 0 rows affected

obclient [(none)]> ALTER PROXYCONFIG SET syslog_level=WARN;
Query OK, 0 rows affected

obclient [(none)]> ALTER PROXYCONFIG SET enable_compression_protocol=false;
Query OK, 0 rows affected

obclient [(none)]> SHOW PROXYCONFIG LIKE '%compress%'\G
*************************** 1. row ***************************
         name: enable_compression_protocol
        value: False
         info: if enabled, proxy will use compression protocol with server
  need_reboot: false
visible_level: USER
*************************** 2. row ***************************
         name: enable_syslog_file_compress
        value: False
         info: Whether to enable archive log compression
  need_reboot: false
visible_level: SYS
2 rows in set
```

## 相关文档

* 有关 OBProxy 部署的详细信息，请参见 [部署方式](https://www.oceanbase.com/docs/enterprise-odp-enterprise-cn-10000000000982790)。
* 有关调整 OBProxy 参数的详细信息，请参见 [配置参数说明](https://www.oceanbase.com/docs/enterprise-odp-enterprise-cn-10000000000982784)。
* 更多通过 OBProxy 连接 OceanBase 数据库的详细信息，请参见 [连接管理](https://www.oceanbase.com/docs/enterprise-odp-enterprise-cn-10000000000982772)。