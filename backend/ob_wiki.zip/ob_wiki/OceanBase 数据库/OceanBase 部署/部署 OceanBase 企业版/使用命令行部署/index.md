# 分类索引：使用命令行部署

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [OceanBase 部署](../../index.md) / [部署 OceanBase 企业版](../index.md) / 使用命令行部署 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **使用命令行部署 OceanBase 集群** | 涵盖 使用命令行部署三副本 OceanBase 集群、使用命令行部署两副本加仲裁服务的 OceanBase 集群、使用命令行部署单副本 OceanBase 集群。 | `使用命令行部署 OceanBase 集群` | [进入目录](./使用命令行部署 OceanBase 集群/index.md) |
| **通过 oatcli 配置部署环境** | 涵盖 使用 oatcli 初始化 OBServer 服务器、（可选）配置时钟源。 | `通过 oatcli 配置部署环境` `（可选）配置时钟源` | [进入目录](./通过 oatcli 配置部署环境/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [（可选）部署 OBProxy.md](./（可选）部署 OBProxy.md) | 提供关于（可选）部署 OBProxy的相关内容， | （可选）部署 OBProxy,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,使用命令行部署,文档,使用帮助,OceanBase,分布式,数据库 |
