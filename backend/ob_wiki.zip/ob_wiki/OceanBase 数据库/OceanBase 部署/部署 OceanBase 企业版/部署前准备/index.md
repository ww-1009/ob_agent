# 叶子索引：部署前准备

> 位置：> 位置：[ob_wiki](../../../../../index.md) / [OceanBase 数据库](../../../../index.md) / [OceanBase 部署](../../../index.md) / [部署 OceanBase 企业版](../../index.md) / [部署前准备](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [服务器配置.md](./服务器配置.md) | 提供关于服务器配置的相关内容， | 服务器配置,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [准备安装包.md](./准备安装包.md) | 提供关于准备安装包的相关内容， | 准备安装包,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [服务器配置.md](./服务器配置.md) | 提供关于服务器配置的相关内容， | 服务器配置,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [准备安装包.md](./准备安装包.md) | 提供关于准备安装包的相关内容， | 准备安装包,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [部署 OAT.md](./部署 OAT.md) | 提供关于部署 OAT的相关内容， | 部署 OAT,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [准备服务器.md](./准备服务器.md) | 提供关于准备服务器的相关内容， | 准备服务器,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [部署 OAT.md](./部署 OAT.md) | 提供关于部署 OAT的相关内容， | 部署 OAT,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
| [准备服务器.md](./准备服务器.md) | 提供关于准备服务器的相关内容， | 准备服务器,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库 |
