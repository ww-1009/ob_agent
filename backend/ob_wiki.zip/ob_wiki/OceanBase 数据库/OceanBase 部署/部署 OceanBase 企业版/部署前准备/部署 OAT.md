---
title: 部署 OAT
description: 提供关于部署 OAT的相关内容，
keywords: 部署 OAT,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,部署前准备,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 部署 OAT

本节主要介绍使用 Docker 部署 OAT。

## 前提条件

* 安装 OAT 服务器的操作系统满足要求。详细信息，请参见 [服务器配置](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500188)。
* 您已经安装并启动 Docker。推荐 Docker 版本为社区版 17.03 及以上。

  #### 注意

  如果您使用 oat-all-in-one 安装包部署 OAT，oat-all-in-one 的 `install.sh` 脚本将自动安装 Docker，您无需再单独安装 Docker。
* OAT 的默认端口 `7000` 未被占用。
* 您拥有服务器的 `root` 用户权限。

## 操作步骤

### 方案一：使用 oat-all-in-one 安装包部署 OAT

#### 注意

在使用 oat-all-in-one 安装包部署之前，建议在终端中输入 `setenforce 0` 命令关闭 SELinux（Security-Enhanced Linux）。

1. 通过 `scp` 命令将 oat-all-in-one 安装包上传到服务器中。

   其中 `oat_server_ip` 为部署 OAT 的服务器的 IP 地址，`oat_directory` 为部署存放安装包的目录，`oat_xxx.tar` 为安装包的名称。

   ```
   scp <oat_directory/oat-all-in-one-xxx.tar> <oat_server_user>@<oat_server_ip>:oat_directory
   ```

   示例如下：

   ```
   [root@xxx /home/admin/rpm]# scp oat-all-in-one-x86-411.tar admin@xxx.xxx.xxx.xxx:/home/admin/rpm
   admin@xxx.xxx.xxx.xxx's password:
   oat-all-in-one-x86-411.tar                                                                              100% 1649MB 401.9MB/s   00:04
   ```
2. 解压 oat-all-in-one 安装包。

   示例如下：

   ```
   [root@xxx /home/admin/rpm]# tar -xf oat-all-in-one-x86-411.tar
   ```
3. 运行安装脚本 `install.sh`。

   运行解压目录 `oat-all-in-one-x86` 中的安装脚本 `install.sh`。

   ```
   sh oat-all-in-one-x86/install.sh
   ```

   如果您的环境没有 Docker，运行此命令将自动安装 Docker，部署 OAT 并扫描已有的镜像和工具软件包。

   根据提示，依次确认以下信息：

   1. 请指定 Docker 的根目录，默认值 `/docker`，可自定义。如果已安装 Docker，会跳过此步骤。
   2. 请指定 OAT 数据目录的路径，默认值 `/oat_data`，可自定义。
   3. 请指定 OAT HTTP 监听端口，默认值 `7000`，可自定义。
   4. 请指定 OAT 数据库端口，默认值 `3306`，可自定义。
   5. 请输入 OAT 管理员账户密码（设置初始登录密码），可自定义。
   6. 根据返回的 URL 访问 OAT，验证 OAT 服务的可用性。

   示例如下：

   ```
   [root@xxx /home/admin/rpm]# sh oat-all-in-one-x86/install.sh
   ```

   根据提示信息，完成以下配置：

   1. Docker 的根目录使用默认值，直接回车。

      ```
      Before installation, please set the config below:
      Input the docker root dir: /docker
      ```
   2. OAT 数据目录的路径，修改为 `/home/admin/oat_data`，然后回车。

      ```
      Input the OAT data dir: /home/admin/oat_data
      ```
   3. OAT HTTP 监听端口使用默认值，直接回车。

      ```
      Input the OAT HTTP listen port: 7000
      ```
   4. OAT 数据库端口使用默认值，直接回车。

      ```
      Input the OAT database port: 3306
      ```
   5. 设置 OAT 管理员账户密码（初始登录密码），然后回车。

      ```
      Input the OAT admin user password(login password): ******
      ```
   6. 根据返回的 URL 访问 OAT，验证 OAT 服务的可用性。

      返回结果如下：

      ```
      Start prepare docker
      Docker is already exists, start check...
      Already installed docker check healthy, skip install docker
      Created symlink from /etc/systemd/system/multi-user.target.wants/docker.service to /usr/lib/systemd/system/docker.service.
      Start prepare OAT
      Loaded image: reg.docker.alibaba-inc.com/oceanbase/oat:4.1.1_20230512_x86
      f4f5dbe127f62f9ec016dabfc6b1b272da2dd7794c255aed9e335cb83192ad2b
      check OAT url http://127.0.0.1:7000/hc
      curl: (7) Failed connect to 127.0.0.1:7000; Connection refused
      OAT API not ready, please wait, sleep 5s retry...
      curl: (7) Failed connect to 127.0.0.1:7000; Connection refused
      OAT API not ready, please wait, sleep 5s retry...
      curl: (7) Failed connect to 127.0.0.1:7000; Connection refused
      OAT API not ready, please wait, sleep 5s retry...
      curl: (7) Failed connect to 127.0.0.1:7000; Connection refused
      OAT API not ready, please wait, sleep 5s retry...
      OAT API ready
      Copy images and binary_packages to OAT data dir
      Trigger OAT scan api to find images and binary_packages
      Trigger scan task success, please visit OAT web site and wait for scan task finished
      OAT is ready for visit
      url is: http://xxx.xxx.xxx.xxx:7000
      user/password is: ******
      ```

#### 说明

* `install.sh` 脚本启动 OAT 容器默认使用 `--net host`（主机网络模式）。如您需要配置为其他网络模式，请下载 OAT 容器手动启动。
* x86（aarch64）版本的 oat-all-in-one 默认只包含 x86（aarch64）和 noarch 的镜像和软件包，如需 aarch64（x86）架构，请自行下载拷贝到 OAT 容器挂载的对应目录，然后发起扫描任务进行添加。

### 方案二：使用 OAT docker image 独立部署 OAT

1. 通过 `scp` 命令将 OAT 安装包上传到服务器中。

   其中 `oat_server_ip` 为部署 OAT 的服务器的 IP 地址，`oat_directory` 为部署存放安装包的目录，`oat_xxx.tar` 为安装包的名称。

   ```
   scp <oat_directory/oat_xxx.tar> <oat_server_user>@<oat_server_ip>:oat_directory
   ```

   示例如下：

   ```
   [root@xxx /home/admin/rpm]# scp oat_4.1.0_20230331_x86.tgz admin@xxx.xxx.xxx.xxx:/home/admin/rpm
   admin@xxx.xxx.xxx.xxx's password:
   oat_4.1.0_20230331_x86.tgz                               100%  438MB   4.3MB/s   01:41
   ```
2. 挂载 OAT 目录。

   在服务器创建 `/data_dir` 目录用来保存 OAT 的持久化数据。在 `/data_dir` 目录被挂载到 OAT 容器后，OAT 会自动创建 `/data_dir/logs`、`/data_dir/images` 和 `/data_dir/db` 目录，分别用于存放 OAT 的系统日志、组件和产品的 Docker 镜像以及 OAT 的数据库文件。示例如下：

   ```
   [root@xxx /]# mkdir -p /data_dir
   ```
3. 将 OAT 安装包装载为镜像。

   进入到存放 OAT 安装包的目录，执行以下语句：

   ```
   [root@xxx /]# cd oat_directory

   [root@xxx /oat_directory]# docker load -i oat_xxx.tar
   ```

   示例如下：

   ```
   [root@xxx /]# cd /home/admin/rpm

   [root@xxx /home/admin/rpm]# docker load -i oat_4.1.0_20230331_x86.tgz
   06f6bfff6616: Loading layer [==================================================>]  230.8MB/230.8MB
   e1505344677e: Loading layer [==================================================>]  3.072kB/3.072kB
   01ede0eada53: Loading layer [==================================================>]  690.2MB/690.2MB
   78073091fd9e: Loading layer [==================================================>]  8.704kB/8.704kB
   5d96997aeb89: Loading layer [==================================================>]  232.8MB/232.8MB
   17fa9a0a477e: Loading layer [==================================================>]  156.1MB/156.1MB
   Loaded image: reg.docker.alibaba-inc.com/oceanbase/oat:4.1.0_20230331_x86
   ```
4. 用 `docker images` 命令获取 OAT 镜像的标签。

   #### 说明

   以下命令仅适用于本地只加载了一个 OAT 安装包的情况。对于装载多个安装包的情况，可以通过 `docker images` 查看显示内容，并使用冒号（:）连接前两列的内容。

   ```
   oat_image=`docker images | grep oat | awk '{printf $1":"$2"\n"}'`
   ```

   示例如下：

   ```
   [root@xxx /home/admin/rpm]# oat_image=`docker images | grep oat | awk '{printf $1":"$2"\n"}'`
   ```
5. 运行 `docker run` 命令，启动 OAT。

   其中 `$oat_image` 是 OAT 镜像的标签。

   ```
   docker run -d --net host --name oat -v /data_dir:/data --restart on-failure:5 $oat_image
   ```

   #### 说明

   * OAT 的 HTTP 服务默认监听 `7000` 端口，可以指定 `-e HTTP_PORT=7001` 参数修改为其他端口。
   * 可以指定 `-e OAT_INITIAL_ADMIN_PASSWORD=xxx` 参数修改 OAT 的密码。
   * OAT 内置了 MariaDB 作为数据存储，默认监听 `3306` 端口，可以指定 `-e DB_PORT=3307` 参数修改为其他端口。
   * 建议使用 `--net host` 参数启动，因为 bridge 网络模式启动的容器可能被 `docker0` 网桥故障或操作系统参数 `ip_forward` 影响。

   示例如下：

   ```
   [root@xxx /home/admin/rpm]# docker run -d --net host --name oat -v /data_dir:/data --restart on-failure:5 `docker images | grep oat | awk '{printf $1":"$2"\n"}'`
   79978776c4d478d36b0b61d6ccfb186d39dbd2d29695a27937d0fc654b58ffb9
   ```

## 后续操作

OAT 部署成功后，您需要登录 OAT 来确认部署是否成功。

1. 在浏览器中输入 OAT 的访问地址，按回车键。

   OAT 的访问地址：`http://oat_server_ip:7000`。

   其中 `oat_server_ip` 为部署 OAT 的服务器的 IP 地址。
2. 如果在浏览器窗口中看到登录界面，表示已经成功安装并启动 OAT。

   在显示的登录页面，使用 `admin` 账号登录系统。

   #### 注意

   请联系 OceanBase 售后支持获取 OAT 默认用户名 admin 账号的默认密码。为保证账号安全，首次登录后请及时修改密码。

   ![1](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.1.0/4.deploy/3.deploy-oceanbase-database-enterprise/1%E7%99%BB%E5%BD%95%E9%A1%B5%E9%9D%A2.png)
3. 设置密码激活账号。

   使用 `admin` 账号的默认密码登录，然后设置密码激活账号。

   ![2](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.1.0/4.deploy/3.deploy-oceanbase-database-enterprise/0%E5%AF%86%E7%A0%81%E6%BF%80%E6%B4%BB-%E4%B8%AD%E6%96%87.png)

## 相关文档

更多安装 OAT 的信息，请参见 [安装 OAT](https://www.oceanbase.com/docs/enterprise-oat-doc-cn-1000000000304881)。