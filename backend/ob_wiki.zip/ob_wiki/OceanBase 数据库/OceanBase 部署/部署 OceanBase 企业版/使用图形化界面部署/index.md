# 分类索引：使用图形化界面部署

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [OceanBase 部署](../../index.md) / [部署 OceanBase 企业版](../index.md) / 使用图形化界面部署 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **部署 OCP** | 先概述 部署 OCP，再分项介绍 上传安装包、创建 MetaDB、OCP 部署说明。 | `部署 OCP` `上传安装包` `创建 MetaDB` `OCP 部署说明` | [进入目录](./部署 OCP/index.md) |
| **使用 OCP 部署 OceanBase 集群** | 涵盖 使用 OCP 部署单副本 OceanBase 集群、使用 OCP 部署三副本 OceanBase 集群、使用 OCP 部署两副本加仲裁服务的 OceanBase 集群。 | `使用 OCP 部署 OceanBase 集群` | [进入目录](./使用 OCP 部署 OceanBase 集群/index.md) |
| **通过 OAT 配置部署环境** | 涵盖 添加服务器。 | `通过 OAT 配置部署环境` `添加服务器` | [进入目录](./通过 OAT 配置部署环境/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [（可选）部署 OBProxy.md](./（可选）部署 OBProxy.md) | 提供关于（可选）部署 OBProxy的相关内容， | （可选）部署 OBProxy,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,使用图形化界面部署,文档,使用帮助,OceanBase,分布式,数据库 |
