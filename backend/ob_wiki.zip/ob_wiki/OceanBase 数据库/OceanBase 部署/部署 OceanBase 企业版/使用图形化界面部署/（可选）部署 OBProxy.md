---
title: （可选）部署 OBProxy
description: 提供关于（可选）部署 OBProxy的相关内容，
keywords: （可选）部署 OBProxy,OceanBase 数据库,OceanBase 部署,部署 OceanBase 企业版,使用图形化界面部署,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# （可选）部署 OBProxy

OceanBase 数据库代理（OceanBase Database Proxy，简称：ODP，又称 OBProxy）是OceanBase 提供的一种数据库代理中间件，它可以用于连接池管理、负载均衡、故障转移等功能。OBProxy 是一个可选的组件，它的部署与否取决于您的应用需求和场景。

本节主要介绍使用 OCP 创建 OBProxy 集群。

#### 说明

* 本节以 OCP V4.2.1 版本为例提供操作指导。不同 OCP 版本的操作界面可能不同，请以实际界面为准。
* OBProxy 在任何一个机器上部署后，通过向外暴露一个 ip:port 来提供 OceanBase 的代理服务。用户可以像访问 MySQL 数据库一样通过该 ip:port 即可访问 OceanBase 数据库，一般推荐部署在 OBServer 节点上。
* 建议一台机器上只部署一个 OBProxy 服务，并且使用约定的 `2883` 端口。当同一台机器上部署多个 OBProxy 服务时，需要指定不同端口予以区分。

## 前提条件

* 您已部署 OCP。详细信息，请参见 [部署 OCP](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502645)。
* 当前登录的用户是 `OBPROXY_MANAGER` 角色，或有管理 OBProxy 的权限。详细信息，请参见 [角色概述](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000001541995) 和 [OCP 默认角色](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000001541990)。
* 已获取 OBProxy RPM 包。详细信息，请参见 [准备安装包](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500190)。

## 操作步骤

1. 登录 OCP。
2. 在左侧导航栏单击 **OBProxy**，进入 **OBProxy** 页面。
3. 在 **OBProxy** 页面，单击右上方的 **创建 OBProxy 集群**。
4. 在 **创建 OBProxy 集群** 页面，配置 **基本设置**。

   | 参数 | 描述 |
   | --- | --- |
   | **集群名** | 您可根据实际业务情况，自定义集群名称，以英文字母开头，可包含英文、数字和下划线。 |
   | **录入 Proxyro 账号的密码** | Proxyro 账号用于 OBProxy 访问 OceanBase 集群，未录入则使用 Proxyro 账号的默认密码进行连接。密码格式要求如下： * 长度为 8 ~ 32 个字符。 * 只能包含字母、数字和特殊字符 `` ~!@#%^&*_-+=`|(){}[]:;',.?/ ``。 * 大小写字母、数字和特殊字符都至少包含 2 个。 |
   | **软件版本** | 选择要安装的 OBProxy 版本。 说明   * 仅可选择 V1.8.0 及以上版本的 OBProxy 软件包。 * 若可连接的 OceanBase 集群中存在 V4.0.0 及以上版本的集群时，仅支持选择 V4.0.0 及以上版本的 OBProxy 软件包。 |
   | **负载均衡管理** | 默认关闭状态。  * 负载均衡管理关闭状态需配置以下信息：   + 访问地址：OBProxy 集群访问地址，仅用于生成租户的连接串，不影响实际使用。如果是 VIP 地址，需要自己申请并绑定到 OBProxy Server。   + 访问端口：默认为 2883，支持自定义端口号。 * 负载均衡管理开启状态需配置以下信息：   + 负载均衡器：默认为 OBLB。阿里云 SLB 服务仅适用于专有云环境，建议联系技术支持同学进行协助。   + OBLB 服务：您可选择部署 OCP 时已配置的 OBLB 服务，或单击 **添加 OBLB 服务** 按钮，在右侧面板中新建 OBLB 服务。   + VIP：选择 OBLB 具体的 VIP 地址。   + 访问端口：默认为 2883，支持自定义端口号。   + 域名配置（可选）：用于指向 VIP 及端口的配置信息，平台未提供 VIP 与域名的映射关系，需自行准备域名解析服务。 |
   | **启动方式** | 该 OBProxy 集群的启动方式，可取值： * ConfigUrl：多集群启动方式，即该 OBProxy 集群可访问多个 OceanBase 集群。 * RsList：单集群启动方式，即该 OBProxy 集群仅可访问创建 OBProxy 集群时指定的那个 OceanBase 集群，OBProxy 集群创建成功后不可追加可连接的 OceanBase 集群。 |

   ![1](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.2/400.deploy/OCP422/7%E5%88%9B%E5%BB%BAODP-1%E5%9F%BA%E6%9C%AC%E8%AE%BE%E7%BD%AE.png)
5. （可选）在 **创建 OBProxy 集群** 页面，配置 **部署 OBProxy**。

   如需在创建 OBProxy 集群时就部署 OBProxy，可在该步骤就行配置。否则可跳过该步骤，待集群创建成功后，通过 **接管 OBProxy** 或 **添加 OBProxy** 向集群中添加 OBProxy。

   打开配置 **部署 OBProxy** 的开关。参考下表填写部署信息。

   | **参数** | **描述** |
   | --- | --- |
   | **机房** | OBProxy 所在的机房，一个 OBProxy 只能存在于一个机房。 |
   | **机型（可选）** | 可选项。如果选择了机型，后面主机列表会根据机型进行过滤。 |
   | **选择 OBProxy 主机** | 选择部署 OBProxy 所使用的主机。  系统默认显示两个主机的选择，仅够部署两个 OBProxy，如需部署更多，可单击 **添加 OBProxy** 来增加主机。如只部署 1 个 OBProxy，可单击如上图所示的主机后的删除图标来删除该主机。 |

   ![2](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.2/400.deploy/OCP422/7%E5%88%9B%E5%BB%BAODP-2%E9%83%A8%E7%BD%B2OBProxy.png)
6. （可选）在 **创建 OBProxy 集群** 页面，配置 **参数设置**。

   打开 **参数设置**，添加或修改启动参数和其它参数。

   ![3](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.2/400.deploy/OCP422/7%E5%88%9B%E5%BB%BAODP-3%E5%8F%82%E6%95%B0%E8%AE%BE%E7%BD%AE.png)
7. 打开 **自定义配置**，对集群端口、操作系统所属主用户及路径进行配置。

   | **参数** | **描述** |
   | --- | --- |
   | **SQL 端口** | 默认为 2883，支持自定义端口。 |
   | **Exporter 端口** | 默认为 2884，支持自定义端口。 |
   | **操作系统所属主用户** | 用于配置安装、运行 OBServer 的操作系统用户，不支持编辑，可通过系统参数 `ocp.operation.default.os.user` 调整默认配置，操作详情可参考 [修改系统参数](https://www.oceanbase.com/docs/common-ocp-1000000000348346)。 |
   | **软件安装路径** | * 当 **操作系统所属主用户** 为 admin 时，**软件安装路径** 默认为 `/home/admin/obproxy`，支持自定义路径。 * 当 **操作系统所属主用户** 为非 admin 时，**软件安装路径** 默认为 `/opt/oceanbase/obproxy`，支持自定义路径。配置完成后，单击 **测试**，校验路径是否可用。若不可用，您可根据测试结果进行排查，或将路径修改为其它可用路径。 |

   #### 说明

   当您对 `ocp.operation.default.os.user` 参数进行修改后，该参数的修改仅对创建分布式集群、创建 OBProxy 集群 和创建仲裁服务产生影响，不影响已有集群的其他配置。

   ![4](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.2/400.deploy/OCP422/7%E5%88%9B%E5%BB%BAODP-4%E8%87%AA%E5%AE%9A%E4%B9%89%E8%AE%BE%E7%BD%AE.png)
8. 完成配置后，单击右下角 **提交**。

## 相关文档

更多有关使用 OCP 创建 OBProxy 集群的信息，请参见 [创建 OBProxy 集群](https://www.oceanbase.com/docs/common-ocp-1000000000347962)。