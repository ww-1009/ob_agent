# 分类索引：部署 OceanBase 社区版

> 位置：[ob_wiki](../../../index.md) / [OceanBase 数据库](../../index.md) / [OceanBase 部署](../index.md) / 部署 OceanBase 社区版 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **本地部署** | 下设 部署前配置、通过图形化界面部署，共 2 个子分类。 | `本地部署` `部署前配置` `通过图形化界面部署` | [进入目录](./本地部署/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OceanBase 数据库社区版部署概述.md](./OceanBase 数据库社区版部署概述.md) | 提供关于OceanBase 数据库社区版部署概述的相关内容， | OceanBase 数据库社区版部署概述,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,文档,使用帮助,OceanBase,分布式,数据库 |
| [在 Kubernetes 环境中部署 OceanBase 集群.md](./在 Kubernetes 环境中部署 OceanBase 集群.md) | 提供关于在 Kubernetes 环境中部署 OceanBase 集群的相关内容， | 在 Kubernetes 环境中部署 OceanBase 集群,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,文档,使用帮助,OceanBase,分布式,数据库 |
