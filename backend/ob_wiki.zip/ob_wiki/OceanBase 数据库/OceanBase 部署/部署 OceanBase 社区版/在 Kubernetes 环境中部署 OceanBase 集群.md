---
title: 在 Kubernetes 环境中部署 OceanBase 集群
description: 提供关于在 Kubernetes 环境中部署 OceanBase 集群的相关内容，
keywords: 在 Kubernetes 环境中部署 OceanBase 集群,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 在 Kubernetes 环境中部署 OceanBase 集群

本文介绍如何在 Kubernetes 环境中部署 OceanBase 集群，可以作为生产环境部署的参考。如需要了解更多自定义部署和配置方法，请参考 [OceanBase K8s 运维工具文档](https://www.oceanbase.com/docs/ob-operator-doc)。

## 前提条件

在开始部署之前，请确保您的环境满足以下要求。

### 硬件资源

为确保生产环境的稳定性和性能，建议 Kubernetes 剩余资源满足以下建议配置：

* CPU：24 个可用 CPU 以上。
* 内存：72 GB 可用内存以上。
* 存储：使用 SSD 存储，可用空间 400 GB 以上。

### 软件依赖

* Kubernetes 集群：版本需要在 v1.18 以上。
* helm：用来部署 ob-operator 和 OceanBase Dashboard，请参考 [helm 安装文档](https://helm.sh/docs/intro/install/) 完成安装。
* cert-manager：ob-operator 依赖 cert-manager 进行证书管理。请参考 [cert-manager 安装文档](https://cert-manager.io/docs/installation/) 完成安装。
* 存储：集群中需要有可用的 storage class，我们对一些常见的存储系统做了测试，具体如下表。可以参考存储兼容性中的测试结果来判断是否满足需求，本文中将使用 [local-path-provisioner](https://github.com/rancher/local-path-provisioner) 作为示例。

  | 存储方案 | 测试版本 | 是否兼容 | 说明 |
  | --- | --- | --- | --- |
  | local-path-provisioner | 0.0.23 | ✅ | 建议开发和测试环境使用 |
  | Rook CephFS | v1.6.7 | ❌ | CephFS 不支持 fallocate 系统调用 |
  | Rook RBD (Block) | v1.6.7 | ✅ |  |
  | OpenEBS (cStor) | v3.6.0 | ✅ |  |
  | GlusterFS | v1.2.0 | ✅ | 机器内核版本不低于 5.14 时兼容 |
  | Longhorn | v1.6.0 | ✅ |  |
  | JuiceFS | v1.1.2 | ✅ |  |
  | NFS | v5.5.0 | ❌ | NFS 协议 >= 4.2 时能启动集群，但无法回收租户资源 |
* MySQL 客户端或 OBClient：用于连接 OceanBase 集群。

## 操作步骤

#### 说明

本文以 ob-operator V2.3.3、OceanBase Dashboard V0.5.0 为例介绍操作步骤，其他版本可能略有不同。

### 步骤一：部署 ob-operator

ob-operator 是 OceanBase 在 Kubernetes 中的核心管控组件。推荐使用 Helm 进行部署。

1. 添加 ob-operator 仓库

   ```
   helm repo add ob-operator https://oceanbase.github.io/ob-operator/
   helm repo update ob-operator
   ```
2. 安装 ob-operator

   ```
   helm install ob-operator ob-operator/ob-operator --namespace=oceanbase-system --create-namespace
   ```

   `--namespace` 用于设置安装的命名空间，可根据需要自定义，建议使用 `oceanbase-system`。
3. 验证是否安装成功

   ```
   kubectl get pod -n oceanbase-system
   ```

   预期的输出结果如下，pod 的 `STATUS` 为 `Running`。

   ```
   NAME                                            READY   STATUS    RESTARTS   AGE
   oceanbase-controller-manager-644b489fcc-6hlwf   2/2     Running   0          1m
   ```

### 步骤二：部署 OceanBase Dashboard

OceanBase Dashboard 提供了可视化的集群管理和监控能力。

1. 安装 OceanBase Dashboard

   ```
   helm install oceanbase-dashboard ob-operator/oceanbase-dashboard --namespace=oceanbase-system --set service.type=NodePort
   ```

   #### 说明

   `service.type` 默认值即为 `NodePort`，如果您的环境支持 LoadBalancer，可将 `service.type` 设置为 `LoadBalancer` 以获得外部 IP。
2. 获取访问地址

   ```
   # 查看服务端口
   kubectl get svc -n oceanbase-system oceanbase-dashboard-oceanbase-dashboard
   ```
3. 登录 OceanBase Dashboard

   可使用上一步查看到的服务端口，通过浏览器访问 OceanBase Dashboard。默认账号和密码均为 `admin`，首次登录需修改密码。

   * 如果 `service.type` 指定为 NodePort 类型，可通过 `http://<任意节点IP>:<NodePort端口>` 访问。
   * 如果 `service.type` 指定为 LoadBalancer 类型，可通过 `http://<External-IP>:<端口>` 访问。

### 步骤三：部署 OceanBase 集群

登录 OceanBase Dashboard 后，您可单击左侧导航栏 **集群**，在集群页面中单击 **集群列表** 右上角 **创建集群** 进入 **创建集群** 页面。

1. 配置基础信息

   您可在该页面配置集群的 **命名空间**、**集群名**、**集群模式**、**root 密码** 等信息。

   ![基础信息](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-01.png)

   | 参数 | 说明 |
   | --- | --- |
   | 命名空间 | 通过下拉列表选择创建 OceanBase 集群的命名空间，您也可单击下拉列表中的 **+ 新增命名空间** 创建新的命名空间。新增命名空间时，空间名需以小写字母开头、小写字母或者数字结尾，可包含小写字母、数字和 `-`，且长度不超过 63 个字符。 |
   | 资源名称 | Kubernetes 中 OceanBase 集群自定义资源，不可和同一个命名空间下的已有 OceanBase 集群资源名称重复。自定义资源名称时，需以小写字母开头、小写字母或者数字结尾，可包含小写字母、数字和 `-`，且长度不超过 63 个字符。 |
   | 集群名 | 设置 OceanBase 集群名。集群名需以英文字母开头、英文或数字结尾，可包含英文、数字和下划线，且长度在 2 ~ 32 个字符之间。 |
   | 集群模式 | 通过下拉列表选择集群部署模式，不同集群模式对 OceanBase 数据库的版本有要求，且集群部署模式会影响故障时恢复的策略，需按照实际环境和集群版本进行选择。 * **常规模式：**未做任何特殊处理，直接使用 pod IP 地址进行 bootstrap。目前能够识别 calico 和 kube-ovn 插件，在故障重建 pod 时使用故障前的 IP 地址，建议为 OceanBase 集群分配单独的网段避免被其他 pod 占用。若 K8s 集群使用的是其他网络插件，会进行扩容再缩容的故障恢复策略，这往往需要更长的时间来复制大量的数据，且不能从多数派节点故障的场景中恢复。 * **单体模式：**会使用 `127.0.0.1` 进行 bootstrap，仅限于部署单节点集群时使用。由于指定了 `127.0.0.1` 作为 OBServer 服务地址，可以在 pod 重建时复用原来的数据快速恢复。 * **service 模式：**为每一个 OBServer 服务再创建一个 service，使用 service 的 cluster ip 地址进行 bootstrap，在 pod 重建时也可以复用原来的数据进行快速恢复，一般情况下建议使用这种模式。 |
   | 优化场景 | 提供了常用的 OceanBase 集群使用场景的参数模版，按照使用场景选择会自动进行参数设置。优化场景的具体介绍可参见 [配置最佳实践](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000004475424)。 |
   | root 密码 | sys 租户的 root 用户密码，可单击 **随机生成**，由 Dashboard 自动生成随机字符串，也可自定义设置。自定义密码时，密码设置需满足如下要求： * 长度为 8~32 个字符 * 只能包含字母、数字和特殊字符（`~!@#%^&*_-+=|()[]:;,.?/`） * 大小写字母、数字和特殊字符都至少包含 2 个配置后可单击 **复制密码**，复制后保存已配置的密码。 |
   | 删除保护 | 可通过勾选控制是否开启删除保护，开启后删除该 OceanBase 集群的操作将会被 webhook 拦截，需要解除之后才能删除该集群。 |
   | 高级配置 | 单击 **高级配置** 后的展开图标可配置 **proxyro 密码**，未打开 **高级配置** 时，Dashboard 会自动生成一个随机字符串作为 proxyro 密码。 proxyro 密码是 sys 租户的 proxyro 用户密码，当 OceanBase 集群中的 proxyro 密码与 ODP 中的 proxyro 密码保持一致时，ODP 才可访问对应的 OceanBase 集群。可单击 **随机生成**，由 Dashboard 生成随机字符串，也可自定义设置。自定义密码时，密码设置需满足如下要求： * 长度为 8~32 个字符 * 只能包含字母、数字和特殊字符（`~!@#%^&*_-+=|()[]:;,.?/`） * 大小写字母、数字和特殊字符都至少包含 2 个配置后可单击 **复制密码**，复制后保存已配置的密码。 |
2. 配置集群拓扑

   集群拓扑主要配置集群所有的 Zone 信息，一般至少需要配置 3 个 Zone，可单击 **+ 添加Zone** 或对应 Zone 后的删除图标新增或删除 Zone。

   ![集群拓扑](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-02.png)

   | 参数 | 说明 |
   | --- | --- |
   | zone名称 | 配置 OceanBase 数据库中的 Zone 名称，可自定义。Zone 名称需以英文字母开头，英文或数字结尾，可包含英文、数字和下划线，且长度在 2~32 个字符之间。 |
   | server数 | 设置当前 Zone 下包含多少个 OBServer 服务。 |
   | K8s 集群 | 该参数仅针对多 K8s 集群部署的场景，用于设置将这个 Zone 部署到哪个 K8s 集群当中，单 K8s 集群中部署可以留空。多 K8s 集群部署的介绍可参见 [多 K8s 集群部署](https://www.oceanbase.com/docs/community-ob-operator-doc-1000000003903467)。 |
   | Topology | 可单击 **Topology** 前的展开按钮进行亲和性配置，支持 node selector、pod affinity 和 toleration 的配置。配置仅对当前 Zone 下 OBServer 服务的 pod 生效。 |
3. 配置 OBServer 资源

   ![observer资源](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-03.png)

   | 参数 | 说明 |
   | --- | --- |
   | 镜像 | 配置部署 OceanBase 集群使用的镜像，可以通过单击 **镜像列表** 查看所有镜像，镜像 tag 对应 OceanBase 数据库版本号，推荐使用 LTS 版本的镜像。镜像应写全 `registry/image:tag`，例如 `oceanbase/oceanbase-cloud-native:4.2.0.0-101000032023091319`。 |
   | 资源 | 包括 CPU、内存和存储资源，其中存储将创建 3 个独立的 PVC 用来存放数据、运行日志和 redo log。数据、运行日志和 redo log 的配置至少需为 **内存** 配置的三倍。支持为 PVC 开启独立生命周期，勾选 **PVC 独立生命周期** 后，删除 OBServer 资源时不会级联删除 PVC，需要手动删除。  可单击 **OBserver** 模块右上角的 **最小规格配置** 按钮，Dashboard 会自动按照最小规格填充资源。 |
4. 可选配置

   可单击 **监控**、**参数设置**、**挂载 NFS 备份卷** 后的按钮进行对应内容的配置。

   ![可选配置](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-04.png)

   | 模块 | 参数 | 说明 |
   | --- | --- | --- |
   | 监控 | 镜像 | 监控开启后可以配置 obagent 作为 sidecar 容器提供监控功能，此处用于配置部署 obagent 使用的镜像。可以通过单击 **镜像列表** 查看所有镜像，镜像 tag 对应 obagent 版本号。镜像应写全 `registry/image:tag`，例如 `oceanbase/obagent:4.2.0-100000062023080210`。 |
   | 资源 | 配置部署 obagent 所需的 CPU 数量和内存，需填写正整数。 |
   | 参数设置 | 参数名 | 填写 OceanBase 集群的参数。 |
   | 参数值 | 为对应参数设置合理的值，设置的参数值对所有 OBServer 服务生效。 |
   | 操作 | 可单击 **删除** 字段删除对应的参数。 说明 可单击 **+ 添加参数** 新增一行用于配置参数。 |
   | 挂载 NFS 备份卷 | 地址 | 如需使用 NSF 进行备份恢复，可在此处配置 NFS 服务的地址。 |
   | 路径 | 填写备份路径，NFS 的路径将会挂载到 OBServer 服务的容器中。 |
5. 提交等待创建成功

   完成上述配置后，单击 **提交**，等待 **集群列表** 中 **状态** 变为 **正常运行**，表示集群已经创建成功。

   #### 说明

   正常情况下，预计两三分钟即可创建成功。

   ![成功](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-05.png)

### 步骤四：创建租户

集群部署完成后，建议创建业务租户共应用使用。您可单击左侧导航栏 **租户**，在租户页面中单击 **租户列表** 右上角 **创建租户** 进入 **创建租户** 页面。

1. 填写租户基本信息

   ![基本信息](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-06.png)

   | 参数 | 说明 |
   | --- | --- |
   | OB集群 | 通过下拉列表选择待创建租户所在的 OceanBase 集群。 |
   | 资源名 | Kubernetes 中租户自定义资源的名称，租户会创建在集群相同的 namespace 下。 |
   | 租户名 | 待创建的租户名。 |
   | 密码 | 租户的 root 账号密码。可单击 **随机生成**，由 Dashboard 自动生成随机字符串，也可自定义设置。自定义密码时，密码设置需满足如下要求： * 长度为 8~32 个字符 * 只能包含字母、数字和特殊字符（`~!@#%^&*_-+=|()[]:;,.?/`） * 大小写字母、数字和特殊字符都至少包含 2 个配置后可单击 **复制密码**，复制后保存已配置的密码。 |
   | 优化场景 | 提供了常用的 OceanBase 数据库使用场景的参数模版，按照使用场景选择会自动进行参数设置。优化场景的具体介绍可参见 [配置最佳实践](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000004475424)。 |
   | 连接白名单 | 可以连接租户的白名单地址，默认 `%` 表示任意地址。 |
   | 删除保护 | 可通过勾选控制是否开启删除保护，开启后删除该租户的操作将会被 webhook 拦截，需要解除之后才能删除该租户。 |
2. 填写租户资源池配置

   ![资源配置](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-08.png)

   | 参数 | 说明 |
   | --- | --- |
   | 副本分布 | 可通过单击各个 Zone 前的勾选框配置租户分布在哪些 Zone 中，并设置在对应 Zone 中的优先级、副本类型和 unit 数量。 |
   | 资源单元规格 | 配置租户每个 unit 的资源，建议根据 **副本分布** 模块显示的 **可用资源** 情况酌情配置。 |
3. 提交等待创建成功

   配置完成后，单击 **提交**，等待 **租户列表** 中 **状态** 变为 **正常运行**，表示租户已经创建成功。

   ![创建成功](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-09.png)

### 步骤五：部署 ODP

ODP（又称 OBProxy） 是应用连接分布式 OceanBase 集群的必要组件，可以将请求路由到正确的 OBServer 节点。您可单击左侧导航栏 **OBProxy**，在 OBProxy 页面中单击 **集群列表** 右上角 **创建 OBProxy 集群** 进入 **创建 OBProxy 集群** 页面。

1. 配置基本信息

   ![基本信息](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-10.png)

   | 参数 | 说明 |
   | --- | --- |
   | 资源名称 | 在 Kubernetes 中创建的 deployment 的名称。配置的名称需以小写字母开头、小写字母或者数字结尾，可包含小写字母、数字和 `-`，且长度不超过 63 个字符。 |
   | OBProxy 集群名称 | ODP 的应用名称。 |
   | 连接 OB 集群 | 可以通过下拉列表选择连接的 OceanBase 集群，默认是使用 rs\_list 方式连接选中的 OceanBase 集群。 |
   | 命名空间 | kubernetes 中部署 ODP 的命名空间，选择 OceanBase 集群之后，默认会自动填入选中的 OceanBase 集群的 namespace。 |
   | OBProxy root 密码 | ODP 管理租户（`proxysys`）的 `root` 用户密码。可单击 **随机生成**，由 Dashboard 自动生成随机字符串，也可自定义设置。自定义密码时，密码设置需满足如下要求： * 长度为 8~32 个字符 * 只能包含字母、数字和特殊字符（`~!@#%^&*_-+=|()[]:;,.?/`） * 大小写字母、数字和特殊字符都至少包含 2 个配置后可单击 **复制密码**，复制后保存已配置的密码。 |
2. 更多配置

   ![更多配置](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-11.png)

   | 参数 | 说明 |
   | --- | --- |
   | 镜像 | 配置部署 ODP 使用的镜像，可以通过单击 **镜像列表** 查看所有镜像，建议部署最新版本。镜像 tag 对应 ODP 版本号，镜像应写全 `registry/image:tag`，例如 `oceanbase/obproxy-ce:4.3.3.0-5`。 |
   | 服务类型 | 通过下拉列表选择为 ODP 创建的 service 类型。如果仅需在 kubernetes 集群内访问，可以选择使用 ClusterIP；如果需要在集群外访问，可以根据情况选择 NodePort 或者 LoadBalancer。 |
   | 副本数 | 配置 ODP 的副本数。 |
   | CPU 核数 | 配置分配给 ODP 的 CPU 核数。 |
   | 内存大小 | 配置分配给 ODP 的内存资源。 |
   | 参数设置 | 可以单击 **+ 添加**，以 KV 的形式来配置 ODP 的参数。 |
3. 提交等待创建成功

   完成上述配置后，单击 **提交**，等待 **集群列表** 中 **状态** 变为 **Running**，表示 ODP 已经创建成功。

   ![创建成功](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-12.png)

### 步骤六：连接验证

部署完成后，您可以通过 OBProxy 详情页面查看 **服务地址**，通过该地址来连接集群。

![ODP页面](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.4.1/400.deploy/500.community-edition/300.deploy-in-the-k8s-cluster-14.png)

执行如下命令，通过 ODP 连接 `obcluster` 集群的 `obtenant2` 租户。连接租户的详细介绍可参见 [连接方式概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499955)。

```
mysql -h10.10.10.1 -P2883 -uroot@obtenant2#obcluster -p****** oceanbase
```

输出如下：

```
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MySQL connection id is 7
Server version: 5.6.25 OceanBase_CE 4.3.5.3 (r103000092025080818-e8da5f0afb288ed0add0613740c6ccf2a3c6830b) (Built Aug  8 2025 18:43:02)

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MySQL [oceanbase]>
```

## 相关文档

本文档仅包含了最基本的部署方式，适用于初始化的环境搭建，我们还支持全面的运维、监控功能，以及针对更高高可用要求的多 K8s 集群中的部署模式，您可以进一步在 Dashboard 页面上探索这些功能，或者参考链接了解。

* [GitHub ob-operator 文档](https://oceanbase.github.io/ob-operator/zh-Hans/)
* [GitHub ob-operator 代码仓库](https://github.com/oceanbase/ob-operator)
* [OceanBase K8s 运维工具文档](https://www.oceanbase.com/docs/ob-operator-doc)