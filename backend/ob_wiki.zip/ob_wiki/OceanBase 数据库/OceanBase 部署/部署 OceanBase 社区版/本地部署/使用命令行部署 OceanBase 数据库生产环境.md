---
title: 使用命令行部署 OceanBase 数据库生产环境
description: 提供关于使用命令行部署 OceanBase 数据库生产环境的相关内容，
keywords: 使用命令行部署 OceanBase 数据库生产环境,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用命令行部署 OceanBase 数据库生产环境

本文介绍如何通过 obd 黑屏命令行方式部署 OceanBase 数据库生产环境。

#### 说明

obd 除了支持通过命令行方式部署 OceanBase 数据库生产环境外，也支持通过白屏部署 OceanBase 集群环境。推荐您通过 obd 白屏方式进行部署，详细操作步骤请参考 [通过 obd 白屏部署 OceanBase 集群](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502653)。

## 名词解释

* 中控机器

  安装 obd 的机器，用于管理 OceanBase 集群，存储 OceanBase 集群安装包和集群配置信息。
* 目标机器

  安装 OceanBase 数据库的机器。
* OceanBase 数据库

  一款完全自研的企业级原生分布式数据库，详细信息请参见 [OceanBase 数据库文档](https://www.oceanbase.com/docs/oceanbase-database-cn)。
* obd

  OceanBase Deployer，OceanBase 安装部署工具，简称为 obd。详细信息请参考 [OceanBase 安装部署工具文档](https://www.oceanbase.com/docs/obd-cn)。
* ODP

  OceanBase Database Proxy，OceanBase 数据库代理，是 OceanBase 数据库专用的代理服务器，简称为 ODP（又称为 OBProxy）。详细信息请参见 [OceanBase 数据库代理文档](https://www.oceanbase.com/docs/odp-doc-cn)。
* OBAgent

  OBAgent 是 OceanBase 数据库监控采集框架，支持推、拉两种数据采集模式，可以满足不同的应用场景。
* obconfigserver

  OceanBase Configserver，obconfigserver 可提供 OceanBase 的元数据注册，存储和查询服务。详细信息请参见 [ob-configserver](https://github.com/oceanbase/ob-configserver/tree/main)。
* Grafana

  Grafana 是一款开源的数据可视化工具，它可以将数据源中的各种指标数据进行可视化展示，以便更直观地了解系统运行状态和性能指标。详细信息可参见 [Grafana 官网](https://grafana.com/)。
* Prometheus

  Prometheus 是一个开源的服务监控系统和时序数据库，其提供了通用的数据模型以及快捷数据采集、存储和查询接口。详细信息可参见 [Prometheus 官网](https://prometheus.io/)。

## 前提条件

在部署 OceanBase 数据库之前，请您确认以下信息：

* 您的机器满足软硬件要求。详细信息，参考 [软硬件要求](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500194)。
* 生产环境下，您需要进行环境和配置检查，具体操作请参考 [部署前配置](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502655) 章节。
* 中控机器中已安装 obd 和 OBClient 客户端，建议安装最新版本，详细信息请参见官网《OceanBase 安装部署工具》文档 [快速上手/安装 obd](https://www.oceanbase.com/docs/common-obd-cn-1000000003892241) 和 [OBClient 文档](https://github.com/oceanbase/obclient/blob/master/README.md)。

  #### 说明

  OceanBase All in One 安装时会自动安装 obd 和 OBClient 客户端，因此，若您计划参照下文步骤一操作下载并安装 OceanBase All in One，可忽略此条要求。

## 部署模式

本文采用三副本部署模式，推荐使用四台机器，您可以根据自己实际情况选择合适的部署方案。本文中四台机器的使用情况如下：

| 角色 | 机器 | 备注 |
| --- | --- | --- |
| obd | 10.10.10.4 | 安装在中控机上的自动化部署软件 |
| OBServer 节点 | 10.10.10.1 | OceanBase 数据库 Zone1 |
| OBServer 节点 | 10.10.10.2 | OceanBase 数据库 Zone2 |
| OBServer 节点 | 10.10.10.3 | OceanBase 数据库 Zone3 |
| ODP | 10.10.10.1、10.10.10.2、10.10.10.3 | OceanBase 数据库专用的反向代理软件 |
| OBAgent | 10.10.10.1、10.10.10.2、10.10.10.3 | OceanBase 数据库监控采集框架 |
| obconfigserver | 10.10.10.4 | 可提供 OceanBase 的元数据注册，存储和查询服务 |
| Prometheus | 10.10.10.4 | 一个开源的服务监控系统和时序数据库，其提供了通用的数据模型以及快捷数据采集、存储和查询接口 |
| Grafana | 10.10.10.4 | 一款开源的数据可视化工具，它可以将数据源中的各种指标数据进行可视化展示，以便更直观地了解系统运行状态和性能指标 |

#### 说明

* 在生产环境下，推荐将 ODP 和应用部署在一台机器上，以节省 ODP 访问应用的时间。您可以在每个应用的服务器上部署一个 ODP 服务。
* 部署 ODP 的机器使用的配置可以和部署 OceanBase 数据库的机器配置不一致。部署 ODP 最小只需 1C/1G 内存。
* 单机部署操作步骤可参考 OceanBase 安装部署工具文档中 [部署 OceanBase 集群](https://www.oceanbase.com/docs/common-obd-cn-1000000003754549) 一文。

## 操作步骤

#### 注意

* 以下内容以 x86 架构的 CentOS Linux 7.9 镜像作为环境，其他环境可能略有不同。
* 部署 OceanBase 集群之前，为了数据安全，建议您切换到非 root 用户。

### 步骤一：（可选）下载并安装 OceanBase All in One

从 V4.0.0 开始，OceanBase 提供统一的安装包 OceanBase All in One。您可以通过这个统一的安装包一次性完成 obd、OceanBase 数据库、ODP、OBAgent 等组件的安装。

您也可根据实际需求从 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 选择部分组件下载安装或者指定组件的版本。

#### 在线安装

若您的机器可以连接网络，可执行如下命令在线安装。

```
[admin@test001 ~]$ bash -c "$(curl -s https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/download-center/opensource/oceanbase-all-in-one/installer.sh)"
[admin@test001 ~]$ source ~/.oceanbase-all-in-one/bin/env.sh
```

#### 离线安装

若您的机器无法连接网络，可参考如下步骤离线安装。

1. 从 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 下载最新的 OceanBase All in One 安装包，并将其复制到中控机任意目录下。
2. 在安装包所在目录下执行如下命令解压安装包并安装。

   ```
   [admin@test001 ~]$ tar -xzf oceanbase-all-in-one-*.tar.gz
   [admin@test001 ~]$ cd oceanbase-all-in-one/bin/
   [admin@test001 bin]$ ./install.sh
   [admin@test001 bin]$ source ~/.oceanbase-all-in-one/bin/env.sh
   ```

#### 说明

您可通过执行 `which obd` 和 `which obclient` 命令检测是否安装成功，如果可以找到 `.oceanbase-all-in-one` 目录下的 obd 和 obclient 路径，则表示安装成功。

### 步骤二：配置 obd

#### 说明

本文以 obd V3.5.0 为例提供操作指导。不同 obd 版本的配置文件可能不同，请以实际配置文件为准。更多 obd 相关内容请参见 [OceanBase 安装部署工具文档](https://www.oceanbase.com/docs/obd-cn)。

如果是离线部署 OceanBase 集群，可参考 **步骤一** 在中控机上下载并安装 OceanBase All in One，OceanBase All in One 提供的组件已经经过相互适配测试，为官方推荐版本。

如果是离线部署且对部署所需组件版本有特别要求，可从 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 自行下载组件对应版本安装包，将下载的安装包复制到中控机任一目录，在该目录下参考以下步骤 1~3 将安装包上传到 obd 本地镜像库。

#### 说明

如果是在线部署 OceanBase 集群，可跳过步骤 1~3。

1. 禁用远程仓库

   ```
   [admin@test001 rpm]$ obd mirror disable remote
   ```

   #### 说明

   安装 OceanBase All in One 后默认关闭远程仓库，您可通过 `obd mirror list` 命令进行确认，查看 Type=remote 对应的 Enabled 变成了 False，说明已关闭远程镜像源。
2. 将安装包添加至本地镜像库

   ```
   [admin@test001 rpm]$ obd mirror clone *.rpm
   ```
3. 查看本地镜像库中安装包列表

   ```
   [admin@test001 rpm]$ obd mirror list local
   ```
4. 选择配置文件

   若您机器中的 obd 是通过直接下载的方式安装，则可在 `/usr/obd/example` 目录下查看 obd 提供的配置文件示例。

   若您机器中的 obd 是通过解压 OceanBase All in One 的方式安装，则可在 `~/.oceanbase-all-in-one/obd/usr/obd/example` 目录下查看 obd 提供的配置文件示例。请根据您的资源条件选择相应的配置文件。

   #### 说明

   配置文件分为小规格开发和专业开发两种模式，两种模式的配置文件中配置项基本相同，配置的规格略有不同，您可根据实际资源条件进行选择。

   * 小规格开发模式：适用于个人设备（内存不低于 8 GB），配置文件名中带有 `mini` 或 `min` 标识。
   * 专业开发模式：适用于高配置 ECS 或物理服务器（可用资源不低于 16 核 64 GB）。

   如果您选择单机部署，即目标机器只有一台，可参考单机部署配置文件。

   * 本地单机部署配置样例：mini-local-example.yaml、local-example.yaml
   * 单机部署配置样例：mini-single-example.yaml、single-example.yaml
   * 单机部署 + ODP 配置样例：mini-single-with-obproxy-example.yaml、single-with-obproxy-example.yaml

   如果您选择分布式部署，即目标机器有多台，可参考分布式安装配置文件。

   * 分布式部署 OceanBase 数据库配置样例：mini-distributed-example.yaml、distributed-example.yaml
   * 分布式部署 OceanBase 数据库 + ODP 配置样例：mini-distributed-with-obproxy-example.yaml、distributed-with-obproxy-example.yaml
   * 分布式部署全部组件：all-components-min.yaml、all-components.yaml
5. 修改配置文件。

   #### 说明

   您需根据您环境的真实情况修改下述参数。

   1. 创建配置文件

      ```
      vim deploy.yaml
      ```

      此处仅为示例，您可根据实际情况自定义配置文件名。
   2. 修改用户名和密码。

      ```
      ## Only need to configure when remote login is required
      user:
        username: admin
      #   password: your password if need
        key_file: /home/admin/.ssh/id_rsa
      #   port: your ssh port, default 22
      #   timeout: ssh connection timeout (second), default 30
      ```

      `username` 为登录到目标机器的用户名，确保您的用户名有 `home_path` 的写权限。`password` 和 `key_file` 均用于验证用户，通常情况下只需要填写一个。

      #### 注意

      在配置秘钥路径后，如果您的秘钥不需要口令，请注释或者删除 `password`，以免 `password` 被视为秘钥口令用于登录，导致校验失败。
   3. 修改机器的 IP、端口和相关目录，并配置内存相关参数及密码。

      ```
      oceanbase-ce:
        # version: 4.2.5.0
        servers:
          # Please don't use hostname, only IP can be supported
          - name: server1
            ip: 10.10.10.1
          - name: server2
            ip: 10.10.10.2
          - name: server3
            ip: 10.10.10.3
        global:
          devname: eth0
          cluster_id: 1
          # please set memory limit to a suitable value which is matching resource. 
          memory_limit: 64G # The maximum running memory for an observer
          system_memory: 30G # The reserved system memory. system_memory is reserved for general tenants.
          datafile_size: 192G # Size of the data file. 
          datafile_next: 200G
          datafile_maxsize: 1T
          log_disk_size: 192G # The size of disk space used by the clog files.
          scenario: htap
          enable_syslog_wf: false # Print system logs whose levels are higher than WARNING to a separate log file. The default value is true.
          max_syslog_file_count: 4 # The maximum number of reserved log files before enabling auto recycling. The default value is 0.
          enable_auto_start: true
          # observer cluster name, consistent with obproxy's cluster_name
          appname: obdemo
          mysql_port: 2881 # External port for OceanBase Database. The default value is 2881. DO NOT change this value after the cluster is started.
          rpc_port: 2882 # Internal port for OceanBase Database. The default value is 2882. DO NOT change this value after the cluster is started.
          obshell_port: 2886 # Operation and maintenance port for OceanBase Database.
          # The working directory for OceanBase Database. OceanBase Database is started under this directory. This is a required field.
          home_path: /home/admin/observer
          # The directory for data storage. The default value is $home_path/store.
          data_dir: /data
          # The directory for clog. The default value is the same as the data_dir value.
          redo_dir: /redo
          root_password: ****** # root user password, can be empty
          proxyro_password: ******** # proxyro user pasword, consistent with obproxy's observer_sys_password, can be empty
        server1:
          zone: zone1
        server2:
          zone: zone2
        server3:
          zone: zone3
      ```

      若机器中存在不一致的配置项，可将相关配置项移到对应 server 里进行配置，配置文件中对应 server 中的配置优先级高于 `global`。以其中两台机器中配置端口不同为例：

      ```
      server2:
        mysql_port: 3881
        rpc_port: 3882
        zone: zone2
      server3:
        mysql_port: 2881
        rpc_port: 2882
        zone: zone3
      ```

      | 配置项 | 是否必选 | 默认值 | 说明 |
      | --- | --- | --- | --- |
      | version | 可选 | 镜像库中最新版本 | 指定待部署组件版本，通常情况下不需要指定。 |
      | servers | 必选 | 无 | 每台机器需要用 `- name: 机器标识名 (换行)ip: 机器 IP` 指定，多个机器就指定多次，机器标识名不能重复。  在机器 IP 不重复的情况下，也可以使用 `- <ip> （换行）- <ip>` 的格式指定，此时 `- <ip>` 的格式相当于 `- name: 机器 IP（换行）ip: 机器 IP`。 |
      | devname | 可选 | 无 | 和 `servers` 里指定的 IP 对应的网卡，通过 `ip addr` 命令可以查看 IP 和网卡对应关系。 |
      | memory\_limit | 可选 | 0 | observer 进程能从环境中获取的最大内存，未配置的情况下以 `memory_limit_percentage` 配置项为准，配置项详细介绍请参考 [memory\_limit](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502349) 和 [memory\_limit\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502268)。 |
      | system\_memory | 可选 | 0M | 保留的系统内存，该参数值会占用 `memory_limit` 的内存，未配置的情况下 OceanBase 数据库会自适应。 |
      | datafile\_size | 可选 | 0 | 指定对应节点数据文件（block\_file）大小，未配置的情况下以 `datafile_disk_percentage` 配置项为准，详细介绍请参见 [datafile\_size](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502366) 和 [datafile\_disk\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502193)。 |
      | datafile\_next | 可选 | 0 | 控制磁盘空间的增长步长，用于设置自动扩容，未配置的情况下若要开启自动扩容功能可参见 [配置磁盘数据文件的动态扩容](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499963)。 |
      | datafile\_maxsize | 可选 | 0 | 限制磁盘空间的最大可用上限，用于设置自动扩容，未配置的情况下若要开启自动扩容功能可参见 [配置磁盘数据文件的动态扩容](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499963)。 |
      | log\_disk\_size | 可选 | 0 | 用于设置 Redo 日志磁盘的大小，未配置的情况下以`log_disk_percentage` 配置项为准，详细介绍请参考 [log\_disk\_size](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502202) 和 [log\_disk\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502279)。 |
      | scenario | 可选 | htap | 设置集群负载类型，未配置该配置项的情况下，会提供交互式选项供用户选择负载类型。可选值如下： * `express_oltp`：适用于贸易、支付核心系统、互联网高吞吐量应用程序等工作负载。没有外键等限制、没有存储过程、没有长交易、没有大交易、没有复杂的连接、没有复杂的子查询。 * `complex_oltp`：适用于银行、保险系统等工作负载。他们通常具有复杂的联接、复杂的相关子查询、用 PL 编写的批处理作业，以及长事务和大事务。有时对短时间运行的查询使用并行执行。 * `olap`：适用于实时数据仓库分析场景。 * `htap`：适用于混合 OLAP 和 OLTP 工作负载。通常用于从活动运营数据、欺诈检测和个性化建议中获取即时见解。 * `kv`：适用于键值工作负载和类似 Hbase 的宽列工作负载，这些工作负载通常具有非常高的吞吐量并且对延迟敏感。 |
      | enable\_syslog\_wf | 可选 | true | 设置是否把 WARN 以上级别的系统日志打印到一个单独的日志文件中。 |
      | max\_syslog\_file\_count | 可选 | 0 | 设置在回收日志文件之前可以容纳的日志文件数量。值为 0 时表示不自动清理。 |
      | enable\_auto\_start | 可选 | 0 | 控制是否开启 observer 进程自启动功能。配置为 `true` 时，若 OBServer 节点重启，会自动拉起 observer 进程。 说明 配置该配置项时需确保部署用户拥有 sudo 权限，且部署环境非容器环境。 |
      | appname | 可选 | obcluster | 设置 OceanBase 集群名。 |
      | mysql\_port | 必选 | 2881 | 设置 SQL 服务协议端口号，默认为 2881。 |
      | rpc\_port | 必选 | 2882 | 设置远程访问的协议端口号，是 observer 进程跟其他节点进程之间的 RPC 通信端口，默认为 2882。 |
      | obshell\_port | 必选 | 2886 | 设置 OceanBase 数据库运维端口，默认为 2886。 |
      | home\_path | 必选 | 无 | OceanBase 数据库安装路径，建议在普通用户 admin 下。 |
      | data\_dir | 可选 | $home\_path/store | 设置存储 SSTable 等数据的目录，建议配置为独立的磁盘。 |
      | redo\_dir | 可选 | 与 `data_dir` 相同 | clog 的目录，默认与 data\_dir 值相同，建议配置为独立的磁盘。 |
      | root\_password | 可选 | 随机字符串 | OceanBase 集群的超级管理员（root@sys）的密码，建议设置复杂的密码。使用 obd V2.1.0 及之后版本时，未设置的情况下会自动生成随机字符串。 |
      | proxyro\_password | 可选 | 随机字符串 | ODP 连接 OceanBase 集群使用的账户名（proxyro@sys）的密码。使用 obd V2.1.0 及之后版本时，未设置的情况下会自动生成随机字符串。 |
   4. 配置 obproxy-ce 组件并修改 IP 和 `home_path`。

      ```
      obproxy-ce:
        # version: 4.3.4.0
        # package_hash: 5c5dca3a355cc7286146ed978ebb26a6342e42e02cd3ca8b9739d300519a449f
        depends:
          - oceanbase-ce
        servers:
          - name: server1
            # Please don't use hostname, only IP can be supported
            ip: 10.10.10.1
          - name: server2
            ip: 10.10.10.2
          - name: server3
            ip: 10.10.10.3
        global:
          prometheus_listen_port: 2884
          listen_port: 2883
          rpc_listen_port: 2885
          enable_obproxy_rpc_service: true
          # vip_address: "10.10.10.5"
          # vip_port: 3306
          home_path: /home/admin/obtest/obproxy
          client_session_id_version: 2
          proxy_id: 822
          obproxy_sys_password: ********
          observer_sys_password: ********
          skip_proxy_sys_private_check: true
          enable_strict_kernel_release: false
          enable_cluster_checkout: false
      ```

      | 配置项 | 是否必选 | 默认值 | 说明 |
      | --- | --- | --- | --- |
      | version | 可选 | 镜像库中最新版本 | 指定待部署组件版本，通常情况下不需要指定。 |
      | depends | 可选 | 无 | 设置组件依赖关系，配置后当前组件会自动从依赖组件中获取信息。当组件之前存在依赖关系时，该配置项为必选。 |
      | servers | 必选 | 无 | 每台机器需要用 `- name: 机器标识名 (换行)ip: 机器 IP` 指定，多个机器就指定多次，机器标识名不能重复。  在机器 IP 不重复的情况下，也可以使用 `- <ip> （换行）- <ip>` 的格式指定，此时 `- <ip>` 的格式相当于 `- name: 机器 IP（换行）ip: 机器 IP`。 |
      | listen\_port | 必选 | 2883 | ODP 监听端口，默认 2883。 |
      | prometheus\_listen\_port | 必选 | 2884 | ODP prometheus 监听端口，默认 2884。 |
      | rpc\_listen\_port | 可选 | 2885 | ODP 中 RPC 服务监听端口，默认为 2885。 说明 该配置项仅在部署 ODP V4.3.0 及以后版本，并且 `enable_obproxy_rpc_service` 取值为 `true` 时生效。 |
      | enable\_obproxy\_rpc\_service | 可选 | true | 控制是否启用 ODP RPC 服务，默认为 `true` 表示启用 RPC 服务，取值为 `false` 时表示停止 RPC 服务，此时 `rpc_listen_port` 配置将不生效。 说明 * 该配置项仅在部署 ODP V4.3.0 及以后版本时生效。 * 若未配置该配置项，升级 ODP 后该配置项默认值将被置为 `false`。 |
      | vip\_address | 可选 | 无 | 当部署多节点 ODP 时，可通过该选项配置 VIP 的 IP 地址。 注意 * obd 自 V3.3.0 起支持为 ODP 配置 VIP。 * obd 不提供负载均衡的部署，如需设置负载均衡，请提前部署并配置好对应负载均衡。 |
      | vip\_port | 可选 | 无 | 当部署多节点 ODP 时，可通过该选项配置 VIP 的访问端口。 注意 * obd 自 V3.3.0 起支持为 ODP 配置 VIP。 * obd 不提供负载均衡的部署，如需设置负载均衡，请提前部署并配置好对应负载均衡。 |
      | home\_path | 必选 | 无 | ODP 安装路径，建议在普通用户 admin 下。 |
      | client\_session\_id\_version | 可选 | 2 | 用于设置是否使用新的 Client Session ID 生成逻辑。仅可配置为 `1` 或 `2`，配置为 `2` 时使用新的 Client Session ID 生成逻辑。 |
      | proxy\_id | 可选 | 0 | 用于设置标识 ODP 的 ID，以保障不同 ODP 生成的 Client Session ID 不会发生冲突。根据 `client_session_id_version` 配置项的取值不同，`proxy_id` 配置项的取值范围有如下两种情况。 * 配置项 `client_session_id_version` 的值配置为 `1` 时，配置项 `proxy_id` 的取值范围为 [0,255]。 * 配置项 `client_session_id_version` 的值配置为 `2` 时，配置项 `proxy_id` 的取值范围为 [0,8191]。 |
      | obproxy\_sys\_password | 可选 | 随机字符串 | ODP 管理员账户（root@proxysys）的密码。使用 obd V2.1.0 及之后版本时，未设置的情况下会自动生成随机字符串。 |
      | observer\_sys\_password | 可选 | 默认为和 `proxyro_password` 相同的随机字符串 | ODP 连接 OceanBase 集群使用的账户名（proxyro@sys）的密码，配置密码需和 `proxyro_password` 的值相同。使用 obd V2.1.0 及之后版本时，未设置的情况下会自动生成和 `proxyro_password` 相同的随机字符串。 |
   5. 修改监控组件。

      ```
      obagent:
        depends:
          - oceanbase-ce
        # The list of servers to be monitored. This list is consistent with the servers in oceanbase-ce.
        servers:
          - name: server1
            ip: 10.10.10.1
          - name: server2
            ip: 10.10.10.2
          - name: server3
            ip: 10.10.10.3
        global:
          monagent_http_port: 8088
          mgragent_http_port: 8089
          home_path: /home/admin/obagent
          http_basic_auth_password: ********
      prometheus:
        servers:
          - 10.10.10.4
        depends:
          - obagent
        global:
          port: 9090
          # The working directory for prometheus. prometheus is started under this directory. This is a required field.
          home_path: /home/admin/prometheus
          basic_auth_users: #<username>: <password>, the key is the user name and the value is the password.
            admin: ********
      grafana:
        servers:
          - 10.10.10.4
        depends:
          - prometheus
        global:
          port: 3000
          login_password: ********
          home_path: /home/admin/grafana
      ```

      | 配置项 | 是否必选 | 默认值 | 说明 |
      | --- | --- | --- | --- |
      | servers | 必选 | 无 | 每台机器需要用 `- name: 机器标识名 (换行)ip: 机器 IP` 指定，多个机器就指定多次，机器标识名不能重复。  在机器 IP 不重复的情况下，也可以使用 `- <ip> （换行）- <ip>` 的格式指定，此时 `- <ip>` 的格式相当于 `- name: 机器 IP（换行）ip: 机器 IP`。 |
      | depends | 可选 | 无 | 设置组件依赖关系，配置后当前组件会自动从依赖组件中获取信息。当组件之前存在依赖关系时，该配置项为必选。 |
      | home\_path | 必选 | 无 | 组件的安装路径，建议在普通用户 admin 下。 |
      | monagent\_http\_port | 必选 | 8088 | OBAgent 监控服务端口。 |
      | mgragent\_http\_port | 必选 | 8089 | OBAgent 管理服务端口。 |
      | http\_basic\_auth\_password | 可选 | 随机字符串 | HTTP 服务认证密码，自定义情况下要求密码长度最少为一个字符，可包含数字（0~9）、大写字母（A~Z）、小写字母（a~z）、特殊符号（`~^*{}[]_-+`）。未配置的情况下，obd 会自动生成随机字符串。可在部署成功后通过 `obd cluster edit-config` 命令查看配置文件中对应的配置项获取密码。 |
      | basic\_auth\_users | 可选 | `admin: *****` 其中，`admin` 为用户名，`*****` 为随机生成的密码 | Prometheus Web 服务的认证信息，键名为用户名，值为密码。 |
      | login\_password | 可选 | 随机字符串 | Grafana 登录密码，可在部署成功后通过 `obd cluster edit-config` 命令查看配置文件中对应的配置项获取密码。 |

### 步骤三：部署 OceanBase 集群

#### 说明

本节中所使用命令的详细使用方法可参考 OceanBase 安装部署工具文档中的 [集群命令组](https://www.oceanbase.com/docs/common-obd-cn-1000000003754444)。

1. 部署 OceanBase 集群

   ```
   [admin@test001 ~]$ obd cluster deploy obtest -c deploy.yaml
   ```

   联网情况下，在您执行了 `obd cluster deploy` 命令之后，obd 将检查您的目标机器是否有部署所需安装包。如果没有安装包，obd 将自动从 YUM 源获取。
2. 启动 OceanBase 集群

   ```
   [admin@test001 ~]$ obd cluster start obtest
   ```

   启动成功后，会输出 obshell Dashboard 和监控组件的访问地址。在阿里云或其他云环境下，安装程序可能因无法获取公网 IP 而输出内网地址，此 IP 非公网地址，您需要使用正确的地址。
3. 查看 OceanBase 集群状态

   ```
   # 查看 obd 管理的集群列表
   [admin@test001 ~]$ obd cluster list

   # 查看 obtest 集群状态
   [admin@test001 ~]$ obd cluster display obtest
   ```
4. （可选）修改集群配置

   OceanBase 数据库有数百个配置项，有些配置是耦合的，在您熟悉 OceanBase 数据库之前，不建议您修改示例配件文件中的配置。此处示例用来说明如何修改配置，并使之生效。

   使用 `obd cluster edit-config` 命令进入编辑模式，修改集群配置。

   ```
   [admin@test001 ~]$ obd cluster edit-config obtest
   ```

   修改配置并保存退出后，obd 会告知如何使得此次修改生效，保存修改后输入如下。

   ```
   Search param plugin and load ok
   Search param plugin and load ok
   Parameter check ok
   Save deploy "obtest" configuration
   Use `obd cluster reload obtest` to make changes take effect.
   ```

   复制 obd 输出的命令执行即可。

   ```
   [admin@test001 ~]$ obd cluster reload obtest
   ```

### 步骤四：连接 OceanBase 集群

此处以使用 OBClient 客户端连接 OceanBase 集群为例：

```
obclient -h<IP> -P<PORT> -u<user_name>@<tenant_name>#<cluster_name> -p -c -A
# example
obclient -h10.10.10.4 -P2883 -uroot@sys#obdemo -p -c -A
```

参数说明：

* -h：提供 OceanBase 数据库连接 IP，直连时为 OBServer 节点地址，通过 ODP 连接时为 ODP 地址。
* -u：提供 OceanBase 数据库的连接账户，格式有：`用户名@租户名#集群名`、`集群名:租户名:用户名`、`集群名-租户名-用户名` 或者 `集群名.租户名.用户名`。MySQL 租户的管理员用户名默认是 `root`。

  #### 注意

  连接时所用的集群名为配置文件中 `appname` 配置名称，而非部署时的 `deploy name`。
* -P：提供 OceanBase 数据库连接端口，直连时为 `mysql_port` 配置项的值，通过 ODP 连接时为 `listen_port` 配置项的值。
* -p：提供 OceanBase 数据库连接密码。
* -c：表示在 OBClient 运行环境中不要忽略注释。

  #### 说明

  Hint 是特殊的注释，不受 -c 影响。
* -A：表示在 OBClient 连接数据库时不自动获取统计信息。

更多连接 OceanBase 集群的详细操作可参见 [连接 OceanBase 数据库](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499955) 章节。

### 步骤五：创建用户租户

部署 OceanBase 集群之后，建议创建用户租户进行业务操作。sys 租户仅做集群管理使用，不适合在业务场景中使用。

您可以使用如下两种方法创建用户租户：

* 方法一：使用 obd 创建用户租户。

  ```
  obd cluster tenant create <deploy name> [-n <tenant name>] [flags]
  # example
  obd cluster tenant create test -n obmysql --max-cpu=2 --memory-size=2G --log-disk-size=3G --max-iops=10000 --iops-weight=2 --unit-num=1 --charset=utf8
  ```

  该命令默认根据集群剩余全部可用资源创建租户，您可通过配置各个参数控制租户占用资源的多少，命令详细使用方法请参考 obd 手册 [集群命令组](https://www.oceanbase.com/docs/common-obd-cn-1000000003754444) 中 `obd cluster tenant create` 命令。
* 方法二：通过命令行创建用户租户，详细操作可参考 [创建租户](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499837)。

## 相关操作

### 管理集群

您可执行如下命令对 obd 部署的集群进行管理，详细命令参见 OceanBase 安装部署工具文档 [集群命令组](https://www.oceanbase.com/docs/common-obd-cn-1000000003754444) 一文。

```
# 查看集群列表
obd cluster list

# 查看集群状态，以部署名为 obtest 为例
obd cluster display obtest

# 停止运行中的集群，以部署名为 obtest 为例
obd cluster stop obtest

# 销毁已部署的集群，以部署名为 obtest 为例
obd cluster destroy obtest
```

### 卸载 OceanBase All in One

您可参考如下步骤卸载已安装的 OceanBase All in One。

1. 卸载安装包

   ```
   [admin@test001 ~]$ cd oceanbase-all-in-one/bin/
   [admin@test001 bin]$ ./uninstall.sh
   ```
2. 删除环境变量

   ```
   [admin@test001 bin]$ vim ~/.bash_profile
   # 删除该文件中的 source /home/admin/.oceanbase-all-in-one/bin/env.sh
   ```
3. 使修改生效

   删除环境变量后，您需重新登录终端，或者执行 source 命令使修改生效，可参考如下命令。

   ```
   [admin@test001 ~]$ source ~/.bash_profile
   ```