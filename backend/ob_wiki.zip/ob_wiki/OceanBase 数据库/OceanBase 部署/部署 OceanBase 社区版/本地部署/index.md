# 分类索引：本地部署

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [OceanBase 部署](../../index.md) / [部署 OceanBase 社区版](../index.md) / 本地部署 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **部署前配置** | 涵盖 （可选）查看资源、（可选）创建用户、（可选）配置时钟源。 | `部署前配置` `（可选）查看资源` `（可选）创建用户` `（可选）配置时钟源` | [进入目录](./部署前配置/index.md) |
| **通过图形化界面部署** | 涵盖 通过 obd 图形化界面部署 OceanBase 集群、通过 OCP 部署 OceanBase 集群。 | `通过图形化界面部署` `通过 OCP 部署 OceanBase 集群` | [进入目录](./通过图形化界面部署/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [部署 OceanBase 数据库容器环境.md](./部署 OceanBase 数据库容器环境.md) | 提供关于部署 OceanBase 数据库容器环境的相关内容， | 部署 OceanBase 数据库容器环境,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库 |
| [软硬件要求.md](./软硬件要求.md) | 提供关于软硬件要求的相关内容， | 软硬件要求,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用 systemd 部署 OceanBase 数据库.md](./使用 systemd 部署 OceanBase 数据库.md) | 提供关于使用 systemd 部署 OceanBase 数据库的相关内容， | 使用 systemd 部署 OceanBase 数据库,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用命令行部署 OceanBase 数据库生产环境.md](./使用命令行部署 OceanBase 数据库生产环境.md) | 提供关于使用命令行部署 OceanBase 数据库生产环境的相关内容， | 使用命令行部署 OceanBase 数据库生产环境,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库 |
