---
title: 部署 OceanBase 数据库容器环境
description: 提供关于部署 OceanBase 数据库容器环境的相关内容，
keywords: 部署 OceanBase 数据库容器环境,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 部署 OceanBase 数据库容器环境

本文介绍如何通过 Docker 容器部署单节点 OceanBase 数据库。

#### 注意

本文档操作仅适用于学习或测试场景，请不要应用于生产环境。

## 前提条件

在执行本文操作前，您需确认以下信息：

* 您已安装 Docker 并启动 Docker 服务，详细操作请参考 [Docker 文档](https://docs.docker.com/get-docker/)。

  #### 说明

  在使用 x86 架构的 MAC 机器中，仅支持使用 V4.9.0 及以下版本的 Docker 部署 OceanBase 数据库，可点击 [链接](https://desktop.docker.com/mac/main/amd64/81317/Docker.dmg?_gl=17jelfd_gcl_auOTk5Nzk0MDUwLjE3MTE4ODMyNzM._gaNDQyMjE1MDE5LjE3MTE4ODMyNzQ._ga_XJWPQMJYHQ*MTcxOTIxOTEwMy4xMS4xLjE3MTkyMjEwMTAuNjAuMC4w) 下载 Docker。
* 您的机器满足软硬件要求。详细信息，参考 [软硬件要求](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500194)。

## 部署 OceanBase 数据库

### （可选）步骤一：拉取 OceanBase 数据库镜像

运行如下命令，拉取 OceanBase 数据库所需镜像。

* 搜索 OceanBase 数据库相关镜像

  ```
  [admin@test001 ~]$ sudo docker search oceanbase
  ```
* 拉取 OceanBase 数据库最新镜像

  ```
  [admin@test001 ~]$ sudo docker pull oceanbase/oceanbase-ce
  ```

  #### 说明

  + 若拉取 Docker 镜像失败，您也可从 quay.io 或者 ghcr.io 仓库中拉取镜像，只需将上述拉取命令中的 `oceanbase/oceanbase-ce` 对应替换为 `quay.io/oceanbase/oceanbase-ce` 或 `ghcr.io/oceanbase/oceanbase-ce`，如执行 `sudo docker pull quay.io/oceanbase/oceanbase-ce` 从 quay.io 中拉取镜像。
  + 本步骤命令中的仓库地址更换后，步骤二中的命令需同步替换仓库地址，两条命令所用仓库需保持统一。
  + 上述命令默认拉取最新版本，可根据实际需求在 [dockerhub](https://hub.docker.com/r/oceanbase/oceanbase-ce/tags)、[quay.io](https://quay.io/repository/oceanbase/oceanbase-ce?tab=tags) 或 [ghcr.io](https://github.com/oceanbase/docker-images/pkgs/container/oceanbase-ce)中选择版本。

### 步骤二：启动 OceanBase 数据库实例

运行如下命令，启动 OceanBase 数据库实例。

根据当前容器部署最大规格实例

部署 mini 的独立实例

使用快速启动模式部署实例

```
[admin@test001 ~]$ sudo docker run -p 2881:2881 -v $PWD/ob:/root/ob -v $PWD/obd/cluster:/root/.obd/cluster --name obstandalone -e MODE=NORMAL -e OB_TENANT_PASSWORD=***** -d oceanbase/oceanbase-ce
```

```
[admin@test001 ~]$ sudo docker run -p 2881:2881 -v $PWD/ob:/root/ob -v $PWD/obd/cluster:/root/.obd/cluster --name obstandalone -e MODE=MINI -e OB_TENANT_PASSWORD=***** -d oceanbase/oceanbase-ce
```

启动模式下，若配置租户和资源相关的环境变量，除 `OB_TENANT_PASSWORD` 和 `OB_SYS_PASSWORD` 外，其他变量均不生效。创建的用户租户名默认且只能为 `test`。

`shell dmin@test001 ~]$ sudo docker run -p 2881:2881 -v $PWD/ob:/root/ob -v $PWD/obd/cluster:/root/.obd/cluster --name obstandalone -e MODE=SLIM -d oceanbase/oceanbase-ce`

示例中的选项作用如下：

* `-p` 用于将容器的端口映射到宿主机端口，示例中是将容器中的 `2881` 端口映射到宿主机的 `2881` 端口。
* `-v` 用于在容器与宿主机之间共享文件或目录，实现数据持久化或配置共享。默认情况下，系统会在容器的 `/root/ob` 目录下部署 OceanBase 数据库，并在 `/root/.obd/cluster` 下保存其配置。您可使用该选项在宿主机上持久化数据。

  您也可使用 `-v` 选项挂载需要执行的 SQL 去执行，示例如下，您需将 `{init_sql_folder_path}` 修改为实际初始化 SQL 的文件路径。

  ```
  [admin@test001 ~]$ sudo docker run -p 2881:2881 -v {init_sql_folder_path}:/root/boot/init.d --name obstandalone -e MODE=SLIM -d oceanbase/oceanbase-ce
  ```
* `--name` 用于设置 Docker 容器名称，比如示例中创建一个名为 `obstandalone` 的 Docker 容器。
* `-e` 用于设置环境变量，示例中 `MODE` 用于设置 OceanBase 数据库的启动模式，`OB_TENANT_PASSWORD` 用于设置 OceanBase 数据库中 root@test 用户密码。详细的环境变量介绍可参见下文 [支持配置的环境变量](#支持配置的环境变量)。

#### 说明

Docker 启动时默认启用 `enable_rich_error_msg` 参数。如果发生错误，您可以使用 trace 命令获取详细的错误信息。

启动预计需要 2~5 分钟。执行以下命令，如果返回 `boot success!`，则表示启动成功。

```
[admin@test001 ~]$ sudo docker logs obstandalone | tail -1
boot success!
```

### 步骤三：连接 OceanBase 数据库实例

oceanbase-ce 镜像安装了 obd（OceanBase Deployer，OceanBase 安装部署工具）和 OBClient（OceanBase 命令行客户端）。您可选择进入容器，使用 obd 命令管理和 OBClient 客户端连接实例，也可使用宿主机本地 OBClient 或 MySQL 客户端连接到 OceanBase 数据库实例。

#### 进入容器后连接

1. 进入 Docker 容器

   ```
   [admin@test001 ~]$ sudo docker exec -it obstandalone bash
   ```
2. 查看集群详情

   ```
   # 查看集群列表
   obd cluster list
   # 查看 obcluster 集群详情
   obd cluster display obcluster
   ```
3. 连接集群

   ```
   obclient -h127.0.0.1 -uroot@sys -A -Doceanbase -P2881 -p
   ```

#### 使用宿主机本地客户端连接

您可选择使用宿主机本地 OBClient 或 MySQL 客户端连接到 OceanBase 数据库实例，示例如下：

```
[admin@test001 ~]$ obclient -uroot@sys -h127.0.0.1 -P2881 -p
```

#### 说明

若启动 OceanBase 数据库实例时未通过环境变量配置密码，实例中创建的用户默认使用空密码。

连接成功后，终端将显示如下内容：

```
Welcome to the OceanBase.  Commands end with ; or \g.
Your OceanBase connection id is 3221711319
Server version: OceanBase_CE 4.3.0.1 (r100000242024032211-0193a343bc60b4699ec47792c3fc4ce166a182f9) (Built Mar 22 2024 13:19:48)

Copyright (c) 2000, 2018, OceanBase and/or its affiliates. All rights reserved.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

obclient [(none)]>
```

### 支持配置的环境变量

| 变量名 | 默认值 | 取值说明 | 描述 |
| --- | --- | --- | --- |
| MODE | MINI | * `MINI`：表示容器将使用最少的资源启动集群。 * `NORMAL`：表示容器将尽可能使用容器的全部资源启动集群。 * `SLIM`：表示容器将只启动 OceanBase 数据库并使用快速启动模式。  说明 当 `MODE` 配置为 `SLIM` 时，若配置租户和资源相关的环境变量，除 `OB_TENANT_PASSWORD` 和 `OB_SYS_PASSWORD` 外，其他变量均不生效。 | 设置集群启动模式。 |
| EXIT\_WHILE\_ERROR | true | * `true`：无法启动 OceanBase 数据库时退出容器。 * `false`：无法启动 OceanBase 数据库时不退出容器，您可以登录容器进行调试。 | 控制当无法启动 OceanBase 数据库时是否退出容器。 |
| OB\_CLUSTER\_NAME | obcluster | 无 | 设置 OceanBase 集群名称。 |
| OB\_TENANT\_NAME | test | 最长 63 个字节，只能为大小写英文字母，数字和下划线，并且不能是 OceanBase 数据库的关键字。 | 配置后将在 OceanBase 集群中创建一个同名的 MySQL 租户，未配置的情况下会默认创建名为 `test` 的 MySQL 租户。 说明 当 `MODE` 配置为 `SLIM` 时，用户租户名默认且只能为 `test`，配置为其他值时不生效。 |
| OB\_MEMORY\_LIMIT | 6G | [6G, +∞) | 设置 OceanBase 集群可用的总内存大小，作用等同于其他两种方案中的 [memory\_limit](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502349) 配置项。 |
| OB\_DATAFILE\_SIZE | 5G | [5G, +∞) | 设置 OceanBase 集群中数据文件的大小，作用等同于其他两种方案中的 [datafile\_size](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502366)。 |
| OB\_LOG\_DISK\_SIZE | 5G | [5G, +∞) | 设置 OceanBase 集群中 Redo 日志磁盘的大小，作用等同于其他两种方案中的 [log\_disk\_size](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502202)。 |
| OB\_SYS\_PASSWORD | 默认为空 | 需设置为字符串，对字符串无要求 | 设置 OceanBase 集群中 sys 租户的管理员用户（root@sys）密码。 |
| OB\_TENANT\_PASSWORD | 默认为空 | 需设置为字符串，对字符串无要求 | 设置 OceanBase 集群中 `OB_TENANT_NAME` 对应租户的管理员用户密码，未配置 `OB_TENANT_NAME` 的情况下默认为 root@test 用户的密码。 |
| OB\_SYSTEM\_MEMORY | 1G | [1G, +∞) | 设置 OceanBase 集群中预留给租户 ID 为 `500` 的租户的内存容量，作用等同于其他两种方案中的 [system\_memory](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502296)。 |
| OB\_TENANT\_MIN\_CPU | 无 | 不涉及 | 设置 OceanBase 集群中 `OB_TENANT_NAME` 对应租户的最小 CPU 规格，未配置的情况下默认会占用 OceanBase 集群全部剩余资源。其作用等同于创建资源单元中的 `MIN_CPU`，创建资源单元的详细介绍可参见 [CREATE RESOURCE UNIT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501957)。 |
| OB\_TENANT\_MEMORY\_SIZE | 无 | 不涉及 | 设置 OceanBase 集群中 `OB_TENANT_NAME` 对应租户的内存规格，未配置的情况下默认会占用 OceanBase 集群全部剩余资源。其作用等同于创建资源单元中的 `MEMORY_SIZE`，创建资源单元的详细介绍可参见 [CREATE RESOURCE UNIT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501957) |
| OB\_TENANT\_LOG\_DISK\_SIZE | 无 | 不涉及 | 设置 OceanBase 集群中 `OB_TENANT_NAME` 对应租户日志盘空间的大小，未配置的情况下默认会占用 OceanBase 集群全部剩余资源。其作用等同于创建资源单元中的 `LOG_DISK_SIZE`，创建资源单元的详细介绍可参见 [CREATE RESOURCE UNIT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501957) |
| OB\_CONFIGSERVER\_ADDRESS | 无 | 不涉及 | 设置 obconfigserver 地址，示例: `http://10.10.10.1:8080`。 |