---
title: 使用 systemd 部署 OceanBase 数据库
description: 提供关于使用 systemd 部署 OceanBase 数据库的相关内容，
keywords: 使用 systemd 部署 OceanBase 数据库,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,本地部署,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 systemd 部署 OceanBase 数据库

本文介绍如何使用 systemd 部署及管理单节点 OceanBase 数据库。

#### 注意

本文档操作仅适用于学习或测试场景，请不要应用于生产环境。

## 前提条件

在执行本文操作前，您需确认以下信息：

* 您使用的环境是 RPM 平台系统，目前已验证支持的系统如下。

  + Anolis OS 8.X 版本（内核 Linux 4.19 版本及以上）
  + CentOS Linux 8.X 版本（内核 Linux 4.19 版本及以上）
  + Debian 10、11 和 12 版本（内核 Linux 4.19 版本及以上）
  + openEuler 22.03 和 24.03 版本（内核 Linux 5.10.0 版本及以上）
  + Ubuntu 18.04、20.04 和 22.04 版本（内核 Linux 4.19 版本及以上）
* 您环境中已安装 jq 命令行工具，并正确配置了 systemd 作为系统和服务管理器。
* 您环境中已安装数据库连接工具（MySQL 客户端或 OBClient 客户端）。
* 您计划部署的 OceanBase 数据库为 V4.2.2 或之后版本。
* 您使用的用户已具有执行 sudo 命令的权限。

## 部署 OceanBase 数据库

### 步骤一：安装 OceanBase 数据库

根据所用环境能否连接外部网络，分为在线安装和离线安装两种安装方法。

在线安装

离线安装

1. 添加 OceanBase 镜像源

   ```
   [admin@test001 ~]$ sudo yum-config-manager --add-repo https://mirrors.aliyun.com/oceanbase/OceanBase.repo
   ```
2. 安装 OceanBase 数据库

   ```
   [admin@test001 ~]$ sudo yum install oceanbase-ce oceanbase-ce-libs obclient
   ```

   该命令默认部署最新版本，您可通过声明版本号安装指定版本，如使用 `yum install oceanbase-ce-4.2.2.0` 命令安装 OceanBase 数据库 V4.2.2 版本，推荐安装最新版本。

1. 您可从 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 下载所需版本的 OceanBase 数据库及对应依赖库（`OceanBase Libs`）。下载完成后，将安装包复制到您的机器上。推荐您使用最新版本的安装包。
2. 在安装包所在目录下，执行 rpm 命令安装 OceanBase 数据库。

   ```
   [admin@test001 ~]$ rpm -ivh oceanbase-ce-*.rpm
   ```

### 步骤二：启动 OceanBase 数据库

安装 OceanBase 数据库后，您可参照如下步骤启动 OceanBase 数据库。

1. （可选）修改配置文件

   您可参照该步骤修改配置文件，未修改的情况下将使用配置文件中的默认配置进行部署。

   ```
   [admin@test001 ~]$ vim /etc/oceanbase.cnf
   ```

   该文件包含的配置项内容如下：

   ```
   mysqlPort=2881
   rootPwd=""
   redoDir=/var/lib/oceanbase/redo
   dataDir=/var/lib/oceanbase/data
   datafile_size=2G
   cpu_count=16
   memory_limit=6G
   system_memory=1G
   log_disk_size=13G
   ```

   #### 说明

   * 您可在该配置文件中添加其他配置项，详细配置项的介绍可参见 [配置项总览](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500146)。
   * 目前 OBServer 节点的 IP（默认为 `127.0.0.1`）和 Zone（默认为 `zone1`）不支持修改。

   配置文件中的配置项介绍如下表：

   | 配置项 | 是否必选 | 默认值 | 说明 |
   | --- | --- | --- | --- |
   | mysqlPort | 可选 | 2881 | OceanBase 数据库 SQL 服务协议端口号。 |
   | rootPwd | 可选 | 默认为空 | OceanBase 集群的超级管理员（`root@sys`）的密码，建议设置复杂的密码。 |
   | redoDir | 可选 | /var/lib/oceanbase/redo | clog、ilog 和 slog 的目录，建议配置为独立的磁盘。 |
   | dataDir | 可选 | /var/lib/oceanbase/data | 设置存储 SSTable 等数据的目录，建议配置为独立的磁盘。 |
   | datafile\_size | 可选 | 0 | 指定对应节点数据文件（block\_file）大小，未配置的情况下以 `datafile_disk_percentage` 配置项为准，详细介绍请参见 [datafile\_size](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502366) 和 [datafile\_disk\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502193)。 |
   | cpu\_count | 可选 | 0 | OceanBase 数据库可使用的 CPU 总数，如果设置为 0，将自动检测。 |
   | memory\_limit | 可选 | 0 | observer 进程能从环境中获取的最大内存，未配置的情况下以 `memory_limit_percentage` 配置项为准，配置项详细介绍请参考 [memory\_limit](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502349) 和 [memory\_limit\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502268)。 |
   | system\_memory | 可选 | 0M | 保留的系统内存，该参数值会占用 `memory_limit` 的内存，未配置的情况下 OceanBase 数据库会自适应。 |
   | log\_disk\_size | 可选 | 0 | 用于设置 Redo 日志磁盘的大小，未配置的情况下以`log_disk_percentage` 配置项为准，详细介绍请参考 [log\_disk\_size](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502202) 和 [log\_disk\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502279)。 |
2. 启动 OceanBase 数据库

   ```
   [admin@test001 ~]$ sudo systemctl start oceanbase
   ```

### 步骤三：连接 OceanBase 数据库

此处以通过 OBClient 连接 OceanBase 数据库为例，命令如下：

```
[admin@test001 ~]$ obclient -h127.0.0.1 -uroot@sys -P2881 -p -A oceanbase
```

参数说明：

* -h：提供 OceanBase 数据库连接 IP，使用 systemd 启动的 OceanBase 数据库默认 IP 为 `127.0.0.1`。
* -u：提供 OceanBase 数据库的连接账户，格式：`用户名@租户名`。MySQL 租户的管理员用户名默认是 `root`。
* -P：提供 OceanBase 数据库连接端口，使用 systemd 启动的 OceanBase 数据库默认端口是 `2881`。
* -p：提供 OceanBase 数据库连接密码，建议不在连接命令中提供，改为在执行命令后的提示符下输入，密码文本不可见。
* -A：表示在 OBClient 连接数据库时不自动获取统计信息。
* oceanbase：访问的数据库的名称，可以更改为业务数据库名。

## 管理 OceanBase 数据库

目前仅支持通过 systemd 对 OceanBase 数据库进行启动（start）、停止（stop）以及查看状态（status）操作。

* 查看 OceanBase 数据库状态

  ```
  [admin@test001 ~]$ sudo systemctl status oceanbase
  ```

  查看 OceanBase 数据库状态有如下几种情况：

  + `Active` 展示为 `active (running)`，且 `Status` 展示为 `Service is running` 时，表示 OceanBase 数据库正在启动中。
  + `Active` 展示为 `active (running)`，且 `Status` 展示为 `Service is ready` 时，表示已成功启动 OceanBase 数据库。
  + `Active` 展示为 `inactive (dead)`，表示服务已经停止，即 OceanBase 数据库已停止。
  + `Active` 展示为 `failed`，表示服务发生了错误，需查看日志进行排查。
* 停止 OceanBase 数据库

  ```
  [admin@test001 ~]$ sudo systemctl stop oceanbase
  ```
* 卸载 OceanBase 数据库

  卸载 OceanBase 数据库前建议先停止 OceanBase 数据库，之后执行如下步骤卸载 OceanBase 数据库。

  1. 删除 OceanBase 数据库软件包

     在线安装方式下，您可执行如下命令：

     ```
     [admin@test001 ~]$ sudo yum erase package
     ```

     `package` 需替换为待删除的软件包名，您可通过 `yum list | grep oceanbase` 命令查看软件包名。

     离线安装方式下，您可执行如下命令：

     ```
     [admin@test001 ~]$ sudo rpm -e package
     ```

     `package` 需替换为待删除的软件包名，您可通过 `rpm -qa | grep oceanbase` 命令查看软件包名。
  2. （可选）删除 OceanBase 数据库数据

     执行第一步后，您环境中的 OceanBase 数据库已被卸载，但是 OceanBase 数据库的数据还存在。若您之后重新部署 OceanBase 数据库，还可以查看和操作该 OceanBase 数据库的数据。

     执行本步骤删除 OceanBase 数据库数据后，您部署的 OceanBase 数据库将完全被卸载。

     删除 OceanBase 数据库安装目录

     ```
     [admin@test001 ~]$ rm -rf /home/admin/oceanbase
     ```

     删除 OceanBase 数据库数据目录

     ```
     [admin@test001 ~]$ rm -rf /var/lib/oceanbase
     ```

## 相关文档

* 您可登录集群执行 `ALTER USER` 命令修改用户密码，命令详细介绍请参见 [ALTER USER](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001503272)。
* 部署 OceanBase 数据库后，更多连接 OceanBase 数据库的详细介绍可参见 [连接 OceanBase 数据库](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499955)。