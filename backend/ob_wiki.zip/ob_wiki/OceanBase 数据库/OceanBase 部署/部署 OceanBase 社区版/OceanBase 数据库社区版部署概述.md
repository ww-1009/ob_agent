---
title: OceanBase 数据库社区版部署概述
description: 提供关于OceanBase 数据库社区版部署概述的相关内容，
keywords: OceanBase 数据库社区版部署概述,OceanBase 数据库,OceanBase 部署,部署 OceanBase 社区版,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# OceanBase 数据库社区版部署概述

OceanBase 数据库社区版支持多种部署方式：

* 如果想要快速部署单机版的 OceanBase 进行功能体验，可以参考快速部署部分。
* 如果想要在生产环境中进行标准化部署，可以参照标准部署部分。
* 如果想要进行在线体验，可以参考在线体验部分。

## 快速部署

* 对于非原生支持的操作系统（比如 MAC 和 Windows），建议使用 Docker 镜像的方式进行部署；具体操作参见 [部署 OceanBase 数据库容器环境](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001937353)。
* 对于原生支持的操作系统（Linux 系列，具体见支持的操作系统列表），建议使用 obd 进行部署；具体操作参见官网《OceanBase 安装部署工具》文档 [快速上手/快速启动 OceanBase 数据库](https://www.oceanbase.com/docs/community-obd-cn-1000000001477792)。

## 标准部署

* 对于线上环境，建议使用 obd 进行标准部署；具体操作参见 [通过 obd 白屏部署 OceanBase 集群](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502653)。
* 对于 kubernetes 环境，建议使用 ob-operator 的方式部署；具体操作参见 [在 Kubernetes 集群中部署 OceanBase 数据库](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499737)。

## 在线体验

对于需要在线体验的用户，可以登录 [OceanBase 体验站](https://www.oceanbase.com/demo/deploy-a-oceanbase-ce-single-node-cluster) 进行功能体验。