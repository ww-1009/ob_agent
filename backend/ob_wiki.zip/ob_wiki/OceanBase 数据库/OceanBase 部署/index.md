# 分类索引：OceanBase 部署

> 位置：[ob_wiki](../../index.md) / [OceanBase 数据库](../index.md) / OceanBase 部署 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **部署 OceanBase 企业版** | 下设 部署前准备、使用命令行部署、使用图形化界面部署，共 3 个子分类。 | `部署 OceanBase 企业版` `部署前准备` `使用命令行部署` `使用图形化界面部署` | [进入目录](./部署 OceanBase 企业版/index.md) |
| **部署 OceanBase 社区版** | 下设 本地部署，共 1 个子分类。 | `部署 OceanBase 社区版` `本地部署` | [进入目录](./部署 OceanBase 社区版/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OceanBase 集群高可用部署方案简介.md](./OceanBase 集群高可用部署方案简介.md) | 提供关于OceanBase 集群高可用部署方案简介的相关内容， | OceanBase 集群高可用部署方案简介,OceanBase 数据库,OceanBase 部署,文档,使用帮助,OceanBase,分布式,数据库 |
| [部署概述.md](./部署概述.md) | 提供关于部署概述的相关内容， | 部署概述,OceanBase 数据库,OceanBase 部署,文档,使用帮助,OceanBase,分布式,数据库 |
| [清理旧集群.md](./清理旧集群.md) | 提供关于清理旧集群的相关内容， | 清理旧集群,OceanBase 数据库,OceanBase 部署,文档,使用帮助,OceanBase,分布式,数据库 |
