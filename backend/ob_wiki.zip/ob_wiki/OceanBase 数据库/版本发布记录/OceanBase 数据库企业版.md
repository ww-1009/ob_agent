---
title: OceanBase 数据库企业版
description: 提供关于OceanBase 数据库企业版的相关内容，
keywords: OceanBase 数据库企业版,OceanBase 数据库,版本发布记录,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-09-07T09:01:45.000+00:00
---

# OceanBase 数据库企业版

本文主要介绍 OceanBase 数据库企业版所有版本的发版说明。

## V5.0.1

[**点击查看 V5.0.1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V5.0.1)

**版本信息：**

* 发布时间：2026 年 07 月 24 日
* 版本号：V5.0.1
* 分布式 RPM 版本：oceanbase-5.0.1.0-1000000220260724
* 单机版 RPM 版本：oceanbase-standalone-5.0.1.0-1000000220260724

**版本概览：**

OceanBase 数据库 V5.0.1 是 OceanBase 数据库 V4.6.0 的延续版本，持续对数据库的能力进行完善，其中包括：

* DDL 能力增强：

  + 新增支持加列、删列以及分区操作的并行 DDL。
  + 支持列存转行存、行列混存转行存的延迟在线 DDL，从而完善了行存、列存以及行列混存三种存储格式的相互 Online 转换。
  + 新增支持表模式（`partial_update`、`delete_insert` 和 `append_only`）在线切换；且增强了 Compaction TTL 能力，支持定义用户列为 TTL 列，且支持 `partial_update` 表定义 TTL 属性，能覆盖更多的业务场景。
  + 新增支持创建随机分布表，在数据写入时自动均匀打散到集群各节点，无需用户自定义分区，系统会自动切换，提升易用性。
* 负载均衡能力的增强：新增支持 Zone 级表组和 `SUBPARTITION` 表组，更多维度的控制分区的聚集和均衡策略。
* 对物化视图功能从监控诊断、增量刷新性能和使用易用性以及功能稳定性全方面做了能力提升。
* 兼容性维度上对 Oracle 的语法、函数、表达式等做了进一步的增强。
* 提供了 Database 级资源隔离（CPU/IO）的能力，允许将每个 Database 映射到独立的资源组，实现 CPU 和 IO 的细粒度隔离。

## V4.6.0

### V4.6.0 Hotfix4

[**点击查看 V4.6.0 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.6.0)

**版本信息：**

* 发布时间：2026 年 07 月 13 日
* 版本号：V4.6.0 Hotfix4
* 分布式 RPM 版本号：oceanbase-4.6.0.0-100040012026070914

**关键缺陷修复：**

* 修复 VSAG SetImmutable 后，未释放锁内存的问题。
* 修复备份操作时，系统可能出现错误码 -9120 的问题。
* 混合搜索场景下的向量查询功能接入 Query Profile 机制。
* 修复内存爆，DASTokenOpH 模块占用 6G+ 的问题。
* 修复混合搜索查询 rescan 时没有切 LS id，可能导致查询卡住超时的问题。
* 修正 `hybrid_search_partition_path` 参数的生效逻辑。
* 修复混合搜索 bq snap 和 active segment 都存在场景召回率的问题。
* 混合搜索放开 point get 优化路径，提供 search options 配置。
* 修复 LS 销毁，向量资源清理适配的问题。
* 修复混合搜索接口返回空的问题。

### V4.6.0 Hotfix3

[**点击查看 V4.6.0 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.6.0)

**版本信息：**

* 发布时间：2026 年 06 月 17 日
* 版本号：V4.6.0 Hotfix3
* 分布式 RPM 版本号：oceanbase-4.6.0.0-100030012026061216

**关键缺陷修复：**

* 修复索引查找时在数据表中未找到对应行的问题。
* 修复在 `check_when_is_match` 处发生 observer 崩溃的问题。
* 修复重建全文索引正交删表在清理阶段的问题。
* 修复预过滤场景返回查询结果 0 的问题。
* 修复在 `prepare_insert_iter` 处发生 observer 崩溃的问题。
* 修复向量索引冻结与持久化频繁失败的问题。
* 修复添加 `filter` 条件执行慢的问题。
* 修复因搜索索引导致合并卡住的问题。

### V4.6.0 Hotfix2

[**点击查看 V4.6.0 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.6.0)

**版本信息：**

* 发布时间：2026 年 06 月 11 日
* 版本号：V4.6.0 Hotfix2
* 分布式 RPM 版本号：oceanbase-4.6.0.0-100020012026061020

**关键缺陷修复：**

* 修复在执行排序操作时，`add_heap_sort_row` 函数发生崩溃的问题。
* 修复 500 租户模块 CommonArray 膨胀的问题。
* 修复 **向量 + term + limit100** 在 10p 和 30p 时候 RT 差距大的问题。
* 修复分区表向量混合搜索 search option 设置 pre-knn 走暴力搜索的问题。
* 修复 TTL Lock 行报主键冲突的问题。
* 修复未提交行不能使用 rowscn skip index 的问题。
* 修复在执行 HNSW 索引相关操作时，`get_index_number` 函数发生崩溃的问题。
* 修复稀疏向量索引 sindi 创建报错 7604 的问题。
* 修复默认转义符为空的版本控制问题。
* 修复创建 text-embedding-v4 模型的语义向量，执行 refresh index 报错 4016 的问题。
* 修复 dbeaver 客户端工具非分区表后建全文索引报错 4016 的问题。
* 修复 SINDI 索引创建失败报错 4013 的问题。
* 优化升级脚本。
* 修复 knn+json\_overlaps 的大小账号场景，90% 选择率，查询秒级的问题。
* 修复 HNSW 前过滤结果不稳定的问题。
* 修复 `do_close` 方法发生崩溃的问题。
* 修复混合搜索多路 knn 场景，不同 knn 路使用不同的向量列，不同向量列纬度不同，查询报错 4016 的问题。

### V4.6.0 Hotfix1

[**点击查看 V4.6.0 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.6.0)

**版本信息：**

* 发布时间：2026 年 04 月 20 日
* 版本号：V4.6.0 Hotfix1
* 分布式 RPM 版本号：oceanbase-4.6.0.0-100010032026041710

**关键缺陷修复：**

* 修复混合搜索 dsl 没有走到分区裁剪，和普通 SQL 查询 RT 有数量级差距。
* 修复全文索引多分区表 select index 失败的问题。
* 修复混合搜索 filter 查询会算分与 es 不符合的问题。
* 修复 VecIdxTask 模块疑似泄漏的问题。
* 修复 AI Function 支持图片 && 支持并发的问题。
* 修复调用 AI\_EMBED 函数时引发 observer 进程崩溃的问题。
* 修复向量索引构建过程中序列化操作引发 observer 进程崩溃的问题。
* 修复 `UPDATE` 语句因列投影偏移触发防御性错误的问题。

### V4.6.0

[**点击查看 V4.6.0 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.6.0)

**版本信息：**

* 发布时间：2026 年 4 月 10 日
* 版本号：V4.6.0
* RPM 版本号：oceanbase-4.6.0.0-100000132026040922

**版本概述：**

OceanBase 数据库 V4.6.0 是一次面向现代化与 AI 数据处理的重要升级。其核心在于全面增强智能数据能力，推出原生 SQL 混合搜索接口，支持向量、全文与标量的多模态融合查询，并优化向量索引，构建端到端的 RAG 解决方案。同时，它显著提升 HTAP 混合负载性能，实现列存副本智能路由与强一致读，并优化并行执行引擎。在企业级基础上，通过 PL 引擎优化、无侵入列加密、缓存认证机制以及智能运维能力增强，为关键业务提供了一个更高效、可靠与智能的一体化数据平台。

## V4.5.0

[**点击查看 V4.5.0 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.5.0)

**版本信息：**

* 发布时间：2025 年 11 月 26 日
* 版本号：V4.5.0
* RPM 版本号：oceanbase-4.5.0.0-100000172025112420

**版本概述：**

OceanBase V4.5.0 是面向 AI 场景的敏捷迭代版本，对内核 AI 能力进行了大的升级。新版本从构建、查询、DML 和易用性四个维度对 IVF\_FLAT/IVF\_PQ 索引进行了全面优化。同时支持了内存稀疏向量索引，提供更加优异的稀疏向量检索性能。新版本的混合搜索能力也得到了大幅增强，支持了多路向量的混合搜索，并支持多路向量查询结果集采用加权方式进行融合重排。同时基于内置的 Embedding 能力，新版本支持用户基于文本列创建语义索引，简化用户使用向量索引的流程。

此外，新版本在 Oracle 租户模式下支持了 INTERVAL 分区功能，降低了分区管理的复杂性。新版本对 Index Skip Scan 功能的性能和稳定性做了提升，并默认打开了该功能。

## V4.4.2

### V4.4.2 BP2 Hotfix1

[**点击查看 V4.4.2 BP2 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.4.2)

**版本信息：**

* 发布时间：2026 年 07 月 15 日
* 版本号：V4.4.2 BP2 Hotfix1
* RPM 版本号：oceanbase-4.4.2.2-102010032026071509

**版本概述：**

* Fixed the merge verification failure issue caused by incorrect LZ4 compression package version invocation.
* Fixed the query range extraction error issue with the NVL function.
* Fixed the core dump issue during SPM evolution.
* Support convert union to values in ps.
* Added support for the DBMS\_XMLDOM.getFirstChild function.
* Array now supports long text type elements - removed the 16MB size limit for arrays.

### V4.4.2 BP2

[**点击查看 V4.4.2 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.4.2)

**版本信息：**

* 发布时间：2026 年 06 月 30 日
* 版本号：V4.4.2 BP2
* RPM 版本号：oceanbase-4.4.2.2-102000172026063016

**版本概述：**

OceanBase V4.4.2 BP2 为 V4.4.x 系列的稳定补丁版本，聚焦高可用架构完善、企业级兼容性扩展及大规模场景性能优化。高可用领域正式支持主备库强同步（RPO=0），新增最大保护与最大可用两种保护模式，并引入延迟备库能力以降低误操作传播风险；同步链路可观测性通过 per-LS 粒度监控视图与历史位点快照得到显著增强。数据同步架构实现重大升级，OBCDC 优化 UPDATE 拆分合并逻辑以保障下游 CDC 语义一致性。Oracle 兼容性扩展至 UDT 列类型、全文检索（CTXSYS.CONTEXT）、XML DOM 及模板/非模板混合分区等关键能力；MySQL 模式新增全角转半角函数。同时，两种模式共同引入 `caching_sha2_password` 认证插件，支持基于 SHA-256 的强认证与认证结果缓存，在安全性与连接性能间取得平衡。SQL/PL 执行层优化覆盖硬解析内存管理、Plan Cache 诊断、JSON/Trigger 性能及全局索引访问路径；存储管理强化包括备份数据完整性校验、归档启停性能优化及回收站任务调度精细化。物化视图模块重构异步刷新调度框架，支持并发控制与任务取消能力，并简化增量刷新定义门槛。基础设施层面引入 Python UDF 沙箱隔离、分库分表 Outline 自动绑定及仲裁服务实时监控视图，全面提升了系统的可运维性与生产环境稳定性。

### V4.4.2 BP1

[**点击查看 V4.4.2 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.4.2)

**版本信息：**

* 发布时间：2026 年 04 月 20 日
* 版本号：V4.4.2 BP1
* RPM 版本号：oceanbase-4.4.2.1-101000192026041623

**版本概述：**

V4.4.2 BP1 是 V4.4.2（LTS 版本）的首个 BP 版本，在原有支持 V4.2.5 BP7 平滑升级至 V4.4.2 的基础上，新增支持 V4.3.5 BP6 平滑升级至 V4.4.2 BP1。该版本面向 TP/AP 业务，补充了多项关键特性，进一步提升系统性能与稳定性。

### V4.4.2

[**点击查看 V4.4.2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.4.2)

**版本信息：**

* 发布时间：2026 年 02 月 10 日
* 版本号：V4.4.2
* RPM 版本号：oceanbase-4.4.2.0-100000252026020915

**版本概述：**

OceanBase V4.4.2 是面向混合负载的 TP/AP 大融合 LTS 版本，深度集成 4.2.5 LTS 的事务处理能力与 4.3.5 LTS 的分析处理能力，在数据管理、兼容性、系统安全和运维诊断等多维度系统性增强内核能力，为关键交易负载与复杂分析负载提供更强大、更稳定的技术支撑。

在 **TP 场景**下，新版本支持二级分区表的一级分区与普通一级分区表进行交换，极大简化大规模数据分区管理和数据重组；重构 Oracle 模式全局临时表，显著提升临时表性能；新增 MySQL 模式 Session 级私有临时表，完善临时表体系。OBCDC 支持表级恢复后的增量数据同步，并支持同步 virtual 生成列，更好地满足下游系统对表级增量数据和生成列的消费需求。

在 **AP 场景**下，V4.4.2 对物化视图进行了全方位增强，包括 DDL 操作支持、增量刷新能力优化、嵌套物化视图级联刷新、以及基于无主键表的物化视图等，显著提升查询性能和数据分析灵活性。新增支持以 V1.4.7、2.x、3.x 逻辑备份和物理备份作为数据源导入 4.x 集群，拓展跨版本数据迁移与导数能力；支持自动创建分区的 INTERVAL 分区和 MySQL Union Distinct RCTE，进一步增强 Oracle/MySQL 语法与行为兼容性。同时，扩展 Oracle 模式下的空间几何函数，更好满足 GIS 及空间分析应用需求。

在 **KV 场景**下，持续完善 OBKV 能力，新增弱读、TTL 支持索引扫描、热 Key 查询优化等特性，并完成对 OBKV‑HBase 监控项的治理，在高并发 KV 与时序场景下提供更低时延与更强可观测性。

在 **性能**方面，V4.4.2 面向细分场景进行了专项优化：串行建表性能在同等场景下提升约 60%；优化 PL 中 UDF、Trigger 等执行路径并支持事务异步提交，有效提升业务逻辑处理效率。针对国产化大规格 CPU 环境，PDML 性能提升约 25%，复制表 Follower 查询性能提升约 14 倍，逼近 Leader 查询能力，显著增强系统横向扩展能力。同时，引入 PX 自适应任务切分机制，自动识别并切分长尾任务，实现并行查询负载重均衡，加速查询完成。

在 **安全与运维诊断**方面，新版本支持业务无感知列加密和 Clog 日志 TDE 加密，从数据到日志构建更牢固的安全防线；同时优化死锁检测机制，增强 Active Session History (ASH) 数据完整性，并重构 SQLSTAT 统计信息，为数据库管理员定位性能瓶颈和异常 SQL 提供更精细、更可靠的诊断工具。

**V4.4.2 作为 LTS 版本，推荐 TP、AP 和 HTAP 业务使用。**

## V4.4.1

[**点击查看 V4.4.1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.4.1)

**版本信息：**

* 发布时间：2025 年 09 月 26 日
* 版本号：V4.4.1
* RPM 版本号：oceanbase-4.4.1.0-100000242025092415

**版本概述：**

OceanBase V4.4.1 作为存算分离架构的第二个 LDS 版本，在多个维度实现了显著提升。在**共享存储架构**方面，进一步增强日志服务能力，支持水平扩缩容以支撑大量日志流的写入负载。SYS 租户支持单副本部署，解决了额外资源占用问题的同时简化运维。新增 Azure Blob 支持，扩展多云部署能力。OBKV-HBase 也针对共享存储模式进行了专项性能优化。

V4.4.1 版本也对**向量检索能力**进行了升级，支持 Hybrid Search 混合检索，提升召回效果。新增 AI function 能力，支持 SQL 访问大模型。此外通过适配 ARM 架构、无主键表优化、IVF 索引优化等手段进一步提高向量检索的性能。新增视图展示向量索引内存占用和异步任务状态，提升易用性。

V4.4.1 版本全面优化外表查询、旁路导入、存储层读写、PL 硬解析、UDF 执行、SQL 硬解析、Batch DML 及 DDL 性能。PL 硬解析耗时降低 14%，UDF 性能提升 15%-26%，旁路导入排序算法升级显著提升导入效率。

在兼容性方面，V4.4.1 版本在 MySQL 租户模式新增 Python UDF。在 Oracle 租户模式下，支持了 UTL\_HTTP 系统包及 DBMS\_PLSQL\_CODE\_COVERAGE 系统包。在**安全**方面，支持了 RPC 传输加密支持国密以及 TLS 免密登录能力。

V4.4.1 版本支持手动备份数据清理、设置执行备份任务的节点范围、消费归档日志适配强关归档场景。此外支持了 HMS Catalog、OBCDC 支持同步备租户、LOB 大对象的前镜像输出、外表支持 JDBC 插件、备库支持 flashback 接入新主库、SQL 关键字限流、Database 级负载均衡、基于 I/O 负载的自适应仲裁等关键能力。

## V4.4.0 Beta

[**点击查看 V4.4.0 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.4.0)

**版本信息：**

* 发布时间：2025 年 07 月 08 日
* 版本号：V4.4.0
* RPM 版本号：oceanbase-4.4.0.0-100000562025070723

**版本概述：**

OceanBase 数据库重磅推出 V4.4.0 版本，同时支持 Shared-Nothing 与 Shared-Storage 两种部署形态，是 OceanBase 面向多云、AI 时代的重大架构升级。Shared-Storage 形态下，计算节点和数据存储完全分离，存储可按需购买，计算节点可灵活扩缩容，从而实现极致的资源弹性与成本优化，并支持 AP、TP、KV 全产品形态。基于存算分离架构，OceanBase 开创性地实现了独立的日志服务 LogService，不仅数据共享日志也能共享，OBServer 变成真正意义上的无状态的计算引擎，可独立快速扩缩容，也解决了单副本跨 AZ 容灾的难题。存算分离架构下，全模块协同优化，支持了增量数据共享、本地数据缓存、Transfer、列存等能力，保证 Shared-Storage 与 Shared-Nothing 架构相当的功能、性能及更强的高可用能力。此外，新版本内核还支持了全文短语精确匹配、扩展了 JAVA UDF 功能、打通数据归档 HDFS 的路径 ，并优化了外表查询、UDF 执行、PS Cursor Fetch 数据的性能 ，增强了 CSV 导入诊断能力、支持 RPC IO 线程配置项动态生效等，提升系统易用性。

## V4.3.5

### V4.3.5 BP6 Hotfix5

[**点击查看 V4.3.5 BP6 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 08 月 25 日
* 版本号：V4.3.5 BP6 Hotfix5
* 分布式 RPM 版本号：oceanbase-4.3.5.6-106050032026082419
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.6-106050022026082419

**关键缺陷修复：**

* Fix SQLERRM and PL exception messages respect `enable_ob_error_msg_style`.
* Fix crash when handling JSON type params in PS protocol.
* Fix nested-aggregate rewrite for hierarchical queries.
* Fix node crash.
* Add configuration items for RPC link allocation diagnostic objects.
* Add max pl block time for purge spm.
* Fix ROUND real result metadata in MySQL mode.
* `compress_reserve_size` rely on `syslog_disk_size`.
* Fix topn sort dump failure when no rows received yet.
* Fix `implicit_commit_before_cmd_execute` remove `clean_dblink_conn`.
* Avoid concurrent mlog purge after scheduler timeout.
* Optimize add time interval control for tenant stopped log.
* Opt `ob_tc`.
* Fix the issue of SPM evolution selecting the wrong plan due to statistical errors in secondary routing scenarios.
* Fix negative value in the `LOCAL_PARALLEL_SESSION_COUNT` field in `GV$OB_PX_TARGET_MONITOR`.
* Fix ddl hint not add database name.
* Don't default retry three times for `OB_ERR_TRUNCATED_WRONG_VALUE_FOR_FIELD`.
* Fix remove useless tenant info fetching to avoid circular dep in schema refresh.
* Fix `DELETED_UNRETRYABLE_ERROR` bug.
* Optimize recyclebin batch purge.
* Fix charset and coercibility compatibility issues.
* Fix hash collision of backup-mode MacroBlockId causing O(n^2) `do_copy_ids`.
* Fix dag\_net scheduling starvation with per-type reserved quota.
* Opt the partition selection algorithm for LS balance.
* Fix core when print reused index tree prefetcher.
* Fix the issue of performance statistics errors in SPM evolution switching plan.

### V4.3.5 BP6 Hotfix4

[**点击查看 V4.3.5 BP6 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 07 月 15 日
* 版本号：V4.3.5 BP6 Hotfix4
* 分布式 RPM 版本号：oceanbase-4.3.5.6-106040012026071317
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.6-106040012026071317

**关键缺陷修复：**

* Fix `json_query` empty path compatibility for legacy multi-value index schema.
* Fix empty char padding in Oracle mode.
* Fix TRUNCATE bug when input precision is `PRECISION_UNKNOWN_YET`.
* Fix schema guard session\_id is invalid issue.
* Fix implicit CAST vector format corruption in GROUP CONCAT DISTINCT.
* Fix query pushdown bug that causes error in dblink query.
* Disable creating global index when the table partition key is generated column of lob.
* Fix parallel udpate schema dep info table issue.
* Fix unpivot op reset\_skip misuse in buffered path leading to row leakage.
* Fix `FROM_UNIXTIME` scale deduction incorrect for implicit-cast NUMBER param with uninitialized scale.
* Remove foreign key stack check in table modify op for oracle mode.
* Fix optimize preducate pull-up.
* Hidden table has been deleted, fail to exit fulltext index build task.
* Bugfix let mview concurrent refresh fast fail.
* Modify the dynamic sampling output line count of mlog.
* Fix compound ddl bugs.

### V4.3.5 BP6 Hotfix3

[**点击查看 V4.3.5 BP6 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 06 月 09 日
* 版本号：V4.3.5 BP6 Hotfix3
* 分布式 RPM 版本号：oceanbase-4.3.5.6-106030012026060810
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.6-106030012026060810

**关键缺陷修复：**

* Fix JSON expression returns wrong result when json\_path is dynamic const in NLJ.
* Defer ObLSBackup{Meta,Data}DagNet `inner_init_before_run_` to first task.
* Fix literal number parsing in oracle mode.
* Fix spi\_cursor\_init cursor leak bug.
* Fix OR-expand multi-index plan wrongly rejected due to unprecise range exprs.
* Fix show\_trace bypass `sample_pct` when `ob_enable_show_trace` is on.
* Fix [oracle] union to values wrongly handle type for empty char.
* Optimize the performance of `get_difference` in `finish_transfer_task`.

### V4.3.5 BP6 Hotfix2

[**点击查看 V4.3.5 BP6 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 06 月 02 日
* 版本号：V4.3.5 BP6 Hotfix2
* 分布式 RPM 版本号：oceanbase-4.3.5.6-106020022026060115
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.6-106020012026060115

**关键缺陷修复：**

* Fix false positive error 4377 occurred when enable GTS optimization.
* Fix `start_replay_scn` calc when PalfBaseInfo is default placeholder.
* Correctness issue caused by the two lines of batch statements for update + lock.
* Update `progressive_merge_round` in all version upgrade processor.
* Fix desc view bug.
* Fix hidden table when multiple DDL in single stmt.
* Fix timeout when execute call/anonymous block in danymic sql.
* Fix 4377 bug when drop not null for mlog base table.
* Fix `GROUP BY` pushdown through cross join loses ON clause filter.
* Fix nvl range expr bug.
* Bugfix for rich format matching routine.
* Fix alter prefix column not null and case.
* Fix `spi_convert_objparam` with CHARACTER SET ANY\_CS.
* Resolve package-qualified name (db.pack) as label to avoid recursive namespace lookup.
* Fix backup plus archivelog with deleted ls issue.
* Optimizing synonym plan matching time consumption.
* Prune pull to local spf plan if parallel > 1 in fast refresh.
* Fix `archive_lag_target` not effective on rs archive checkpoint interval.
* Fix prune issue of optimizer.
* Fix old progress checker for major merge.
* Fix create ObSequenceRawExpr for `T_FUN_SYS_PL_SEQ_NEXT_VALUE` in expr factory.
* Fix missing empty column when `skip_blank_lines` is true.
* Bugfix utl\_recomp returned results before jobs completed.
* Fix 4016 for %rowtype and %type.

### V4.3.5 BP6 Hotfix1

[**点击查看 V4.3.5 BP6 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 04 月 30 日
* 版本号：V4.3.5 BP6 Hotfix1
* 分布式 RPM 版本号：oceanbase-4.3.5.6-106010042026042914
* 单机版 RPM 版本号：oceanbase-4.3.5.6-106010042026042914

**关键缺陷修复：**

* Fix handle sqc finish msg failure leads to px hang.
* Fix xml cast.
* Fix tuple locking issue for truncate.
* Fix incomplete context issue for resolver.
* Fix null vid not complete.
* Xpath filter bugfix.
* Fix xmltable in gbk cs type.
* Fix find\_in\_set result error when second param is dynamic const.
* Fix forbid PL composite exprs pushdown.
* Fix refcursor default value.
* Fix transformer issue for limit (pushdown through join).
* Split long transactions in `rebuild` to avoid subsequent long transaction alerts and prolonged resource consumption.
* Fix refresh error -4002.
* Fix TLD\_OriAccess out of memory.
* Support materialized views without base table and fix mysqltest.
* Add checker for `alloc_object`.
* Modify the scheduling behavior of MV, schedule every time, and check if there is already a task when refreshing.
* Fix the program CRASH caused by plan cache plan eviction.
* Fix hnsw remote das.
* Fix core about udf deterministic cache.
* Update vsag to 0.15.11
* Adjust `max_run_duration` for mview/mlog schedual job.
* Fix the sharp drop in the IVF brute search recall rate in `LATENCY_FIRST` mode.
* Fix memdata sync wrong execute when ddl execute.
* Fix user define vars in subplan scan result diff with mysql.
* Fix unit GC causing client disconnections.
* Fixed the LOB Locator invalidation issue, added protection against cross-cluster LOB access.
* Fix group by pushdown with lob column.
* Disable 4377 check in inner sql of foreign key.
* Disable streaming plans for complex connections.
* Fix delete tenant memory leak.
* Fix bypass 4377 check for foreign key lookups.
* Fix for pseudo columnref pushdown groupby aggr bug.
* Fix memory leak for vector index memdata sync.
* Fix the issue where the mutually exclusive logic of backend tasks affects non hnsw tasks.
* Create table like path support domain index.
* Add tx share limit adaptive adjustment.
* Fix pl cache check synonym issue.
* Fix the issue of scheduling zombie tasks that cannot be recovered.
* Fix the implementation bug in the plan cache LRU eviction policy.
* Bugfix fix a core caused by TriggerHandle::init\_param\_new\_row.
* Fix unstable mview complete refresh mysqltests.
* Fix redo\_dispatch flow\_controll issue.
* Fix some changeuser bugs.
* Add vec\_approx to choose the appropriate avaliable local index and refine vec\_adaptive\_try\_path by quey range.
* Fix check create vector index on column table issue when upgrade.
* Allow tenant worker processing mysql requests and responsing error packet during tenant kill session.
* Add mysql test for csv crash.
* Support batch renew location cache in compile stage.
* Change the owner of mv refresh job, and ignore index check for min/max mv.
* Fix ObMPQuery::deserialize\_com\_field\_list core bug.

### V4.3.5 BP6

[**点击查看 V4.3.5 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 04 月 09 日
* 版本号：V4.3.5 BP6
* 分布式 RPM 版本号：oceanbase-4.3.5.6-106000032026040817
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.6-106000032026040817

**关键缺陷修复：**

* Fix CSV schema inference crash on malformed line delimiters.
* Fix ddl failed on table with mv that contains hidden column.
* Check memstore and vector memory by new rpc instead of inner sql.
* Fix package var sync in mysql mode.
* Align OBKV temporal scale handling with SQL truncation/round behavior.
* Fix left to anti replace part expr cause 4016.
* Fix ObSPIService::get\_result flush\_buffer when rend query result to client.
* Improve truncate table/partition compound with transfer.
* Fix hash join crash in nestloop mode and left output join.
* BugFix dblink hang caused by connection cleanup during commit.
* BugFix after statement trigger not triggered for RETURNING DML.
* Insert view change oracle mode check dup base col rule.
* Release scan resource for cached lob meta iterator.
* Fix insertup does not use get.
* Fix resolver issue for rowid.
* Check decimalint length before data written.
* Add sys variable json\_float\_full\_precision to control parse json float precision.
* Fix oracle json\_merge\_patch expr core.
* Refine join output rowcnt.
* Tablegroup sharding='NONE' is invalid when add new partition.

### V4.3.5 BP5 Hotfix7

[**点击查看 V4.3.5 BP5 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 03 月 18 日
* 版本号：V4.3.5 BP5 Hotfix7
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105070022026031722
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105070022026031722

**关键缺陷修复：**

* Fix hash join not skip left null.
* Fix inner path reverse scan issue.
* Fix ensure privilege check is performed correctly in CTE.
* Remove const column in skyline interesting order dim.
* Fix the issue where mismatched LOB character lengths cause error 4016.
* Fix goto stmt add close local cursor variable.
* Fix `__all_virtual_dml_stats` in sys tenant return dup rows.
* Disable expansion plan in `auto` mode if aggregate param exists in rollup list.
* BugFix decimal\_int in PL dblink.
* Bugfix disable pushdown limit to rcte.
* Fix session gtt data not clean while session disconnected.
* Fix different logic ids between multiple replicas.
* Fix missing table alias name when building rowid expr.
* Fix co merge dag schedule problem.
* Fix add compute plan type for for-update operator.
* Offline ddl hold snapshot.
* Fix use global index refine min/max too slow.
* Skip permission checks in connectivity verification during backup cleanup.
* Fix gather online stat cause -6005 conflict.
* Fix cursor fetch sql\_audit does not record -4026.
* Add noinline for window funtion and sort.
* Fix the missing fields in hash cnnt by serialization.

### V4.3.5 BP5 Hotfix6

[**点击查看 V4.3.5 BP5 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 02 月 11 日
* 版本号：V4.3.5 BP5 Hotfix6
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105060022026020920
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105060022026020920

**关键缺陷修复：**

* Fix json multivalue index bug in vec pre filter scenario.
* Ctas force refresh table schema after alter table.
* Disable LATE\_MATERIALIZATION for fts query.
* Flatten cnnop in parser.
* Add pending\_log backpress write thread and submit redo after log synced.
* Fix spf pkey distributed plan bug for null value.
* Fix get min mv mds bug in GetMinMVMdsSnapshotFunctor.
* Fix some cardinality estimation bugs.
* Fix extract number query range cause real agent table report 4224.
* Fix truncate table cannot clean useless \_\_all\_monitor\_modified.
* Release rowkey doc and data table snapshot.
* Fix global index extract phy rowid cause 4016.
* Fix table in black list not collect by auto gather task.
* Do not record xa stmt in event history.
* Miss wake up bug fix.

### V4.3.5 BP5 Hotfix5

[**点击查看 V4.3.5 BP5 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 01 月 16 日
* 版本号：V4.3.5 BP5 Hotfix5
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105050012026011511
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105050012026011511

**关键缺陷修复：**

* Fix core at ObKVCacheMap::clean\_garbage\_node.
* Fix SQL-level memory limit issue in thread-switching tenant scenarios.
* Deduce all redundant join conditions for two tables without any join conditions.
* Fix dbms\_scheduler call gather\_schema\_stats report 4014.
* Add total\_alloc\_size\_ check in ObSqlMemoryCallback.
* Fix timer scan full schema issue.
* Fix non-deterministic filters should not be pushdown to basic table.
* Enable create larger view.

### V4.3.5 BP5 Hotfix4

[**点击查看 V4.3.5 BP5 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 01 月 09 日
* 版本号：V4.3.5 BP5 Hotfix4
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105040012026010810
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105040012026010810

**关键缺陷修复：**

* Fix deterministic udf issue.
* Support disable shared expr extraction by hint.
* Fix json\_query&json\_value empty path core.
* Fix rownum to offset constraint bug.
* Use tracepoint control operator dummy ptr for detect closed.
* Fix runtime filter group send bug.
* Fix update baseline item cause dead lock.
* Fix a bug where the result set of a merge join is incorrect when the join condition contains shared expr.
* Fix gather index stats cost too much time.
* Fix synonym resolution failure in proxy mode for cross-user queries.
* Check ls replay\_scn of member\_list before transfer.

### V4.3.5 BP5 Hotfix3

[**点击查看 V4.3.5 BP5 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 12 月 29 日
* 版本号：V4.3.5 BP5 Hotfix3
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105030022025122819
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105030022025122820

**关键缺陷修复：**

* Fix stuck while redo\_dispatch\_memory\_limit usedup but can't output any records.
* Fix noorder auto increment ddl report 4038.
* Fix scalar aggregate.
* Fix index back cost.
* Fix lock row conflict in OBKV-HBase.
* Fix bug data inconsistency caused by concurrent batch insert operations.
* Fix clean dblink conn hang bug.
* Bugfix json\_table plan not correct in inner subquery path.
* Bugfix null string in pl json get\_string.
* Fix coredump in utl file.
* Fix vector\_month\_name core and date\_to\_ob\_time bug.
* Fix support for usernames with special characters when setting audit rules.
* Fix gv$ob\_kvcache should only get di once per tenant.
* Fix dynamic partition may generate incorrect high bound val with IANA timezone.

### V4.3.5 BP5 Hotfix2

[**点击查看 V4.3.5 BP5 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 12 月 12 日
* 版本号：V4.3.5 BP5 Hotfix2
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105020022025121200
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105020022025121200

**关键缺陷修复：**

* Add knob contrl replay memory limit and parallel replay.
* Support parallel ddl for empty set CTAS.
* Fix query string is too long to display.
* Fix thread enter other tenant's cgroup.
* Cannot pushdown filter with aggr through wind func.
* BugFix NEW.col as an inner call inout parameter in trigger.
* Fix use wrong end trans interface for xa trans + autonomous scene.
* Bugfix ignore index\_back dimension for fulltext search query due to functional lookup.
* Fix format\_exception\_stack add error\_messeage charset\_convert.
* Add column convert flag when cast bit to string in set stmt.
* Enhance mlog dynamic sampling.

### V4.3.5 BP5 Hotfix1

[**点击查看 V4.3.5 BP5 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 11 月 26 日
* 版本号：V4.3.5 BP5 Hotfix1
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105010022025112520
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105010022025112520

**关键缺陷修复：**

* Change default server\_status\_ of ok pkt from 0x22 to 0x02.
* Fix the inconsistency in the to\_char result compared to Oracle.
* Fix merge join accumulating match\_groups\_ without reseting problem.
* Fix typed null add plan bug.
* Fix the uint64\_t underflow issue in tablet stat.
* Adjust oracle sys view index deduce in gbk tenant.
* Avoid querying tablet before transfer in commit.
* Fix add \_force\_unstreaming\_cursor parameter.

### V4.3.5 BP5

[**点击查看 V4.3.5 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 11 月 17 日
* 版本号：V4.3.5 BP5
* 分布式 RPM 版本号：oceanbase-4.3.5.5-105000212025111617
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.5-105000062025111617

**版本概述：**

OceanBase 数据库 V4.3.5 BP5 版本在向量数据库能力、查询性能优化、数据管理增强、兼容性改进等方面实现多项关键升级，全面强化了其在复杂业务场景下的稳定性和效率。在向量搜索方面，新增 `similarity` 函数及 IVF 索引性能优化，支持通过相似度阈值过滤结果，并通过 Kmeans 并行化、迭代式过滤算法等技术显著提升向量查询与索引构建效率。查询性能突破，Delete-Insert 表模式引入 Skip Index 预裁剪技术，减少扫描开销；笛卡尔积计算性能优化；UDF 展开优化减少 PL 层交互；Oracle 模式新增空间函数（如 `SDO_CONTAINS`、`SDO_AREA`），增强 GIS 处理能力。数据管理增强，物化视图支持复杂场景（如 Left Join 聚合、嵌套视图、`MIN`/`MAX` 非基本列）的增量刷新；分区交换功能扩展至 List 分区表，实现瞬时数据迁移；SQL 统计信息（`GV$OB_SQLSTAT`）新增多维度指标（如全表扫次数、批量执行优化）。兼容性与易用性，MySQL 模式语法补充（如 `array<>` 定义、JSON 类型转换）及 Oracle 模式 PS 协议 Prepare 阶段参数解析能力；DBLink 超时机制改为继承会话级 `ob_query_timeout`，解决嵌套 SQL 超时上限问题。稳定性与可观测性，日志流迁移规避坏盘副本；ASH 报告生成加速；报错信息补充约束名等关键诊断信息。

**关键缺陷修复：**

* Fix ObExprUserCanAccessObj param type bug.
* If group id not changed, do not repeatedly add tid to cgroup file.
* Add some transaction error code to inner error code.
* Fix push subquery bug.
* Fix mock lock/unlock user for standby tenant.
* Fix the issue where specifying LOCAL has no effect when adding a unique constraint.
* Fix vector prune non-vec index bug.
* Fix ObBatchRpc singleton analysis core when observer exits.
* Fix memory dynamic leak of inner call stmt.
* Fix sum ps information when its input type is string.
* Opt last\_value() over half sliding window.
* Disable direct load plan spm execute retry.
* Disable complex rescan path pruning.
* Remove remove\_const expr during aggr subquery pullup.
* Fix regexp exec error 'U\_REGEX\_TIME\_OUT'.
* Fix v$open\_cursor add display other user's cursors.
* Fix force enable plan tracing error 4016.
* Ignore normal nl path for connect\_by join.
* Fix win func topn partition sort plan gen.
* Fix unstreaming cursor fill result without switch memory context.
* Fix print hostname of reverse link bug.
* Fix misssing constraint after add not null lob.
* Fix DataStoreVecExtraResult not destroy mem\_context for sorting in destructor.
* Fix set system time zone bug.
* Recover when pid is moved out of cgroup dir.
* Block bugFix -4377 after before update trigger.
* Fix cg scanner projector after add column.
* Do not count IO traffic when IO request is canceled.
* Fix dynamic memory leak.
* Fix refine json path cache memory use.
* Add generate three stage group by constraint.
* Fix 0 can be inserted into date column in strict mode.
* Fix sql audit of PS Cursor fetch, add more informations.
* Fix dbms lob\_read 4002 beacase of lob payload\_size not update.
* Semistruct Fix merge 4016.
* Fix memory expend on unnest expr.
* Fix query range cannot be extracted in int to oracle number.
* Fix tmp file always flush\_all after write buffer pool shrinking is aborted.
* Fix the problem that the division precision of number is inconsistent with mysql.
* Fix no\_cost\_based\_query\_transformation should allow heuristic semi\_to\_inner.
* Fix alter routine compile will create multi same name object.
* Fix convert charset of schema name when dblink connect to Oracle.
* Fix batch insert optimization failure after disabling PS parameterization.
* Fix ObRowStore do not free buffer when occur exception.
* Fix lose semi info of inner query when pulling up subquery.
* Optimize tablet\_id related hotspot in sql compile.
* Get min active snapshot version from all sessions.
* Fix old query range bug when merge key part after range condition.
* Fix old query range phy rowid cause hang.
* Modify first\_exe\_time of the streaming cursor to time from open to the end of fetch.
* Set prefix gen column nullable when create prefix index.
* Fix collect range graph infos cause too much time.
* Fix profiler use wrong key\_id as unit\_id for type and trigger.
* Fix [oracle] create/grant view without needed priv should raise proper error.
* Fixed the issue of SQL requests being hard parsed in PS+SPM scenarios.
* Restrict redundancy removal during predicate deduction.
* Use WaitGuard in SendMsgResponse::wait().
* Keep order for right child of merge right outer join.
* Fix incorrect update order of table stat info in exchange partition.
* Fix select distinct order by bug.
* Fix disable late materialization after it happened.
* Fix the recyclebin-bug of create hidden table.
* BUGFIX optimize the cost of \_\_all\_virtual\_ls\_info.
* Fix incorrect pre-calc cache hit after freeing temp expr factory.
* Relax the strict deterministic check for char type.
* To avoid the session mistakenly thinking that its fd is open due to the reuse of closed fd.
* Fix bug generated column can not match index.
* Add fb\_snapshot in lob locator tx snapshot.
* Adjust hash join left rows output method.
* Restrict query range extraction of 'not in' expr.
* Fix shared part expr bug.
* Enable post-groupby subquery join-first unnesting for stmt with group by but no unique key.
* Skip disk hung check when device is object storage.
* Meta tenant does not update throttle limit adaptively.
* Optimizing the performance of nested loop join operator in Cartesian product scenarios.
* Call mysql\_close to release resource when mysql\_real\_connect failed.
* Feat user-friendly err msg when PL Debug without CAP\_SYS\_PTRACE.
* Fix recover many small table issue.
* Fix remove use less sys schema change check.
* Fix index merge with push down distinct using block gi.

### V4.3.5 BP4 Hotfix17

[**点击查看 V4.3.5 BP4 Hotfix17 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 08 月 04 日
* 版本号：V4.3.5 BP4 Hotfix17
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104170012026080417

**关键缺陷修复：**

* Avoid concurrent mlog purge after scheduler timeout.

### V4.3.5 BP4 Hotfix16

[**点击查看 V4.3.5 BP4 Hotfix16 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 06 月 10 日
* 版本号：V4.3.5 BP4 Hotfix16
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104160012026060816

**关键缺陷修复：**

* Disable plan expiration for non-user-session queries.

### V4.3.5 BP4 Hotfix15

[**点击查看 V4.3.5 BP4 Hotfix15 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 05 月 25 日
* 版本号：V4.3.5 BP4 Hotfix15
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104150012026052210

**关键缺陷修复：**

* Prune pull to local spf plan if parallel > 1 in fast refresh.
* Fix `se_calc_const_expr` `set_cur_time` multi times.

### V4.3.5 BP4 Hotfix14

[**点击查看 V4.3.5 BP4 Hotfix14 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 04 月 29 日
* 版本号：V4.3.5 BP4 Hotfix14
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104140022026042815

**关键缺陷修复：**

* 修复 plan cache 计划淘汰导致程序 CRASH 问题。
* 修改物化视图的调度行为，每次都调度，刷新时检测是否已存在任务
* 调整 mv/mlog 调度作业的 `max_run_duration`。
* 优化 MySQL 模式 MAV 的增量刷新性能，在 MAV 增量刷新场景启用 merge into。

### V4.3.5 BP4 Hotfix13

[**点击查看 V4.3.5 BP4 Hotfix13 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 04 月 21 日
* 版本号：V4.3.5 BP4 Hotfix13
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104130012026042014

**关键缺陷修复：**

* 修复 mlog 分批删除避免大事务问题。
* 修复物化视图刷新任务在节点下线期间会丢失的问题。

### V4.3.5 BP4 Hotfix12

[**点击查看 V4.3.5 BP4 Hotfix12 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 04 月 10 日
* 版本号：V4.3.5 BP4 Hotfix12
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104120022026040910

**关键缺陷修复：**

* 修复缩容期间出现了断连问题。
* 支持批处理 block\_get 表位置。
* 修复 PlanCache LRU 淘汰实现存在的问题。
* 修复 observer 机器上完成了删租户，后续该租户发到该 observer 的请求在网络层会被直接断连，不会回 error 包的问题。

### V4.3.5 BP4 Hotfix11

[**点击查看 V4.3.5 BP4 Hotfix11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 03 月 23 日
* 版本号：V4.3.5 BP4 Hotfix11
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104110022026032015
* 单机版版本号：oceanbase-standalone-4.3.5.4-104110012026032015

**关键缺陷修复：**

* 修复执行 `insert up` 语句发生冲突且 `update` 之后的新值和旧值没有任何变化，但 `current_timestamp` 列上的索引却更新了的问题。

### V4.3.5 BP4 Hotfix9

[**点击查看 V4.3.5 BP4 Hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 02 月 13 日
* 版本号：V4.3.5 BP4 Hotfix9
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104090012026021115

**关键缺陷修复：**

* 修复 `insert up` 语句在不更新主键/分区键/唯一键的情况下，冲突行会拆分成 `delete + insert` 的问题。

### V4.3.5 BP4 Hotfix8

[**点击查看 V4.3.5 BP4 Hotfix8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 02 月 10 日
* 版本号：V4.3.5 BP4 Hotfix8
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104080012026020919
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104080012026020919

**关键缺陷修复：**

* 修复异步统计信息处理导致 CPU 持续打满的问题。
* 修复升级脚本 `-t` 参数设置的问题。

### V4.3.5 BP4 Hotfix7

[**点击查看 V4.3.5 BP4 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 01 月 06 日
* 版本号：V4.3.5 BP4 Hotfix7
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104070022026010511

**关键缺陷修复：**

* 修复 memstore 不释放的问题。
* 修复 `delete` 大事务的 cb 把租户内存占满，导致 memstore 提前限速的问题。

### V4.3.5 BP4 Hotfix6

[**点击查看 V4.3.5 BP4 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 12 月 16 日
* 版本号：V4.3.5 BP4 Hotfix6
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104060012025121519
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104060012025121520

**关键缺陷修复：**

* Add knob contrl replay memory limit and parallel replay.
* BugFix NEW.col as an inner call inout parameter in trigger.
* BugFix -4377 after before update trigger.
* Fix gv$ob\_kvcache should only get di once per tenant.

### V4.3.5 BP4 Hotfix5

[**点击查看 V4.3.5 BP4 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 11 月 26 日
* 版本号：V4.3.5 BP4 Hotfix5
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104050022025112417
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104050012025112417

**关键缺陷修复：**

* Adapter memdata nullptr core cause by renew.
* Fix date\_add and date\_sub error when interval is month or quarter.
* Fix add \_force\_unstreaming\_cursor parameter.
* Fix memory overflow for approx count distinct bypassing.
* Fix report no partition for given value bug.

### V4.3.5 BP4 Hotfix4

[**点击查看 V4.3.5 BP4 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 11 月 10 日
* 版本号：V4.3.5 BP4 Hotfix4
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104040012025110519
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104040012025110519

**关键缺陷修复：**

* Fixed the issue of SQL requests being hard parsed in PS+SPM scenarios.
* Check transfer task status before clearing.
* Meta tenant does not update throttle limit adaptively.
* Fix topk value was set to 0, which resulted in an error in Vsag.
* fix post filter with parallel.

### V4.3.5 BP4 Hotfix3

[**点击查看 V4.3.5 BP4 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 10 月 28 日
* 版本号：V4.3.5 BP4 Hotfix3
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104030042025102723
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104030022025102723

**关键缺陷修复：**

* 支持 List 一级分区表与非分区表进行分区交换。
* 修复纯列存分区表加列后，不同分区合并进度不同，基线包含列数不同，新加列上的聚合函数下压存储在切分区 rescan 场景下存在 bug，写坏内存，有概率会出现随机正确性问题或者 core 的问题。
* 修复分区交换前，分区表被收集了统计信息，分区交换后统计信息更新失败的问题。
* 修复向量 `in` 场景下，`in` 里面的条件无法分别下压给两个基表，导致无法抽取 query range，执行时间较长的问题。

### V4.3.5 BP4 Hotfix2

[**点击查看 V4.3.5 BP4 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 10 月 17 日
* 版本号：V4.3.5 BP4 Hotfix2
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104020022025101617
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104020022025101617

**关键缺陷修复：**

* 修复使用 unnest 表达式展开嵌套 Array 时，数据量较大会导致内存膨胀的问题。
* 优化 json 路径内存使用。
* 修复 `UTF8MB4` 字符集的 OceanBase 数据库 Oracle 模式通过 DBLink 访问 `GBK` 字符集的 Oracle 表的中文列名时，字符集转换失败报错 -4258 的问题。
* 修复 Oracle GBK 租户下，连接字符集为 UTF8，通过 `dbms_lob.read` 查询 outrow lob 时报错 4002 的问题。
* 优化 minor merge 策略。
* 修复列存表加列后，全量合并之前，查询访问新列导致 OBServer Crash 的问题。
* 修复 `SELECT *` 方式查询 HDFS 外部表时，执行报错 -4002 的问题。

### V4.3.5 BP4 Hotfix1

[**点击查看 V4.3.5 BP4 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 09 月 18 日
* 版本号：V4.3.5 BP4 Hotfix1
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104010032025091722
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104010022025091722
* 共享存储 RPM 版本号：oceanbase-sharestorage-4.3.5.4-104010022025091810

**关键缺陷修复：**

* 修复 4.3.5BP4 引入的 Oracle 模式全局临时表意外删除的问题。
* 修复 V4.2.5 BP3 及之后版本使用原生 MySQL 驱动执行 PL 时，若用户无 `SELECT ON .` 权限可能触发报错的问题。
* 修复 Oracle 模式下，定义 Decimal Int 列的内部表，Inner sql 无法抽 query range 导致性能差的问题。

### V4.3.5 BP4

[**点击查看 V4.3.5 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 09 月 10 日
* 版本号：V4.3.5 BP4
* 分布式 RPM 版本号：oceanbase-4.3.5.4-104000052025090918
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.4-104000062025090915

**版本概述：**

OceanBase 数据库 V4.3.5 BP4 版本在兼容性、性能与功能体验方面进行了多项重要升级。MySQL 模式下恢复支持 Session 级别私有临时表操作（创建/修改/删除及索引管理），并新增 GIS 函数 ST\_AsGeoJSON() 支持生成列。物化视图优化支持增量刷新时排除维度表刷新（通过 `AS OF PROCTIME()` 语法），单表聚合场景支持 `MIN()`/`MAX()` 聚合函数，且实现 MLOG 表的自动管理（创建/替换/清理）。向量索引优化 VSGA 锁机制，HNSW\_BQ 索引新增 cosine 和 ip 距离计算，支持弱读及超大规模分区表（10M/100M/1B 向量数据）。引入租户级 PS 参数化开关 `enable_ps_parameterize`，支持灵活控制常量参数化策略。SQL 实时内存监控功能新增 `[G]V$OB_PROCESSLIST` 视图，支持 TOP N SQL 实时分析。Full Schema 刷新机制升级为 Server 级更新，解决高并发 DDL 场景下的性能抖动问题。UDF 性能优化，对 `DETERMINISTIC` 标记函数支持结果缓存，非缓存场景执行路径针对性优化。AP 参数模板默认关闭全量旁路导入，优化资源分配策略。

**关键缺陷修复：**

* 优化并发数和压力大场景事务超时的问题。
* 修复源表新增 `skip index` 后，导致备份防御失败报错的问题。
* 修复 `const` 表达式出现在 `UPDATE` 和 `GROUP BY` 中，被标记成共享表达式，下压到 table scan 中，导致在聚合中填了 `NULL` 值导致结果错误的问题。
* 修复迁移等操作导致单机出现多个日志流，线程打满问题。
* 修复链路不指定 database、绑定 outline、remote 执行场景 RT 抖动的问题。
* 修复增大插入 batch 场景下，锁冲突然变高，SQL 反复重试导致 CPU 被打爆的问题。
* 修复 `GROUP BY` 包含 `JOIN` 两侧的表达式，执行报错 4016 的问题。
* 修复 ps cursor 执行的 SQL 路由到非 Leader 节点时不会触发二次路由走 remote 计划的问题。
* 修复使用 cs encoding, 对于使用整型存储的列，如果有 filter 下压，可能会发生查询少行或者多行的问题。
* 修复系统表有 outrow lob 数据，`UPDATE` 或者 `DELETE` 时，outrow lob 的 lob 辅助表没有被删除的问题。
* 修复批量写入过程中，冲突行回滚后，回滚的 `tx_node` 被覆盖写掉，导致 `memtable` 遍历 `B+tree` 的叶节点链表时出错导致的 4377 问题。
* 修复使用有问题的驱动（客户的版本未知）发通过二合一协议 253 长度的 SQL 到 Server 导致 observer crash 的问题。
* 修复 `MIN()`/`MAX()` 执行性能不优的问题。
* 优化统计信息收集问题。
* 修复使用序列 nextval 值时 unique constraint 冲突的问题。
* 修复 `LAG` 函数的 igore nulls 在存储过程中和 SQL 中表现不一致的问题。
* 修复物化视图刷新 SQL 计划生成时，没有初始化获取 `parallel_degree_limit` 的值，最终 auto dop 使用默认行为限制刷新 SQL 的 dop 问题。

### V4.3.5 BP3 Hotfix6

[**点击查看 V4.3.5 BP3 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 10 月 20 日
* 版本号：V4.3.5 BP3 Hotfix6
* 分布式 RPM 版本号：oceanbase-4.3.5.3-103060032025102011
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.3-103060022025102011

**关键缺陷修复：**

* 修复分区交换前，分区表被收集了统计信息，分区交换后统计信息更新失败的问题。
* 支持一级 List 分区表与非分区表的分区交换。
* 修复分区数很多时，批量冻结 dag 积压，导致合并卡住的问题。
* 修复备份清理筛选 `piece` 不应该使用 `checkpoint_scn` 的问题。

### V4.3.5 BP3 Hotfix5

[**点击查看 V4.3.5 BP3 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 10 月 14 日
* 版本号：V4.3.5 BP3 Hotfix5
* 分布式 RPM 版本号：oceanbase-4.3.5.3-103050022025100922
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.3-103050012025100922

**关键缺陷修复：**

* 修复使用 unnest 表达式展开嵌套 Array 时，数据量较大会导致内存膨胀的问题。
* 优化 json 路径内存使用的问题。
* 修复列存表加列后，全量合并之前，查询访问新列导致 OBServer Crash 的问题。
* 修复 `UTF8MB4` 字符集的 OceanBase 数据库 Oracle 模式通过 DBLink 访问 GBK 字符集的 Oracle 表的中文列名时，字符集转换失败报错 -4258 的问题。
* 优化外表中的 `LD_LIBRARY_PATH` 设置问题。

### V4.3.5 BP3 Hotfix4

[**点击查看 V4.3.5 BP3 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 09 月 25 日
* 版本号：V4.3.5 BP3 Hotfix4
* 分布式 RPM 版本号：oceanbase-4.3.5.3-103040042025092501
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.3-103040032025092501
* 共享存储 RPM 版本号：oceanbase-sharestorage-4.3.5.3-103040012025092515

**关键缺陷修复：**

* 修复 Oracle GBK 租户下，连接字符集为 UTF8，通过 `dbms_lob.read` 查询 outrow lob 时报错 4002 的问题。
* 修复 `GROUP BY` 包含 `JOIN` 两侧的表达式，`FUNCTION TABLE` 中依赖左侧传递的 exec param，且两表没有连接条件在 `ON` 和 `WHERE` 中时，SQL 执行报错 -4016 的问题。
* 修复在 `UPDATE` 带聚合的关联子查询中写常量表达式，写入的数据是 `NULL` 而不是常量值时，执行结果不符合预期的问题。
* 修复 V4.2.5 BP3 及之后版本使用原生 MySQL 驱动执行 PL 时，若用户无 `SELECT ON .` 权限可能触发报错的问题。
* 修复租户内存不足，向量 rebuild index 失败后无法正常删除辅助表，导致 `drop table` 任务卡住的问题。
* 修复 cosine 距离函数在 arm 的机器没有做 simd 优化的问题。
* 优化 minor merge 策略。
* 修复 `SELECT *` 方式查询 HDFS 外部表时，执行报错 -4002 的问题。

### V4.3.5 BP3 Hotfix3

[**点击查看 V4.3.5 BP3 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 09 月 02 日
* 版本号：V4.3.5 BP3 Hotfix3
* 分布式 RPM 版本号：oceanbase-4.3.5.3-103030022025090117
* 单机版 RPM 版本号：oceanbase-standalone-4.3.5.3-103030022025090117
* 共享存储 RPM 版本号：oceanbase-sharestorage-4.3.5.3-103030052025091016

**关键缺陷修复：**

* 修复 `SELECT UNION ALL` 存在精度缺失的问题。
* 修复使用 cs encoding，对于使用整型存储的列，如果有 filter 下压，可能会发生查询少行或者多行的问题。
* 新增 `approx_count_distinct_precision` 配置项，用于控制 `approx_count_distinct` 函数内部 hyper loglog 算法的 hash 桶个数，以控制输出精度。
* 优化统计信息收集的问题。
* 优化涉及向量 SQL 性能问题。
* 修复 Delete-Insert 模式和 Runtime Filter 功能正交场景导致的数据写入不一致，进而合并报错 CHECKSUM ERROR 的问题。

### V4.3.5 BP3 Hotfix2

[**点击查看 V4.3.5 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 08 月 21 日
* 版本号：V4.3.5 BP3 Hotfix2
* RPM 版本号：oceanbase-4.3.5.3-103020012025082017

**关键缺陷修复：**

* 修复列存合并场景 MemTable 无法释放的问题。
* 修复批量写入过程中，冲突行回滚后，回滚的 `tx_node` 被覆盖写掉，导致 MemTable 遍历 B+tree 的叶节点链表时出错导致的 4377 问题。
* 修复复制表超大分区复制且源端机器上有其他分区的高频访问时，RT 上涨的问题。
* 修复自动分区分裂正交 Buffer 表场景下分裂 meta major 卡住的问题。
* 修复 OBCI 查询 `clob` 字段乱码的问题。
* 修改 `member of` 查询条件抽取精确 Query Range，不需要上层回表及 filter。
* 修复系统表有 `OUTROW LOB` 数据，`UPDATE` 或者 `DELETE` 时，`OUTROW LOB` 的 `LOB` 辅助表没有被删除的问题。
* 修复 `extract` 函数处理 XML，OceanBase 数据库和原生 Oracle 表现不一致的问题。

### V4.3.5 BP3 Hotfix1

[**点击查看 V4.3.5 BP3 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 08 月 08 日
* 版本号：V4.3.5 BP3 Hotfix1
* RPM 版本号：oceanbase-4.3.5.3-103010012025080717

**关键缺陷修复：**

* 修复内部死锁记录表时间显示异常的问题。
* 修复访问归档介质有权限问题报错后概率 core 问题。
* 修复阿里云 al8 系统 ODPS 外表创建失败的问题。
* 修复当前优化器剪裁掉了不包含 nlj 下压条件的计划导致特定场景估行不准的问题。

  #### 说明

  如果想要使用这一次的 bugfix，需要提前升级优化器版本。
* 修复特定场景下自动分裂没有发起的问题。
* 修复外表 `INSERT OVERWRTIE SELECT` 无法使用到多并发能力的问题。
* 修复 `LAG` 函数的 `IGORE NULLS` 在存储过程中和 SQL 中表现不一致的问题。
* 修复 spm baseline 数据量持续增长的问题，限制基准表中相关内部表存储原始 SQL 文本长度为 64KB。
* 修复自动分裂调度器错误码误判的问题。
* 修复使用 `rb_to_string` 表达式合并场景数据不一致的问题。

### V4.3.5 BP3

[**点击查看 V4.3.5 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 07 月 21 日
* 版本号：V4.3.5 BP3
* RPM 版本号：oceanbase-4.3.5.3-103000102025071821

**版本概述：**

OceanBase 数据库 V4.3.5 BP3 在数据安全、性能优化、兼容性扩展及多模态能力等方面实现全面升级。在数据安全领域，新增业务无感知的列加密功能，支持通过权限控制动态返回明文或加密数据，强化敏感数据保护；性能方面，通过适配 ODPS Storage API 提升外表访问效率，优化并行执行（PX）负载均衡、rescan 流程及 Batch DML 冲突处理，使查询与写入性能显著提升（如 Batch DML 全冲突场景性能最高提升 42%）；扩展性与兼容性上，新增 Azure Blob 对象存储支持，增强 OBKV-HBase 的共享存储模式与 Hive/Spark/Flink 兼容性，并支持 JSON 数据类型及 RoaringBitmap 聚合函数优化；系统稳定性方面，引入 SQL 关键字限流能力，通过精细化流量控制避免资源争抢，同时优化物化视图的级联刷新、增量刷新及稳定性问题。此外，向量数据库能力进一步增强，适配 ARM 架构，优化 IVF 索引构建与查询性能，支持小规格 HNSW 索引加速，并新增内存管理与索引参数控制功能，满足 PB 级 IOT 场景需求。

**关键缺陷修复：**

* 修复 SQL 中有非常量的 `convert_tz`，`convert_tz` 执行慢的问题。
* 修复特定场景下向量数据库索引重建期间不可用问题。
* 修复带全局索引的表执行 PDML，无法走到 DAS 层的攒批，导致的性能问题。
* 修复 query range 抽取在表达式计算时使用了 `exec_ctx` 的 allocator，造成动态内存泄露的问题。
* 优化列存表合并重整数据耗时较大的问题。
* 修复字符序 `CS_TYPE_UTF8MB4_BIN` 下，使用 `find_in_set` 函数返回值不符合预期问题。
* 修复硬解析过程中对多分区表频繁多次拉取统计信息，导致硬解析慢的问题。
* 修复 `beng` 分词器对空格的识别不正确导致出现两个分词，全文索引创建失败的问题。
* 修复行存索引列存表回表代价计算偏大的问题。
* 修复 `decimal int` 与 PL 正交场景的 core 问题。
* 修复在数据量大的场景，分裂采样的 SQL 耗时较高，导致建索引执行慢的问题。
* 修复内部表 filter 顺序被优化器交换，导致 `user_can_access_obj` 函数参数出现了 `NULL` 值，查询 `all_indexes` 表概率性执行报错的问题。
* 修复 `unpivot` 语句新生成列的长度推导处理有问题导致语句报错的问题。
* 修复动态语句执行过程中反拼 SQL 没有拼接 `ORA_ROWSCN` 的 table 信息，导致 resolve 报错的问题。
* 修复改写的索引匹配检查没有考虑到前缀索引，能匹配前缀索引的 or 分支被判定为无法匹配索引，导致没有尝试做 or 展开的问题。
* 修复开 IO 隔离，并且用户查询期间有迁移复制场景下 RT 抖动问题。
* 修复 SQL 语句结果 `count(distinct)` 包含多列时，结果不正确的问题。

### V4.3.5 BP2 Hotfix9

[**点击查看 V4.3.5 BP2 Hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 08 月 27 日
* 版本号：V4.3.5 BP2 Hotfix9
* RPM 版本号：oceanbase-4.3.5.2-102090012025082611

**关键缺陷修复：**

* 修复使用 cs encoding，对于使用整型存储的列，如果有 filter 下压，则可能会发生查询少行或者多行的问题。
* 优化统计信息收集问题。

### V4.3.5 BP2 Hotfix8

[**点击查看 V4.3.5 BP2 Hotfix8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 08 月 21 日
* 版本号：V4.3.5 BP2 Hotfix8
* RPM 版本号：oceanbase-4.3.5.2-102080022025082111

**关键缺陷修复：**

* 修复系统表有 `outrow lob` 数据，`UPDATE` 或者 `DELETE` 时，`outrow lob` 的 `lob` 辅助表没有被删除的问题。
* 关闭 optimizer rowgoal 且 `LIMIT` 能下压到回表前时，仍然按照 `LIMIT` 行数计算回表代价。

### V4.3.5 BP2 Hotfix7

[**点击查看 V4.3.5 BP2 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 08 月 15 日
* 版本号：V4.3.5 BP2 Hotfix7
* RPM 版本号：oceanbase-4.3.5.2-102070022025081416

**关键缺陷修复：**

* 修复列存合并场景 MemTable 无法释放的问题。
* 修复复制表超大分区复制且源端机器上有其他分区的高频访问时，RT 上涨的问题。
* 修复 `LAG` 函数的 igore nulls 在存储过程中和 SQL 中表现不一致的问题。
* 修复外表 `INSERT OVERWRTIE SELECT` 无法使用到多并发能力的问题。
* 修复 Query Range 抽取在表达式计算时使用了 `exec_ctx` 的 `allocator`，造成动态内存泄露的问题。
* 修复自动分裂调度器错误码误判的问题。
* 修复 spm baseline 数据量持续增长的问题，限制基准表中相关内部表存储原始 SQL 文本长度为 1k。
* 修复使用 `rb_to_string` 表达式合并场景数据不一致的问题。
* 修复自动分区分裂正交 Buffer 表场景下分裂 meta major 卡住的问题。
* 修复 OBCI 查询 `clob` 字段乱码的问题。
* 修改 member of 查询条件抽取精确 Query Range，不需要上层回表及 filter。

### V4.3.5 BP2 Hotfix6

[**点击查看 V4.3.5 BP2 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 07 月 31 日
* 版本号：V4.3.5 BP2 Hotfix6
* RPM 版本号：oceanbase-4.3.5.2-102060032025073110

**关键缺陷修复：**

* 修复分区表构建全文索引，且分批构建 sstable 场景下，未设置错误码导致全文索引任务卡住的问题。
* 修复隐式 cast 写在连接条件中不走索引，进行全表扫描，导致查询慢的问题。
* 修复 SQL 语句结果 `count(distinct)` 包含多列时候，结果不正确的问题。
* 修复向量化 2.0 的 min/max 在计算变长类型时没有复用 buffer，导致动态内存泄露的问题。
* 修复内部死锁记录表时间显示异常问题。
* 修复字符序 `CS_TYPE_UTF8MB4_BIN` 下，使用 `find_in_set` 函数返回值不符合预期的问题。
* 修复访问归档介质有权限问题报错后概率 core 问题。
* 修复阿里云 al8 系统 ODPS 外表创建失败问题。
* 修复当前优化器剪裁掉了不包含 nlj 下压条件的计划导致特定场景估行不准问题。

  #### 注意

  如果想要使用这一次的 bugfix，需要提前升级优化器版本。
* 修复普通表与复制表关联查询时，因复制表无法感知到普通表副本的选择情况，直接选择了 `LOCAL` 副本而错误生成分布式计划，导致无法命中 `REMOTE` 计划的问题。
* 修复由于复制表的 `advisor_table_id` 设置错误，当复制表的约束设置的是普通表，且普通表是 `romote` 表时，如果复制表选择 `romote` 副本会导致计划无法正确匹配的问题。
* 修复特定场景下自动分裂没有发起的问题。

### V4.3.5 BP2 Hotfix5

[**点击查看 V4.3.5 BP2 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 07 月 03 日
* 版本号：V4.3.5 BP2 Hotfix5
* RPM 版本号：oceanbase-4.3.5.2-102050042025070221

**关键缺陷修复：**

* 修复对空格的不正确处理，出现两个分词，导致出现全文索引创建失败的问题，完善 `BENG` 分词器的空格识别条件。
* 修复 `unpivot` 语句新生成列的长度推导处理有问题导致报错的问题。
* 修复内部表 filter 顺序被优化器交换，导致 `user_can_access_obj` 函数参数出现了 `NULL` 值，查询 `all_indexes` 表概率性执行报错的问题。

### V4.3.5 BP2 Hotfix4

[**点击查看 V4.3.5 BP2 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 06 月 26 日
* 版本号：V4.3.5 BP2 Hotfix4
* RPM 版本号：oceanbase-4.3.5.2-102040022025062518

**关键缺陷修复：**

* 修复慢 SQL 条件下压没有物化，性能下降明显问题。
* 修复 `union` 合并多分支 `wm_concat` 聚合查询，内存使用过高，报错 4013 的问题。
* 修复 `or` 连接的 SQL 无法使用多个前缀索引分别扫描，执行慢的问题。
* 修复兼容模式下 `SHOW CREATE TABLE` 的全文索引定义中包含 MySQL 不识别的属性，导致 Binlog 下游解析失败的问题。

### V4.3.5 BP2 Hotfix3

[**点击查看 V4.3.5 BP2 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 06 月 18 日
* 版本号：V4.3.5 BP2 Hotfix3
* RPM 版本号：oceanbase-4.3.5.2-102030012025061813

**关键缺陷修复：**

* 修复 MySQL 模式 `insert into on duplicate key update` 场景下，`last_insert_id` 的兼容性问题。

### V4.3.5 BP2 Hotfix2

[**点击查看 V4.3.5 BP2 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 06 月 12 日
* 版本号：V4.3.5 BP2 Hotfix2
* RPM 版本号：oceanbase-4.3.5.2-102020032025061118

**关键缺陷修复：**

* 修复 V4.3.5 BP2 版本 substring 函数对中文字符个数判定不准的问题。
* 修复全文后建索引时间长的问题。
* 修复查询时内存索引缺失，并发查询或 parallel hint，会导致多次载入向量索引/rebuild index 过程中，无法走索引扫描的问题。

### V4.3.5 BP2 Hotfix1

[**点击查看 V4.3.5 BP2 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 05 月 27 日
* 版本号：V4.3.5 BP2 Hotfix1
* RPM 版本号：oceanbase-4.3.5.2-102010032025052623

**关键缺陷修复：**

* 修复 Decimal Int 与 PL 正交的场景 core 问题。
* 修复分裂场景空表创建索引慢的问题。
* 修复动态采样在条件下推场景估行不准，导致计划选择不优的问题。
* 修复合并日志误报问题。
* 修复 V4.3.1 升级 V4.3.5 升级写 slog checkpoint 过程中，mark sweep 宏块未回收导致 meta 租户 clog 盘满的问题。

### V4.3.5 BP2

[**点击查看 V4.3.5 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 05 月 15 日
* 版本号：V4.3.5 BP2
* RPM 版本号：oceanbase-4.3.5.2-102000162025051417

**版本概述：**

OceanBase 数据库 V4.3.5 BP2 版本在产品形态、功能增强和系统优化方面进行了全面升级，主要包括：新增 Shared-Storage AP 产品形态，适配存在冷热数据特征的 AP 业务，通过 IO 优化提升性能。备份归档功能增强，支持阿里云 OSS WORM 特性及动态更新 ak/sk 信息，提升数据合规性和安全性。数据管理方面，表级恢复支持列存表，新增分区伪列简化查询，同时优化 MySQL 模式下的复合 DDL 操作和堆表旁路导入性能。物化视图功能扩展至支持基表为外表，并增强诊断能力。性能优化方面，硬解析效率提升、统计信息策略统一、数据倾斜场景计划改进及 Sort/CSV 解析优化显著提升处理速度。新增 Map 数据类型、JSON 半结构化存储及稀疏向量类型，丰富数据处理能力，同时引入 `HNSW_BQ` 向量索引优化高维数据检索。系统层面，资源隔离能力增强、大规格国产 CPU 扩展性提升及 Batch DML 优化提高运维效率，MySQL 模式新增 Event Scheduler 和表锁功能，支持定时任务和并发控制。此外，动态分区管理、全局索引自动分裂及配置项解耦 RS 状态等改进进一步简化数据库管理。产品行为变更包括统一会话 ID 语义和默认启用匿名块参数化，提升兼容性与性能。

该版本通过深度 HTAP 能力融合，为高并发事务处理与复杂分析场景提供更安全、高效、智能的分布式数据库解决方案。

**关键缺陷修复：**

* 修复 Oracle 模式下，UDF、UDT 中定义 authid current\_user，解析 PL 对象使用的 namespace 不正确导致执行报错的问题。
* 修复部分 `KILL SESSION` 场景不生效的问题。
* 修复 Oracle 模式下，JDBC setDouble 接口序列化的数据类型兼容性问题。
* 修复 MySQL 模式下，被截断的查询没有提示 warning 的问题。
* 修复调整 dag 队列配置后合并卡住问题。
* 修复旁路导入场景 TLD\_MemChunk 模块内存膨胀导致 4013 的问题。
* 修复备库登录遇到系统触发器开启事务报错的问题。
* 修复物化视图增量刷新导致 CPU 飙高问题。
* 修复 MySQL 模式下大量 trigger 触发调度慢的问题。
* 优化弱网环境下恢复速度。
* 修复 CTE temp table 场景 500 租户内存占用高的问题。
* 修复 MySQL JSON 兼容性问题。
* 修复打开 TDE 加密后合并报错的问题。

### V4.3.5 BP1 Hotfix6

[**点击查看 V4.3.5 BP1 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 05 月 22 日
* 版本号：V4.3.5 BP1 Hotfix6
* RPM 版本号：oceanbase-4.3.5.1-101060022025052114

**关键缺陷修复：**

* 修复 arm 平台下存储下压结果不正确的问题。
* 修复 500 租户内存占用高问题。
* 修复 V4.3.1 升级 V4.3.5，升级写 slog checkpoint 过程中，mark sweep 宏块未回收导致 meta租户 clog 满问题。
* 修复获取统计信息性能损耗严重问题。

### V4.3.5 BP1 Hotfix5

[**点击查看 V4.3.5 BP1 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 04 月 25 日
* 版本号：V4.3.5 BP1 Hotfix5
* RPM 版本号：oceanbase-4.3.5.1-101050012025042323

**关键缺陷修复：**

* 修复调整 dag 队列配置后合并卡住问题。
* 修复 alter modify 修改成非空约束报错问题。
* 修复 tde 加密后合并报错问题。
* 修复 parquet 文件外表读取 `lob` 类型列，列值长度超过 65536 时，查询报错的问题。
* 修复带全局索引的 `replace into` PDML 执行报错 4377 的问题。
* 外表 meta 信息持久化策略优化。

### V4.3.5 BP1 Hotfix4

[**点击查看 V4.3.5 BP1 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 04 月 18 日
* 版本号：V4.3.5 BP1 Hotfix4
* RPM 版本号：oceanbase-4.3.5.1-101040012025041719

**关键缺陷修复：**

* `insert on duplicate key update` 支持 pdml 并行执行。
* 支持 Flush Tables 语法，语法不报错但实际功能不生效。
* 修复物化视图增量刷新 CPU 飙高的问题。
* 优化部分 AP 场景计算性能不优的问题。
* 修复 `string` 类型做主键，特定场景数据正确性问题。
* 修复 `merge into` 语句，`using` 的是 `dual` 表，并且只有 `insert` 或 `update` 其中一个子句时，可能产生报错的问题。
* 修复 ARM 环境宽表场景的性能问题。
* 修复 `union all` SQL 报错 -5807 问题。
* 修复异步统计信息刷新，非预期地刷掉 table 级别 Plan Cache 的问题。
* 修复多个客户端同时创建 prepare\_stmt 且都走到 kvcache 淘汰流程时，偶发节点宕机的问题。

### V4.3.5 BP1 Hotfix3

[**点击查看 V4.3.5 BP1 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 04 月 02 日
* 版本号：V4.3.5 BP1 Hotfix3
* RPM 版本号：oceanbase-4.3.5.1-101030012025040200

**关键缺陷修复：**

* 修复 `_ST_GeoHash` 函数输出结果异常问题。
* 修复 insert on duplicate key update 性能问题。

### V4.3.5 BP1 Hotfix2

[**点击查看 V4.3.5 BP1 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 03 月 31 日
* 版本号：V4.3.5 BP1 Hotfix2
* RPM 版本号：oceanbase-4.3.5.1-101020012025033110

**关键缺陷修复：**

* 修复 ODPS 表不存在相关分区时，通过 ODPS 外表写入 ODPS 表报错的问题。
* 修复自定义 type object id 超过 1048575 时不可用的问题。
* 修复超多投影列的 merge set 路径生成耗时较高的问题。
* 修复 MySQL 模式下 `PERCENTILE_CONT` 表达式反拼错误的问题。

### V4.3.5 BP1

[**点击查看 V4.3.5 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 03 月 18 日
* 版本号：V4.3.5 BP1
* RPM 版本号：oceanbase-4.3.5.1-101010012025031723

**版本概述：**

OceanBase 数据库 V4.3.5 BP1 版本带来了多项功能增强或变动。该版本新增堆组织表模式，显著提升了主键查询速度与数据导入性能；MySQL 模式下引入 `STRING` 数据类型，满足 AP 业务对列长宽容度的需求，同时向量索引新增 `HNSW_SQ` 和 `IVF` 索引类型，进一步优化了向量查询效率。在数据恢复方面，表级恢复通过物理恢复辅助租户机制优化实现性能提升，尤其在无共享模式下支持快速恢复。旁路导入功能增强包括支持堆表带唯一索引的增量导入，并通过向量化优化及流程精简提升导入性能。容灾机制升级为租户级独立容灾，避免 RS 与租户间相互影响。分区管理方面，MySQL 模式新增二级分区支持，全文索引则扩展了分词器属性与布尔模式查询功能。此外，新增 URL 外表支持直接通过 `SELECT` 查询外部数据源，物化视图增强并行度控制与 LOB 类型支持，`CAST`/`IN`/逻辑表达式性能优化提升查询效率。

在兼容性方面，OBKV 组件新增 Cell 级 TTL 和 HBase 攒批执行功能，并推出兼容 Redis 3.2-5.0 的持久化接口。其他重要改进包括列加密函数、PL 触发器增强、Oracle 模式快速删列、`ARRAY` 类型函数完善，以及启动加速至 40 秒内完成集群初始化与租户创建。该版本还对同城双机房容灾模式、HDFS 外表读取等场景进行了功能强化，全面提升了 OLTP/AP 混合负载场景下的性能与易用性。

**关键缺陷修复：**

* 修复创建存储过程后，保存的 DDL 中最尾部的注释丢失的问题。
* 修复行存索引列存表回表代价计算过大的问题。
* 修复 Oracle 模式下 `UNIQUE` 约束被误删导致无法删表问题。
* 修复一些特定场景下内存泄漏问题。
* 修复 Oracle 模式特定场景下临时表关联 `UPDATE` 报错问题。
* 修复特定场景下备份报错问题。
* 修复 OCP 依赖 freeze cnt 参数未清零导致频繁冻结问题。
* 修复走列间等值编码场景合并报错 4103 问题。
* 修复物化视图自增主键达到上限，导致全量刷新报错问题。
* 修复新的 query range 框架，特定场景下扫描代价严重偏低，sql 计划不优问题。
* 修复特定场景下升级后重建局部索引报错问题。
* 修复列转行合并场景 core 的问题。
* 修复列存合并场景读不到事务数据合并超时问题。
* 修复物化视图中包含 array 等没有精度的数据类型刷新报错问题。
* 修复行存表升级后异步行转列导致正确性问题。
* 修复旁路导入使用 insert overwrite 写入大量数据与写统计信息锁冲突导致旁路导入性能变差问题。
* 修复事务数据表无法回收，数据量积累，会导致磁盘爆问题。
* 修复因为 sql\_audit 达到内存上限导致新数据写不进 sql audit 问题。
* 修复向量化 2.0 正交特定场景下一些 core 问题。
* 修复分区倾斜严重场景存储估行偏差。易选错索引导致计划走偏问题。
* 修复行列混存分区表特定场景下收集统计信息失败问题。
* plan size 内存占用优化。
* 修复外表特定场景下查询行数错误问题。
* 修复外表 immediate 模式刷新带分区的外表后删除某分区查询 hung 住问题。
* 修复 DDL 某些并发场景下的数据正确性问题。
* 修复特定场景下使用 PL 造成的内存泄漏和 core 等问题。
* 修复全文索引特定场景内存不安全导致的 core 问题。
* 修复全文索引并发场景下执行卡住/报错等问题。
* 修复 rpc 执行和删租户并发导致的 core 问题。

### V4.3.5 Hotfix12

[**点击查看 V4.3.5 Hotfix12 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2026 年 01 月 14 日
* 版本号：V4.3.5 Hotfix12
* RPM 版本号：oceanbase-4.3.5.0-100120012026011215

**关键缺陷修复：**

* 修复弱读延迟较大的问题。
* 修复物化视图被误 gc 问题。

### V4.3.5 Hotfix11

[**点击查看 V4.3.5 Hotfix11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 07 月 29 日
* 版本号：V4.3.5 Hotfix11
* RPM 版本号：oceanbase-4.3.5.0-100110012025072810

**关键缺陷修复：**

* 修复模拟扩容时，复制表源端复制时 RT 抖动飙高问题。
* 修复迁移 tx data 不连续及迁移写宏块没有检查磁盘水位的问题。

### V4.3.5 Hotfix10

[**点击查看 V4.3.5 Hotfix10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 07 月 17 日
* 版本号：V4.3.5 Hotfix10
* RPM 版本号：ooceanbase-4.3.5.0-100100032025071516

**关键缺陷修复：**

* 修复后台巡检线程遍历导致触发 `get_all_macro_ids` 持有锁卡住，引起业务流量 RT 上涨问题。
* 修复 `MIN`/`MAX` 函数动态内存泄露问题。
* 修复 SqlAggrFunGroCo 模块内存占用太多问题。
* 修复隐式聚合的 `MIN`/`MAX` 函数在 agg row 中没有存储中间结果指针导致的 core 问题。

### V4.3.5 Hotfix9

[**点击查看 V4.3.5 Hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 07 月 02 日
* 版本号：V4.3.5 Hotfix9
* RPM 版本号：oceanbase-4.3.5.0-100090012025063017

**关键缺陷修复：**

* 修复缩容场景， QPS 异常下跌的问题。

### V4.3.5 Hotfix8

[**点击查看 V4.3.5 Hotfix8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 05 月 30 日
* 版本号：V4.3.5 Hotfix8
* RPM 版本号：oceanbase-4.3.5.0-100080012025052715

**关键缺陷修复：**

* 修复物化视图删除后，snapshot 未及时清理导致租户恢复卡住的问题。
* 支持通过配置 `_compaction_prewarm_percentage` 为 100，将物化视图基表 mini/minor 数据 100% 刷入 block cache。
* 修复 parse pl 时日志打印 core 的问题。
* 修复偶发合并卡住的问题。
* 修复 parquet 文件外表读取 lob 类型列，列值长度超过 65536 时，报错 data too long 的问题。
* 修复索引表中已经有数据，通过 `ALTER TABLE` 方式开启 TDE 加密，后续再触发微块重用时，合并报错的问题。
* 修复 500 租户内存占比高的问题。
* 修复 decimal int 与 PL 正交 core 的问题。

### V4.3.5 Hotfix7

[**点击查看 V4.3.5 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 04 月 11 日
* 版本号：V4.3.5 Hotfix7
* RPM 版本号：oceanbase-4.3.5.0-100070012025040810

**关键缺陷修复：**

* 修复 `_ST_GeoHash` 函数输出结果异常的问题。
* 修复使用全文索引合并报错的问题。
* 修复 merge 语法报错的问题。
* 修复表或分区有大的数据变化，统计信息过期后 SPM 选取计划不优的问题。
* 修复 `[G]V$SESSTAT` 和 `[G]V$SESSION_WAIT` 视图缺少后台 Session 记录的问题。
* 修复 MV 增量刷新 CPU 飙高的问题。

### V4.3.5 Hotfix6

[**点击查看 V4.3.5 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 03 月 20 日
* 版本号：V4.3.5 Hotfix6
* RPM 版本号：oceanbase-4.3.5.0-100060022025031922

**关键缺陷修复：**

* 修复列存合并期间持续写入，持续触发冻结导致卡住的问题。
* 修复创建 `immediate` 刷新模式的 ODPS 分区外表后，删除源端 ODPS 表分区，PX 查询该外表 hung 住直到超时的问题。
* 修复外表导入报错 `ERROR 11018 (HY000): Invalid external file: Invalid: Parquet magic bytes not found in footer.` 的问题。
* 修复外表 meta 信息持久化过于频繁导致性能不优的问题。
* 修复触发器中枚举类型比较 bug 导致 `update` 报错 -4016 的问题。
* 修复物化视图后台刷新时 Session 的 database id 设置错误的问题。
* 修复物化视图全量刷新复用原表的自增主键，较快达到上限，导致物化视图全量刷新报错的问题。
* 修复 TPC-H Q7 性能回退的问题。

### V4.3.5 Hotfix5

[**点击查看 V4.3.5 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 02 月 26 日
* 版本号：V4.3.5 Hotfix5
* RPM 版本号：oceanbase-4.3.5.0-100050012025022422

**关键缺陷修复：**

* 修复存储层估行不准导致 cpu 打满的问题。
* 修复外表导入数据不一致的问题。

### V4.3.5 Hotfix4

[**点击查看 V4.3.5 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 02 月 24 日
* 版本号：V4.3.5 Hotfix4
* RPM 版本号：oceanbase-4.3.5.0-100040012025021921

**关键缺陷修复：**

* 优化实时物化视图查询逻辑，解决部分场景下性能不优的问题。
* 修复老版本向量化引擎可能存在的 topn filter 正确性或节点 core 问题。
* 修复带有 `with column group(all columns)` 的行存表，从低版本升级到 4.3.5 版本后，使用异步行转列功能引起的兼容性问题。
* 修复 SQL Audit 内存回收利用失败的问题。

### V4.3.5 Hotfix3

[**点击查看 V4.3.5 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 02 月 10 日
* 版本号：V4.3.5 Hotfix3
* RPM 版本号：oceanbase-4.3.5.0-100030012025020717

**关键缺陷修复：**

* 修复 enum 类型不支持 outer to inner 改写的问题。
* 修复 hash join 等值条件的左侧是一个需要计算表达式而非投影列，且左侧输出的每一行占据空间较大，行长均值大于 256 字节时，可能导致 Core 的问题。
* 优化 Parquet 文件 IO 读取性能。

### V4.3.5 Hotfix2

[**点击查看 V4.3.5 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 01 月 24 日
* 版本号：V4.3.5 Hotfix2
* RPM 版本号：oceanbase-4.3.5.0-100020012025012015

**关键缺陷修复：**

* 优化物化视图合并性能。
* 修复向量化 2.0 路径写空 array core 的问题。

### V4.3.5 Hotfix1

[**点击查看 V4.3.5 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2025 年 01 月 15 日
* 版本号：V4.3.5 Hotfix1
* RPM 版本号：oceanbase-4.3.5.0-100010012025011314

**关键缺陷修复：**

修复物化视图中包含 `ARRAY` 等没有精度的数据类型时，在增量刷新物化视图的时候可能因为错误的检查报错的问题。

### V4.3.5

[**点击查看 V4.3.5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.5)

**版本信息：**

* 发布时间：2024 年 12 月 31 日
* 版本号：V4.3.5
* RPM 版本号：oceanbase-4.3.5.0-100000232024123020

**版本概述：**

OceanBase 数据库 V4.3.5 是面向 AP 场景第一个 LTS 版本。在 V4.3.4 的基础上，新版本继续完善产品能力，新增了对嵌套物化视图的支持，并完善了全文索引和向量索引功能。此外，数据导入导出的能力也得到了增强：支持指定分区旁路导入、外表支持读取 ORC 格式文件，以及 SELECT INTO OUTFILE 现在支持导出 Parquet 和 ORC 格式。优化器能力的增强包括基于基线优先策略的 SPM 演进、优化器估行系统的改进、递归公用表表达式 (CTE) 的抽取与 INLINE 代价验证优化，此外，对 Query Range 提取能力也进行了强化。

在兼容性方面，OceanBase 数据库 MySQL 租户下兼容了 XA 事务功能，完善了 Latin1 字符集，Oracle 租户间的存储过程远程调用支持了复杂类型，助力 Oracle 和 MySQL 业务的平滑迁移。

在性能优化方面，V4.3.5 对表级恢复性能、旁路导入性能、DML 性能以及 DDL 性能都做了不同程度的优化，新版本不仅支持行存与列存的在线转换，还实现了快速中间加列，并且扩展了并行 DDL 操作。同时，通过将统计信息和 CLOG 日志提交集成到资源隔离机制中，并实现了 IO 层级的隔离，进一步增强了 OceanBase 数据库的资源隔离机制。此外，新版本还支持 SQL 级别的内存使用限制，并优化了存储过程的内存使用，以及通过共享线程池来减少租户的内存资源消耗，提升了多种场景下的稳定性。在易用性方面，对 ASH 和 WR 的诊断能力做了增强，支持日志流副本并行迁移优化，以及通过实现日志传输链路的监控视图来增强日志同步链路的可观测性，让 OceanBase 数据库更加好用。新版本支持了更丰富的 ARRAY 和 XML 表达式，对 JSON/XML/GIS 类型数据执行过程中内存占用进行了优化。同时对 OBKV-HBase 和 HBase 的兼容能力做了增强，并支持了 OBKV 的 P95/P99 指标观测。

## V4.3.4

### V4.3.4 BP1

[**点击查看 V4.3.4 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.4)

**版本信息：**

* 发布时间：2024 年 12 月 10 日
* 版本号：V4.3.4 BP1
* RPM 版本号：oceanbase-4.3.4.1-101000022024120914

**版本概述：**

* 特性增强：响应时间统计直方图：当前已支持基于不同 SQL 类别的平均响应时间/最大响应时间指标，但缺乏更细粒度的反映某个分位 SQL 执行性能的指标展示。新版本增加响应时间直方图功能，可基于 [G]V$OB\_QUERY\_RESPONSE\_TIME\_HISTOGRAM 系统视图计算和监控不同类型 SQL 不同分位的响应时间统计。
* 修复共享存储模式下 rebuild 场景误 GC 宏块的问题。
* 修复创建物化视图时偶发快照保留记录漏维护的问题。
* 修复有向量索引的表添加分区失败的问题。

### V4.3.4 GA Hotfix1

[**点击查看 GA Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.4)

**版本信息：**

* 发布时间：2024 年 11 月 29 日
* 版本号：V4.3.4 GA Hotfix1
* RPM 版本号：oceanbase-4.3.4.0-100010012024112517

**版本概述：**

* 修复 OBKV-Hbase scan 时，limit 不生效的问题。
* 修复 OBKV addColumn 两个不同 family 设置同名 column 报错 -5008 的问题。
* 修复 OBKV 指定多个 cf 或不指定 cf，exist 接口导致 Core 的问题。
* 修复物化视图依赖的基表增量数据较多时，实时物化视图查询性能较差的问题。

### V4.3.4

[**点击查看 V4.3.4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.4)

**版本信息：**

* 发布时间：2024 年 10 月 31 日
* 版本号：V4.3.4
* RPM 版本号：oceanbase-4.3.4.0-100000132024103017

**版本概述：**

OceanBase V4.3.4 是面向 AP 业务的 GA 版本，在第一个 GA 版本 V4.3.3 的基础上，新增多个重要特性。推出面向 TP 历史库业务场景的存算分离产品形态，利用标准对象存储来共享基线数据和日志数据，有效降低存储成本，由于实现了存储和计算分离，增强了节点的扩缩容弹性；完善多值索引能力，丰富全文索引场景，提升查询性能；完善旁路导入功能，优化主键表写临时文件开销，提高数据导入效率；新增自动分区分裂功能、Format Outline 功能、租户级全局控制导数走旁路导入功能，提升产品易用性；通过拆分 DBMS\_SCHEDULER 任务调度线程到租户级别、用户表锁请求不占用租户工作线程等系统改造，提升产品稳定性；同时对 OBKV 支持全局索引、OBKV-HBase 能力增强等 V4.2.5 及之前版本的大部分特性，进行了补充支持。

## V4.3.3

### V4.3.3 BP1 Hotfix6

[**点击查看 V4.3.3 BP1 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2025 年 02 月 07 日
* 版本号：V4.3.3 BP1 Hotfix6
* RPM 版本号：oceanbase-4.3.3.1-101060012025012322

**版本概述：**

修复 4.3.3 版本 bloom filter 后构建特性引入 bug，导致节点 core 的问题。

### V4.3.3 BP1 Hotfix5

[**点击查看 V4.3.3 BP1 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2025 年 01 月 14 日
* 版本号：V4.3.3 BP1 Hotfix5
* RPM 版本号：oceanbase-4.3.3.1-101050022025011419

**版本概述：**

* 修复 dag 模块 bug 导致节点 core 的问题。
* PL 支持 Roaringbitmap 数据类型。
* 支持 `SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED` 语法不报错，隔离级别实际表现为 Read Committed。

### V4.3.3 BP1 Hotfix4

[**点击查看 V4.3.3 BP1 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2024 年 12 月 30 日
* 版本号：V4.3.3 BP1 Hotfix4
* RPM 版本号：oceanbase-4.3.3.1-101040032024123011

**版本概述：**

* 修复 SQL 计划突变，索引选择不优的问题。
* 修复 memstore 凌晨释放慢的问题。
* 修复存储过程报错 -4013 的问题。
* 修复合并 checksum error 问题。
* 支持 parquet 读 IO 优化。
* 修复自增列返回 last insert id 和 MySQL 不一致的问题。

### V4.3.3 BP1 Hotfix3

[**点击查看 V4.3.3 BP1 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2024 年 12 月 02 日
* 版本号：V4.3.3 BP1 Hotfix3
* RPM 版本号：oceanbase-4.3.3.1-101030022024120210

**版本概述：**

* 修复修改列 Skip Index 属性后，下一轮合并有宏块重用时合并报错的问题。
* 修复 `Sdo_Geometry` 只打印 9 位精度的问题。
* 修复 2 副本的 data checksum error 丢失问题。
* 修复使用匿名块向 DATE 类型插入空串时报错 OBE-01840 的问题。
* 修复 PS 协议下，包含大 inlist 的 SQL 查询耗时过高的问题。

### V4.3.3 BP1 Hotfix2

[**点击查看 V4.3.3 BP1 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2024 年 11 月 13 日
* 版本号：V4.3.3 BP1 Hotfix2
* RPM 版本号：oceanbase-4.3.3.1-101020012024111309

**版本概述：**

* 修复 PX 线程打满 CPU 的问题。
* 修复通过 parquet 外表查询多列数据的场景，列排布与 Parquet Page 不一致导致报错 -4258 的问题。
* 修复 SQL 触发的 core 问题。
* 修复分区表局部索引估行过小的问题。

### V4.3.3 BP1 Hotfix1

[**点击查看 V4.3.3 BP1 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2024 年 11 月 04 日
* 版本号：V4.3.3 BP1 Hotfix1
* RPM 版本号：oceanbase-4.3.3.1-101010012024110321

**版本概述：**

修复 partition wise join 场景中，`UPDATE` 执行报错 -4016 的问题。

### V4.3.3 BP1

[**点击查看 V4.3.3 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2024 年 10 月 18 日
* 版本号：V4.3.3 BP1
* RPM 版本号：oceanbase-4.3.3.1-101000032024102022

**版本概述：**

* 新增从 V4.2.4\_CE 版本 patch 的 “SQL实时诊断” 特性。
* 修复一些 BUG 和稳定性问题。

### V4.3.3

[**点击查看 V4.3.3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.3)

**版本信息：**

* 发布时间：2024 年 9 月 30 日
* 版本号：V4.3.3
* RPM 版本号：oceanbase-4.3.3.0-100000412024101200

**版本概述：**

OceanBase V4.3.3 作为 4.3 系列的第一个 GA 版本发布，在几个关键场景完成了突破。一是在关系型数据库基础上支持了适用于 AI 类分析处理的向量类型及索引；二是更好满足 HTAP 混合负载场景下，TP、AP 资源物理强隔离诉求的全新的列存副本形态；三是面向 AP 类查询任务的整体可观的性能提升。除此之外，新增 `ARRAY` 复杂类型支持、优化 Roaringbitmap 类型计算性能，强化物化视图改写刷新等能力，扩展外表功能、提高外表导入性能，优化 AP 类 SQL 的计划生成和执行策略，加快面向 OLAP 负载的产品化能力提升。新版本还支持了一种只需恢复日志无需恢复数据到本地即可提供读服务的快速恢复能力，也支持了 QUERY 级别的资源组设定，提升了系统的可靠性和易用性。同时，V4.2.4 及之前版本的绝大部分特性已经在 V4.3.3 补充支持，后续也会推出同样可应用于 OLTP 业务生产的全新融合版本。

## V4.3.2

### V4.3.2 Beta

[**点击查看 V4.3.2 Beta Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.2)

**版本信息：**

* 发布时间：2024 年 7 月 16 日
* 版本号：V4.3.2 Beta
* RPM 版本号：oceanbase-4.3.2.0-100000442024071321

**版本概览：**

OceanBase V4.3.2 是面向 AP 业务的性能增强版本，数据读取、数据分发、数据计算、向量化处理、计划选择全方位改进，AP 类基准测试性能整体提升 10%-15%。引入 Roaringbitmap 数据类型及相关计算表达式，给大数据集合运算和去重场景提供了更优选择。丰富增量旁路导入功能、提升全量旁路导入性能，扩展支持 Parquet 文件外表，加速大规模数据的处理速度。作为一款一体化数据库，新版本也针对 `express oltp`、`complex oltp`、`olap`、`htap`、`kv` 等 5 类场景分别梳理了场景化参数模版，配合部署工具，让初始配置就适合每一种业务类型。此外，新版本还融合了 V4.2.x 系列前序版本的诸多兼容性增强和用户体验改进特性，并合入了TP 类 SQL 的性能改进，致力于满足各类应用场景对产品的诉求。

## V4.3.1

### V4.3.1 Beta

[**点击查看 V4.3.1 Beta Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.1)

**版本信息：**

* 发布时间：2024 年 5 月 17 日
* 版本号：V4.3.1 Beta
* RPM 版本号：oceanbase-4.3.1.0-100000212024051522

**版本概览：**

OceanBase V4.3.1 在 V4.3.0 基础上，新增全文索引特性提升文档检索效率，扩展实时物化视图、物化视图改写、主键物化视图等功能以满足多场景的分析需求。引入分区管理新机制，如分区交换、外表分区、MySQL 模式分区键数据类型扩展等，提升大规模数据的处理能力。多模特性（含 JSON、XML、GIS）功能升级，增加 JSON 多值索引、JSON 部分更新的能力支持，促进异构数据的迁移与融合。MySQL 与 Oracle 兼容性持续增强，支持 Lateral Derived Tables、 MySQL 锁函数、Oracle 视图注释与远程 UDF 调用等，以便融入生态。提供增量旁路导入能力，提升了多次导入场景的入库性能，同时优化了多局部索引场景下的 DML 性能，提高了基础统计信息收集效率，并在行采样、小规格 TP 场景取得了显著的性能提升。新版本也进一步优化了资源使用，支持了 CLOG 日志缓存和存储压缩、SQL 临时结果压缩、系统日志压缩等特性。补充完善了 MySQL 权限体系、支持了操作系统配置检查，加固系统安全。一如既往地关注用户体验，增加资源规格估算能力，增强备份透明度，提供 IPV6 格式支持，赋能数据库管理与运维。 V4.3.1 定位为 Beta 版本，推荐实时数仓或联机交易业务测试使用，下半年将发布推荐用于生产的 GA 版本。

## V4.3.0

### V4.3.0 Beta

[**点击查看 V4.3.0 Beta Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.3.0)

**版本信息：**

* 发布时间：2024 年 3 月 22 日
* 版本号：V4.3.0 Beta
* RPM 版本号：oceanbase-4.3.0.1-101000062024032200
* 版本说明：Beta 版本解决了大部分缺陷，并趋于稳定。推荐测试环境使用。

**版本概览：**

OceanBase 数据库 V4.3.0 版本深入典型 AP 场景，不再局限于 TP + 轻量化 AP 的版本定位。基于 LSM-Tree 架构推出列存引擎，实现行存、列存数据存储一体化，同时推出基于 Column 数据格式描述的新版向量化引擎和基于列存的代价模型，支持高效处理大宽表，显著提升 AP 场景查询性能，并兼顾 TP 业务场景。新增 Oracle 兼容的物化视图功能，通过预计算存储视图的查询结果提升实时查询性能，支撑快速报表生成和数据分析场景。新版本内核也扩展了 Online DDL、支持了租户克隆等功能，优化 PDML、优化 `LOB` 类型旁路导入性能、节点重启性能，增加 S3 备份恢复介质支持，优化系统资源使用，并增加索引使用监控、客户端本地导入等功能提升系统易用性。推荐用于复杂分析、实时报表、实时数仓或联机交易等混合负载场景。

## V4.2.5

### V4.2.5 BP7 Hotfix14

[**点击查看 V4.2.5 BP7 hotfix14 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 07 月 08 日
* 版本号：V4.2.5 BP7 Hotfix14
* RPM 版本号：oceanbase-4.2.5.7-107110022026052719

**版本概览：**

* Fix dblink hang caused by connection cleanup during commit.
* Fix meta merge persisting NOP into major sstable after add column.
* Fix core at double destruct slice\_writer\_.
* Fix slog ckpt abort due to retryable io err.

### V4.2.5 BP7 Hotfix13

[**点击查看 V4.2.5 BP7 hotfix13 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 06 月 30 日
* 版本号：V4.2.5 BP7 Hotfix13
* RPM 版本号：oceanbase-4.2.5.7-107130022026062610

**版本概览：**

* Fix bug caused by the concurrency of transfer and partition splitting.
* Optimize ddl kv dump scheduler.
* Fix: update sequence\_id after ddl.
* Fix oracle json\_merge\_patch expr core.
* Fix base64\_decode function to support strings containing newline characters.
* Fix fast parser mismatches identifiers starting with INSERT/REPLACE prefix.
* Fix: let ObTimeGuard warn without trace logging.
* Fix incorrect logging when obtaining di.

### V4.2.5 BP7 Hotfix12

[**点击查看 V4.2.5 BP7 hotfix12 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 06 月 09 日
* 版本号：V4.2.5 BP7 Hotfix12
* RPM 版本号：oceanbase-4.2.5.7-107120012026060515

**版本概览：**

* Fix JSON expression returning wrong result when json\_path is dynamic const in NLJ.
* Upgrade libcurl version to meet security requirements.

### V4.2.5 BP7 Hotfix11

[**点击查看 V4.2.5 BP7 hotfix11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 05 月 29 日
* 版本号：V4.2.5 BP7 Hotfix11
* RPM 版本号：oceanbase-4.2.5.7-107110022026052719

**版本概览：**

* Fix coredump in utl file.
* Fix hash join crash in nestloop mode with left output join.
* Fixed that automatic source switching was not triggered due to palf log replication stall.
* Fix correctness issue caused by two lines of batch statements for update + lock.

### V4.2.5 BP7 Hotfix10

[**点击查看 V4.2.5 BP7 hotfix10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 05 月 12 日
* 版本号：V4.2.5 BP7 Hotfix10
* RPM 版本号：oceanbase-4.2.5.7-107100012026050915

**版本概览：**

* Stop-server ignores -4019 servers.

### V4.2.5 BP7 Hotfix9

[**点击查看 V4.2.5 BP7 hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 05 月 09 日
* 版本号：V4.2.5 BP7 Hotfix9
* RPM 版本号：oceanbase-4.2.5.7-107090012026050615

**版本概览：**

* Support order by for left child of union.

### V4.2.5 BP7 Hotfix8

[**点击查看 V4.2.5 BP7 hotfix8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 04 月 22 日
* 版本号：V4.2.5 BP7 Hotfix8
* RPM 版本号：oceanbase-4.2.5.7-107080022026042120

**版本概览：**

* Fix direct load ddl task hang.
* Support parallel ddl for empty set CTAS.
* Fix some issues about ob\_log.

### V4.2.5 BP7 hotfix7

[**点击查看 V4.2.5 BP7 hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 04 月 14 日
* 版本号：V4.2.5 BP7 Hotfix7
* RPM 版本号：oceanbase-4.2.5.7-107070012026041221

**版本概览：**

* Fix issue is\_batched\_multi\_stmt = 0 when value as column name.
* Add async /proc cpu sampler for high tenant count scenario.
* Fix unit GC causing client disconnections.
* Free a log\_cb\_pool with the gc\_pool\_list.
* Allow tenant worker processing mysql requests and responsing error packet during tenant kill session.

### V4.2.5 BP7 hotfix6

[**点击查看 V4.2.5 BP7 hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 03 月 27 日
* 版本号：V4.2.5 BP7 Hotfix6
* RPM 版本号：oceanbase-4.2.5.7-107060012026032514

**版本概览：**

* Fix left to anti replace part expr cause 4016.
* Fix ObSPIService::get\_result flush\_buffer when rend query result to client.
* Fix insert\_up global index is\_row\_changed\_ inconsistency causing 4377.
* Fix insert up does not use get.
* Fix goto stmt add close local cursor variable.
* Fix hash join op not skip left null.
* Fix the missing fields in hash cnnt by serialization.
* Fix a core when use duplicated keys in associative array constructor with =>.
* Fix result error when pushing limit with sql\_calc\_found\_rows.

### V4.2.5 BP7 hotfix5

[**点击查看 V4.2.5 BP7 hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 02 月 27 日
* 版本号：V4.2.5 BP7 Hotfix5
* RPM 版本号：oceanbase-4.2.5.7-107050012026022515

**版本概览：**

* Support app\_trace\_id.
* Fix enable cgroup partly not effected.
* Fix disable pushdown limit to rcte.

### V4.2.5 BP7 Hotfix4

[**点击查看 V4.2.5 BP7 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 02 月 10 日
* 版本号：V4.2.5 BP7 Hotfix4
* RPM 版本号：oceanbase-4.2.5.7-107040022026020919

**版本概览：**

* Fix missing table alias name when building rowid expr.
* Blocker ctas force refresh table schema after alter table.
* Fix spf pkey distributed plan bug for null value.
* Fix the issue of slow dbms\_lob.read performance.
* Fix backup memory usage alloc speed and free speed not match issue.
* Add the fsync before read macro block during the construction of sstable.
* Fix compat version.
* Fix truncate table cannot clean useless \_\_all\_monitor\_modified.
* Fix upgrade script error when add -t parameter.

### V4.2.5 BP7 Hotfix3

[**点击查看 V4.2.5 BP7 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 01 月 16 日
* 版本号：V4.2.5 BP7 Hotfix3
* RPM 版本号：oceanbase-4.2.5.7-107030012026011319

**版本概览：**

* Fix rownum to offset constraint bug.
* Support disable shared expr extraction by hint.
* Add some transaction error code to inner error code.
* Fix merge join accumulating match\_groups\_ without reseting problem.
* Fix tmp file dir id leakage.
* Fix a bug where the result set of a merge join is incorrect when the join condition contains shared expr.
* Meta tenant does not update throttle limit adaptively.
* Fix deterministic udf issue.
* Fix the inconsistency in the to\_char result compared to Oracle.
* Remove remove\_const expr during aggr subquery pullup.
* Fix the uint64\_t underflow issue in tablet stat.
* Fix noorder auto increment ddl report 4038.
* Data inconsistency caused by concurrent batch insert operations.
* Fix clean dblink conn hang bug.
* Fix select chinese schema@dblink bug.
* Fix show create table lost template information.
* Fix SYS\_CONTEXT's map is not initialized due to DDLResolver use ObSQLSessionInfo::test\_init() to init session.
* Streaming cursor read uncommitted data behavior compatibility.
* Fix overwrite return code in range filter deserialization.
* Fix priv issue when switch db & modify definer pl action.
* Fix the inaccuracy of the upper\_trans\_version for major sstable.
* Fix prevent unexpected session push to session pool if alloc sys\_vars\_() fails.
* Check row count in micro\_writer before build new micro block.
* Update progressive\_merge\_round for sys tables.
* Fix ObIDiagnoseInfoMgr use-after-free.

### V4.2.5 BP7 Hotfix2

[**点击查看 V4.2.5 BP7 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 12 月 12 日
* 版本号：V4.2.5 BP7 Hotfix2
* RPM 版本号：oceanbase-4.2.5.7-107020022025121120

**版本概览：**

* Fix direct load support unused column.
* Fix alter routine compile debug issue.
* Window func reuses frame to improve performance.
* Fix init ObInsertUpCtDef.

### V4.2.5 BP7 Hotfix1

[**点击查看 V4.2.5 BP7 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 11 月 28 日
* 版本号：V4.2.5 BP7
* RPM 版本号：oceanbase-4.2.5.7-107010032025112814

**版本概览：**

* Fix typed null add plan bug.
* Fix mysql exception add ob\_error\_code to check is internal\_error.
* Fix create index report 5019.
* Change default server\_status\_ of ok pkt from 0x22 to 0x02.
* Fix the wild pointer issue in the log stream balancing module.
* Fix query string is too long to display.
* Fix push subquery bug.
* Fix non-deterministic filters should not be pushdown to basic table.
* Fix format\_exception\_stack add error\_messeage charset\_convert.
* Avoid querying tablet before transfer in commit.
* Support remove\_lock\_priority in ob\_admin.
* Use hint to change lock\_mode in dml.
* Fix NEW.col as an inner call inout parameter in trigger.
* Slog checkpoint adapt log only replica.
* Feat insertup do up directly.
* Change \_update\_all\_columns\_for\_trigger default value to true.

### V4.2.5 BP7

[**点击查看 V4.2.5 BP7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 11 月 3 日
* 版本号：V4.2.5 BP7
* RPM 版本号：oceanbase-4.2.5.7-107000092025103121

**版本概览：**

V4.2.5 BP7 版本进行了多项优化与增强：

* **优化选主策略**

  针对 4F1A 场景，primary\_zone 设置为 "z1,z2;z3,z4"，当 z1、z2 所在 region 不可用时，在 V4.2.5 BP7 之前的版本，会选举 IP 最小的 Zone 作为新主，即 Leader 会全部切到 z3 而非均衡到 z3 和 z4。在 V4.2.5 BP7 支持了优化选主策略后，当高优先级的所有 Zone 都不可用时，Leader 会均匀打散到低一个优先级的各 Zone，即 Leader 会打散分布在 z3 和 z4 上，由此提高系统的高可用性。
* **支持批量获取索引 DDL**

  Oracle 租户模式下扩展 DBMS\_METADATA 指令，支持以主表 `table_name`，`schema_name` 为条件批量获取该表的所有 Index DDL 的函数 [GET\_TABLE\_INDEX\_DDL](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000004275063)；通过传入 `table_name` 获取该表的所有 Index DDL，避免了根据每一个 `index_name` 来获取 Index DDL 的多次查表问题；其次，方案通过将存储过程拆分成多个能够走索引的 SQL，避免了全表扫描造成的性能缺陷。
* **SQLSTAT 能力增强**

  支持 `multi_query` 用以判断路由错误和同步提交；支持 `muti_query_batch_execute` 可以用来判断语句是否走 Batch 优化；支持 `full_table_scan` 用以判断 SQL 出现全表扫的次数；支持 `error_count` 用以统计 SQL 报错情况。更多详细内容，请通过 [GV$OB\_SQLSTAT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501652) 或 [DBA\_WR\_SQLSTAT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501724) 等视图获取。
* **ASH REPORT 生成加速**

  由于 ASH REPORT 的生成涉及 JOIN ASH 数据和 WR 数据，耗时较长，本特性在不改变 ASH REPORT 的行为的情况下，加速了 ASH REPORT 的生成。
* **Oracle 模式下支持 PL/SQL Wrap 功能**

  [PL/SQL Wrap](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000004275061) 功能允许用户将 PL/SQL 对象的源码进行加密混淆，防止任何人从 `*_SOURCE` 视图中查看加密对象的明文源码，从而可以满足部分业务保护核心算法和流程的需求。OceanBase 提供了 Wrap Utility 和 DBMS\_DDL 系统包两种方式进行 PL/SQL 源码加密。
* **备份归档适配 OSS WORM**

  阿里云 OSS 提供了 [WORM（Write Once Read Many）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499882#1-title-%E9%85%8D%E7%BD%AE%E5%BD%92%E6%A1%A3%E7%9B%AE%E7%9A%84%E7%AB%AF) 特性，用户通过命令为 Bucket 配置保留策略后，在保留策略指定的 Object 保留时间到期之前，仅支持在 Bucket 中上传和读取 Object。Object 保留时间到期后，才可以修改或删除 Object。新版本 OceanBase 数据库备份归档适配了阿里云 OSS 的 WORM 特性，支持使用已配置合规保留策略的 OSS Bucket 作为备份归档目的端，帮助用户满足数据安全存储及政策合规要求。

### V4.2.5 BP6 Hotfix4

[**点击查看 V4.2.5 BP6 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2026 年 03 月 31 日
* 版本号：V4.2.5 BP6 Hotfix4
* RPM 版本号：oceanbase-4.2.5.6-106040012026033011

**版本概览：**

* Add async /proc cpu sampler for high tenant count scenario.

### V4.2.5 BP6 Hotfix3

[**点击查看 V4.2.5 BP6 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 11 月 25 日
* 版本号：V4.2.5 BP6 Hotfix3
* RPM 版本号：oceanbase-4.2.5.6-106030012025112319

**版本概览：**

* Fix typed null add plan bug.
* Fix mysql exception add ob\_error\_code to check is internal\_error.
* Fix create index report 5019.
* Fix the wild pointer issue in the log stream balancing module.
* Fix push subquery bug.
* Fix non-deterministic filters should not be pushdown to basic table.
* Fix format\_exception\_stack add error\_messeage charset\_convert.
* Avoid querying tablet before transfer in commit.

### V4.2.5 BP6 Hotfix2

[**点击查看 V4.2.5 BP6 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 10 月 24 日
* 版本号：V4.2.5 BP6 Hotfix2
* RPM 版本号：oceanbase-4.2.5.6-106020012025102316

**版本概览：**

* 修复部署集群时区不符合预期的问题。
* 修复添加非空 LOB 列后遗漏非空约束的问题。
* 修复计算 `shared_meta_bytes` 前未重置空间使用量的问题。
* 修复建表后更改列定义时报错 maximum key length exceeded 的问题。
* 修复迁移过程中缺少可选配置以跳过必要空间检查的问题。
* 修复在 PS+SPM 场景下 SQL 请求被硬解析的问题。
* 修复 LOB 定位器事务快照中缺少 `fb_snapshot` 的问题。
* 修复空 `outrow_lob` 数据处理不当的问题。
* 修复某些 DDL 操作导致主键长度超过 16K 但未报错的问题。

### V4.2.5 BP6 Hotfix1

[**点击查看 V4.2.5 BP6 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 09 月 25 日
* 版本号：V4.2.5 BP6 Hotfix1
* RPM 版本号：oceanbase-4.2.5.6-106010022025092415

**版本概览：**

* 修复执行 SQL 报错 4377 的问题。默认使用 MERGE ANTI JOIN 会报错，指定 hint 走 HASH ANTI JOIN 后正常执行。
* 修复带 maxversion 的表进行 deleteColumns 或 deleteFamily 操作时数据删除遗漏的问题。
* 修复 ObRowStore 发生异常时缓冲区未释放的问题。
* 修复升级后调用存储过程报错的问题。通过添加版本控制机制，确保能正常调用 Show Create 函数。
* 修复更新参数时出现的死锁问题。在查询内部 SQL 时不再持有 `ObTenantConfigMgr::rwlock_` 锁。

### V4.2.5 BP6

[**点击查看 V4.2.5 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 08 月 25 日
* 版本号：V4.2.5 BP6
* RPM 版本号：oceanbase-4.2.5.6-106000052025082216

**版本概览：**

V4.2.5 BP6 版本进行了多项优化与增强：

* 在分布式执行的全局索引回表场景下，性能提升了 3%–5%；
* 优化备库读功能并增强其稳定性；
* 扩展支持通过 Azure Blob 协议访问 Azure Blob 对象存储；
* 新增 UDF 结果缓存功能，并针对无法缓存的场景优化了执行路径；
* 新增 TO\_PINYIN 表达式，并增加可选参数，支持控制输出的大小写、全拼或首字母格式。

### V4.2.5 BP5 Hotfix2

[**点击查看 V4.2.5 BP5 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 08 月 18 日
* 版本号：V4.2.5 BP5 Hotfix2
* RPM 版本号：oceanbase-4.2.5.5-105020012025081414

**版本概览：**

* 修复 rownum >=0 生成的约束有误，导致命中不了计划的问题。
* 放开 oceanbase 库 inner sql 绑定 Outline 的权限。
* 修复清理过期备份遗留 infos 和 complement\_log 目录的问题。
* 修复 insert select 表带有 trigger 时，向量化执行性能差的问题。
* 修复 ELR 失效的问题，回滚导致 ELR 性能回退的优化。
* 修复 INNER PATH 索引裁剪的问题。
* 修复谓词复杂和 AND 太多导致的 Query Range 抽取慢的问题。
* 兼容 Oracle 的 JOSN 约束检查行为。
* 修复 drop/truncate partition update globale indexes 完成后部分全局索引仍处于重建阶段的问题。
* 修复 NULL 值没有命中 FALSE 约束，无法命中计划导致频繁硬解析的问题。
* 修复使用 SPM 时数据持续增长的问题，限制 Baseline 相关内部表存储，原始的 SQL 文本长度由之前的 10M 调整为 64K。
* 修复 DML RETURNING 遇到锁冲突将错误码抛给用户的问题。
* 修复内部死锁记录表时间显示异常的问题。
* 异构 Zone 对租户倍数变更场景的优化。
* 修复异构 Zone 在配置项 `enable_transfer` 关闭时，增加 Unit 会持续不结束的问题。
* 修复缩容 Unit 时 RT 突增的问题。

### V4.2.5 BP5 Hotfix1

[**点击查看 V4.2.5 BP5 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 07 月 18 日
* 版本号：V4.2.5 BP5 Hotfix1
* RPM 版本号：oceanbase-4.2.5.5-105010032025071717

**版本概览：**

* 修复 PL Resolver 对 `*."LEVEL"` 处理中，涉及 SQL 列名为 LEVEL 时报语法错误的问题。
* 修复 PL 存在与同义词依赖同名的对象时，查询缓存被认为过期，需要重新 Resolver 的问题。
* 修复 OBKV async query 场景中，Session 回收后被重复使用野指针导致 core dump 的问题。
* 修复 Sequence 在主备库切换和 DDL 的场景下，导致序列值重复的问题。

### V4.2.5 BP5

[**点击查看 V4.2.5 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 07 月 10 日
* 版本号：V4.2.5 BP5
* RPM 版本号：oceanbase-4.2.5.5-105000052025070822

**版本概览：**

V4.2.5 BP5 版本支持了异构 Zone 功能，同一租户支持至多拥有两种不同的 Unit Num，为 OBServer 的运维能力和扩缩容能力带来了提升。此前 OBServer 受限于同一租户各 Zone 的 Unit Num 必须相同，当遇到故障且没有机器替换时，需要将所有 Zone 都降低 Unit Num，扩大了运维范围；此外，扩缩容场景可以利用该能力在 Follower 副本先行操作，然后切换 Leader 至扩缩容完成的 Zone，实现更平滑的扩缩容；另外还在 MySQL 模式下支持快速删列，标记删除无需数据重整。

### V4.2.5 BP4 Hotfix7

[**点击查看 V4.2.5 BP4 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 11 月 14 日
* 版本号：V4.2.5 BP4 Hotfix7
* RPM 版本号：oceanbase-4.2.5.4-104070012025111400

**版本概览：**

* Fix alter table failed.
* Avoid querying tablet before transfer in commit.

### V4.2.5 BP4 Hotfix6

[**点击查看 V4.2.5 BP4 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 09 月 08 日
* 版本号：V4.2.5 BP4 Hotfix6
* RPM 版本号：oceanbase-4.2.5.4-104060012025090511

**版本概览：**

* 增加日志巡检和归档管理，实现问题的早期发现和快速定位。
* 修复使用 SPM 时数据持续增长的问题，限制 Baseline 相关内部表存储（原始 SQL 文本长度由之前的 10M 调整为 1K）。
* 修复 DBLink 连接缓存导致 Crash 的问题。
* 增加版本控制，解决升级后 SHOW CREATE FUNCTION 报错的问题。

### V4.2.5 BP4 Hotfix5

[**点击查看 V4.2.5 BP4 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 08 月 01 日
* 版本号：V4.2.5 BP4 Hotfix5
* RPM 版本号：oceanbase-4.2.5.4-104050032025073119

**版本概览：**

* 修复清理过期备份遗留 infos 和 complement\_log 目录的问题。
* 修复 ELR 失效的问题，回滚导致 ELR 性能回退的优化。
* 修复谓词复杂和 AND 太多导致的 Query Range 抽取慢的问题。
* 修复 INNER PATH 索引裁剪的问题。

### V4.2.5 BP4 Hotfix4

[**点击查看 V4.2.5 BP4 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 07 月 15 日
* 版本号：V4.2.5 BP4 Hotfix4
* RPM 版本号：oceanbase-4.2.5.4-104040042025071121

**版本概览：**

* 修复 SPM 硬解析时间过长的问题，优化获取回放基线策略。
* 修复事务在两阶段提交过程中参与者因为异常原因被杀后，主事务进入提交流程发送提交给参与者导致 Crash 的问题。
* 修复 S3 协议恢复慢的问题。
* 修复 PL 执行参数类型不匹配报错的问题。
* 修复 Sequence 在主备库切换和 DDL 的场景下，导致序列值重复的问题。
* 修复 NULL 值没有命中 FALSE 约束，无法命中计划导致频繁硬解析的问题。
* 修复迁移复制过程中，源端的 IO 未正确打标，原本应归类为 background group 的 IO 被错误地归入了预留给 SQL 前台请求的 other group，导致前台 IO 被无关操作占用，从而影响了用户 TPS/QPS 的问题。

### V4.2.5 BP4 Hotfix3

[**点击查看 V4.2.5 BP4 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 07 月 03 日
* 版本号：V4.2.5 BP4 Hotfix3
* RPM 版本号：oceanbase-4.2.5.4-104030012025070212

**缺陷修复：**

* 修复因复制表 `advisor_table_id` 配置错误，复制表的约束设置为普通表（REMOTE）时，导致执行计划无法匹配副本的问题。
* 修复普通表与复制表关联查询时，因复制表无法感知到普通表副本的选择情况，直接选择了 LOCAL 副本而错误生成分布式计划，导致无法命中 REMOTE 计划的问题。
* 修复 SPM 在演进计划完成时间点遭遇大量并发流量时，为较差的演进计划连续分配流量，导致演进计划平均 CPU 时间统计偏低，进而错误判定该计划胜出的问题。
* 修复开启 SPM 功能时，执行 `ALTER SYSTEM FLUSH LIB CACHE GLOBAL;` 命令刷新 Lib Cache 导致 Baseline 强制清除内存，从而 Crash 的问题。
* 修复因复制表 `advisor_table_id` 配置错误，当复制表的约束设置为普通表（REMOTE）时，导致执行计划无法匹配副本的问题。

### V4.2.5 BP4 Hotfix2

[**点击查看 V4.2.5 BP4 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 06 月 24 日
* 版本号：V4.2.5 BP4 Hotfix2
* RPM 版本号：oceanbase-4.2.5.4-104020022025062018

**版本概览：**

* 修复改写推导谓词错误导致的正确性问题。
* 修复游标投影列包含字符类型列时报错的问题。
* 修复 PL Profiler 在并行执行场景下的报错问题。
* 通过 RCTE 优化视图间依赖关系计算。
* 修复视图 `ALL_INDEXES` Filter 顺序交换导致的执行报错问题。
* 修复当 SPM 使用 fixed baseline 或 BaselineFirst 模式时，因访问已释放内存导致 Crash 的问题。

### V4.2.5 BP4 Hotfix1

[**点击查看 V4.2.5 BP4 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 06 月 16 日
* 版本号：V4.2.5 BP4 Hotfix1
* RPM 版本号：oceanbase-4.2.5.4-104010032025061319

**版本概览：**

* 修复多线程并发读取内部表 Baseline 至内存与写入新计划 Baseline 时，因内存访问冲突导致的错误 5136 问题。
* 修复包含动态参数的 range prefix cnt 计算错误导致的计划未按预期裁剪的问题。
* 修复 SPM+PS 模式添加获取计划失败时反复重试的问题。
* 修复大事务在并发回调一条日志的情况下，Checksum 状态机维护错误，导致 Leader 上 Checksum 计算有误与 Follower 上报 Checksum 不一致的问题。
* 修复 Clog 持久化失败导致事务超时的问题。
* 修复 OLTP 使用索引查询性能回退的问题。

### V4.2.5 BP4

[**点击查看 V4.2.5 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 05 月 30 日
* 版本号：V4.2.5 BP4
* RPM 版本号：oceanbase-4.2.5.4-104000082025052817

**版本概览：**

V4.2.5 BP4 版本实现了多项性能优化与功能增强：在性能方面，重构了 `INFORMATION_SCHEMA.COLUMNS` 视图以支持索引点查；优化空表索引创建速度；支持特定场景下预计算子查询降低计算量；将 DDL 操作后的 Schema 刷新机制由 Session 级升级至 Server 级；采用新 SPM 演进策略降低代价；通过日志流再均衡减少热点风险。在功能方面，新增旁路导入 OceanBase 数据库 2.x 备份数据；MySQL 模式支持二级分区添加；备库日志裁剪提升 Failover 能力；旁路导入异步 Commit 规避单任务超时回滚。此外，该版本还强化了备库读稳定性。

### V4.2.5 BP3 Hotfix6

[**点击查看 V4.2.5 BP3 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 11 月 13 日
* 版本号：V4.2.5 BP3 Hotfix6
* RPM 版本号：oceanbase-4.2.5.3-103060032025111215

**版本概览：**

* 修复 PL 循环使用 `DBMS_LOB.WRITEAPPEND` 包导致内存膨胀的问题。
* 修复 `utl_file` 在特定场景下触发 Core Dump 的问题。
* 修复临时表隔离产生死锁的问题。
* 修复迁移失败报错 4551 的问题。

### V4.2.5 BP3 Hotfix5

[**点击查看 V4.2.5 BP3 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 06 月 19 日
* 版本号：V4.2.5 BP3 Hotfix5
* RPM 版本号：oceanbase-4.2.5.3-103050012025061710

**版本概览：**

* 修复包含动态参数的 range prefix cnt 计算错误导致的计划未按预期裁剪的问题。
* 修复 DBLink 场景下队列积压问题。

### V4.2.5 BP3 Hotfix4

[**点击查看 V4.2.5 BP3 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 06 月 03 日
* 版本号：V4.2.5 BP3 Hotfix4
* RPM 版本号：oceanbase-4.2.5.3-103040042025052114

**版本概览：**

* 修复 PL Cursor 嵌套调用场景下内存膨胀的问题。
* 修复修改 `_push_join_predicate` 参数后，原本包含非基表条件下推的嵌套循环连接（NLJ）执行计划，在通过 Outline 回放时被优化器改写为笛卡尔积后执行连接条件的普通 NLJ 计划。由于两种计划的优化器计算逻辑差异未体现在 Plan Hash Value 中，导致 SPM（SQL Plan Management）无法识别执行计划回放失败的问题。
* 修复多线程调用 UTL 的 OPEN 和 CLOSE 时报错 4200 的问题。
* 修复 PL 依赖视图+同义词场景下，PL Cache 未命中的问题。
* 修复 IPV6 Locality 变更增加节点时卡住的问题。
* 修复 DAS Rescan 计划裁减的问题。
* 修复 ASH 采集数据长度受限报错的问题。

### V4.2.5 BP3 Hotfix3

[**点击查看 V4.2.5 BP3 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 05 月 09 日
* 版本号：V4.2.5 BP3 Hotfix3
* RPM 版本号：oceanbase-4.2.5.3-103030032025050809

**版本概览：**

* 修复基于同义词查询视图无法命中执行计划的问题。
* 修复 ARM 平台下存储下压结果不正确的问题。
* 修复生成冗余计划导致 SPM 无法演进的问题。

### V4.2.5 BP3 Hotfix2

[**点击查看 V4.2.5 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 04 月 30 日
* 版本号：V4.2.5 BP3 Hotfix2
* RPM 版本号：oceanbase-4.2.5.3-103020062025042921

**版本概览：**

* 修复公共同义词与跨 Schema 存储过程同名导致的 PL/SQL 游标缓存失效问题。

### V4.2.5 BP3 Hotfix1

[**点击查看 V4.2.5 BP3 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 04 月 23 日
* 版本号：V4.2.5 BP3 Hotfix1
* RPM 版本号：oceanbase-4.2.5.3-103010072025041817

**版本概览：**

* 修复当启用 `_enable_enhanced_cursor_validation` 时，事务已关联 ≥8 张表的情况下，游标访问第 8 张及后续表时，因无法读取后续表的当前事务修改而导致的问题。
* 修复含有恒 False 条件和 `rownum=1` 时的正确性问题。
* 修复 NLJ Batch+Union 语句是 Select 常量语句（Union 语句数量超过 128）时 Core 的问题。
* 修复 Parser 过程中因处理 6k 行 package 时发生栈溢出报错 4019，异常路径因直接使用栈缓冲区打印 PL 文本导致内存越界，最终导致 Core 的问题。
* 修复 `_ST_GeoHash` 函数输出结果异常的问题。
* 修复 Cursor 定义使用 NULL 列时无法继续赋值的问题。
* 修复备份导入解析 Comment 内容包含 Primary Key 时报错的问题。
* 修复 GroupBy 下压改写丢失谓词的问题。
* 修复公共同义词与 PL 对象同名时 `dbms_utility.name_resolve` 解析的问题。
* 修复分页查询正确性问题。
* 修复事务并发场景下 Core 的问题。

### V4.2.5 BP3

[**点击查看 V4.2.5 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 03 月 31 日
* 版本号：V4.2.5 BP3
* RPM 版本号：oceanbase-4.2.5.3-103000152025033110

**版本概览：**

V4.2.5 BP3 版本增强了一系列诊断能力，包括优化了 Ash Report 的展现形式；新增了对 I/O、事务相关信息的统计项；SQL 计划查询能力增强；稳定性增强与采集性能优化。性能方面优化了 Oracle 模式下的三十余张系统视图，并支持这些视图的 TABLE\_NAME/COLUMN\_NAME 的等值查询利用索引加速的能力；优化表事务回收策略，高 TPS 场景下显著降低 I/O 负载；支持并行补偿日志加快备份速度；存在关联 Update 的 DML 语句支持 PDML 并行执行。此外，在 MySQL 模式下新增支持外键引用存在非唯一索引的列的特性。

### V4.2.5 BP2 Hotfix4

[**点击查看 V4.2.5 BP2 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 05 月 14 日
* 版本号：V4.2.5 BP2 Hotfix4
* RPM 版本号：oceanbase-4.2.5.2-102040012025050823

**版本概览：**

* 修复在 PL Cursor 嵌套调用场景下内存膨胀的问题。
* 修复 ASH 诊断信息不准确的问题。

### V4.2.5 BP2 Hotfix3

[**点击查看 V4.2.5 BP2 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 03 月 27 日
* 版本号：V4.2.5 BP2 Hotfix3
* RPM 版本号：oceanbase-4.2.5.2-102030052025032518

**版本概览：**

* 修复由于 SSTable 中存在转储未提交的数据时，导致该 SSTable 中的 `UPPER_TRANS_VERSION` 不能被正确计算的问题。
* 修复自定义 TYPE OBJECT ID 超过 1048575 条时不可用的问题。
* 修复在 MySQL 模式下 XA 事务中，Stash Savepoint（用于 Trigger 场景）的创建和释放接口不匹配的问题。当尝试释放 Savepoint 时，系统返回“不存在”，导致 Trigger 报错。
* 修复视图 `information_schema.COLUMNS` 中部分字段的字段类型改为 longtext 类型时，并未适配 LOB 类型导致报错 4016 的问题。

### V4.2.5 BP2 Hotfix2

[**点击查看 V4.2.5 BP2 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 03 月 17 日
* 版本号：V4.2.5 BP2 Hotfix2
* RPM 版本号：oceanbase-4.2.5.2-102020022025031414

**版本概览：**

* 修复分区合并时 I/O 过高的问题。
* 修复 `DBMS_SQL.DESCRIBE_COLUMNS` 系统包返回信息错误的问题。

### V4.2.5 BP2 Hotfix1

[**点击查看 V4.2.5 BP2 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 03 月 11 日
* 版本号：V4.2.5 BP2 Hotfix1
* RPM 版本号：oceanbase-4.2.5.2-102010022025030614

**版本概览：**

* 新增配置项 `utl_file_open_max` 用于控制在 Oracle 模式下单节点可同时打开的 `UTL_FILE` 文件最大数量。
* 修复当查询语句包含超过 14 个 Enum 类型字段时，Prepare 阶段报错 4016 的问题。
* 修复 OBKV 模式下，基于时间分区的二级分区宽表在更新数据时报错 4016 的问题。

### V4.2.5 BP2

[**点击查看 V4.2.5 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 01 月 20 日
* 版本号：V4.2.5 BP2
* RPM 版本号：oceanbase-4.2.5.2-102000122025011711

**版本概览：**

V4.2.5 BP2 版本推出多项核心优化与功能升级，重点包括：分区权重均衡机制通过动态调整分区权重解决业务流量不均问题，提升集群负载能力；支持手动创建及管理日志流、暂停/恢复均衡任务以增强运维灵活性；新增 PS 参数化开关和实时 SQL 内存监控，优化性能诊断与执行计划控制；强化安全防护，支持 TLS 证书免密登录；完善备份/归档路径配置，减少跨地域带宽占用；在兼容性方面，扩展 MySQL 模式 Event 功能、提升 OBKV 组件的生态适配与性能；同时优化小规格 OLTP 性能及统计信息收集效率，并扩展 `ob_admin` 工具支持云原生备份场景参数解析。此次更新全面覆盖负载均衡、安全防护、运维效率及多生态兼容，助力复杂业务场景高效稳定运行。

### V4.2.5 BP1 hotfix2

[**点击查看 V4.2.5 BP1 hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 1 月 15 日
* 版本号：V4.2.5 BP1 hotfix2
* RPM 版本号：oceanbase-4.2.5.1-101020052025011421

**版本概览：**

* 修复 Query Range Size 溢出导致错误裁剪的问题。
* 修复在 OBServer 版本 ≥ V4.2.2 版本、ODP 版本 < V4.2.3 版本的情况下，使用原生 MySQL 高版本驱动登录并采用 `caching_sha2_password` 认证方法时，触发 Change User 命令 Hung 住的问题。
* 修复 KV 参数模版初始化报错的问题。
* 修复系统包升级报错 4016 问题。
* 修复 ResetConnection 协议下 SqlSession 内存膨胀问题。
* 修复 SPJ 子查询中 WHERE 条件含有 2 个参数的 SUBSTR 函数引发 Core 的问题。

### V4.2.5 BP1 hotfix1

[**点击查看 V4.2.5 BP1 hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2025 年 1 月 2 日
* 版本号：V4.2.5 BP1 hotfix1
* RPM 版本号：oceanbase-4.2.5.1-101010012024123117

**版本概览：**

* 修复优化器 DAS Rescan 路径裁剪问题。
* 修复物化视图偶现不可读的问题。

### V4.2.5 BP1

[**点击查看 V4.2.5 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2024 年 12 月 6 日
* 版本号：V4.2.5 BP1
* RPM 版本号：oceanbase-4.2.5.1-101000182024120722

**版本概览：**

V4.2.5 BP1 版本新增 MySQL 租户下基于 TDE 透明加密的列加密功能。备份恢复功能新增了 NFSv3 协议的支持。同时支持了并行 Drop Table，提高频繁 Drop Table 场景下的吞吐能力。此外，通过在存储层实现真正的批量接口，显著提升了诸如 Batch Insert、Delete 大量数据、Insert On Duplicate Key Update 等 Batch DML 场景下的性能。V4.2.5 BP1 版本进一步适配了 `MySQL_EVENT` 功能，并优化了 `DBMS_SCHEDULER` 的整体调度机制，新增支持 `JOB_CLASS` 相关功能，支持用 `set_attribute` 修改 JOB 的 `max_failures` 属性以及用命令来恢复 STATE 为 BROKEN 状态的 JOB。

### V4.2.5

[**点击查看 V4.2.5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)

**版本信息：**

* 发布时间：2024 年 10 月 21 日
* 版本号：V4.2.5
* RPM 版本号：oceanbase-4.2.5.0-100000082024102022

**版本概览：**

OceanBase 数据库 V4.2.5 版本是面向 AP/TP 的全新的 LTS 版本。在 V4.2.4 版本基础上，新版本继续完善产品能力，支持了基线优先的 SPM 演进，基于分区表的晚期物化等功能，并进行了优化器估行系统改进以及 CTE 抽取/ INLINE 代价验证改进，有力增强了优化器能力。新版本支持了消费日志支持强关归档、Transfer 搬迁活跃事务以及基于 IO 负载的自适应仲裁升降级，进一步提高了系统的稳定性和可靠性。

在兼容性方面，OceanBase 数据库 MySQL 租户下兼容了锁函数、非法日期、XA 事务等功能，助力 MySQL 业务的平滑迁移。OceanBase 数据库 Oracle 租户下完善了 DBMS\_LOCK 包、支持快速删列，同时 Oracle 租户间的存储过程远程调用支持了复杂类型。新版本进行了表级恢复性能优化、升级性能优化，大大减小表级恢复和升级的耗时。同时通过将统计信息及 clog 日志提交接入资源隔离以及实现 DDL 资源隔离，进一步强化了 OceanBase 数据库的资源隔离机制。新版本支持 SQL 级内存使用限制，并优化了存储过程内存使用，提升了多场景下的稳定性。

在易用性方面，新版本也做了诸多工作。ASH 诊断新增行锁等待和重试等待事件、响应时间直方图、日志传输链路视图等举措提升了系统的可观测性。日志副本并行迁移优化、动态修改 OBServer 内存资源规格实时生效、新增 ./alert/alert.log 日志文件用于记录 DBA 关注的日志信息，让 OceanBase 数据库更加好用。新版本新增了 OBKV-Redis 模型的支持，丰富了 OceanBase 的多模生态。同时优化了 OBKV-HBase 过期删除能力，解决“热 Key”场景下的数据版本过多问题。新增 ColumnPaginationFilter 及 Reverse Scan 接口，进一步增强 HBase 的兼容性。

## V4.2.4

[**点击查看 V4.2.4 Beta Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.4)

**版本信息：**

* 发布时间：2024 年 7 月 10 日
* 版本号：V4.2.4
* RPM 版本号：oceanbase-4.2.4.0-100000252024070621

**版本概览：**

OceanBase 数据库 V4.2.4 版本是面向 TP 和 HTAP 业务的高度兼容、高性能、安全且易于管理的新版本。在 V4.2.3 版本基础上，新版本继续完善产品兼容性，新增多项 MySQL 特性支持，包括 Event Scheduler、ASCII/TIS620 字符集、列默认值定义为表达式等，提升 MySQL 迁移的便利性；支持 DBLink 跨 Oracle 租户远程调用存储过程，增强 PL 报错堆栈的准确性，丰富 `DBMS_SCHEDULER` 子功能等，助力 Oracle 业务的平滑迁移。增强优化器能力，支持统计信息过期后的自适应修正，优化直方图采样策略，提升估行准确性以防统计信息走偏。新版本也实现了主备库之间的自动路由功能，确保服务高可用性，即使在主库故障情况下也能无缝切换至备库继续提供服务。提升 PDML 高并发性能，优化 DAS 执行 GTS 开销，支持物理备库的并行同步，整体提升了小规格 OLTP 性能。另外新增了 MySQL 模式审计功能，支持 REFERENCES、CREATE/DROP ROLE、TRIGGER 权限管理，强化数据库企业级安全特性。运维易用性方面，扩展分区均衡的运维能力，优化死锁检测诊断机制，重构 ASH 报告内容展示，提升实时诊断准确性，提升了用户操作的便捷性和效率。同时重构了 OBKV 请求的 `SQL_ID` 生成方式，提升 OBKV 可观测性。

## V4.2.3

### V4.2.3 BP1 Hotfix1

[**点击查看 V4.2.3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.3)

**版本信息：**

* 发布时间：2024 年 6 月 26 日
* 版本号：V4.2.3 BP1 Hotfix1
* RPM 版本号：oceanbase-4.2.3.1-101010032024062123

**版本信息：**

* 修复高精场景下 GIS 索引没有起到过滤效果，查询性能较差的问题。
* 修复高精场景下 GeometryCollection 类型使用 ST\_Intersects 表达式检索不到数据的问题。

### V4.2.3 BP1

[**点击查看 V4.2.3 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.3)

**版本信息：**

* 发布日期：2024 年 6 月 14 日
* 版本号：V4.2.3 BP1
* RPM 版本号：oceanbase-4.2.3.1-101000012024061216

**版本概览：**

* 修复插入或查询时间相关生成列或函数索引时，使用的 Timezone 和创建表时使用的地区定义的 Timezone 不一致，引起的内存泄漏问题。
* 修复备份恢复访问 S3 协议的对象存储时，必须指定 `s3_region` 的问题。
* 优化大 Package 在创建阶段 LLVM 编译慢的问题。
* 优化 PL 并发编译慢的问题，增加 `PLSQL_OPTIMIZE_LEVEL` 系统变量支持调整编译优化级别和并发数。
* 修复 `UTL_RECOMP` 系统包 Job 执行状态不准确的问题。
* 修复 `UTL_RECOMP.RECOMP_PARALLEL` 执行失败重复执行后，部分 PACKEAGE BODY 没有被重新编译的问题。
* 刷新编译优化的数据文件，优化系统性能。
* 修复 Oracle 模式下，`drop user xxx cascade` 后，记录存储过程编译结果相关的内部表数据没有被及时清除的问题。

### V4.2.3 Beta

[**点击查看 V4.2.3 Beta Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.3)

**版本信息：**

* 发布时间：2024 年 4 月 26 日
* 版本号：V4.2.3 Beta
* RPM 版本号：oceanbase-4.2.3.0-100000232024042317

**版本概览：**

V4.2.x 系列发布 OceanBase 数据库 V4.2.3 Beta 新版本，V4.2.3 Beta 版本支持了一系列 MySQL 兼容特性，如角色、列级权限、Union Distinct RCTE 及大量小功能兼容；也支持了 Proxy User、UTL\_RECOMP、DBMS\_PROFILER、DBLink SAVEPOINT 等多个业务需要的 Oracle 功能。新版本在多个场景优化了系统性能，如优化多模类型读写计算和 OBKV 处理效率，扩展 Batch DML 的并行执行能力，提升备份/网络备库性能，解决自增列/Sequence 在 Order 模式下的性能问题等。同时，备份恢复扩展支持了 S3 及兼容 S3 协议的对象存储（如：OBS，GCS）作为备份目的端。在资源优化方面，进行了一系列优化包括 DDL 临时结果空间优化、旁路导入能力提升和全局前后台 CPU 资源隔离等。新版本也实现了多个业务期待的易用性功能，如用于日志分析和误操作识别的 ObLogMiner 功能，应对 Buffer 表性能问题的合并策略选择，提供模糊绑定计划和限流方式的 Format Outline，用于识别无用索引的索引使用监控特性，提供更高可读性的面向数据库管理员的 `alert.log` 系统日志，增加日志流副本管理的用户命令，提供物理恢复进度展示能力。更详细的 PX 诊断数据以及 ASH Report 的节点级分析等，有效提高系统易用性。

推荐云上或社区有新版本功能需求的客户进行测试。

## V4.2.2

### V4.2.2 BP1

[**点击查看 V4.2.2 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.2)

**版本信息：**

* 发布时间：2024 年 3 月 5 日
* 版本号：V4.2.2 BP1
* RPM 版本号：oceanbase-4.2.2.1-101000012024030619

**版本概览：**

* 修复经停 oceanbase-4.1.0.0-100000982023031415 或者 oceanbase-4.1.0.0-100001122023040322 版本, 最终升级到 oceanbase-4.2.2.0-100000082024011317 后，执行 DDL 卡住的问题。
* 修复备份、Transfer、合并、IO 错误等场景同时发生时，备份索引文件上备份记录的 SSTable meta 和 secondary SSTable meta 版本不匹配，导致恢复时找不到一致的 SSTable meta 从而报错 -4016 can not find table key from meta 的问题。
* 修复 Oracle 模式下，对不带 Lob 列的原始表 add 一个 not null 的 Lob 列后，如果进行 Truncate 或其他影响 Lob 列数据的操作，SQL 报错 -4016，fail to get index or lob table schema 的问题。
* 修复删除列操作开启并行时，可能导致的节点 Core 问题。

### V4.2.2 GA

[**点击查看 V4.2.2 GA Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.2)

**版本信息：**

* 发布时间：2024 年 1 月 15 日
* 版本号：V4.2.2 GA
* RPM 版本号：oceanbase-4.2.2.0-100000082024011317

**版本概览：**

作为 OceanBase 数据库 V4.2.1 后继版本，V4.2.2 版本已正式发布。内核层面进一步加强，重构估行系统和统计信息收集机制，持续完善 MySQL/Oracle 兼容性，新增 Lateral Derived Tables、分页查询保序、DBLink 调用远端 UDF 等多项业务依赖特性；同时两种模式下也分别补充完善了 GIS/XML/JSON 等多模数据类型实现；新增 SQLSTAT、TIME MODEL、手动 Transfer 分区等多项易用性功能改进；通过降低索引临时空间占用、支持 OBKV RPC 压缩等一系列特性，优化系统资源使用。优化小规格基础测试性能，提高系统稳定性。

## V4.2.1

### V4.2.1 BP11 Hotfix15

[**点击查看 V4.2.1 BP11 Hotfix15 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2026 年 02 月 11 日
* 版本号：V4.2.1 BP11 Hotfix15
* RPM 版本号：oceanbase-4.2.1.11-111150022026020915

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix14

[**点击查看 V4.2.1 BP11 Hotfix14 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2026 年 01 月 09 日
* 版本号：V4.2.1 BP11 Hotfix14
* RPM 版本号：oceanbase-4.2.1.11-111140012026010621

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix13

[**点击查看 V4.2.1 BP11 Hotfix13 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 12 月 12 日
* 版本号：V4.2.1 BP11 Hotfix13
* RPM 版本号：oceanbase-4.2.1.11-111130012025120810

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix12

[**点击查看 V4.2.1 BP11 Hotfix12 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 11 月 06 日
* 版本号：V4.2.1 BP11 Hotfix12
* RPM 版本号：oceanbase-4.2.1.11-111120022025110311

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix11

[**点击查看 V4.2.1 BP11 Hotfix11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 10 月 16 日
* 版本号：V4.2.1 BP11 Hotfix11
* RPM 版本号：oceanbase-4.2.1.11-111110012025101314

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix10

[**点击查看 V4.2.1 BP11 Hotfix10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 09 月 25 日
* 版本号：V4.2.1 BP11 Hotfix10
* RPM 版本号：oceanbase-4.2.1.11-111100012025092309

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix9

[**点击查看 V4.2.1 BP11 Hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 09 月 18 日
* 版本号：V4.2.1 BP11 Hotfix9
* RPM 版本号：oceanbase-4.2.1.11-111090012025091215

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix7

[**点击查看 V4.2.1 BP11 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 08 月 14 日
* 版本号：V4.2.1 BP11 Hotfix7
* RPM 版本号：oceanbase-4.2.1.11-111070032025081120

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix6

[**点击查看 V4.2.1 BP11 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 07 月 22 日
* 版本号：V4.2.1 BP11 Hotfix6
* RPM 版本号：oceanbase-4.2.1.11-111060012025071816

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix5

[**点击查看 V4.2.1 BP11 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 07 月 15 日
* 版本号：V4.2.1 BP11 Hotfix5
* RPM 版本号：oceanbase-4.2.1.11-111050022025071110

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix4

[**点击查看 V4.2.1 BP11 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 06 月 12 日
* 版本号：V4.2.1 BP11 Hotfix4
* RPM 版本号：oceanbase-4.2.1.11-111040032025061010

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix3

[**点击查看 V4.2.1 BP11 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 05 月 20 日
* 版本号：V4.2.1 BP11 Hotfix3
* RPM 版本号：oceanbase-4.2.1.11-111030012025051713

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix2

[**点击查看 V4.2.1 BP11 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 05 月 15 日
* 版本号：V4.2.1 BP11 Hotfix2
* RPM 版本号：oceanbase-4.2.1.11-111020032025051316

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11 Hotfix1

[**点击查看 V4.2.1 BP11 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 04 月 15 日
* 版本号：V4.2.1 BP11 Hotfix1
* RPM 版本号：oceanbase-4.2.1.11-111010032025041110

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP11

[**点击查看 V4.2.1 BP11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 03 月 28 日
* 版本号：V4.2.1 BP11
* RPM 版本号：oceanbase-4.2.1.11-111000052025032520

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP10 Hotfix6

[**点击查看 V4.2.1 BP10 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 02 月 28 日
* 版本号：V4.2.1 BP10 Hotfix6
* RPM 版本号：oceanbase-4.2.1.10-110060022025022409

**版本概览：**

修复业务反馈问题，版本稳定性提升。

### V4.2.1 BP10 Hotfix5

[**点击查看 V4.2.1 BP10 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2025 年 01 月 22 日
* 版本号：V4.2.1 BP10 Hotfix5
* RPM 版本号：oceanbase-4.2.1.10-110050012025011614

**版本概览：**

* 修复 reset connection 导致内存堆积的问题。
* 修复特定场景下 json 字段使用 in 条件过滤结果不正确的问题。
* 修复特定 order by union 语句裁剪不正确可能导致 core dump 的问题。
* 修复特定 update set 的子查询合并改写在存在共享子查询表达式时可能导致 core dump 的问题。
* 修复优化器策略调整导致的部分场景无法选到回表索引的问题。

### V4.2.1 BP10 Hotfix4

[**点击查看 V4.2.1 BP10 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 12 月 25 日
* 版本号：V4.2.1 BP10 Hotfix4
* RPM 版本号：oceanbase-4.2.1.10-110040012024122218

**版本概览：**

* 修复 tenant\_id 可能超限导致的不可用问题。
* 修复 alter sequence PL 需要重编译的问题。
* 修复存在外连接以及满足特定形式的复杂过滤谓词情况下查询不正确的问题。
* 修复 gb18030 字符集下使用 dbms\_session 的报错问题。

### V4.2.1 BP10 Hotfix2

[**点击查看 V4.2.1 BP10 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 12 月 05 日
* 版本号：V4.2.1 BP10 Hotfix2
* RPM 版本号：oceanbase-4.2.1.10-110020012024120420

**版本概览：**

* 修复某些场景写入压力比较大的时候，查询和写入的性能下降的问题。
* 修复特定字符集场景下存储过程报错 4002 的问题。
* 修复特定场景下，动态采样估行错误的问题。
* 修复特定字符集场景下，like 表达式结果不正确的问题。
* 修复分区表场景局部索引估行过小的问题。
* 修复特定场景下，unit 迁移后资源不释放的问题。
* 修复创建特定分区表时报错 14037 的问题。
* 修复并行增加唯一索引导致卡合并的问题。

### V4.2.1 BP10

[**点击查看 V4.2.1 BP10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 11 月 15 日
* 版本号：V4.2.1 BP10
* RPM 版本号：oceanbase-4.2.1.10-110000072024111216

**版本概览：**

* **备份配置项**

  用户在进行数据备份的时候，也期望能将源端集群级、租户级配置项一起备份，用于后续快速恢复集群和租户状态。新版本支持通过 `ALTER SYSTEM BACKUP CLUSTER PARAMETERS TO 'xxxx'` 命令对集群级配置项单独指定路径发起备份，并支持在备份数据集中增加租户配置项的备份。同时 ob\_admin 工具提供了 `dump_backup` 命令用于查看备份的配置项信息。
* **备份租户资源配置信息**

  为了避免业务抖动，物理恢复的目标租户的资源配置建议与源租户相同。新版本支持将租户资源相关的配置一起备份到备份数据集中，包括 `primary_zone`/`unit_num`/`locality/unit config` 资源规格等，便于进行同等规格的租户恢复。

  关于配置项备份的详细介绍，参见 [配置项备份](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001667656)。
* **归档备库延时优化**

  跨云灾备架构下，归档备库延时支持降低到 1 秒内。
* **ASH 诊断热点分区**

  在不存在异常慢 SQL，但某个节点 CPU 负载很高时，可以怀疑可能存在热点分区问题。新版本在 ASH 中增加 `tablet_id` 信息的收集，便于监控热点分区，从而进行下一步的运维处理。
* **批量导入现有执行计划到 SPM 基线**

  OceanBase 已经支持指定 `sql_id` 导入 cache 中的执行计划到 SPM 基线的能力。但需要导入的计划较多时，一条条导入会比较麻烦，新版本新增 `DBMS_SPM.BATCH_LOAD_PLANS_FROM_CURSOR_CACHE` 子程序用于支持批量导入。

### V4.2.1 BP9 Hotfix2

[**点击查看 V4.2.1 BP9 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 10 月 25 日
* 版本号：V4.2.1 BP9 Hotfix2
* RPM 版本号：oceanbase-4.2.1.9-109020012024102319

**版本概览：**

修复 ifnull 函数整形类型推导返回结果类型与 MySQL 不一致的问题。

### V4.2.1 BP9 Hotfix1

[**点击查看 V4.2.1 BP9 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 10 月 12 日
* 版本号：V4.2.1 BP9 Hotfix1
* RPM 版本号：oceanbase-4.2.1.9-109010022024101120

**版本概览：**

* 修复备份恢复 `ob_admin check_exist` 不生效，无法 dump `tenant_backup_set_infos.obbak` 文件的问题。

### V4.2.1 BP9

[**点击查看 V4.2.1 BP9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 09 月 20 日
* 版本号：V4.2.1 BP9
* RPM 版本号：oceanbase-4.2.1.9-109000092024091919

**版本概览：**

* **主备库自动路由**

  在 V2.x、V3.x 系列中，OceanBase 支持集群级主备库，使用 `CLUSTER_NAME` 作为唯一表示一组主备集群的标识，用户通过 ODP 连接时，指定集群名即可自动路由到主集群。V4.x 变更为租户级主备库，主租户不记录备租户信息，备租户也不记录主租户信息，主备关系通过外部工具如 OCP 来维护，没办法通过 ODP 连接自动路由到主租户。新版本引入 `SERVICE_NAME` 概念，用于管理一组主备租户，通过 ODP 指定 `SERVICE_NAME` 登录，如 `obclient -h $ip -P $port -u$user_name@SERVICE:$service_name` ，ODP 可根据 `SERVICE_NAME` 将连接路由至主租户，以满足 V4.x 主备库自动路由的需求。同时，系统租户下也提供了一套 `SERVICE_NAME` 管理命令，用于为租户创建、删除、启动、停止 `SERVICE_NAME`。

  该功能需要配套 ODP V4.3.1 和 OCP V4.3.1 及之后版本使用。
* **定时/手动分区均衡**

  OceanBase V4.2 开始支持基于 Transfer 的分区均衡功能，通过租户级配置项 `partition_balance_schedule_interval` 控制均衡任务的调度周期，默认从 OBServer 启动时间算起，每 2 小时进行一次分区均衡。该配置项易用性较差，无法明确控制分区均衡任务的执行时间。由于 Transfer 动作可能会阻塞对应分区的读写，业务高峰期进行分区均衡会影响 RT；如果需要均衡的分区较多，也可能会暂时加大集群负载，影响集群性能。为了优化这一场景，新增 `DBMS_BALANCE` 系统包，为用户提供手动触发分区均衡的方法 `DBMS_BALANCE.TRIGGER_PARTITION_BALANCE(balance_timeout)`，同时在用户租户创建时内置了定时分区均衡任务 SCHEDULED\_TRIGGER\_PARTITION\_BALANCE，默认每日 00:00 触发一次分区均衡，用户也可根据业务特点通过 DBMS\_SCHEDULER 子程序修改定时调度的时间、频率等信息，以便更加灵活、可靠地管理分区均衡任务。
* **支持对函数索引收集统计信息**

  老版本未对函数索引收集统计信息，导致部分场景下，SQL 选不到包含函数索引的执行计划，进而无法获得最优性能。新版本调整收集策略，放开函数索引的统计信息收集。
* **Insertup、Replace 语句 multi query 性能优化**

  对 `INSERT ... VALUES ... ON DUPLICATE KEY UPDATE ...` 和 `REPLACE ... VALUES ...` 两类语句，支持 multi query 场景下的 batch 处理，提升 DML 执行性能。
* **S3 对象存储访问新增可选参数 addressing\_model**

  支持 S3 路径配置可选参数 `addressing_model`，可选参数值：`virtual_hosted_style`/`path_style`。S3 路径配置`addressing_model=path_style` 后，支持以 path style addressing model 访问对象存储；配置 `addressing_model=virtual_hosted_style` 或不配置可选参数 `addressing_model` 默认以 virtual hosted style 访问对象存储。
* **通过 JDBC setMaxRows 接口控制 SQL 返回行数**

  Oracle 模式下，支持通过 JDBC setMaxRows 接口在协议层控制原始 SQL 执行完成后的最大返回行数。
* **存储层估行**

  优化器支持根据统计信息进行估行，但是这一手段在数据倾斜、列相关、统计信息过期等场景稍显不足，如果行数估计不准，会导致索引选错计划走偏等问题。因此，在这些场景下优化器会使用存储层辅助估行，直接通过索引信息获取相关行数，实时且准确。但如果表是分区表，或者抽取的 range 数量超过 10 个，当前都不会使用存储层估行。新版本调整了部分限制场景也使用存储层估行，以获得更准确的行数估计。更多详细信息，请参见 [存储层估行](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000221485)。

### V4.2.1 BP8 Hotfix1

[**点击查看 V4.2.1 BP8 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 08 月 28 日
* 版本号：V4.2.1 BP8 Hotfix1
* RPM 版本号：oceanbase-4.2.1.8-108010012024082314

**版本概览：**

* 修复备份恢复访问对象存储，设置的目的端不支持 md5 或者不完全兼容 md5 校验报错的问题。
* 修复 ob\_admin 在 dump\_backup 打印超过 99 个备份集的信息，OCP 无法显示恢复的问题。
* 修复用户变量名中包含非法字符报错的问题。
* Hint 支持通过 `_push_join_predicate` 关闭非基表条件下推。
* 修复自定义函数返回类型精度与 MySQL 不兼容的问题。
* 修复调用存储过程返回报错 4023 的问题。
* 修复特定场景下 PlJit 内存模块泄漏的问题。

### V4.2.1 BP8

[**点击查看 V4.2.1 BP8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 07 月 25 日
* 版本号：V4.2.1 BP8
* RPM 版本号：oceanbase-4.2.1.8-108000052024072217

**版本概览：**

* **日志流副本管理**

  V4.0 之前的版本，OceanBase 数据库提供了分区副本管理的一系列运维命令，比如为分区添加一个副本、为分区删除一个副本、对分区的一个副本进行类型转换等。V4.x 系列在设计上使用日志流代替了分区的概念，对标低版本的分区运维命令。新版本重新设计实现了日志流副本级别任务的运维方式，提供了一系列语法，用于支持日志流副本的添加、删除、副本类型转换、迁移、修改日志流 Paxos 成员数量和取消容灾任务等能力，满足客户手动运维日志流副本的需求。
* **DBLink 支持指定域名访问**

  OceanBase 数据库支持通过 DBLink 访问远端数据库。老版本需要在创建 DBLink 时指定远端数据库的 IP 地址，新版本增加支持配置域名地址。
* **主备租户角色切换验证**

  OceanBase 数据库支持租户级主备角色切换，如在数据无损情况下可以将备租户 SWITCHOVER 成主租户，将主租户 SWITCHOVER 成备租户，或在数据损失情况下将备租户 FAILOVER 成主租户。主备租户角色切换操作有失败的可能，为了降低实际执行角色切换动作的风险，新版本新增支持主备租户角色切换验证功能（SWITCHOVER/FAILOVER VERIFY），在切换命令后添加 VERIFY 关键字，可以提前验证对应操作是否可以成功执行，如对应操作不可执行，将给出报错信息。
* **主备租户事件展示**

  OceanBase 数据库 V4.2.1 BP8 之前，主备租户 SWITCHOVER、FAILOVER 等事件记录在 RS 事件中，RS 事件会随时间清理，且租户级记录混在集群操作记录中不易查找。新版本将主备租户操作记录拆分到每个租户下，通过 `CDB/DBA_OB_TENANT_EVENT_HISTORY` 视图透出。
* **事务提交后 Cursor 访问**

  V4.0 开始，事务提交后不允许 Cursor 继续 Fetch 数据。V4.2.1 BP8 开始允许 Cursor 在没读取当前事务修改的表的情况下，在事务结束后依然可以 Fetch 数据，但需要通过 `_enable_enhanced_cursor_validation` 配置项开启。
* **增加 SM3 加密函数**

  MySQL 模式下新增 SM3 加密函数，Oracle 模式下在 `DBMS_CRYPTO.HASH` 子程序下新增 HASH\_SM3 哈希加密算法。
* **仲裁支持混合云双活架构**

  作为 OceanBase 数据库的总控服务，RS 提供了诸如资源管理、容灾、负载均衡和 Schema 管理等重要功能。目前，在 2F1A/4F1A 部署情况下，因为网络问题触发仲裁降级，但降级后如果日志流 Leader 仍然与 RS 处于网络中断的状态，诸如 DDL 之类依赖 RS 的功能就无法执行，会影响系统可用性。

  为解决这个问题，新增集群级配置项 `arbitration_degradation_policy`，表示不同的仲裁降级策略：

  + `LS_POLICY`：默认的降级策略。
  + `CLUSTER_POLICY`：降级前检查是否与 RS 网络连通。

  当处于 `CLUSTER_POLICY` 时，日志流 Leader 会在降级前检查是否与 RS 连通。如果不连通，则不执行降级，并进入选举“静默”状态，让当前副本不再当选 Leader，从而确保 Leader 最终切到和 RS 网络连通的副本上。另外，进入选举“静默”状态的 Follower 副本会定时检查与 RS 的连通性，当恢复与 RS 的连通时，退出选举“静默”状态，允许其重新当选 Leader。
* **OBKV 响应时间统计直方图**

  在 V4.2.1 BP7 响应时间直方图功能基础上，新版本在 `[G]V$OB_QUERY_RESPONSE_TIME_HISTOGRAM` 系统视图中增加了 OBKV 相关的统计类别，包括 `TABLEAPI SELECT`、`TABLEAPI INSERT`、`TABLEAPI DELETE`、`TABLEAPI UPDATE`、`TABLEAPI REPLACE`、`TABLEAPI QUERY AND MUTATE`、`TABLEAPI OTHER`、`HBASE SCAN`、`HBASE PUT`、`HBASE DELETE`、`HBASE APPEND`、`HBASE INCREMENT`、`HBASE CHECK AND PUT`、`HBASE CHECK AND DELETE`、`HBASE HYBRID BATCH` 等。
* **OBKV-HBase 列分页**

  原生 HBase 支持列分页，这在大宽表场景下提供了更好的查询性能。新版本 OBKV-HBase 也提供了类似的列分页能力，支持通过 ColumnPaginationFilter 过滤器限制返回列数。
* **OBKV-HBase 逆序扫描**

  OBKV-HBase 的数据是按照 RowKey（行键）排序存储的，在需要有序访问数据的场景，一般会以 RowKey 正序（从小到大）扫描。但实际业务中还存在需要倒序访问数据的场景，因此新版本新增 Reverse Scan 功能，允许用户以 RowKey 逆序（从大到小）扫描表中的数据，提升查询性能。

### V4.2.1 BP7 Hotfix3

[**点击查看 V4.2.1 BP7 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 06 月 28 日
* 版本号：V4.2.1 BP7 Hotfix3
* RPM 版本号：oceanbase-4.2.1.7-107030032024062709

**版本概览：**

* 修复使用腾讯云对象存储 COS 归档备份导致内存泄漏的问题。
* 修复 Oracle 模式下使用 PS 协议，`CASE WHEN` 类型推导可能导致报错 4016 的问题。
* 修复 OBKV 前缀索引扫描报错 4016 的问题。
* 修复事务数据表转储异常的问题。

### V4.2.1 BP7 Hotfix2

[**点击查看 V4.2.1 BP7 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 06 月 14 日
* 版本号：V4.2.1 BP7 Hotfix2
* RPM 版本号：oceanbase-4.2.1.7-107020012024061213

**版本概览：**

* 修复执行 `comment on TABLE` 操作可能遇到报错的问题。
* 修复备份清理会遗留 Table List 的问题。
* 修复某些场景下 PL 传入空数组报错 4013 的问题。
* 修复 obcdc 某些场景下可能拉取不到导致退出的问题。
* 修复频繁垂直扩缩容场景下可能导致 Core Dump 的问题。

### V4.2.1 BP7 Hotfix1

[**点击查看 V4.2.1 BP7 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 06 月 06 日
* 版本号：V4.2.1 BP7 Hotfix1
* RPM 版本号：oceanbase-4.2.1.7-107010022024060601

**版本概览：**

修复某些高负载场景下，事务数据表积累大量数据写放大，导致整体 I/O 负载过高的问题。

### V4.2.1 BP7

[**点击查看 V4.2.1 BP7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 05 月 30 日
* 版本号：V4.2.1 BP7
* RPM 版本号：oceanbase-4.2.1.7-107000112024052920

**版本概览：**

* **操作系统适配支持**

  新增 8U 操作系统适配支持。
* **备份恢复支持 S3/OBS/GCS**

  新增支持 S3 协议，可将 S3/OBS/GCS 作为日志归档和数据备份的目的端，同时支持使用 S3/OBS/GCS 上的备份数据进行物理恢复。
* **旁路导入中间数据支持开启压缩**

  旁路导入过程中，中间数据占用空间过大时，可能会导致磁盘空间满，进而导致导入失败。新版本增加旁路导入中间数据压缩功能，通过租户级配置项 `_ob_ddl_temp_file_compress_func` 控制是否开启及使用的压缩算法。

  默认为 `NONE`，表示不开启压缩，适用于磁盘空间足够，希望获得更高导入性能的场景。根据业务需要可修改为 `ZSTD` 或 `LZ4`，来指定对应的压缩算法开启中间数据压缩，或设置为 `AUTO` 自适应开启压缩。
* **SET/PIECE 级物理恢复**

  实际业务中存在二次备份场景，需把数据备份集或归档日志手动搬迁到新的路径。新版本增加了 SET/PIECE 级物理恢复功能，提供 `ADD RESTORE SOURCE` 命令来加载新路径的数据备份集 SET 或日志归档 PIECE，支持按需恢复到指定时间。更多信息请参见 [执行指定路径的恢复](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000827705)。
* **迁移复制源端选择优化**

  新版本将各 Server 按照地域信息划分为同 IDC、同 Region 不同 IDC、跨 Region 三种区域关系，同时提供 `choose_migration_source_policy` 配置项，用于迁移复制场景下，指定源端的选择模式，以便优先考虑地理位置就近因素以及 Follower 副本来提升迁移效率、降低 Leader 压力。更多信息请参见 [choose\_migration\_source\_policy](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000833394)。
* **物理恢复进度统计**

  为了用户在使用物理恢复功能时可以了解恢复任务的运行状态和进度，并预估完成时间，新版本增加了物理恢复进度统计功能。用户可通过 `CDB/DBA_OB_RESTORE_PROGRESS` 视图实时查看恢复进度，获得更好的使用体验。更多信息请参见 [查看物理恢复进度](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000218387)。
* **大规格租户事务数据表转储调度优化**

  优化大规格租户下事务数据表转储不及时的问题，加快事务数据表的转储调度，进一步优化 Buffer 表性能。
* **全局 CPU 前后台任务隔离**

  在之前版本，OceanBase 数据库已实现通过租户 Unit 规格来配置租户间的 CPU 资源隔离，提供 `DBMS_RESOURCE_MANAGER` 系统包来配置租户内的 CPU 资源隔离。新版本支持全局 CPU 前后台任务隔离，可以在整体层面上限制后台任务的可用资源，相对租户内使用 `DBMS_RESOURCE_MANAGER` 单独配置更加方便易用。更多信息请参见 [使用全局 CPU 资源的前后台隔离](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000859614)。
* **新增响应时间统计直方图**

  在之前版本，OceanBase 数据库已支持基于不同 SQL 类别的平均响应时间/最大响应时间指标，但缺乏更细粒度的反映某个分位 SQL 执行性能的指标展示。新版本增加响应时间直方图功能，可基于 `[G]V$OB_QUERY_RESPONSE_TIME_HISTOGRAM` 系统视图计算和监控不同类型 SQL 的 P90/P95 之类的响应时间统计。更多信息请参见 [GV$OB\_QUERY\_RESPONSE\_TIME\_HISTOGRAM](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000833388)、[V$OB\_QUERY\_RESPONSE\_TIME\_HISTOGRAM](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000833387)。
* **分区均衡策略优化**

  新版本优化了分区均衡策略，支持在创建分区表时连续分区打散。当用户表存在 longtext/lob 列或局部索引时，分区磁盘均衡也会计算关联表，使磁盘使用更加均衡。更多信息请参见 [租户内均衡](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000801146)。
* **同城双机房类最大可用模式**

  同城双机房 2F1A+2F 部署模式下，当 2F1A 所在机房宕机后，2F 所在机房无法达成多数派，无法正常提供服务。新版本提供日志流副本的成员列表修改能力，支持在 OCP 或 ob\_admin 进行集群恢复。
* **OBCDC 启动加速**

  新版本优化了 OBCDC 启动性能，协助提升下游 Binlog 工具的同步性能。
* **JSON 可嵌套层数扩展**

  历史版本限制 JSON 文档的可嵌套最大深度为 100，新版本提供 `json_document_max_depth` 配置项，允许用户根据需求调整嵌套深度。对于超过 100 的 JSON 嵌套层数需求，用户可适当调大该配置。更多信息请参见 [json\_document\_max\_depth](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000833393).
* **基于 I/O 负载的自适应仲裁升降级**

  新版本实现了基于 I/O 负载的日志盘故障探测算法，可以更有效地探测到云盘故障并执行仲裁降级，避免云盘故障持续影响业务请求。

  具体而言，故障探测算法持续学习日志盘的写入性能数据，如果算法探测到日志盘写入性能相比基准性能有大幅下跌，即标记日志盘为故障状态，并执行仲裁降级。标记日志盘故障后，算法依然会持续探测日志盘性能是否处于故障状态，只有当过去一段时间内日志盘性能都处于正常范围时，才将日志盘标记为正常状态，保证仲裁升级后业务请求不因日志盘故障而抖动。
* **支持 HBase PageFilter 功能**

  OB-HBase 模型下, 支持使用 HBase 中的 PageFilter 对 Row 进行限制, 返回指定数量的 Row。
* **备份性能优化**

  OceanBase 数据库在备份过程中，通过连续性校验确保基线版本大于转储版本来保证数据完整。然而，连续性检查涉及读取备份介质上的数据并执行带锁操作，因此会影响备份性能。新版本优化了备份过程中连续性校验操作带来的性能开销，支持通过 `ha_low_thread_score` 控制备份使用的线程数，从而有效提高备份性能。更多信息请参见 [ha\_low\_thread\_score](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000000220387)。

### V4.2.1 BP6 Hotfix1

[**点击查看 V4.2.1 BP6 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 05 月 27 日
* 版本号：V4.2.1 BP6 Hotfix1
* RPM 版本号：oceanbase-4.2.1.6-106010032024052709

**版本概览：**

修复堆栈溢出可能导致 OBServer Core Dump 的问题。

### V4.2.1 BP6

[**点击查看 V4.2.1 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 04 月 25 日
* 版本号：V4.2.1 BP6
* RPM 版本号：oceanbase-4.2.1.6-106000022024042414

**版本概览：**

* 修复 `SET collation_connection = 'utf8mb4_unicode_ci'` 后，`information_schema` 下字符串类型的列比较/关联操作，会报错 `Illegal mix of collations`，和原生 MySQL 不兼容的问题。
* 修复 Oracle 模式下，快速删除的列还会在 `all_col_comments` 视图中显示的问题。
* 修复升级混跑过程中读写 Lob 数据可能触发 Core 的问题。
* 修复 OBKV 异步查询超时导致内存泄漏的问题。

### V4.2.1 BP5

[**点击查看 V4.2.1 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 04 月 19 日
* 版本号：V4.2.1 BP5
* RPM 版本号：oceanbase-4.2.1.5-105000072024041817

**版本概览：**

* **统计信息优化**

  该版本实现了新的统计信息收集框架，基于系统资源拆分了统计信息收集过程，优化了 TopK 直方图的收集流程，默认以增量方式收集统计信息，并优化了历史统计信息的管理方式。同时，基于新的收集框架优化了以下场景：

  + 支持设置列级统计信息的最大值/最小值，方便线上环境的应急。
  + 修复统计信息锁定的 Bug（未收集统计信息的表锁定统计信息之后，会误认为有统计信息）。
  + 支持设置统计信息的块采样 Perfs，针对大宽表的收集，用户可以指定表的块采样 Perfs，提升收集效率。
  + 优化自动收集的默认收集策略，默认情况下，针对数据量超过 1 亿以上的大宽表在并行度为 1 的情况下，使用块采样的策略，目标采样行数 1 亿行，同时限制其单表收集最大时间为 1 小时。
  + 优化动态采样在大宽表场景下的使用，自适应选择行采样或块采样，降低采样时间开销。
* **DBMS\_SCHEDULER 路由优化**

  该版本支持通过 `DBMS_SCHEDULER.SET_ATTRIBUTE` 设置 Job 路由策略。通过配置 Job 路由至 Leader 节点，降低 RPC 开销，提升执行性能。具体如下：

  + 不指定 `instance_id` 属性时，Job 默认在 Primary Zone 执行。
  + 指定 `instance_id` 为某个 Zone 时，Job 默认在对应的 Zone 上执行。
  + 指定 `instance_id` 为 RANDOM 时，Job 会进行随机路由。
* **支持 DBMS\_SCHEDULER.STOP\_JOB**

  新增 `DBMS_SCHEDULER.STOP_JOB` 子程序，用于终止正在运行的 Job，便于出现异常时进行 Job 管理。
* **Buffer 表自适应合并优化**

  当用户在某张表上频繁地执行插入并且同时进行批量删除，或者有大量的并发更新操作时，可能会遇到一种现象：表中的数据行数并不大，但是查询和更新的性能出现明显下降。这种现象在 OceanBase 数据库中称为 Queuing 表（业务上有时又称 Buffer 表）效应。

  Buffer 表是 LSM-Tree 架构数据库都要面对的一类问题。LSM-Tree 架构下的删除操作在合并之前都只是逻辑上标记删除而非物理删除，当增量数据中存在大量标记删除的数据时，物理行数量将远多于逻辑行，从而造成严重的读放大现象，并影响优化器执行方案的生成。

  OceanBase 数据库在 V4.1.0 版本做到了自动识别哪些分区在一段时间内发生比较多更改，并对这些分区进行自适应 Compaction，但缺少人为控制手段。

  为了更灵活地解决 Buffer 表带来的性能下降问题，该版本继续优化了 Buffer 表自适应合并特性，提供了 5 种档位的合并策略，允许用户根据业务场景为每张表设置不同的 `table_mode`，来应对 Buffer 表引起的读放大现象，从而提高系统长期运行下的 QPS 等性能指标。
* **PL 重新编译逻辑优化**

  将存储过程编译为共享库后，可以供多个线程使用。但如果所依赖的对象发生变更，共享库可能会失效，需要重新进行编译。

  该版本针对重新编译场景做了梳理细化，在临时表匹配、静态 SQL 依赖对象信息收集、表 DDL 变更等方面进行一系列逻辑优化，减少因 PL CACHE 缓存对象失效导致重新编译的场景。
* **Processlist 统计时间优化**

  视图 `information_schema.PROCESSLIST`、`GV$OB_PROCESSLIST` 中增大 `TIME` 和 `TOTAL_TIME` 统计精度，并新增 `TOTAL_CPU_TIME` 表示请求 CPU 使用时间。
* **支持 Clog 存储压缩**

  随着越来越多 AP、HBase 场景的替换需求出现，高写入场景可能会导致 Clog 日志盘吞吐达到上限，需要通过扩容来解决资源问题。但可能集群其他类资源是未达到瓶颈的，整体扩容导致业务成本升高，资源过度浪费。

  为解决这一问题，该版本新增 Clog 日志存储压缩功能，通过将事务提交的日志进行压缩，间接提高日志盘吞吐能力，提升日志盘可容纳的事务日志总量。
* **OUTROW 存储的 LOB 读写性能优化**

  该版本支持了 OUTROW LOB 进入微块缓存，减少 I/O，提升 OUTROW LOB 读写性能。
* **NETWORK\_WAIT\_TIME 统计项优化**

  SQL AUDIT 中新增 `NETWORK_WAIT_TIME` 统计项，用于展示 Network 类别的等待事件耗时，如同步 RPC、DAS 异步 RPC 锁等。在排查远程执行的慢 SQL 问题时，可以使用该统计项确认网络开销，辅助诊断。

### V4.2.1 BP4 Hotfix3

[**点击查看 V4.2.1 BP4 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 03 月 29 日
* 版本号：V4.2.1 BP4 Hotfix3
* RPM 版本号：oceanbase-4.2.1.4-104030022024032913

**版本概览：**

* 修复同一个租户创建的连接数累计达到 2147483647 次后无法建立连接的问题。
* 修复整个集群重启后，立即执行 create table if not exists 创建已经存在的表，耗时高达 30s 的问题。
* 修复飞腾服务器 ARM 架构下产生的 CPU 热点问题。
* 修复飞腾服务器 ARM 架构下产生的 CPU 大查询性能较差的问题。
* 修复统计信息采集 DML 数据，加读锁形成热点的问题。

### V4.2.1 BP4 Hotfix2

[**点击查看 V4.2.1 BP4 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 03 月 22 日
* 版本号：V4.2.1 BP4 Hotfix2
* RPM 版本号：oceanbase-4.2.1.4-104020022024031915

**版本概览：**

* 修复 OBKV 索引不能包含特殊列（如自增列、生成列、`current_timestamp` 列）的问题。
* 修复对 Semi Join 进行 multi min/max 改写优化导致查询报错 -4016 的问题。
* 修复表锁回调慢导致 Transfer 持续误判存在活跃事务，进而导致 Transfer 一直无法完成，缩容不成功的问题。
* 修复快速删除 `XMLType` 列后，插入报错 -4016 的问题。
* 修复在一个 `UPDATE` 语句中，同时更新 Rowkey 和 Outrow LOB 列时，OBCDC 同步该 DML 产生的 CLOB 时，可能会 Core 的问题。
* 修复 OBCDC 使用 DRCMSG 消息库导致内存泄漏的问题。OBCDC 在 4.2.1.4 版本升级了 DRCMSG 版本（devdeps-drcmsg-1.0-262024012415），序列化场景下该 DRCMSG 存在内存泄漏。新版本升级 DRCMSG 到修复版本（devdeps-drcmsg-1.0-292024030421）。

### V4.2.1 BP4 Hotfix1

[**点击查看 V4.2.1 BP4 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 03 月 08 日
* 版本号：V4.2.1 BP4 Hotfix1
* RPM 版本号：oceanbase-4.2.1.4-104010012024030714

**版本概览：**

* 修复开启全链路诊断功能后，对于复杂 SQL 使用分布式执行计划时，执行 show trace 返回 -4016 报错的问题。
* 修复 outrow Lob meta 未进缓存，导致读磁盘热点引起磁盘延迟升高的问题。
* 修复 select 投影列带反引号时，报语法错误的问题。

### V4.2.1 BP4

[**点击查看 V4.2.1 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 03 月 01 日
* 版本号：V4.2.1 BP4
* RPM 版本号：oceanbase-4.2.1.4-104000062024022914

**版本概览：**

* **Oracle 模式下支持快速删列**

  V4.2.1 BP4 版本将删列操作从真正删除变更为标记删除，极大提升了删列性能。删列后，对应列以隐藏列方式存储。如果业务存在较频繁的删列行为使隐藏列累积到 128 个，会阻塞该表的加列和删列操作，需要通过 `ALTER TABLE ... FORCE` 命令进行隐藏列清理。清理过程中会锁表和重整数据，阻塞其他事务。
* **OBKV batch put 支持覆盖写**

  OBKV 多活架构下，存在订阅增量后会同步到其它地域集群的场景。同步时无法保证旧的数据一定先于新的数据同步成功，所以为了保证正确性，需要在同步的时候对时间戳进行判断。时间戳大则更新，反之不操作。因此该版本 OBKV 新增支持 checkAndInsUp 能力，在满足一定条件下，才执行 insertUp 操作。同时为了提高同步性能，也支持了 checkAndInsUp 的批量执行。
* **手动 Transfer Partition 功能增加 Cancel 能力**

  Cancel Transfer Partition 是对手动 Transfer Partition 功能的完善。用户在发起手动 Transfer Partition 任务后，任务在没有执行完成之前可以尝试取消任务。本功能提供如下能力：

  + 可以指定取消尚未开始 TRANSFER 的任务
  + 可以取消租户下所有没有开始 TRANSFER 的任务
  + 可以取消当前正在执行的 Balance Job
* **OBCDC 支持黑白名单**

  OBCDC 早期版本已具备租户级别的日志同步功能。新版本开始，增加库、表级同步粒度。支持通过简单的正则表达式配置黑白名单，来满足用户只需要同步部分表的数据消费场景。
* **支持备份全量快照表名**

  OCP 及下游厂商适配表级恢复功能时，需要向用户展示可供恢复的表。该版本在备份集中增加持久化对应的快照表名，并提供通过 ob\_admin 来解析备份表名的能力。
* **Multi Min/Max 改写优化**

  在 scalar group by 中，若查询中的聚合函数只有 min/max，且 min/max 的列上有索引，可以将其改写成 order by xxx limit 1，利用索引序消除 order by 并将 limit 1 下推到 table scan 上，从而减少对数据的读取和排序。对于 SQL 中有多个 min/max 存在的场景，历史版本采取了全表扫描方案，新版本考虑将多个 min/max 改写成多个子查询，每个子查询都利用索引直接获取到最大值或最小值，以此来避免全表扫描和排序，优化查询性能。
* **DBLink 支持短链接**

  通过 DBLink 访问远端数据库时，目前采用一个 session 内复用连接（即长连接）的方式。新版本增加不复用连接（即短连接）选项，用于网络环境出现非预期问题时，降低影响。该选项通过 `_enable_dblink_reuse_connection` 控制，表示默认复用连接。取值为 False 时，表示不复用连接。
* **ob\_admin 支持修改 SYS 租户的日志盘空间**

  4.x 版本支持了租户级日志盘，日志盘大小作为租户规格持久化到了 SYS 租户的内部表中。当 SYS 租户多数派副本日志盘停写后，SYS 租户下所有内部表均无法写入，因此通过在线修改 SYS 租户规格的方式无法完成 SYS 租户日志盘满后的运维操作。为此，新版本提供了基于 ob\_amdin 工具在线完成 SYS 租户日志盘扩盘的功能，该功能只影响内存，宕机重启后默认回滚。

### V4.2.1 BP3 Hotfix5

[**点击查看 V4.2.1 BP3 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 01 月 26 日
* 版本号：V4.2.1 BP3 Hotfix5
* RPM 版本号：oceanbase-4.2.1.3-103050012024012511

**版本概览：**

* 修复 Oracle 模式下，对不带 Lob 列的原始表 add 一个 not null 的 Lob 列后，如果进行 Truncate 或其他影响 Lob 列数据的操作时，SQL 报错 -4016，fail to get index or lob table schema 的问题。该问题在 V4.2.1 BP3 引入。
* 修复非流式 cursor（ps cursor 或 PL 内部走非流式路径的 cursor）在 open 和 fetch 之间，如果有 commit 语句，fetch 报错 ORA-01002 的问题。

### V4.2.1 BP3 Hotfix4

[**点击查看 V4.2.1 BP3 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 01 月 18 日
* 版本号：V4.2.1 BP3 Hotfix4
* RPM 版本号：oceanbase-4.2.1.3-103040012024011620

**版本概览：**

修复内核因实现类似于 SQLPlus 客户端去除字符串换行前空格的行为，导致与原生 Oracle 不兼容的问题。从该版本开始，不再对字符串换行前的空格进行处理。

### V4.2.1 BP3 Hotfix2

[**点击查看 V4.2.1 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 01 月 11 日
* 版本号：V4.2.1 BP3 Hotfix2
* RPM 版本号：oceanbase-4.2.1.3-103020012024011011

**版本概览：**

修复在 PS 二合一协议开启下的 SQL 远程执行计划生成失败、自增主键和二级索引冲突导致的 OBKV 客户端报错以及包含 LONGTEXT 列的表在执行 OBKV TTL 任务时失败的问题。

### V4.2.1 BP3 Hotfix1

[**点击查看 V4.2.1 BP3 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2024 年 01 月 05 日
* 版本号：V4.2.1 BP3 Hotfix1
* RPM 版本号：oceanbase-4.2.1.3-103010012024010418

**版本概述：**

修复调用 `DBMS_MONITOR` 包传入小数类型数据报错 `Incorrect arguments to control info` 的问题。

### V4.2.1 BP3

[**点击查看 V4.2.1 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 12 月 29 日
* 版本号：V4.2.1 BP3
* RPM 版本号：oceanbase-4.2.1.3-103000052023122809

**版本概览：**

新增 OBServer 到 ODP 链路压缩、网络备库性能优化、OBKV 全局索引功能，以及对 Oracle 模式和 MySQL 模式进行了多项性能优化和特性升级，同时还新增了统计信息复制功能、SQL 限流功能优化、备份进度展示功能，并提升了 MySQL 8.0 语法兼容性。

### V4.2.1 BP2 Hotfix1

[**点击查看 V4.2.1 BP2 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 12 月 14 日
* 版本号：V4.2.1 BP2 Hotfix1
* RPM 版本号：oceanbase-4.2.1.2-102020012023121317

**版本概览：**

新建集群默认关闭 NLJ 和 SPF 算子的 BATCH RESCAN 优化，而升级的集群仍保持原状态。存量环境中稳定性问题可通过全局设置禁用该优化。同时，修复了 BATCH RESCAN 导致的 OBServer core 问题，二级分区表组数据分布问题，以及 JSON\_EXTRACT 函数的兼容性问题。

### V4.2.1 BP2

[**点击查看 V4.2.1 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 12 月 05 日
* 版本号：V4.2.1 BP2
* RPM 版本号：oceanbase-4.2.1.2-102010012023120119

**版本概览：**

在 MySQL 模式下引入分页查询保序功能以确保输出顺序的稳定性，并提供手动 Transfer Partition 能力以满足特定的数据分布需求。此外，该版本还优化了物理恢复性能，增加 OBKV 的 RPC 压缩功能，提供 LOB 存储模式的动态配置选项，并新增 Tablet Location 的主动广播能力以减少 SQL 重试和读写错误。

### V4.2.1 BP1 Hotfix1

[**点击查看 V4.2.1 BP1 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 11 月 10 日
* 版本号：V4.2.1 BP1 Hotfix1
* RPM 版本号：oceanbase-4.2.1.1-101010022023110921

**版本概览：**

修复 OBKV 在处理 TTL 表时内存占用过多、TTL 任务执行时日志流切主导致内存未释放，以及重复创建 SESSION 时导致的内存泄漏问题。

### V4.2.1 BP1

[**点击查看 V4.2.1 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 11 月 01 日
* 版本号：V4.2.1 BP1
* RPM 版本号：oceanbase-4.2.1.1-101000062023103122

**版本概览：**

通过在 `DBA_OB_ROOTSERVICE_EVENT_HISTORY` 视图的 `migrate_unit` 和 `finish_migrate_unit` 事件中增加新值 `manual_migrate`，用于区别手动迁移和自动迁移。同时，为了简化 OBKV 请求问题的定位，新版本引入 OBKV 连接数统计功能，并新增 `[G]V$OB_KV_CONNECTIONS` 视图来查询当前租户的所有 KV 类活跃 SESSION 信息。

### V4.2.1 GA Hotfix2

[**点击查看 V4.2.1 GA Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 10 月 23 日
* 版本号：V4.2.1 GA Hotfix2
* RPM 版本号：oceanbase-4.2.1.0-100020042023102310

**版本概览：**

修复在 Transfer 场景下自增列未刷新 tablet location cache 导致的执行报错，SQL 执行 NLJ Group Rescan 优化时因存储参数切换引发报错 4016，OBKV 中 `current_timestamp` 作为 TTL 过期列引起的 Core 问题，以及 update 操作中可消除 JOIN 未能应用 PDML 的问题，并解决了 MySQL 模式下隐式类型转换影响谓词推导和优化计划生成的问题。

### V4.2.1 GA Hotfix1

[**点击查看 V4.2.1 GA Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 10 月 17 日
* 版本号：V4.2.1 GA Hotfix1
* RPM 版本号：oceanbase-4.2.1.0-100010052023101619

**版本概览：**

修复复杂 SQL 执行时，使用 SPF 优化造成节点 Core 的问题；`trx_read_only` 设置为 True 时，UDF 内部 SQL 无法命中 Plan Cache，导致性能较差的问题；PS 模式下存储过程中复杂数据类型默认值参数校验失败问题。

### V4.2.1 GA

[**点击查看 V4.2.1 GA Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2023 年 9 月 28 日
* 版本号：V4.2.1 GA
* RPM 版本号：oceanbase-4.2.1.0-100000182023092722

**版本概览：**

OceanBase 数据库 V4.2.1 版本是 V4.2.x 版本系列的第一个长期支持版本（LTS），该版本新增了 VALUES 语句、JSON\_TABLE 表达式等与 MySQL 兼容的功能，同时还提供了 DBLink 调用 Package、读取 Sequence 等与 Oracle 兼容的功能。此外，该版本还推出了 WR 数据采集框架和增强的全链路诊断功能。同时，该版本还优化了系统资源的使用，并增加了表级恢复能力和对备份介质 COS 的支持。推荐将其用于云上和线下常规业务的生产环境中。

## V4.2.0

### V4.2.0 BP1

[**点击查看 V4.2.0 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.0)

**版本信息：**

* 发布时间：2023 年 9 月 14 日
* 版本号：V4.2.0 BP1
* RPM 版本号：oceanbase-4.2.0.0-101000042023091319

**版本概览：**

修复 Oracle 模式下，当 RS 租户和普通租户不在同一台机器上时，DDL 操作尝试在 RS 机器上使用租户 ID 分配内存可能导致的报错 4013 的问题。解决了并行执行时未指定全索引后缀条件下使用index skip scan 计划的正确性问题，以及租户设置 `_optimizer_better_inlist_costing=true` 后可能导致节点 Core dump 的问题，同时修复从 V4.1.x 版本升级到 V4.2.x 版本后 max\_ls\_id 维护不正确造成业务执行耗时过长的问题。

### V4.2.0 GA

[**点击查看 V4.2.0 GA Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.0)

**版本信息：**

* 发布时间：2023 年 8 月 31 日
* 版本号：V4.2.0 GA

**版本概览：**

OceanBase 数据库 V4.2.0 GA 版本在 Beta 版本基础上进一步增强版本稳定性，推荐用于生产。后续 V4.2.1 版本也会作为长期支持版本（LTS）对外提供服务。

### V4.2.0 Beta

[**点击查看 V4.2.0 Beta Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.0)

**版本信息：**

* 发布时间：2023 年 8 月 2 日
* 版本号：V4.2.0 Beta
* 版本说明：Beta 版本解决了大部分缺陷，并趋于稳定。推荐测试环境使用。

**版本概览：**

OceanBase 数据库 V4.2.0 版本是在 V4.1.0 版本基础上进一步健全完善核心特性，补齐了 V3.x 系列的全部主要功能，提升产品可扩展性，优化资源使用，提高性能，增强兼容性与易用性。目前发布的为 V4.2.0 Beta 版本，而后续的 V4.2.x 版本也会作为 长期支持版本（LTS） 对外提供服务。

## V4.1.0

### V4.1.0 BP4 Hotfix1

[**点击查看 V4.1.0 BP4 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 9 月 28 日
* 版本号：V4.1.0 BP4 Hotfix1
* RPM 版本号：oceanbase-4.1.0.2-104010012023092816

**版本概览：**

修复在升级混跑期间，当在 PX 分区表的 JOIN 场景中，查询选择了 PKEY 计划（计划中包含 EXCHANGE OUT DISTR (PKEY) 字段）时，执行结果可能不正确的问题。

### V4.1.0 BP4

[**点击查看 V4.1.0 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 9 月 21 日
* 版本号：V4.1.0 BP4
* RPM 版本号：oceanbase-4.1.0.2-104000032023092119

**版本概览：**

对 OBKV 功能进行优化，新增支持二次路由功能，避免分区 Location Cache 变更造成的请求失败问题。同时对 MySQL 模式下的临时表功能做了禁用的行为变更。

### V4.1.0 BP3 Hotfix2

[**点击查看 V4.1.0 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 9 月 11 日
* 版本号：V4.1.0 BP3 Hotfix2
* RPM 版本号：oceanbase-4.1.0.2-103020012023090809

**版本概览：**

修复并行执行未指定全索引后缀条件（例如，索引键为 c1,c2,c3，但只指定了 c2 而未指定 c3）的情况下，查询执行 index skip scan 计划引发的正确性问题。

### V4.1.0 BP3 Hotfix1

[**点击查看 V4.1.0 BP3 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 8 月 25 日
* 版本号：V4.1.0 BP3 Hotfix1
* RPM 版本号：oceanbase-4.1.0.2-103010012023082514

**版本概览：**

修复 MySQL 模式下变更普通租户规格时，最大连接数降低至 100，非 Root 用户新建连接失败的问题；修复计划生成添加到 Plan Cache 时，复用已经释放计划的指针，导致 server core dump 的问题。

### V4.1.0 BP3

[**点击查看 V4.1.0 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 8 月 25 日
* 版本号：V4.1.0 BP3 Hotfix1
* RPM 版本号：oceanbase-4.1.0.2-103010012023082514

**版本概览：**

在并行 TRUNCATE 场景下，优化序列缓存的实现，确保在 TRUNCATE TABLE 完成后，序列值不会被错误地推高，符合 MySQL 的语义。在 OBKV-Table 中新增支持 min/max/count 等聚合函数的接口，可以直接返回聚合后的结果，无需再返回数据行再进行聚合。同时，还新增了自增主键和连续递增序列的功能，支持在插入数据时进行行数据校验。

### V4.1.0 BP2 Hotfix1

[**点击查看 V4.1.0 BP2 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 6 月 29 日
* 版本号：V4.1.0 BP2 Hotfix1
* RPM 版本号：oceanbase-4.1.0.1-102010012023062910

**版本概览：**

修复 MySQL 模式下，当 timestamp 类型的列指定 default 值为 current\_timestamp 或 now() 时，在进行 insert/update 操作并显式指定该列的值为 default 时，导致插入时间比 current\_timestamp 晚 8 个小时的问题。

### V4.1.0 BP2

[**点击查看 V4.1.0 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 6 月 15 日
* 版本号：V4.1.0 BP2
* RPM 版本号：oceanbase-4.1.0.1-102000042023061309

**版本概览：**

修复一系列关键问题，包括事务挂起、优化器谓词下推、系统时间异常、SQL执行错误、并行更新限制、网络抖动、内存泄漏、租户白名单、数据乱码、视图访问错误、数据类型不一致以及并发操作导致的schema 版本错误，显著提升了数据库的性能。

### V4.1.0 BP1

[**点击查看 V4.1.0 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 5 月 8 日
* 版本号：V4.1.0 BP1
* RPM 版本号：oceanbase-4.1.0.0-101000052023050621

**版本概览：**

修复数据库在特殊数据分布、列删除、存储过程调用、网络配置、资源限制、元数据兼容性、正则表达式函数处理以及生成列索引使用等方面的问题，增强了数据库的稳定性、性能和兼容性。

### V4.1.0

[**点击查看 V4.1.0 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.1.0)

**版本信息：**

* 发布时间：2023 年 3 月 31 日
* 版本号：V4.1.0
* RPM 版本号：oceanbase-4.1.0.0-100001122023040322

**版本概览：**

OceanBase 数据库 V4.1.0 版本面向公有云和开源用户场景需求，在对功能健全优化的同时，不断对产品进行打磨和完善，在对 MySQL 8.0 兼容、性能、易用性、成本方面进行优化增强，目标支持项目规模化复制，是真正可全面商业化推广的版本。

## V3.2.4

### V3.2.4 BP8

[**点击查看 V3.2.4 BP8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2024 年 4 月 17 日
* 版本号：V3.2.4 BP8
* RPM 版本号：oceanbase-3.2.4.8-108000142024041520

**版本概览：**

支持备份备份集对应的 `table_name_list`，并提供 `ob_admin` 解析备份集的 `table_name_list` 的能力。

### V3.2.4 BP7 Hotfix1

[**点击查看 V3.2.4 BP7 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2024 年 1 月 3 日
* 版本号：V3.2.4 BP7 Hotfix1
* RPM 版本号：oceanbase-3.2.4.7-107010022023122913

**版本概览：**

从该版本开始，基于 ARM 平台的 RPM 包，会默认开启 LSE 编译。修复存在等值连接条件的两列上，有一侧存在 IN 表达式，例如 `t1.c1 = t2.c1 and t1.c1 in (1,2,3,4,5)` 时，如果还存在其他列上的连接条件，做 Nest Loop Join 时右表上有多个索引可选的情况下，可能导致存在 IN 条件的列索引无法选择，进而可能导致性能不优的问题。

### V3.2.4 BP7

[**点击查看 V3.2.4 BP7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 12 月 5 日
* 版本号：V3.2.4 BP7
* RPM 版本号：oceanbase-3.2.4.7-107000012023113010

**版本概览：**

该版本有如下功能的新增：支持备份配置项并提供解析能力；新增 XA 事务相关监控统计项，便于在 XA 事务流量发生变化时，用户可以及时感知。

### V3.2.4 BP6 Hotfix4

[**点击查看 V3.2.4 BP6 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2024 年 1 月 29 日
* 版本号：V3.2.4 BP6 Hotfix4
* RPM 版本号：oceanbase-3.2.4.6-106040022024012617

**版本概览：**

修复在不需要回表的全局索引场景下，OBServer 未正确返回二次路由错误信息，导致 ODP 路由不准，性能不佳的问题。

### V3.2.4 BP6 Hotfix3

[**点击查看 V3.2.4 BP6 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 12 月 28 日
* 版本号：V3.2.4 BP6 Hotfix3
* RPM 版本号：oceanbase-3.2.4.6-106030022023122216

**版本概览：**

从该版本开始，基于 ARM 平台的 RPM 包，会默认开启 LSE 编译。修复业务单机分区数较多的情况下，压测流量落在新建分区上，无法利用 Clog 聚合优化，随着时间推移引起性能下降的问题。

### V3.2.4 BP6 Hotfix2

[**点击查看 V3.2.4 BP6 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 12 月 11 日
* 版本号：V3.2.4 BP6 Hotfix2
* RPM 版本号：oceanbase-3.2.4.6-106020012023121110

**版本概览：**

修复 Connect By 数据量过大导致内存溢出的问题。

### V3.2.4 BP6 Hotfix1

[**点击查看 V3.2.4 BP6 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 11 月 8 日
* 版本号：V3.2.4 BP6 Hotfix1
* RPM 版本号：oceanbase-3.2.4.6-106010012023110914

**版本概览：**

修复普通租户下的 `oceanbase.GV$OB_SESSION` 视图可以查到其他租户的 Session 信息的问题；修复 Oracle模式下，`decode` 表达式的第三个参数是 `varchar2/char` 类型，且类型推导过程中 `length_semantics` 未设置时，SQL 执行报错 -4016 的问题。

### V3.2.4 BP6

[**点击查看 V3.2.4 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 11 月 3 日
* 版本号：V3.2.4 BP6
* RPM 版本号：oceanbase-3.2.4.6-106000062023110109

**版本概览：**

* 完善 COREDUMP 信息：COREDUMP 错误信息中支持打印 SQL 内容，便于快速定位问题 SQL ，采取限流等操作应急。
* 允许上调 MySQL 模式下最大分区数：目前 MySQL 模式下限制单表最大分区数为 8192，但遇到部分业务单表分区过万的情况。新版本增加配置项 `max_partition_num` 控制 MySQL 模式下允许的单表最大分区数，在业务分区过多的场景下，可适当调大上限放宽限制。
* `FIND_IN_SET` 函数性能优化：针对 `FIND_IN_SET` 第二个参数为常量的场景，优化了函数执行性能。

### V3.2.4 BP5 Hotfix7

[**点击查看 V3.2.4 BP5 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2024 年 1 月 4 日
* 版本号：V3.2.4 BP5 Hotfix7
* RPM 版本号：oceanbase-3.2.4.5-105070012024010214

**版本概览：**

修复 Primary Zone 为 RANDOM 时，PX Batch Rescan 返回结果不正确的问题；修复 Oracle 模式下，高并发查询 `ALL_` 开头的视图，CPU 使用过高的问题。

### V3.2.4 BP5 Hotfix6

[**点击查看 V3.2.4 BP5 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 12 月 15 日
* 版本号：V3.2.4 BP5 Hotfix6
* RPM 版本号：oceanbase-3.2.4.5-105060012023121115

**版本概览：**

* 修复 OBServer 数量过多时，复制表相关虚拟表 `__all_virtual_duplicate_partition_mgr_stat` 中 `partition_lease_list` 展示不完整的问题。
* 修复切主场景下，复制表事务提交后未读到最新数据的问题。
* 修复复制表切主场景下写入的日志 obcdc 无法识别的问题。

### V3.2.4 BP5 Hotfix5

[**点击查看 V3.2.4 BP5 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 12 月 6 日
* 版本号：V3.2.4 BP5 Hotfix5
* RPM 版本号：oceanbase-3.2.4.5-105050022023120510

**版本概览：**

* 修复 Oracle 模式下，在 For Loop Cursor 中嵌套其他 Block A，在 Block A 中 Goto 到 For Loop Cursor 外层，再次进入 For Loop Cursor 中时，报错 -5589，`Cursor is already open` 的问题。
* 修复 Oracle 模式下，使用 RR（或 Serializable）隔离级别时，如果会话 `autocommit` 为 False，且执行过 Select 语句，设置 `set autocommit = 1` 没有触发隐式提交的问题。
* 修复 Oracle 模式下，使用 RR（或 Serializable）隔离级别情况下，数据被其他 Session 删除并发起转储且超过 `undo_retention` 设置时间时，Read Only 事务返回超时的问题。

### V3.2.4 BP5 Hotfix4

[**点击查看 V3.2.4 BP5 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 11 月 14 日
* 版本号：V3.2.4 BP5 Hotfix4
* RPM 版本号：oceanbase-3.2.4.5-105040022023111323

**版本概览：**

* 修复 PS 模式下，SQL 无法命中 Plan Cache 的问题。
* 修复 Oracle 模式下，使用了和原生 Oracle 不同的 Hash 算法，`dbms_utility.get_hash_value` 执行结果不同的问题。

### V3.2.4 BP5 Hotfix3

[**点击查看 V3.2.4 BP5 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 11 月 3 日
* 版本号：V3.2.4 BP5 Hotfix3
* RPM 版本号：oceanbase-3.2.4.5-105030012023103122

**版本概览：**

* 修复存在函数索引的情况下，Prepare Stmt 中包含函数索引定义且对定义中常量进行了参数化时，SQL 执行报错的问题。
* 修复 `UNION` 子句 `SELECT` 中有常量，常量输出列在外围用作过滤时，由于 Exec Param 将过滤谓词转换为 Startup Filter，并按老引擎执行，SQL 报错 `failed to calc startup filter` 的问题。

### V3.2.4 BP5 Hotfix2

[**点击查看 V3.2.4 BP5 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 10 月 9 日
* 版本号：V3.2.4 BP5 Hotfix2
* RPM 版本号：oceanbase-3.2.4.5-105020052023092709

**版本概览：**

* 修复 MySQL 模式下，`DATETIME` 类型转 `JSON` 类型时区偏移的问题。
* 修复 Oracle 模式下，XA 事务内存泄漏问题。
* 修复 Oracle 模式下，开启 PS 二合一协议时，如果传参为空且对应谓词可以改成恒 False，执行计划走偏性能较差的问题。

### V3.2.4 BP5 Hotfix1

[**点击查看 V3.2.4 BP5 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 9 月 4 日
* 版本号：V3.2.4 BP5 Hotfix1
* RPM 版本号：oceanbase-3.2.4.5-105010012023090116

**版本概览：**

修复在执行 `insert into...on duplicate key /replace into` 语句插入大量冲突行时，由于内存释放不及时，可能导致租户内存不足的报错问题。

### V3.2.4 BP5

[**点击查看 V3.2.4 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 8 月 18 日
* 版本号：V3.2.4 BP5
* RPM 版本号：oceanbase-3.2.4.5-105000012023081513

**版本概览：**

OBKV 引入二次路由功能以规避分区位置缓存变化导致的请求失败问题，同时新增 `opt_param` 和 `no_index` HINT 增强执行计划能力，优化进程列表统计时间精度并新增 CPU 时间统计，增加`GV$SYSSTAT` 视图中的 CPU 时间统计项以更准确反映 CPU 利用率，提升了 Oracle 模式下全局临时表的稳定性，支持 Oracle 的 FM 日期格式修饰词，并兼容 MySQL 8.0 Lateral Derived Tables 功能。

### V3.2.4 BP4 Hotfix5

[**点击查看 V3.2.4 BP4 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 8 月 2 日
* 版本号：V3.2.4 BP4 Hotfix5
* RPM 版本号：oceanbase-3.2.4.4-104050012023073116

**版本概览：**

修复 MySQL 模式下 Trigger 的 Insert 语句返回的 `rows affected` 与原生 MySQL 不一致的问题，解决 `timestamp` 类型列默认值为 `current_timestamp` 或 `now()` 时导致的时区延迟问题，改善 UDF 在存在大量错误日志时的性能问题，解决 Unit 迁移或数量变更时存储过程偶尔报错 4201 的问题，修复 CPU 使用过高导致 RS 切主失败的问题，以及修复 Public 同义词与 Function 对象或 Package 对象同名时，同义词解析无限递归导致爆栈的问题。

### V3.2.4 BP4

[**点击查看 V3.2.4 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 6 月 21 日
* 版本号：V3.2.4 BP4
* RPM 版本号：oceanbase-3.2.4.4-104000052023062021

**版本概览：**

对 OBKV 中进行了功能优化，增强了 Table 模型，支持单分区内的 Count 函数，同时引入了定义过期列功能以实现数据的自动清理。在 MySQL 数据类型方面，新增了对 `NCHAR/NVARCHAR` 类型的支持，并实现了 `SELECT N'xxx'` 语法。为了提升 Oracle 函数的兼容性，还新增了 `SOUNDEX` 和 `NLS_INITCAP` 函数支持，后者目前限于二进制排序。此外，在安全性方面，引入了配置项 `_enable_reserved_user_dcl_restriction`，用于控制是否限制对内置用户的普通用户修改操作，以此加强安全管理。

### V3.2.4 BP3

[**点击查看 V3.2.4 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 4 月 19 日
* 版本号：V3.2.4 BP3
* RPM 版本号：oceanbase-3.2.4.3-103000032023041816

**版本概览：**

新增 OBKV 连接数统计功能简化 OBKV 请求问题的定位流程，引入视图 `GV$OB_KV_CONNECTIONS` 和 `V$OB_KV_CONNECTIONS`，用于查询当前租户所有 KV 类活跃 SESSION 以及当前租户 OBServer 节点上所有 KV 类活跃 SESSION，从而更方便地监控和管理数据库连接。此外，跨机获取 SEQUENCE CURRVAL 的行为也得到了优化。在历史版本中，通过 OBProxy 连接 OBServer 节点时，如果在连续的 NEXTVAL 和 CURRVAL 调用之间发生了路由切换，不同服务端 SESSION 中调用 CURRVAL 会报错。新版本改进了这一行为，支持 OBProxy 连接 OBServer 节点时 CURRVAL 跨路由同步，即在不同服务端 SESSION 中调用 CURRVAL 时，系统会返回上一次的 NEXTVAL 值，从而提高了系统的稳定性。

### V3.2.4 BP2

[**点击查看 V3.2.4 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 2 月 28 日
* 版本号：V3.2.4 BP2
* RPM 版本号：oceanbase-3.2.4.2-102000042023022717

**版本概览：**

* Oracle 模式下系统包 UTL\_RAW 新增支持函数 `CAST_TO_NVARCHAR2()`，将 RAW 值转换为 NVARCHAR2 值。
* Oracle 模式下 DBLINK 支持通过 DNS 域名解析的方式进行连接。
* Oracle 模式下新增支持 `XMLAGG()`、`XMLPARSE()` 和 `XMLELEMENT()` 三个系统函数。
* MySQL 模式下支持 `FROM_BASE64()` 和 `TO_BASE64()` 函数。
* MySQL 模式下系统变量 `DEFAULT_STORAGE_ENGINE` 和 `EVENT_SCHEDULER` 兼容。
* 视图 `V$OB_SQL_AUDIT` 的字段 `REQUEST_TYPE` 新增取值 11，表示该 SQL 是在 PL 内部执行。

### V3.2.4 BP1

[**点击查看 V3.2.4 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2023 年 1 月 9 日
* 版本号：V3.2.4 BP1
* RPM 版本号：oceanbase-3.2.4.1-101000052023010822

**版本概览：**

安全方面优化增强，包括动态设置备份恢复操作的 AK/SK，加密存储 DBLINK 配置密码，RPC 认证通信以及 TDE 能力适配阿里云 KMS。监控统计优化新增事务和 SQL 执行耗时统计。MySQL PL 语法兼容性提升。性能优化使得简易 SQL 场景执行性能提升约4倍。

### V3.2.4

[**点击查看 V3.2.4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.4)

**版本信息：**

* 发布时间：2022 年 11 月 1 日
* 版本号：V3.2.4
* RPM 版本号：oceanbase-3.2.4.0-100000072022102819

**版本概览：**

OceanBase 数据库 V3.2.4 版本是在 V3.2.3 稳定版本的基础上，根据客户系统生产和测试需求，继续在内核功能兼容性和稳定性方面进行迭代增强。核心能力提升如下：- MySQL 兼容性增强：支持地理信息系统（GIS），兼容 MySQL Binlog 解析，新增系统包 `DBMS_RESOURCE_MANAGER`。 - Oracle 兼容性增强：新增系统包 DBMS\_SCHEDULER，系统包函数补充完善。 - 内核增强：支持基于 SQL 规则的资源隔离，支持 IPv6 协议，支持备份到 OBS，日志优化，支持配置事务大小，支持配置登录线程数量。

## V3.2.3

### V3.2.3 BP11 Hotfix4

[**点击查看 V3.2.3 BP11 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2025 年 07 月 23 日
* 版本号：V3.2.3 BP11 Hotfix4
* RPM 版本号：oceanbase-3.2.3.3-111040012025072114

**版本概览：**

* 修复因老执行引擎下 PX Coord 算子、GI 算子在 Rescan 扫描时未重新计算 Startup Filter，导致的正确性问题。
* 修复 NLJ Batch Join 场景下 SQL 执行报错 4002 的问题。
* 修复在临时表场景中，PX SQC Finish Message 中有个别成员对象没有释放，导致的内存泄漏问题。
* 修复在租户内存 Limit 等于 Hold 情况下，因自动内存管理功能瘫痪，导致的磁盘放大问题。
* 修复因存储层估行不准导致的计划生成错误问题。
* 修复 PS Cursor 及 PL 中因执行计划包含 Subplan Filter 或 Nested Loop Join 算子报错引发的 OBServer Core 问题。
* 修复子查询空字符串下 Hint 与 Outline 绑定执行错误导致 OBServer Core 的问题。

### V3.2.3 BP11 Hotfix3

[**点击查看 V3.2.3 BP11 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2025 年 01 月 14 日
* 版本号：V3.2.3 BP11 Hotfix3
* RPM 版本号：oceanbase-3.2.3.3-111030042025011012

**版本概览：**

* 新增 ERROR 日志打印，检测引用计数泄漏问题。
* 新增 PrepareStatement 场景下支持 SHOW 语法。
* 修复 PL/SQL 包例程中 %TYPE 定义的 CLOB 参数其精度长度解析异常的问题。

### V3.2.3 BP11 Hotfix2

[**点击查看 V3.2.3 BP11 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 10 月 16 日
* 版本号：V3.2.3 BP11 Hotfix2
* RPM 版本号：oceanbase-3.2.3.3-111020032024101417

**版本概览：**

* 修复 encoding 导致的备库合并报错 4103 问题。
* 修复包含重复列名的生成表，查询时不引用重复列名导致的正确性问题。
* 修复部分 NLJ 场景下，ScanDASCtx 模块动态内存泄漏的问题。
* 修复部分外键场景执行 Update 语句 Core 的问题。
* 修复 regexp\_replace 表达式在输入参数长度较长时，报错 4013 的问题。

### V3.2.3 BP11 Hotfix1

[**点击查看 V3.2.3 BP11 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 8 月 14 日
* 版本号：V3.2.3 BP11 Hotfix1
* RPM 版本号：oceanbase-3.2.3.3-111010012024081311

**版本概览：**

修复底层模块分区引用计数泄漏的问题。

### V3.2.3 BP11

[**点击查看 V3.2.3 BP11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 7 月 12 日
* 版本号：V3.2.3 BP11
* RPM 版本号：oceanbase-3.2.3.3-111000032024070822

**版本概览：**

**新增 XA 事务相关监控统计项**：部分客户业务会采用 XA 协议来保证跨库事务提交的原子性。由于 OceanBase 数据库本身分布式架构特性，XA 语句的执行需要消耗一定的资源。该版本在 `[G]V$SYSSTAT` 中新增 `XA_TRANS_START_COUNT`、`XA_READ_ONLY_TRANS_TOTAL_COUNT`、`XA_ONE_PHASE_COMMIT_TOTAL_COUNT` 等 30 余项统计项，便于在 XA 事务流量发生变化时，用户可以及时感知。

### V3.2.3 BP10 Hotfix13

[**点击查看 V3.2.3 BP10 Hotfix13 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 6 月 21 日
* 版本号：V3.2.3 BP10 Hotfix13
* RPM 版本号：oceanbase-3.2.3.3-110130012024061819

**版本概览：**

修复 insert on duplicate key update a = values(b) 中 values() 计算问题，导致 OBServer 异常报错 Column 'a' cannot be null 的问题。

### V3.2.3 BP10 Hotfix12

[**点击查看 V3.2.3 BP10 Hotfix12 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 6 月 7 日
* 版本号：V3.2.3 BP10 Hotfix12
* RPM 版本号：oceanbase-3.2.3.3-110120012024060510

**版本概览：**

* 修复 Nested Loop Join 场景 Startup Filter 多次 Rescan 导致 Core 的问题。
* 修复 Nested Loop Join 场景 ScanDASCtx 模块内存膨胀的问题。

### V3.2.3 BP10 Hotfix11

[**点击查看 V3.2.3 BP10 Hotfix11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 5 月 25 日
* 版本号：V3.2.3 BP10 Hotfix11
* RPM 版本号：oceanbase-3.2.3.3-110110032024052217

**版本概览：**

* 修复事务内有较大的 clob 数据插入时，如果插入 SQL 触发唯一键冲突，会导致事务意外回滚的问题。
* 修复 TX\_CALLBACK\_CTX\_ID 模块内存占用率高的问题。
* 修复 PS 二合一协议在某些执行报错场景，无限重试到超时的问题。
* 优化鲲鹏处理器下计算性能（支持 memset 函数、lse、-wl -q 编译选项）。

### V3.2.3 BP10 Hotfix10

[**点击查看 V3.2.3 BP10 Hotfix10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 4 月 30 日
* 版本号：V3.2.3 BP10 Hotfix10
* RPM 版本号：oceanbase-3.2.3.3-110100012024042814

**版本概览：**

* 修复 OCP 开启事务采集时，查询 OBServer 内部表导致集群 Core 的问题。
* 修复 Sequence 在 nocache+noorder 模式下，修改步长后，序列值回退的问题。

### V3.2.3 BP10 Hotfix9

[**点击查看 V3.2.3 BP10 Hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 4 月 17 日
* 版本号：V3.2.3 BP10 Hotfix9
* RPM 版本号：oceanbase-3.2.3.3-110090012024041611

**版本概览：**

* 修复 Nested Loop Join 场景下，大量 Rescan 命中同一个微块导致 500 租户 DecoderCtx 内存膨胀的问题。
* 修复 Varchar 类型转换为 Date 类型异常，导致 OBServer Core 的问题。

### V3.2.3 BP10 Hotfix8

[**点击查看 V3.2.3 BP10 Hotfix8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 2 月 29 日
* 版本号：V3.2.3 BP10 Hotfix8
* RPM 版本号：oceanbase-3.2.3.3-110080012024022713

**版本概览：**

* 修复一个长时间不结束的只读请求，叠加进行业务负载均衡、Drop Table、Truncate Table、Drop Replica 等需要删除分区的操作时，删除分区会卡住，进而可能造成冻结卡住或无法转储导致内存爆、Clog 盘爆的问题。
* 修复 Group By 上拉场景，对相关子查询改写异常，进而导致 SQL 执行报错的问题。
* 修复带多个子查询的 Subplan Filter 算子 PKEY 分布式计划查询结果错误的问题。
* 修复用户 SQL 的 Where 谓词中，包含 `xxx IN subquery1 and xxx NOT IN subquery2`, 如果 `subquery1` 结果集是 `subquery2` 的超集，可能触发改写错误的问题。
* 修复在嵌套语句中，使用动态 SQL，执行 `ALTER SESSION SET` 类型的语句报错的问题。

### V3.2.3 BP10 Hotfix7

[**点击查看 V3.2.3 BP10 Hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 1 月 26 日
* 版本号：V3.2.3 BP10 Hotfix7
* RPM 版本号：oceanbase-3.2.3.3-110070012024012316

**版本概览：**

* 修复 Oracle 模式下，使用 `dbms_metadata.get_ddl` 子程序查看建表语句，不展示表的唯一约束的问题。
* 修复租户过多导致重启 OBServer 失败报错 -4013 的问题。
* 修复内核因实现类似 SQLPlus 客户端 Trim 掉字符串换行前空格行为，导致和原生 Oracle 不兼容的问题。该版开始不再对字符串换行前空格做处理。
* 修复 `INSERT INTO SELECT` 未拦截分区外数据的问题。
* 修复并行场景下，遇到异常报错时，RPC 线程一直不释放，RS 队列堵塞的问题。

### V3.2.3 BP10 Hotfix6

[**点击查看 V3.2.3 BP10 Hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2024 年 1 月 17 日
* 版本号：V3.2.3 BP10 Hotfix6
* RPM 版本号：oceanbase-3.2.3.3-110060012024011615

**版本概览：**

修复执行计划包含 Nested Loop Join 时，若连接条件和投影表达式中存在复杂共享表达式, 查询结果可能不正确的问题。

### V3.2.3 BP10 Hotfix5

[**点击查看 V3.2.3 BP10 Hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 11 月 24 日
* 版本号：V3.2.3 BP10 Hotfix5
* RPM 版本号：oceanbase-3.2.3.3-110050012023112210

**版本概览：**

* **系统包函数 `dbms_utility.get_hash_value` 计算结果范围变更：** Oracle 系统包函数 `dbms_utility.get_hash_value(str, base, bucket_size)` 计算结果范围为 [base, base+bucket\_size)。OceanBase 老版本计算结果范围为 [base, bucket\_size]，新版本变更为 [base, base+bucket\_size)。
* 修复旧版本引擎处理恒 False 谓词的逻辑不完善导致计划走偏的问题。

### V3.2.3 BP10 Hotfix4

[**点击查看 V3.2.3 BP10 Hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 11 月 8 日
* 版本号：V3.2.3 BP10 Hotfix4
* RPM 版本号：oceanbase-3.2.3.3-110040022023110614

**版本概览：**

* 修复 OBServer 在编译含大量 SQL 语句的文本匿名块时，CPU 可能持续飙高无法下降的问题。
* 修复 JDBC 2.2.6 及之前版本与 JDBC 2.2.6 之后版本，设置 `useServerPrepStmts=true` 混跑时，如果 SQL 顶层为 PX 算子产生并行 Encoding 优化，应用侧可能出现获取数据为乱码的问题。
* 修复执行一条带 UDF 的 SQL，UDF 内部会访问 Package 中的复杂类型标量时，直连不同机器，查询返回的结果集不一致的问题。
* 修复错误的子查询合并改写，导致查询结果集错误的问题。

### V3.2.3 BP10 Hotfix3

[**点击查看 V3.2.3 BP10 Hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 10 月 23 日
* 版本号：V3.2.3 BP10 Hotfix3
* RPM 版本号：oceanbase-3.2.3.3-110030012023101913

**版本概览：**

* 修复 JDBC 2.4.5 通过 PS Cursor 执行 SQL 时，`sql_audit` 中没有 `param_values` 内容的问题。
* 修复 MySQL 模式下，`insert/replace into ... values` 报错没体现行（Column）、列（Row）相关信息的问题。
* 修复 Decode 函数的类型推导异常，导致 SQL 执行报错 `value too large for column` 的问题。
* 修复 V3.2.3 版本由于不支持 SEMI JOIN/SUBPLAN FILTER 的短路执行功能，导致迭代器的对位异常，Update 执行报错 -4377 的问题。
* 修复异常情况下临时文件 Read I/O 发生内存泄露，泄漏一段时间后导致大查询和建索引任务报错 -4013 的问题。

### V3.2.3 BP10 Hotfix2

[**点击查看 V3.2.3 BP10 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 9 月 28 日
* 版本号：V3.2.3 BP10 Hotfix2
* RPM 版本号：oceanbase-3.2.3.3-110020022023092816

**版本概览：**

修复升级混跑期间，当在 PX 下执行分区表的 JOIN 场景时，如查询选择了 PKEY 计划(计划中包含 `EXCHANGE OUT DISTR (PKEY)` 字段)，可能会导致执行结果不正确的问题。

### V3.2.3 BP10 Hotfix1

[**点击查看 V3.2.3 BP10 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 9 月 25 日
* 版本号：V3.2.3 BP10 Hotfix1
* RPM 版本号：oceanbase-3.2.3.3-110010042023092216

**版本概览：**

修复非并行执行时，分布式执行中间结果占用内存较大的问题； MySQL 模式下 INSERT IGNORE 未忽略非空约束导致执行报错、 SYSDATE 和 NOW 函数执行结果与原生 MySQL 不一致的问题；优化器改写为 NLJ BC2HOST 计划后，SQL 执行报错的问题。

### V3.2.3 BP10

[**点击查看 V3.2.3 BP10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 9 月 15 日
* 版本号：V3.2.3 BP10
* RPM 版本号：oceanbase-3.2.3.3-110000092023091219

**版本概览：**

OceanBase 数据库 V3.2.3 BP10 版本能力提升如下：

* 在 COREDUMP 错误信息中支持打印 SQL 内容，可以帮助快速定位问题 SQL，并采取限流等操作来进行紧急处理。
* 支持 `GET DIAGNOSTICS`、`GET STACKED DIAGNOSTICS CONDITION`、`DECLARE CONTINUE HANDLER` 和 `SIGNAL SQLSTATE` 等 MySQL PL 语法。
* 支持为 SET 变量赋值子查询。

### V3.2.3 BP9 Hotfix2

[**点击查看 V3.2.3 BP9 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 8 月 18 日
* 版本号：V3.2.3 BP9 Hotfix2
* RPM 版本号：oceanbase-3.2.3.3-109020032023081510

**版本概览：**

修复 ALTER TABLE 操作中的 NOT NULL 约束标记错误，QUERY RANGE 估行未使用直方图统计信息，以及 .NET 平台使用 MySQL Connector 连接时获取系统变量报错的问题。

### V3.2.3 BP9 Hotfix1

[**点击查看 V3.2.3 BP9 Hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 8 月 1 日
* 版本号：V3.2.3 BP9 Hotfix1
* RPM 版本号：oceanbase-3.2.3.3-109010012023072721

**版本概览：**

在 `GV$SYSSTAT` 视图中新增 `cpu time` 统计项，以提供准确的租户 CPU 利用率。

### V3.2.3 BP9

[**点击查看 V3.2.3 BP9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 7 月 14 日
* 版本号：V3.2.3 BP9
* RPM 版本号：oceanbase-3.2.3.3-109000182023071410

**版本概览：**

MySQL 数据类型优化：新增支持 NCHAR/NVARCHAR 数据类型，并支持 `SELECT N'xxx'` 语法。

### V3.2.3 BP8

[**点击查看 V3.2.3 BP8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 4 月 15 日
* 版本号：V3.2.3 BP8
* RPM 版本号：oceanbase-3.2.3.3-108000062023041511

**版本概览：**

在节点宕机或 Leader 切换场景下，新增支持 SQL 快速失败能力，降低响应延迟；将 OBStack 工具集成到 OBServer 安装包中，便于轻量实时地获取线程堆栈；增加配置项 `_enable_reserved_user_dcl_restriction` 控制是否限制普通用户对内置用户进行修改。

### V3.2.3 BP7

[**点击查看 V3.2.3 BP7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2023 年 1 月 19 日
* 版本号：V3.2.3 BP7
* RPM 版本号：oceanbase-3.2.3.3-107000092023011911

**版本概览：**

MySQL 模式下支持 `FROM_BASE64()` 和 `TO_BASE64()` 函数；支持使用 GRANT 语法对系统包 `DBMS_RESOURCE_MANAGER` 赋权；优化虚拟表 `information_schema.table_constraints` 的访问性能。

### V3.2.3 BP6

[**点击查看 V3.2.3 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 11 月15 日
* 版本号：V3.2.3 BP6
* RPM 版本号：oceanbase-3.2.3.3-106000102022111521

**版本概览：**

实现备份恢复操作的动态 AK/SK 设置，优化了 IN 表达式查询性能，支持 OBKV-Table 的 Filter 和 QueryAndMutate 接口函数，引入了标量函数，优化了分区路由，以及增强了安全能力通过透明加密与阿里云 KMS 的适配。

### V3.2.3 BP5

[**点击查看 V3.2.3 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 9 月 9 日
* 版本号：V3.2.3 BP5
* RPM 版本号：oceanbase-3.2.3.2-105000062022090916

**版本概览：**

支持 SQL 文本的预处理语句，增强备份恢复操作通过外部存储 IO 独立子进程功能，新增 MySQL 模式下的 `ADDTIME()` 和 `DAYNAME()` 函数，优化日志输出，新增集群级配置项以控制备份恢复功能及设定相关参数，以及增加 Window Function 数量限制适配不同模式下的要求。

### V3.2.3 BP4

[**点击查看 V3.2.3 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 8 月 5 日
* 版本号：V3.2.3 BP4
* RPM 版本号：oceanbase-3.2.3.1-20220805104621

**版本概览：**

新增支持表级别 HINT 并行设置，增强了存储过程调试的稳定性并支持 ARM 平台，以及支持限定场景下的添加分区能力，并通过配置项 `_enable_add_between_range_partitions` 开启该功能。

### V3.2.3 BP3

[**点击查看 V3.2.3 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 6月 22 日
* 版本号：V3.2.3 BP3
* RPM 版本号：oceanbase-3.2.3.0-20220622171245

**版本概览：**

引入数据库存储加密（TDE）支持国密 SM4 算法，Oracle 模式下支持列字段默认值使用 Sequence 函数定义，存储过程支持类型构造函数，优化了 Limit 算子性能并支持其下推到 Join 算子，以及支持 SELECT INTO 命令设置文件字符集。

### V3.2.3 BP2

[**点击查看 V3.2.3 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 5月 30日
* 版本号：V3.2.3 BP2
* RPM 版本号：oceanbase-3.2.3.0-20220530152606

**版本概览：**

支持通过 `SELECT INTO` 命令将表数据直接导出到阿里云对象存储 (OSS) 上，MySQL 模式下支持 DETERMINISTIC 属性。

### V3.2.3 BP1

[**点击查看 V3.2.3 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 4月 29 日
* 版本号：V3.2.3 BP1
* RPM 版本号：oceanbase-3.2.3.0-20220429172811

**版本概览：**

MySQL 模式下支持关键字 DISTINCTROW。

### V3.2.3

[**点击查看 V3.2.3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.3)

**版本信息：**

* 发布时间：2022 年 4 月 18 日
* 版本号：V3.2.3
* RPM 版本号：oceanbase-3.2.3.0-20220418212020

**版本概览：**

OceanBase 数据库 V3.2.3 版本是继续在内核兼容性和性能方面进行迭代增强，在满足客户生产需要的同时，增强质量保障测试，推出 V3.2.x 系列稳定版本。核心能力提升如下：

* MySQL 兼容性增强：扩展支持 SEQUENCE 对象，支持通用表表达式（CTE），支持 CHECK 约束，CAST 函数支持字符集设置，存储过程支持 GET DIAGNOSTICS 语句，支持 `SEND_LONG_DATA(24)` 协议等。
* Oracle 兼容性增强：支持数据库链接到 Oracle（DBLINK），支持设置 SEQUENCE 对象的起始值，新增系统包函数 `DBMS_LOB.COMPARE`。
* 性能优化：优化 OBKV-Table 查询，优化分区表 NLJ 算子，优化正则表达式等。 - 稳定性提升：增强备份文件完整性校验，优化选择率计算逻辑等。

### V3.2.2 BP2

[**点击查看 V3.2.2 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.2)

**版本信息：**

* 发布时间：2022 年 1 月 19日
* 版本号：V3.2.2 BP2
* RPM 版本号：oceanbase-3.2.2-20220119123901

**版本概览：**

新增在 Oracle 模式下支持 `REVERSE` 函数，优化批量 `UPDATE` 语句执行性能。

## V3.2.2

### V3.2.2 BP1

[**点击查看 V3.2.2 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.2)

**版本信息：**

* 发布时间：2021 年 12 月 15 日
* 版本号：V3.2.2 BP1
* RPM 版本号：oceanbase-3.2.2-20211215001504

**版本概览：**

Oracle 模式下 TRIGGER 支持 `DECODE` 函数，`RANGE/HASH/LIST` 分区裁剪支持非单一时间范围。

### V3.2.2

[**点击查看 V3.2.2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.2)

**版本信息：**

* 发布时间：2022 年 1 月 10 日
* 版本号：V3.2.2
* RPM 版本号：oceanbase-3.2.2-20211130225726

**版本概览：**

OceanBase 数据库 V3.2.2 版本主要是对数据库内核的稳定性和易用性进行迭代改进，打造满足客户生产需要的稳定版本，同时在 MySQL 模式下推出 JSON 格式数据类型。核心特性如下：

* 支持 JSON 类型：MySQL 模式下新增支持 JSON 格式数据类型，支持 DDL 操作、创建索引、SQL 查询、数据类型转换、MySQL 5.7 版本的全量以及 8.0 版本的部分 JSON 函数。- 内核增强：TableGroup 支持非模版化二级分区；支持主备集群解耦。
* 兼容性：MySQL 租户新增支持聚合函数 `BIT_AND()/BIT_OR()/BIT_XOR()`；Oracle 租户新增支持 ArrayBinding 返回生效的行数。
* 易用性：支持 `SQL_AUDIT` 视图显示绑定变量的值；PL 在解析和执行过程异常时返回错误信息与行号。
* 稳定性：新增支持网络传输压缩；优化 `TIMESTAMP` 分区精度。
* 性能：优化 TRUNCATE 带约束表的性能；优化 `SQL_AUDIT` 视图统计资源消耗；优化多重合并算法和 LIMIT 算子下推逻辑。

### V3.2.1 BP1

[**点击查看 V3.2.1 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.1)

**版本信息：**

* 发布时间：2021 年 9月 30日
* 版本号：V3.2.1 BP1
* RPM 版本号：oceanbase-3.2.1-20210930192315

**版本概览：**

增加 CLOG 文件的自动校验和缓存更新，减少 `TMP.FILE` 文件日志输出，支持 PL 中占位符访问 ARRAY 数据元素，引入国密（SM4）算法表加密，以及支持 `ANONYMOUS/PROCEDURE` 对绑定数组变量的支持。

## V3.2.1

[**点击查看 V3.2.1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.1)

**版本信息：**

* 发布时间：2021 年 9 月 30 日
* 版本号：V3.2.1
* RPM 版本号：oceanbase-3.2.1-20210901195302

**版本概览：**

OceanBase 数据库 V3.2.1 版本主要围绕兼容性、HTAP 混合负载、内核能力增强、小规格性价比等几大核心能力，在 Oracle/MySQL 兼容、易用性、稳定性、性能和功能等诸多方面持续迭代增强与优化升级，在提升用户体验的同时，帮助用户更轻松地完成应用迁移、TP 和 AP 统一部署、降低应用开发部署和运维成本。

## V3.2.0

[**点击查看 V3.2.0 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.2.0)

**版本信息：**

* 发布时间：2021 年 7月 5日
* 版本号：V3.2.0
* RPM 版本号：oceanbase-3.2.0-20210705162520

**版本概览：**

OceanBase 数据库 V3.2.0 版本为实验室测试版本，供 OceanBase 内部人员对 HTAP 能力进行验证测试。

## V3.1.2

### V3.1.2 BP11

[**点击查看 V3.1.2 BP11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2023 年 1 月 6 日
* 版本号：V3.1.2 BP11
* RPM 版本号：oceanbase-3.1.2-111000052023010412

**版本概览：**

* 修复存储过程执行报错 -4201, hash map/set entry not exist 的问题。
* 修复 DML 并行执行报错 -4377 的问题。
* 修复 MySQL 模式下，带 UDF 的 Select 语句事务 SCHEDULER 超过 10 万导致 SQL 报错 -4013 的问题。
* 修复 Insert Select 场景，PDML 指定参与者过多的问题。
* 修复只读副本切换全功能型副本报错的问题。
* 修复包含 UNION ALL 的 SQL 多次执行，第一次为分布式计划且两支参数不同，第二次为 Local 计划且两支参数相同，第三次为 Local 计划且两支参数不同情况下，执行计划选择错误，查询结果可能不正确的问题。
* 修复带 UDF 的查询可能产生悬挂事务，进而导致合并超时、日志归档和数据备份失败的问题。

### V3.1.2 BP10

[**点击查看 V3.1.2 BP10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2022 年 9 月 29 日
* 版本号：V3.1.2 BP10
* RPM 版本号：oceanbase-3.1.2-110050022022120810

**版本概览：**

* 修复 Oracle 模式下，PL 中执行 Insert Values 语句，可能出现插入数据精度丢失的问题。
* 修复老引擎中 Subplan Filter 存在多个子查询时，特殊计划形态及数据分布下，Create Table AS 创建表，表数据存在不一致的问题。
* Oracle 模式下支持 UNISTR、ASCIISTR 表达式，解决 OMS 迁移遇到生僻字无法处理的问题。
* 修复 Oracle 模式下，PL 中使用 Insert Values 需要在两处抽取同一变量的场景，选用了错误的执行计划导致执行报错 -4016 的问题。
* 修复 Hash Join 的 Join Key 存在大量 Null 值，造成 Hash Table 倾斜，执行性能较差的问题。
* 修复 px batch rescan 存在 bug 导致 SQL 执行超时的问题。
* 修复 PS Cache 内存碎片造成 SQL 执行报错 -4013 的问题。

### V3.1.2 BP9

[**点击查看 V3.1.2 BP9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2022 年 7 月 28 日
* 版本号：V3.1.2 BP9
* RPM 版本号：oceanbase-3.1.2-20220727191622

**版本概览：**

进行了多项优化和修复，包括增强 CPU 参数精确度、提高 OLAP 业务下算子执行效率、减少 Root Server 模块日志错误以及解决了字符集不同导致的报错问题、`SQL_AUDIT` 视图数据导出问题。此外，还修复了 OBServer 节点全局索引初始化异常、内存使用统计不准确和存储过程执行内存占用过大的问题。

### V3.1.2 BP8 hotfix9

[**点击查看 V3.1.2 BP8 hotfix9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2025 年 03 月 07 日
* 版本号：V3.1.2 BP8 hotfix9
* RPM 版本号：oceanbase-3.1.2-108090022025021811

**缺陷修复：**

解决使用 Node.js 驱动发包异常导致 core 的问题。

### V3.1.2 BP8 hotfix8

[**点击查看 V3.1.2 BP8 hotfix8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 12 月 26 日
* 版本号：V3.1.2 BP8 hotfix8
* RPM 版本号：oceanbase-3.1.2-108080032024122610

**缺陷修复：**

提供 send long data 协议下 core dump 问题的防御支持。

### V3.1.2 BP8 hotfix7

[**点击查看 V3.1.2 BP8 hotfix7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 07 月 13 日
* 版本号：V3.1.2 BP8 hotfix7
* RPM 版本号：oceanbase-3.1.2-20220712165759

**缺陷修复：**

修复落盘报错 dir\_id 为负的问题。

### V3.1.2 BP8 hotfix6

[**点击查看 V3.1.2 BP8 hotfix6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 07 月 06 日
* 版本号：V3.1.2 BP8 hotfix6
* RPM 版本号：oceanbase-3.1.2-20220706142326

**缺陷修复：**

* 修复存储过程导致 core 问题。
* 修复集群合并超时的问题。

### V3.1.2 BP8 hotfix5

[**点击查看 V3.1.2 BP8 hotfix5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 05 月 11 日
* 版本号：V3.1.2 BP8 hotfix5
* RPM 版本号：oceanbase-3.1.2-20220511135649

**缺陷修复：**

* 修复 SqlPsCache 模块内存泄漏问题。
* 修复 pl 调试 core 的问题。

### V3.1.2 BP8 hotfix4

[**点击查看 V3.1.2 BP8 hotfix4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 04 月 29 日
* 版本号：V3.1.2 BP8 hotfix4
* RPM 版本号：oceanbase-3.1.2-20220428131912

**缺陷修复：**

* 修复集群 Leader 节点 core 问题。
* 修复索引构建报错 ERROR 问题。

### V3.1.2 BP8 hotfix3

[**点击查看 V3.1.2 BP8 hotfix3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 04 月 20 日
* 版本号：V3.1.2 BP8 hotfix3
* RPM 版本号：oceanbase-3.1.2-20220420143524

**缺陷修复：**

修复 obdumper 抽数单表报错 4013 问题。

### V3.1.2 BP8 hotfix2

[**点击查看 V3.1.2 BP8 hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 04 月 16 日
* 版本号：V3.1.2 BP8 hotfix2
* RPM 版本号：oceanbase-3.1.2-20220416031647

**缺陷修复：**

* 修复 ref cusor 流式接口 + px 触发的 sql 执行遇到 px 中断的 bug。
* 修复 ps cursor + px 重试触发的 sql 超时 bug。
* 修复 pl immedite sql 未调用 ps close 导致的 psCache 内存泄漏问题。
* 修复 odc 注释里面出现分号报错问题。

### V3.1.2 BP8 hotfix1

[**点击查看 V3.1.2 BP8 hotfix1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2024 年 04 月 13 日
* 版本号：V3.1.2 BP8 hotfix1
* RPM 版本号：oceanbase-3.1.2-20220412220524

**缺陷修复：**

* 修复备份恢复可能导致数据正确性的严重问题。
* 修复队列积压导致集群不可用的问题。

### V3.1.2 BP8

[**点击查看 V3.1.2 BP8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2022 年 3月 30日
* 版本号：V3.1.2 BP8
* RPM 版本号：oceanbase-3.1.2-20220329234820

**版本概览：**

修复包括 `v$sql_audit` 视图时间准确度问题、唯一索引重复数据的错误处理、字符集合混用支持、配置项影响备份数据清理、MySQL 查询参数结果为空、PL/SQL 入参转换报错、PL 调用引起包状态异常、数据备份时 schema version 不准确和不同字符集返回结果报错的问题。

### V3.1.2 BP7

[**点击查看 V3.1.2 BP7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2022 年 2月 24日
* 版本号：V3.1.2 BP7
* RPM 版本号：oceanbase-3.1.2-20220223145512

**版本概览：**

新增支持 OUTER JOIN 的连接条件为子查询语句，Oracle 模式下引入 DBMS\_LOB.COMPARE 方法以支持 CLOB 字段字符串的比较，并通过配置项 `auto_refresh_location_cache` 实现副本位置的动态刷新功能。

### V3.1.2 BP6

[**点击查看 V3.1.2 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 12月 31日
* 版本号：V3.1.2 BP6
* RPM 版本号：oceanbase-3.1.2-20211230114204

**版本概览：**

实现了主备集群解耦，Oracle 模式增加了对 `USERENV('SID')`、`USERENV('LANGUAGE')` 和 `USERENV('INSTANCE')` 的支持，OBServer 默认进行 SCHEMA 变更历史表的记录清理，并且优化了在空表上创建全局索引的性能。

### V3.1.2 BP5

[**点击查看 V3.1.2 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 11月 19日
* 版本号：V3.1.2 BP5
* RPM 版本号：oceanbase-3.1.2-20211119151959

**版本概览：**

MySQL 模式下支持 `DEGREES()` 函数；匿名块支持 `CURSOR` 作为出参；OBServer 启动时增加对执行用户的 `UID` 检查，禁止非 ADMIN 用户启动。

### V3.1.2 BP4

[**点击查看 V3.1.2 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 10月 13日
* 版本号：V3.1.2 BP4
* RPM 版本号：oceanbase-3.1.2-20211013162404

**版本概览：**

优化改进 `gv$sql_plan_monitor` 视图的显示，增加对本地和远端计划信息的记录；增加系统包函数 `DBMS_LOB.OBCI_WRITE`；`NOT IN` 表达式算子支持提取查询范围。

### V3.1.2 BP3

[**点击查看 V3.1.2 BP3 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 9月 15日
* 版本号：V3.1.2 BP3
* RPM 版本号：oceanbase-3.1.2-20210914104736

**版本概览：**

新增分区表开启 SQL PLAN 自动淘汰，支持 TDE 功能与客户自有 KMS 系统集成，MySQL 模式下引入 `ANY_VALUE()` 函数，实现了 Follower 节点副本的强一致性读，LIBOBLOG 支持配置 RS 节点信息，以及 SLOG 和 CLOG 文件支持 4K 字节对齐读写。

### V3.1.2 BP2

[**点击查看 V3.1.2 BP2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 8月 13日
* 版本号：V3.1.2 BP2
* RPM 版本号：oceanbase-3.1.2-20210813154332

**版本概览：**

优化完善 V2.2.77 版本升级 V3.1.2 功能；提升备份恢复功能稳定性，跨版本备份恢复功能完善。

### V3.1.2 BP1

[**点击查看 V3.1.2 BP1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 7月 1日
* 版本号：V3.1.2 BP1
* RPM 版本号：oceanbase-3.1.2-20210701144352

**版本概览：**

修复带备库升级 `checker` 脚本执行报错的问题；修复含 `NULL` 的表达式类型推导报错的问题。

### V3.1.2

[**点击查看 V3.1.2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.2)

**版本信息：**

* 发布时间：2021 年 6月 18日
* 版本号：V3.1.2
* RPM 版本号：oceanbase-3.1.2-20210618150922

**版本概览：**

OceanBase 数据库 V3.1.2 版本为 V3.1.x 系列稳定版本，支撑客户项目应用上线。

## V3.1.1

[**点击查看 V3.1.1 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V3.1.1)

**版本信息：**

* 发布时间：2021 年 5月 18日
* 版本号：V3.1.1
* RPM 版本号：oceanbase-3.1.1-20210508100750

**版本概览：**

OceanBase 数据库 V3.1.1 版本为测试版本，供内外部项目进行 POC 验证测试。

## V2.2.77

### V2.2.77 BP19

[**点击查看 V2.2.77 BP19 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2024 年 6 月 26 日
* 版本号：V2.2.77 BP19
* RPM 版本号：oceanbase-2.2.77-119000122024060513

**版本概览：**

* PL Debug 功能不建议在生产环境使用。该版本增加 PL Debug 开关 `_enable_dbms_debug_package`，默认关闭。开发测试环境需要使用该功能时，请将该配置项设置为 `True。`
* 修复物理归档备份卡住的问题。
* 修复 `_all_virtual_partition_audit` 虚拟表数据为空的问题。
* 修复 CommonArray 模块内存泄露的问题。
* 修复 SqlExecutor 模块内存泄露的问题。
* 修复 CHAR 列和 VARCHAR 比较情况下 Query Range 抽取不正确问题。
* 修复下压 Order By 打标不合理导致查询结果不正确的问题。
* 修复 `convert_skip_null_check` 导致 Core 的问题。
* 修复 `sys` 租户队列积压导致集群不可用问题。

### V2.2.77 BP17

[**点击查看 V2.2.77 BP17 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2023 年 5 月 19 日
* 版本号：V2.2.77 BP17
* RPM 版本号：oceanbase-2.2.77-117000112023051914

**版本概览：**

在安全方面做了强化，增加配置项 `_enable_reserved_user_dcl_restriction` 控制是否限制普通用户对内置用户进行修改。

### V2.2.77 BP16

[**点击查看 V2.2.77 BP16 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2023 年 2 月 14 日
* 版本号：V2.2.77 BP16
* RPM 版本号：oceanbase-2.2.77-116000022023021412

**版本概览：**

新增支持 OBKV 热点行更新的 GROUP COMMIT 能力。在热点行高并发更新场景下，服务端对热点行的更新做聚合，避免每一个操作都去申请行锁、释放行锁，优化行锁竞争等待时间，提升热点行更新速度。

### V2.2.77 BP15

[**点击查看 V2.2.77 BP15 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2023 年 1 月 10 日
* 版本号：V2.2.77 BP15
* RPM 版本号：oceanbase-2.2.77-115000012023010607

**版本概览：**

MySQL 模式下支持 `FROM_BASE64()` 和 `TO_BASE64()` 函数。

### V2.2.77 BP14

[**点击查看 V2.2.77 BP14 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2022 年 12 月 04 日
* 版本号：V2.2.77 BP14
* RPM 版本号：oceanbase-2.2.77-114000072022120410

**版本概览：**

备份恢复操作支持动态设置 AK/SK，用户可在备份中更改对象存储的访问凭证，同时提供了操作建议以保证备份的顺利进行。此外，数据库优化了热点行观测，在 `v$sysstat` 视图中新增了三个统计字段。管理工具 `ob_admin` 增加对华为云对象存储 OBS 的适配。

### V2.2.77 BP13

[**点击查看 V2.2.77 BP13 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2022 年 8月 26日
* 版本号：V2.2.77 BP13
* RPM 版本号：oceanbase-2.2.77-113000052022082622

**版本概览：**

支持在限定场景下的添加分区能力。管理工具 `ob_admin` 新增了修改指定 OBServer 节点的集群级配置项功能，但不支持租户级配置项的修改。此外，还支持对 COS(Cloud Object Storage) 上的备份文件进行标记，以便用户更好地管理备份文件。

### V2.2.77 BP12

[**点击查看 V2.2.77 BP12 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2022 年 6月 14日
* 版本号：V2.2.77 BP12
* RPM 版本号：oceanbase-2.2.77-20220612090508

**版本概览：**

修复了一系列问题，包括解决 Oracle 模式下存储过程创建导致的挂起问题、MySQL 模式下 Limit 算子类型转换报错、缓存路由不准导致 SQL 执行耗时偏高、DBMS\_LOB.SUBSTR 执行报错、`v$sql_audit` 字段显示异常、SYS 租户资源规格未恢复默认、存储过程入参转化报错、JOIN 优化 CPU 资源消耗、空值处理错误问题等。同时还解决了 OBServer 在使用全局索引、停止集群与数据写入并发操作和系统包操作中可能出现的 crash 问题以及创建索引并发异常报错。

### V2.2.77 BP11

[**点击查看 V2.2.77 BP11 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2022 年 5 月 2 日
* 版本号：V2.2.77 BP11
* RPM 版本号：oceanbase-2.2.77-20220502140811

**版本概览：**

透明加密（TDE）功能新增支持阿里云 KMS，并优化了 OBKV-Table 的流式非阻塞查询性能，同时使 in(values) 查询的 values 规格上限与 MySQL 兼容。LIBOBLOG 库增加了租户过滤功能，可配置以同步特定租户的日志数据，并且支持返回日志同步的位点信息。

### V2.2.77 BP10

[**点击查看 V2.2.77 BP10 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2022 年 1 月 17 日
* 版本号：V2.2.77 BP10
* RPM 版本号：oceanbase-2.2.77-20220116224111

**版本概览：**

支持了 OSS 对象存储的 TAG 清理模式，并在 Oracle 模式下增加了对 USERENV('SID') 和 USERENV('LANGUAGE') 的支持。新增了备份空间达到极限时删除过时备份的功能。同时，优化了 QUEUING 表的稳定性和性能，删除了 CLOG 传输中不支持的流式压缩算法，并且支持了磁盘 `DIRECT_IO` 的 4K 写入对齐。

### V2.2.77 BP9

[**点击查看 V2.2.77 BP9 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2021 年 11 月 19 日
* 版本号：V2.2.77 BP9
* RPM 版本号：oceanbase-2.2.77-20211119120733

**版本概览：**

修复了一系列问题，涉及 PX 执行、ODC 资源释放、SQL PARSE 内存申请、临时表约束管理、MERGE INTO 操作、分区排序、REPLACE INTO 操作、`gv$sql_audit` 视图数据准确性、NFS 备份协议、记录密码明文、slog 空间不足导致的启动问题、SHOW TABLE STATUS 显示、时区设置、权限管理、IP 解析、列名重复、BIT 类型兼容性、启动时配置文件读取以及备份到 OSS 存储和类型转换造成的 crash 问题。

### V2.2.77 BP8

[**点击查看 V2.2.77 BP8 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2021 年 10 月 15 日
* 版本号：V2.2.77 BP8
* RPM 版本号：oceanbase-2.2.77-20211117180427

**版本概览：**

增加内部表 `__ALL_VIRTUAL_PROCESSLIST`，展示事务超时状态。

### V2.2.77 BP7

[**点击查看 V2.2.77 BP7 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2021 年 9 月 18 日
* 版本号：V2.2.77 BP7
* RPM 版本号：oceanbase-2.2.77-20210923214552

**版本概览：**

进行了性能和功能优化，包括分区表 SQL PLAN 的淘汰机制，`ob_admin` 支持了 SSL 通信加密，Oracle 模式增加了 `LOAD DATA REPLACE INTO` 功能。此外，增加了用户登录和登出信息的统计，MySQL 模式支持了 ORDER BY 表达式，并优化了分区自动均衡在 STOP SERVER/ZONE 场景下的应用以及优化了路由临时表的机制。

### V2.2.77 BP6

[**点击查看 V2.2.77 BP6 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2021 年 8 月 25 日
* 版本号：V2.2.77 BP6
* RPM 版本号：oceanbase-2.2.77-20210825181323

**版本概览：**

针对备份恢复、会话管理、CLOG 压缩、安全审计、查询执行等方面进行了多项修复，解决了备份备份标记问题、恢复租户操作问题、PX 场景下租户默认超时问题、CLOG 功能可能引发的观察者进程启动失败、高并发下安全审计死锁、Oracle 模式特定查询导致的 OBServer 崩溃以及分布式执行计划内存申请引发的 OBServer 崩溃问题。

### V2.2.77 BP5

[**点击查看 V2.2.77 BP5 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2021 年 7 月 31 日
* 版本号：V2.2.77 BP5
* RPM 版本号：oceanbase-2.2.77-20210730214129

**版本概览：**

MySQL 模式的 SQL\_MODE 支持 `NO_ZERO_IN_DATE`。

### V2.2.77 BP4

[**点击查看 V2.2.77 BP4 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V2.2.7)

**版本信息：**

* 发布时间：2021 年 7 月 13 日
* 版本号：V2.2.77 BP4
* RPM 版本号：oceanbase-2.2.77-20210712224820

**版本概览：**

MySQL 模式支持 `MAKETIME` 和 `UTC_DATE/UTC_TIME/GET_FORMAT` 函数。

### V2.2.77 BP3

[**点击查看 V4.2.1 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2021 年 6 月 18 日
* 版本号：V2.2.77 BP3
* RPM 版本号：oceanbase-2.2.77-20210618130343

**版本概览：**

MySQL 模式增加对数学和日期函数的支持，包括 `LOG/LN/PI/RADIANS/ATAN/ASIN/ACOS/COT`、`MONTHNAME` 、`LAST_DAY`、`QUARTER` 以及 `BIT_LENGTH` 函数。

### V2.2.77 BP2

[**点击查看 V4.2.1 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2021 年 6 月 4 日
* 版本号：V2.2.77 BP2
* RPM 版本号：oceanbase-2.2.77-20210604113922

**版本概览：**

在 MySQL 模式中增加了 LIKE 语句对特殊字符引号的转义支持，并且引入了租户级配置项 `ob_proxy_readonly_transaction_routing_policy`，在开启后，显式的事务不会强制路由，保证事务内部的所有 SQL 都在同一个 OBServer 节点处理。同时，提升了租户的 `sql_audit` 内存存储能力和优化了异步 IO 的超时等待机制。

### V2.2.77 BP1

[**点击查看 V4.2.1 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2021 年 5 月 27 日
* 版本号：V2.2.77 BP1
* RPM 版本号：oceanbase-2.2.77-20210526202046

**版本概览：**

支持租户级配置项 `_tenant_max_trx_size`，设置事务中分区使用内存的最大限制。

### V2.2.77

[**点击查看 V4.2.1 BP3 Hotfix2 Release Notes 的完整内容**](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.1)

**版本信息：**

* 发布时间：2021 年 5 月 8 日
* 版本号：V2.2.77
* RPM 版本号：oceanbase-2.2.77-20210508211731

**版本概览：**

OceanBase 数据库 V2.2.77 版本为 V2.2.x 系列稳定 GA 版本，在产品高可用性、兼容性和安全性进行改进提升，支撑客户项目批量上线。