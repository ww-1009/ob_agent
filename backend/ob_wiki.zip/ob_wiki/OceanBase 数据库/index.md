# 分类索引：OceanBase 数据库

> 位置：[ob_wiki](../index.md) / OceanBase 数据库 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **OceanBase 部署** | 下设 部署 OceanBase 企业版、部署 OceanBase 社区版，共 2 个子分类。 | `OceanBase 部署` `部署 OceanBase 企业版` `部署 OceanBase 社区版` | [进入目录](./OceanBase 部署/index.md) |
| **OceanBase 简介** | 下设 与 Oracle 兼容性对比，共 1 个子分类。 | `OceanBase 简介` `与 Oracle 兼容性对比` | [进入目录](./OceanBase 简介/index.md) |
| **OceanBase 升级** | 下设 OceanBase 企业版升级、OceanBase 社区版升级，共 2 个子分类。 | `OceanBase 升级` `OceanBase 企业版升级` `OceanBase 社区版升级` | [进入目录](./OceanBase 升级/index.md) |
| **版本发布记录** | 涵盖 OceanBase 数据库企业版、OceanBase 数据库社区版、版本号规则。 | `版本发布记录` `OceanBase 数据库企业版` `OceanBase 数据库社区版` `版本号规则` | [进入目录](./版本发布记录/index.md) |
| **参考指南** | 下设 SQL 参考、错误码、配置项和系统变量、系统视图、系统原理、性能调优、数据库对象管理、工具与组件等 14 个子分类。 | `参考指南` `SQL 参考` `错误码` `配置项和系统变量` `系统视图` `系统原理` `工具与组件` | [进入目录](./参考指南/index.md) |
| **常见问题** | 涵盖 高可用 FAQ、SQL FAQ、集群管理 FAQ、部署 FAQ 等 5 项。 | `常见问题` `高可用 FAQ` `SQL FAQ` `集群管理 FAQ` | [进入目录](./常见问题/index.md) |
| **管理数据库** | 下设 安全权限、备份恢复、副本管理、高可用、集群管理、应急处理、日志流管理、租户管理、性能调优 等 13 个子分类。 | `管理数据库` `安全权限` `备份恢复` `副本管理` `性能调优` | [进入目录](./管理数据库/index.md) |
| **快速上手** | 下设 基于 MySQL 模式创建示例应用程序、基于 Oracle 模式创建示例应用程序、上手 OceanBase SQL、体验 OceanBase 高级特性，共 4 个子分类。 | `快速上手` `基于 MySQL 模式创建示例应用程序` `基于 Oracle 模式创建示例应用程序` `上手 OceanBase SQL` | [进入目录](./快速上手/index.md) |
| **数据迁移** | 下设 OceanBase 数据库之间迁移数据、从 CSV 文件迁移数据到 OceanBase 数据库、从 DB2 数据库迁移数据到 OceanBase 数据库、从 MySQL 数据库迁移数据到 OceanBase 数据库、从 OceanBase 数据库迁移数据到 DB2 数据库 等 12 个子分类。 | `数据迁移` `OceanBase 数据库之间迁移数据` `旁路导入` `使用 SQL 语句迁移数据` | [进入目录](./数据迁移/index.md) |
| **应用开发** | 下设 基于 MySQL 模式进行应用开发、基于 Oracle 模式进行应用开发，共 2 个子分类。 | `应用开发` `基于 MySQL 模式进行应用开发` `基于 Oracle 模式进行应用开发` | [进入目录](./应用开发/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OceanBase 术语.md](./OceanBase 术语.md) | 提供关于OceanBase 术语的相关内容， | OceanBase 术语,OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
| [V4.2.5 文档更新记录.md](./V4.2.5 文档更新记录.md) | 提供关于V4.2.5 文档更新记录的相关内容， | V4.2.5 文档更新记录,OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
| [What's New.md](./What's New.md) | 提供关于What's New的相关内容， | What's New,OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
