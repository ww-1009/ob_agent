---
title: 使用 OMS 从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户
description: 提供关于使用 OMS 从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户的相关内容，
keywords: 使用 OMS 从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户,OceanBase 数据库,数据迁移,从 TiDB 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 OMS 从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户

本文将简单介绍使用 OceanBase 迁移服务（OceanBase Migration Service，OMS）从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户中的背景信息。

## 背景信息

OMS 支持创建源端 TiDB 数据库至目标端 OceanBase 数据库 MySQL 租户的数据迁移项目。您可以通过结构迁移、全量迁移和增量同步等，无缝迁移源端数据库的存量业务数据和增量数据至 OceanBase 数据库 MySQL 租户。

TiDB 数据库支持在线事务处理和在线分析处理（Hybrid Transactional and Analytical Processing，HTAP），是一款融合型分布式数据库产品。您需要部署 TiCDC 集群和 Kafka 集群来实现 TiDB 数据库至 OceanBase 数据库 MySQL 租户的增量数据同步。

![tidb-system-zh](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/oms/oms-enterprise/tidb-system-zh.png)

TiCDC 是 TiDB 数据库的增量数据同步工具，通过 PD 集群（TiDB 集群的调度模块，通常由 3 个 PD 节点构成）来实现高可用。TiKV Server 是 TiDB 集群中的 TiKV 节点，它会以变更日志的方式主动发送变更数据至 TiCDC 集群。TiCDC 工具会通过多个 TiCDC 进程获取 TiKV 节点的数据并进行处理后，同步数据至 Kafka 集群。Kafka 集群会保存 TiCDC 工具转换的 TiDB 数据库的增量日志信息，以便 OMS 在执行增量数据同步时，从 Kafka 集群中获取相应数据并实时迁移数据至 OceanBase 数据库 MySQL 租户。如果您在新建 TiDB 数据源时，未绑定 Kafka 数据源，将无法进行增量同步。

## 相关文档

更多使用 OMS 从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户的操作信息，请参见 [迁移 TiDB 数据库的数据至 OceanBase 数据库 MySQL 租户](https://www.oceanbase.com/docs/enterprise-oms-doc-cn-1000000000091374)。