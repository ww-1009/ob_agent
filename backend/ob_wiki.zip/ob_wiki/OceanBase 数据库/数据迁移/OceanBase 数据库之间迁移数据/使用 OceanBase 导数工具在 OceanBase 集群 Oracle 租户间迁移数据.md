---
title: 使用 OceanBase 导数工具在 OceanBase 集群 Oracle 租户间迁移数据
description: 提供关于使用 OceanBase 导数工具在 OceanBase 集群 Oracle 租户间迁移数据的相关内容，
keywords: 使用 OceanBase 导数工具在 OceanBase 集群 Oracle 租户间迁移数据,OceanBase 数据库,数据迁移,OceanBase 数据库之间迁移数据,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 OceanBase 导数工具在 OceanBase 集群 Oracle 租户间迁移数据

本文将介绍如何使用 OceanBase 导数工具从 OceanBase 集群 Oracle 租户迁移数据至 Oracle 租户。

## OceanBase 导数工具简介

OceanBase 导数工具包括导出工具 obdumper 和导入工具 obloader。

* obdumper 是一款使用 Java 开发的客户端导出工具。可以使用该工具将 OceanBase 数据库中定义的对象和数据导出到文件中。有关 obdumper 的详细信息请参见 [obdumper 简介](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142215)。
* obloader 是一款使用 Java 开发的客户端导入工具。该工具提供了非常灵活的命令行选项，可在多种复杂的场景下，将定义和数据导入到 OceanBase 中。有关 obloader 的详细信息请参见 [obloader 简介](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142221)。

## 操作步骤

1. 准备 obdumper 和 obloader 运行环境。详见 [准备环境](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142213) 和 [下载工具](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142214)。
2. 创建存放导出数据的目录。
3. 导出表结构/数据。

   ```
   [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
   $./obdumper -h <主机IP> -P <端⼝> -u <⽤⼾> -p <密码> [--sys-user <sys 租户下用户名> --sys-password <sys 租户下特定用户的密码>] -c <集群名称> -t <租⼾> -D <Schema 库名> [--ddl] [--csv|--sql] [--all|--table '表名'] -f <数据⽂件或者⽬录>
   ```

   #### 说明

   * 使用 OceanBase 物理节点的主机地址和端口导出数据时，无需指定 `-c` 选项。
   * 有关 obdumper 命令行选项的详细信息，请参见 [命令行选项](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142216)。
4. 导入表结构/数据。

   ```
   [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
   $./obloader -h <主机IP> -P <端⼝> -u <⽤⼾> -p <密码>  --sys-user <sys 租户下的 root 用户或 proxyro 用户> --sys-password <sys 租⼾下的账⼾密码> -c <集群> -t <租⼾> -D <Schema 库名> [--ddl] [--csv|--sql] [--all|--table '表名'] -f <数据⽂件或者⽬录>
   ```

   #### 说明

   * 使用 OceanBase 物理节点的主机地址和端口导入数据时，无需指定 `-c` 选项。
   * 有关 obloader 命令行选项的详细信息，请参见 [命令行选项](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142222)。

## 导出和导入数据示例

下表为示例中使用的数据库信息：

| 数据库信息 | 示例值 |
| --- | --- |
| 集群名 | test4000 |
| OceanBase DataBase Proxy (ODP) 主机地址 | xxx.xxx.xxx.xxx |
| OceanBase DataBase Proxy (ODP) 端口号 | 2883 |
| sys 租户下 root 用户的密码 | \*\*\*\*\*\* |
| 源租户名称（Oracle 模式） | oracle001 |
| 租户 oracle001 的用户账号（要求读写权限） | obdumper\_user01 |
| 租户 oracle001 下用户 obdumper\_user01 的密码 | \*\*\*\*\*\* |
| 租户 oracle001 下 Schema 库名称 | OBDUMPER\_USER01 |
| 目标租户名称（Oracle 模式） | oracle002 |
| 租户 oracle002 的用户账号（要求读写权限） | obloader\_user01 |
| 租户 oracle002 下用户 obloader\_user01 的密码 | \*\*\*\*\*\* |
| 租户 oracle002 下 Schema 库名称 | OBLOADER\_USER01 |

### 表结构迁移

使用 obdumper 和 obloader 进行表结构迁移时，需要指定 `--sys-user` 和 `--sys-password` 选项，获取表结构元数据信息。如果未指定该选项，导出/导入功能和性能可能会受到较大的影响。

#### 说明

`--sys-user` 选项用于连接 `sys` 租户下拥有特定权限的用户。导出时如果未指定 `--sys-user` 选项，默认指定的是 `--sys-user root`。

#### 导出 DDL 定义文件

场景描述：从集群 `test4000` 下的租户 `oracle001` 里的 Schema `OBDUMPER_USER01` 中，导出所有已支持的对象定义语句到 `/home/admin/test_migrate_data/ddl_data` 目录。

* 示例语句如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $./obdumper -h xxx.xxx.xxx.xxx -P 2883 -u obdumper_user01 -p ****** -c test4000 -t oracle001 -D obdumper_user01 --sys-user root --sys-password ****** --ddl --all -f /home/admin/test_migrate_data/ddl_data
  2022-12-26 18:41:07 [INFO] Parsed args:
  [--ddl] true
  [--file-path] /home/admin/test_migrate_data/ddl_data
  [--host] xxx.xxx.xxx.xxx
  [--port] 2883
  [--user] obdumper_user01
  [--tenant] oracle001
  [--cluster] test4000
  [--password] ******
  [--database] obdumper_user01
  [--sys-user] root
  [--sys-password] ******
  [--all] true

  2022-12-26 18:41:07 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
  2022-12-26 18:41:07 [INFO] The manifest file: "/home/admin/test_migrate_data/ddl_data/data/MANIFEST.bin" has been saved
  2022-12-26 18:41:07 [INFO] Query column metadata for the table: "TEST_TBL1" finished
  2022-12-26 18:41:07 [INFO] Query column metadata for the table: "TEST_TBL2" finished
  2022-12-26 18:41:07 [INFO] Found 2 empty tables before dump out records. Elapsed: 11.61 ms
  2022-12-26 18:41:07 [WARN] No views are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No triggers are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No functions are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No procedures are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No types are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No type bodies are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No packages are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No package bodies are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No synonyms are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No public synonyms are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No sequences are exist in the schema: "OBDUMPER_USER01"
  2022-12-26 18:41:07 [WARN] No table groups are exist in the tenant: "oracle001"
  2022-12-26 18:41:07 [INFO] Generate 1 dump tasks finished. Total Elapsed: 3.876 ms
  2022-12-26 18:41:07 [INFO] Start 3 schema dump threads for 1 dump tasks finished.
  2022-12-26 18:41:07 [INFO] Build direct com.alibaba.druid.pool.DruidDataSource finished
  2022-12-26 18:41:07 [INFO] No need to acquire DataSource for xxx@sys, as observer is 4.0.0.0
  2022-12-26 18:41:07 [INFO] Return the latest compatible version: 4.0.0.0 -> 4.0.0.0
  2022-12-26 18:41:07 [INFO] Dump create objects success. DbType: OBORACLE Version: 4.0.0.0
  2022-12-26 18:41:07 [INFO] ObOracle(4.0.0.0) is older than 4.0.0.0 ? false
  2022-12-26 18:41:07 [INFO] Load meta/oboracle/oboracle22x.xml, meta/oboracle/oboracle40x.xml successed
  2022-12-26 18:41:07 [INFO] Query 0 dependencies elapsed 41.82 ms
  2022-12-26 18:41:08 [INFO] Query table: "TEST_TBL1" attr finished. Remain: 0
  2022-12-26 18:41:08 [INFO] Query table: "TEST_TBL2" attr finished. Remain: 0
  2022-12-26 18:41:08 [INFO] Query 2 tables elapsed 285.4 ms
  2022-12-26 18:41:08 [INFO] Dump [TABLE] TEST_TBL1 to "/home/admin/test_migrate_data/ddl_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1-schema.sql " finished
  2022-12-26 18:41:08 [INFO] Dump [TABLE] TEST_TBL2 to "/home/admin/test_migrate_data/ddl_data/data/OBDUMPER_USER01/TABLE/TEST_TBL2-schema.sql " finished
  2022-12-26 18:41:08 [INFO] No.1 It has dumped 2 TABLEs finished. Remain: 0
  2022-12-26 18:41:08 [INFO] Total dumped 2 TABLEs finished. Elapsed: 376.1 ms
  2022-12-26 18:41:08 [INFO] Dump the ddl of schema: "OBDUMPER_USER01" finished
  2022-12-26 18:41:08 [INFO] Close connection count: 19 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_840547833_obdumper_user01
  2022-12-26 18:41:08 [INFO] Shutdown task context finished
  2022-12-26 18:41:08 [INFO] ----------   Finished Tasks: 1       Running Tasks: 0        Progress: 100.00%                                                            ----------
  2022-12-26 18:41:08 [INFO]

  All Dump Tasks Finished:

  ----------------------------------------------------------------------------------------------------------------------------
          No.#        |        Type        |             Name             |            Count             |       Status
  ----------------------------------------------------------------------------------------------------------------------------
          1          |       TABLE        |          TEST_TBL2           |              1               |      SUCCESS
          2          |       TABLE        |          TEST_TBL1           |              1               |      SUCCESS
  ----------------------------------------------------------------------------------------------------------------------------

  Total Count: 2          End Time: 2022-12-26 18:41:08


  2022-12-26 18:41:08 [INFO] Dump schema finished. Total Elapsed: 1.070 s
  2022-12-26 18:41:08 [INFO] Unnecessary to upload the data files to the remote cloud storage service
  2022-12-26 18:41:08 [INFO] System exit 0
  ```
* 导出目录结构如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $tree /home/admin/test_migrate_data/ddl_data
  /home/admin/test_migrate_data/ddl_data
  ├── data
  │   ├── CHECKPOINT.bin
  │   ├── MANIFEST.bin
  │   └── OBDUMPER_USER01
  │       └── TABLE
  │           ├── TEST_TBL1-schema.sql
  │           └── TEST_TBL2-schema.sql
  └── logs
      ├── ob-loader-dumper.error
      ├── ob-loader-dumper.info
      └── ob-loader-dumper.warn

  4 directories, 7 files
  ```
* 查看导出结果文件。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $cat /home/admin/test_migrate_data/ddl_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1-schema.sql
  CREATE TABLE "TEST_TBL1" (
          "COL1" NUMBER(11,0) NOT NULL,
          "COL2" VARCHAR2(20 BYTE),
          "COL3" NUMBER(11,0),
          CONSTRAINT "TEST_TBL1_OBPK_1672051192536124" PRIMARY KEY ("COL1")
  );
  ```

#### 导入 DDL 定义文件

场景描述：将从集群 `test4000` 下的租户 `oracle001` 里的 Schema `OBDUMPER_USER01` 导出到 `/home/admin/test_migrate_data/ddl_data` 目录下所有已支持的定义信息，导入到集群 `test4000` 下的租户 `oracle002` 里的 Schema `OBLOADER_USER01` 中。

* 示例语句如下：

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $./obloader -h xxx.xxx.xxx.xxx -P 2883 -u obloader_user01 -p ****** --sys-user root --sys-password ****** -c test4000 -t oracle002 -D obloader_user01 --ddl --all -f /home/admin/test_migrate_data/ddl_data
  2022-12-26 18:48:20 [INFO] Parsed args:
  [--ddl] true
  [--file-path] /home/admin/test_migrate_data/ddl_data
  [--host] xxx.xxx.xxx.xxx
  [--port] 2883
  [--user] obloader_user01
  [--tenant] oracle002
  [--cluster] test4000
  [--password] ******
  [--database] obloader_user01
  [--sys-user] root
  [--sys-password] ******
  [--all] true

  2022-12-26 18:48:20 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
  2022-12-26 18:48:20 [INFO] The manifest file: "/home/admin/test_migrate_data/ddl_data/data/MANIFEST.bin" has been saved
  2022-12-26 18:48:20 [INFO] Init writer thread pool finished
  2022-12-26 18:48:20 [WARN] The object type : "SEQUENCE" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "TABLE_GROUP" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [INFO] Start 128 schema file loader threads successed
  2022-12-26 18:48:20 [INFO] No.1 sql of the file: "/home/admin/test_migrate_data/ddl_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1-schema.sql" exec success. Elapsed: 124.9 ms
  2022-12-26 18:48:20 [INFO] Load file: "TEST_TBL1-schema.sql" succeeded
  2022-12-26 18:48:20 [INFO] No.1 sql of the file: "/home/admin/test_migrate_data/ddl_data/data/OBDUMPER_USER01/TABLE/TEST_TBL2-schema.sql" exec success. Elapsed: 182.3 ms
  2022-12-26 18:48:20 [INFO] Load file: "TEST_TBL2-schema.sql" succeeded
  2022-12-26 18:48:20 [WARN] The object type : "VIEW" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "FUNCTION" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "PROCEDURE" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "TRIGGER" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "PACKAGE" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "TYPE" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "PACKAGE_BODY" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "TYPE_BODY" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "SYNONYM" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "PUBLIC_SYNONYM" doesn't exist in the -schema.sql files
  2022-12-26 18:48:20 [WARN] The object type : "FILE" doesn't exist in the -schema.sql files
  2022-12-26 18:48:21 [INFO] Close connection count: 1 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_1905901800_obloader_user01
  2022-12-26 18:48:21 [INFO] Shutdown task context finished
  2022-12-26 18:48:21 [INFO] ----------   Finished Tasks: 2       Running Tasks: 0        Progress: 100.00%                                                            ----------
  2022-12-26 18:48:21 [INFO]

  All Load Tasks Finished:

  ----------------------------------------------------------------------------------------------------------------------------
          No.#        |        Type        |             Name             |            Count             |       Status
  ----------------------------------------------------------------------------------------------------------------------------
          1          |       TABLE        |          TEST_TBL2           |            1 -> 1            |      SUCCESS
          2          |       TABLE        |          TEST_TBL1           |            1 -> 1            |      SUCCESS
  ----------------------------------------------------------------------------------------------------------------------------

  Total Count: 2          End Time: 2022-12-26 18:48:21


  2022-12-26 18:48:21 [INFO] Load schema finished. Total Elapsed: 1.064 s
  2022-12-26 18:48:21 [INFO] System exit 0
  ```
* 检查导入的表结构。

  ```
  obclient [OBLOADER_USER01]> SHOW CREATE TABLE test_tbl1\G
  *************************** 1. row ***************************
      TABLE: TEST_TBL1
  CREATE TABLE: CREATE TABLE "TEST_TBL1" (
  "COL1" NUMBER(11) CONSTRAINT "TEST_TBL1_OBNOTNULL_1672051700809789" NOT NULL ENABLE,
  "COL2" VARCHAR2(20),
  "COL3" NUMBER(11),
  CONSTRAINT "TEST_TBL1_OBPK_1672051192536124" PRIMARY KEY ("COL1")
  ) COMPRESS FOR ARCHIVE REPLICA_NUM = 3 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0
  1 row in set
  ```

### 表数据迁移

以下将以导出 CSV 数据文件和导入 CSV 数据文件为例进行介绍使用 obdumper 和 obloader 进行表数据迁移。

#### 导出 CSV 数据文件

文件类型定义：CSV 数据文件（后缀名 `.csv`）是逗号分隔值文件格式，CSV 数据文件以纯文本形式存储表格数据，可通过文本编辑器等工具或者 Excel 打开。

场景描述：从集群 `test4000` 下的租户 `oracle001` 里的 Schema `OBDUMPER_USER01` 中，导出所有已支持对象的数据到 `/home/admin/test_migrate_data/csv_data` 目录，数据格式为 CSV 格式。

* 示例语句如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $./obdumper -h xxx.xxx.xxx.xxx -P 2883 -u obdumper_user01 -p ****** -c test4000 -t oracle001 -D obdumper_user01 --sys-user root --sys-password ****** --csv --table '*' -f /home/admin/test_migrate_data/csv_data
  2022-12-27 10:02:20 [INFO] Parsed args:
  [--csv] true
  [--file-path] /home/admin/test_migrate_data/csv_data
  [--host] xxx.xxx.xxx.xxx
  [--port] 2883
  [--user] obdumper_user01
  [--tenant] oracle001
  [--cluster] test4000
  [--password] ******
  [--database] obdumper_user01
  [--sys-user] root
  [--sys-password] ******
  [--table] [*]

  2022-12-27 10:02:20 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
  2022-12-27 10:02:21 [INFO] The manifest file: "/home/admin/test_migrate_data/csv_data/data/MANIFEST.bin" has been saved
  2022-12-27 10:02:21 [INFO] Query column metadata for the table: "TEST_TBL1" finished
  2022-12-27 10:02:21 [INFO] Query column metadata for the table: "TEST_TBL2" finished
  2022-12-27 10:02:21 [INFO] Query partition names for table: "TEST_TBL1" success. (Non-partitioned)
  2022-12-27 10:02:21 [INFO] Query partition names for table: "TEST_TBL2" success. (Non-partitioned)
  2022-12-27 10:02:21 [INFO] Query primary key for table: "TEST_TBL1" success. Elapsed: 160.8 ms
  2022-12-27 10:02:21 [INFO] Query primary key for table: "TEST_TBL2" success. Elapsed: 160.8 ms
  2022-12-27 10:02:21 [INFO] Query table entry for table: "TEST_TBL2" success. Remain: 0. Elapsed: 4.120 ms
  2022-12-27 10:02:21 [INFO] Query table entry for table: "TEST_TBL1" success. Remain: 0. Elapsed: 4.203 ms
  2022-12-27 10:02:21 [INFO] Query all table entries success. Total: 2. Elapsed: 208.0 ms
  2022-12-27 10:02:21 [INFO] ....Splitting rows for non-partitioned table: "TEST_TBL2" success. Batch: 1
  2022-12-27 10:02:21 [INFO] ....Splitting rows for non-partitioned table: "TEST_TBL1" success. Batch: 1
  2022-12-27 10:02:21 [INFO] ....Splitting rows for non-partitioned table: "TEST_TBL2" success. Batch: 2
  2022-12-27 10:02:21 [INFO] ....Splitting rows for non-partitioned table: "TEST_TBL1" success. Batch: 2
  2022-12-27 10:02:21 [INFO] Split rows for non-partitioned table(with primary key): "TEST_TBL2" success. Ranges: 2. Elapsed: 48.60 ms
  2022-12-27 10:02:21 [INFO] Split rows for non-partitioned table(with primary key): "TEST_TBL1" success. Ranges: 2. Elapsed: 48.60 ms
  2022-12-27 10:02:21 [INFO] Generate 4 dump tasks finished. Total Elapsed: 62.72 ms
  2022-12-27 10:02:21 [INFO] Start 128 record dump threads for 4 dump tasks finished
  2022-12-27 10:02:21 [INFO] Dump 5 rows OBDUMPER_USER01.TEST_TBL2 to "/home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL2.1.*.csv" finished
  2022-12-27 10:02:21 [INFO] Dump 5 rows OBDUMPER_USER01.TEST_TBL1 to "/home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1.1.*.csv" finished
  2022-12-27 10:02:22 [INFO] Close connection count: 12 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_840547833_obdumper_user01
  2022-12-27 10:02:22 [INFO] Shutdown task context finished
  2022-12-27 10:02:22 [INFO] ----------   Finished Tasks: 4       Running Tasks: 0        Progress: 100.00%                                                            ----------
  2022-12-27 10:02:22 [INFO]

  All Dump Tasks Finished:

  ----------------------------------------------------------------------------------------------------------------------------
          No.#        |        Type        |             Name             |            Count             |       Status
  ----------------------------------------------------------------------------------------------------------------------------
          1          |       TABLE        |          TEST_TBL2           |              5               |      SUCCESS
          2          |       TABLE        |          TEST_TBL1           |              5               |      SUCCESS
  ----------------------------------------------------------------------------------------------------------------------------

  Total Count: 10         End Time: 2022-12-27 10:02:22


  2022-12-27 10:02:22 [INFO] Unnecessary to merge the data files. As --file-name is missing
  2022-12-27 10:02:22 [INFO] Dump record finished. Total Elapsed: 1.356 s
  2022-12-27 10:02:22 [INFO] Unnecessary to upload the data files to the remote cloud storage service
  2022-12-27 10:02:22 [INFO] System exit 0
  ```
* 导出目录结构如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $tree /home/admin/test_migrate_data/csv_data
  /home/admin/test_migrate_data/csv_data
  ├── data
  │   ├── CHECKPOINT.bin
  │   ├── MANIFEST.bin
  │   └── OBDUMPER_USER01
  │       └── TABLE
  │           ├── TEST_TBL1.1.0.csv
  │           └── TEST_TBL2.1.0.csv
  └── logs
      ├── ob-loader-dumper.error
      ├── ob-loader-dumper.info
      └── ob-loader-dumper.warn

  4 directories, 7 files
  ```
* 查看导出结果文件。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $cat /home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1.1.0.csv
  'COL1','COL2','COL3'
  1,'China',86
  2,'Taiwan',886
  3,'Hong Kong',852
  4,'Macao',853
  5,'North Korea',850
  ```

#### 导入 CSV 数据文件

场景描述：将从集群 `test4000` 下的租户 `oracle001` 里的 Schema `OBDUMPER_USER01` 导出到 `/home/admin/test_migrate_data/csv_data` 目录下所有已支持的 CSV 数据文件，导入到集群 `test4000` 下的租户 `oracle002` 里的 Schema `OBLOADER_USER01` 中。

* 示例语句如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $./obloader -h xxx.xxx.xxx.xxx -P 2883 -u obloader_user01 -p ****** --sys-user root --sys-password ****** -c test4000 -t oracle002 -D obloader_user01 --csv --table '*' -f /home/admin/test_migrate_data/csv_data
  2022-12-27 10:10:36 [INFO] Parsed args:
  [--csv] true
  [--file-path] /home/admin/test_migrate_data/csv_data
  [--host] xxx.xxx.xxx.xxx
  [--port] 2883
  [--user] obloader_user01
  [--tenant] oracle002
  [--cluster] test4000
  [--password] ******
  [--database] obloader_user01
  [--sys-user] root
  [--sys-password] ******
  [--table] [*]

  2022-12-27 10:10:36 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
  2022-12-27 10:10:37 [INFO] The manifest file: "/home/admin/test_migrate_data/csv_data/data/MANIFEST.bin" has been saved
  2022-12-27 10:10:37 [INFO] Query column metadata for the table: "TEST_TBL1" finished
  2022-12-27 10:10:37 [INFO] Query column metadata for the table: "TEST_TBL2" finished
  2022-12-27 10:10:37 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/CHECKPOINT.bin" is unmatched on the suffix[.csv], ignore it
  2022-12-27 10:10:37 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/MANIFEST.bin" is unmatched on the suffix[.csv], ignore it
  2022-12-27 10:10:37 [INFO] Binding table: "TEST_TBL2" to the file: "/home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL2.1.0.csv" finished
  2022-12-27 10:10:37 [INFO] Binding table: "TEST_TBL1" to the file: "/home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1.1.0.csv" finished
  2022-12-27 10:10:37 [INFO] Splitted 2 csv subfiles by 64.0 MB. Elapsed: 19.13 ms
  2022-12-27 10:10:37 [INFO] Generate 2 subfiles finished
  2022-12-27 10:10:37 [INFO] Ignore to clean any tables as --truncate-table or --delete-from-table is not specified
  2022-12-27 10:10:37 [INFO] Query table entry and primary key for table: "TEST_TBL2" finished. Remain: 1
  2022-12-27 10:10:37 [INFO] Query table entry and primary key for table: "TEST_TBL1" finished. Remain: 0
  2022-12-27 10:10:37 [INFO] Query the leader location of "TEST_TBL1" finished. Remain: 0
  2022-12-27 10:10:37 [INFO] Query the leader location of "TEST_TBL2" finished. Remain: 0
  2022-12-27 10:10:37 [INFO] Calculate leader: xxx.xxx.xxx.xxx:2881 of table: "TEST_TBL2", part: 0. Remain: 0
  2022-12-27 10:10:37 [INFO] Calculate leader: xxx.xxx.xxx.xxx:2881 of table: "TEST_TBL1", part: 0. Remain: 1
  2022-12-27 10:10:37 [INFO] Waiting to refresh observer load status ......
  2022-12-27 10:10:38 [INFO] Refresh observer load status success. Table: "TEST_TBL2". Remain: 1
  2022-12-27 10:10:38 [INFO] Refresh observer load status success. Table: "TEST_TBL1". Remain: 0
  2022-12-27 10:10:38 [INFO] Refresh observer load status finished. Elapsed: 36.97 ms
  2022-12-27 10:10:38 [INFO] Use c.l.d.PhasedBackoffWaitStrategy as available cpu(s) is 64
  2022-12-27 10:10:38 [INFO] Create 4096 slots for ring buffer finished. [xxx.xxx.xxx.xxx:2881]
  2022-12-27 10:10:38 [INFO] Start 128 database writer threads finished. [xxx.xxx.xxx.xxx:2881]
  2022-12-27 10:10:38 [INFO] Start 128 csv file reader threads successed
  2022-12-27 10:10:38 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL2.1.0.csv" has been parsed finished
  2022-12-27 10:10:38 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/OBDUMPER_USER01/TABLE/TEST_TBL1.1.0.csv" has been parsed finished
  2022-12-27 10:10:39 [INFO] Wait for the all the workers to drain of published events then halt the workers
  2022-12-27 10:10:39 [INFO] Close connection count: 37 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_1905901800_obloader_user01
  2022-12-27 10:10:39 [INFO] Shutdown task context finished
  2022-12-27 10:10:39 [INFO] ----------   Finished Tasks: 2       Running Tasks: 0        Progress: 100.00%                                                            ----------
  2022-12-27 10:10:39 [INFO]

  All Load Tasks Finished:

  ----------------------------------------------------------------------------------------------------------------------------
          No.#        |        Type        |             Name             |            Count             |       Status
  ----------------------------------------------------------------------------------------------------------------------------
          1          |       TABLE        |          TEST_TBL2           |            5 -> 5            |      SUCCESS
          2          |       TABLE        |          TEST_TBL1           |            5 -> 5            |      SUCCESS
  ----------------------------------------------------------------------------------------------------------------------------

  Total Count: 10         End Time: 2022-12-27 10:10:39


  2022-12-27 10:10:39 [INFO] Load record finished. Total Elapsed: 2.583 s
  2022-12-27 10:10:39 [INFO] System exit 0
  ```
* 检查导入的表数据。

  ```
  obclient [OBLOADER_USER01]> SELECT * FROM test_tbl1;
  +------+-------------+------+
  | COL1 | COL2        | COL3 |
  +------+-------------+------+
  |    1 | China       |   86 |
  |    2 | Taiwan      |  886 |
  |    3 | Hong Kong   |  852 |
  |    4 | Macao       |  853 |
  |    5 | North Korea |  850 |
  +------+-------------+------+
  5 rows in set
  ```