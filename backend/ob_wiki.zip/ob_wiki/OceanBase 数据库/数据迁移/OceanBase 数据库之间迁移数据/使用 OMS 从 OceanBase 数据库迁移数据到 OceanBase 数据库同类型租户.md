---
title: 使用 OMS 从 OceanBase 数据库迁移数据到 OceanBase 数据库同类型租户
description: 提供关于使用 OMS 从 OceanBase 数据库迁移数据到 OceanBase 数据库同类型租户的相关内容，
keywords: 使用 OMS 从 OceanBase 数据库迁移数据到 OceanBase 数据库同类型租户,OceanBase 数据库,数据迁移,OceanBase 数据库之间迁移数据,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 OMS 从 OceanBase 数据库迁移数据到 OceanBase 数据库同类型租户

本文将简单介绍使用 OceanBase 迁移服务（OceanBase Migration Service，OMS）从 OceanBase 数据库迁移数据到 OceanBase 数据库同类型租户中的背景信息。

## 背景信息

您可以在 OMS 控制台创建从 OceanBase 数据库迁移数据至 OceanBase 数据库同类型租户的数据迁移项目，通过结构迁移、全量迁移和增量同步，无缝迁移源端数据库中的存量业务数据和增量数据至目标端数据库。

## 相关文档

更多使用 OMS 从 OceanBase 数据库迁移数据到 OceanBase 数据库同类型租户的操作信息，请参见 [OceanBase 数据库的单向数据迁移](https://www.oceanbase.com/docs/enterprise-oms-doc-cn-1000000000091365)。