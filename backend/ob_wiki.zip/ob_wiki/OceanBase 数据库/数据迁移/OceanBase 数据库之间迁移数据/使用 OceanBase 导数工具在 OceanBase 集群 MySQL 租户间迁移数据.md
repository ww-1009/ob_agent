---
title: 使用 OceanBase 导数工具在 OceanBase 集群 MySQL 租户间迁移数据
description: 提供关于使用 OceanBase 导数工具在 OceanBase 集群 MySQL 租户间迁移数据的相关内容，
keywords: 使用 OceanBase 导数工具在 OceanBase 集群 MySQL 租户间迁移数据,OceanBase 数据库,数据迁移,OceanBase 数据库之间迁移数据,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 OceanBase 导数工具在 OceanBase 集群 MySQL 租户间迁移数据

本文将介绍如何使用 OceanBase 导数工具从 OceanBase 集群 MySQL 租户迁移数据至 MySQL 租户。

## OceanBase 导数工具简介

OceanBase 导数工具包括导出工具 obdumper 和导入工具 obloader。

* obdumper 是一款使用 Java 开发的客户端导出工具。可以使用该工具将 OceanBase 数据库中定义的对象和数据导出到文件中。有关 obdumper 的详细信息请参见 [obdumper 简介](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142215)。
* obloader 是一款使用 Java 开发的客户端导入工具。该工具提供了非常灵活的命令行选项，可在多种复杂的场景下，将定义和数据导入到 OceanBase 中。有关 obloader 的详细信息请参见 [obloader 简介](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142221)。

## 操作步骤

1. 准备 obdumper 和 obloader 运行环境。详见 [准备环境](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142213) 和 [下载工具](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142214)。
2. 创建存放导出数据的目录。
3. 导出表结构/数据。

   ```
   [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
   $./obdumper -h <主机IP> -P <端⼝> -u <⽤⼾> -p <密码> [--sys-user <sys 租户下用户名> --sys-password <sys 租户下特定用户的密码>] -c <集群名称> -t <租⼾> -D <Schema 库名> [--ddl] [--csv|--sql] [--all|--table '表名'] -f <数据⽂件或者⽬录>
   ```

#### 说明

* 使用 OceanBase 物理节点的主机地址和端口导出数据时，无需指定 `-c` 选项。
* 有关 obdumper 命令行选项的详细信息，请参见 [命令行选项](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142216)。

4. 导入表结构/数据。

   ```
   [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
   $./obloader -h <主机IP> -P <端⼝> -u <⽤⼾> -p <密码>  --sys-user <sys 租户下的 root 用户或 proxyro 用户> --sys-password <sys 租⼾下的账⼾密码> -c <集群> -t <租⼾> -D <Schema 库名> [--ddl] [--csv|--sql] [--all|--table '表名'] -f <数据⽂件或者⽬录>
   ```

#### 说明

* 使用 OceanBase 物理节点的主机地址和端口导入数据时，无需指定 `-c` 选项。
* 有关 obloader 命令行选项的详细信息，请参见 [命令行选项](https://www.oceanbase.com/docs/enterprise-oceanbase-dumper-loader-cn-10000000001142221)。

## 示例

下表为示例中使用的数据库信息：

| 数据库信息 | 示例值 |
| --- | --- |
| 集群名称 | test4000 |
| OceanBase DataBase Proxy (ODP) 主机地址 | xxx.xxx.xxx.xxx |
| OceanBase DataBase Proxy (ODP) 端口号 | 2883 |
| sys 租户下 root 用户的密码 | \*\*\*\*\*\* |
| 源租户名称（MySQL 模式） | mysql001 |
| 租户 mysql001 的用户账号（要求读写权限） | obdumper\_user01 |
| 租户 mysql001 下用户 obdumper\_user01 的密码 | \*\*\*\*\*\* |
| 租户 mysql001 下 Schema 库名称 | test\_data |
| 目标租户名称（MySQL 模式） | mysql002 |
| 租户 mysql002 的用户账号（要求读写权限） | obloader\_user01 |
| 租户 mysql002 下用户 obloader\_user01 的密码 | \*\*\*\*\*\* |
| 租户 mysql002 下 Schema 库名称 | test\_data |

### 表结构迁移

使用 obdumper 和 obloader 进行表结构迁移时，需要指定 `--sys-user` 和 `--sys-password` 选项，获取表结构元数据信息。如果未指定该选项，导出/导入功能和性能可能会受到较大的影响。

#### 说明

`--sys-user` 选项用于连接 `sys` 租户下拥有特定权限的用户。导出时如果未指定 `--sys-user` 选项，默认指定的是 `--sys-user root`。

#### 导出 DDL 定义文件

场景描述：从集群 `test4000` 下的租户 `mysql001` 里的 Schema `test_data` 中，导出所有已支持的对象定义语句到 `/home/admin/test_migrate_data/ddl_data` 目录。

* 示例语句如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $./obdumper -h xxx.xxx.xxx.xxx -P 2883 -u obdumper_user01 -p ****** -c test4000 -t mysql001 -D test_data --sys-user root --sys-password ****** --ddl --all -f /home/admin/test_migrate_data/ddl_data
  2022-12-26 14:11:57 [INFO] Parsed args:
  [--ddl] true
  [--file-path] /home/admin/test_migrate_data/ddl_data
  [--host] xxx.xxx.xxx.xxx
  [--port] 2883
  [--user] obdumper_user01
  [--tenant] mysql001
  [--cluster] test4000
  [--password] ******
  [--database] test_data
  [--sys-user] root
  [--sys-password] ******
  [--all] true

  2022-12-26 14:11:57 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
  2022-12-26 14:11:57 [INFO] The manifest file: "/home/admin/test_migrate_data/ddl_data/data/MANIFEST.bin" has been saved
  2022-12-26 14:11:58 [INFO] Query column metadata for the table: "test_tbl1" finished
  2022-12-26 14:11:58 [INFO] Query column metadata for the table: "test_tbl2" finished
  2022-12-26 14:11:58 [WARN] No views are exist in the schema: "test_data"
  2022-12-26 14:11:58 [WARN] No functions are exist in the schema: "test_data"
  2022-12-26 14:11:58 [WARN] No procedures are exist in the schema: "test_data"
  2022-12-26 14:11:58 [WARN] No table groups are exist in the tenant: "mysql001"
  2022-12-26 14:11:58 [INFO] Generate 1 dump tasks finished. Total Elapsed: 3.926 ms
  2022-12-26 14:11:58 [INFO] Start 3 schema dump threads for 1 dump tasks finished.
  2022-12-26 14:11:58 [INFO] Build direct com.alibaba.druid.pool.DruidDataSource finished
  2022-12-26 14:11:58 [INFO] No need to acquire DataSource for xxx@sys, as observer is 4.0.0.0
  2022-12-26 14:11:58 [INFO] Return the latest compatible version: 4.0.0.0 -> 4.0.0.0
  2022-12-26 14:11:58 [INFO] Dump create objects success. DbType: OBMYSQL Version: 4.0.0.0
  2022-12-26 14:11:58 [INFO] ObMySql(4.0.0.0) is older than 4.0 ? false
  2022-12-26 14:11:58 [INFO] Load meta/obmysql/obmysql14x.xml, meta/obmysql/obmysql22x.xml, meta/obmysql/obmysql2271.xml, meta/obmysql/obmysql3230.xml, meta/obmysql/obmysql40x.xml successed
  2022-12-26 14:11:58 [INFO] Query 0 dependencies elapsed 31.35 ms
  2022-12-26 14:12:02 [INFO] ----------   Finished Tasks: 0       Running Tasks: 1        Progress: 0.00%                                                              ----------
  2022-12-26 14:12:03 [INFO] Query table: "test_tbl1" attr finished. Remain: 0
  2022-12-26 14:12:03 [INFO] Query table: "test_tbl2" attr finished. Remain: 0
  2022-12-26 14:12:03 [INFO] Query 2 tables elapsed 5.721 s
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireTablespaceMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireSequenceMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireSynonymMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireTypeMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireTypeBodyMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquirePackageMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquirePackageBodyMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireTriggerMapping()
  2022-12-26 14:12:03 [WARN] c.o.t.l.s.o.ObMySqlDatabase does't implement acquireDatabaseLinkMapping()
  2022-12-26 14:12:03 [INFO] Dump [TABLE] test_tbl1 to "/home/admin/test_migrate_data/ddl_data/data/test_data/TABLE/test_tbl1-schema.sql " finished
  2022-12-26 14:12:03 [INFO] Dump [TABLE] test_tbl2 to "/home/admin/test_migrate_data/ddl_data/data/test_data/TABLE/test_tbl2-schema.sql " finished
  2022-12-26 14:12:03 [INFO] No.1 It has dumped 2 TABLEs finished. Remain: 0
  2022-12-26 14:12:03 [INFO] Total dumped 2 TABLEs finished. Elapsed: 5.818 s
  2022-12-26 14:12:03 [INFO] Dump the ddl of schema: "test_data" finished
  2022-12-26 14:12:04 [INFO] Close connection count: 24 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_2105466567_test_data
  2022-12-26 14:12:04 [INFO] Shutdown task context finished
  2022-12-26 14:12:04 [INFO] ----------   Finished Tasks: 1       Running Tasks: 0        Progress: 100.00%                                                            ----------
  2022-12-26 14:12:04 [INFO]

  All Dump Tasks Finished:

  ----------------------------------------------------------------------------------------------------------------------------
        No.#        |        Type        |             Name             |            Count             |       Status
  ----------------------------------------------------------------------------------------------------------------------------
           1          |       TABLE        |          test_tbl1           |              1               |      SUCCESS
           2          |       TABLE        |          test_tbl2           |              1               |      SUCCESS
  ----------------------------------------------------------------------------------------------------------------------------

  Total Count: 2          End Time: 2022-12-26 14:12:04


  2022-12-26 14:12:04 [INFO] Dump schema finished. Total Elapsed: 6.076 s
  2022-12-26 14:12:04 [INFO] Unnecessary to upload the data files to the remote cloud storage service
  2022-12-26 14:12:04 [INFO] System exit 0
  ```
* 导出目录结构如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $tree /home/admin/test_migrate_data/ddl_data
  /home/admin/test_migrate_data/ddl_data
  ├── data
  │   ├── CHECKPOINT.bin
  │   ├── MANIFEST.bin
  │   └── test_data
  │       └── TABLE
  │           ├── test_tbl1-schema.sql
  │           └── test_tbl2-schema.sql
  └── logs
     ├── ob-loader-dumper.error
     ├── ob-loader-dumper.info
     └── ob-loader-dumper.warn

  4 directories, 7 files
  ```
* 查看导出结果文件。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $cat /home/admin/test_migrate_data/ddl_data/data/test_data/TABLE/test_tbl1-schema.sql
  create table if not exists `test_tbl1` (
        `col1` int(11) not null,
        `col2` varchar(20),
        `col3` int(11),
        primary key (`col1`)
  )
  default charset=utf8mb4
  default collate=utf8mb4_general_ci;
  ```

#### 导入 DDL 定义文件

场景描述：将从集群 `test4000` 下的租户 `mysql001` 里的 Schema `test_data` 导出到 `/home/admin/test_migrate_data/ddl_data` 目录下所有已支持的定义信息，导入到集群 `test4000` 下的租户 `mysql002` 里的 Schema `test_data` 中。

示例语句如下：

```
[xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
$./obloader -h xxx.xxx.xxx.xxx -P 2883 -u obloader_user01 -p ****** --sys-user root --sys-password ****** -c test4000 -t mysql002 -D test_data --ddl --all -f /home/admin/test_migrate_data/ddl_data
2022-12-26 14:31:47 [INFO] Parsed args:
[--ddl] true
[--file-path] /home/admin/test_migrate_data/ddl_data
[--host] xxx.xxx.xxx.xxx
[--port] 2883
[--user] obloader_user01
[--tenant] mysql002
[--cluster] test4000
[--password] ******
[--database] test_data
[--sys-user] root
[--sys-password] ******
[--all] true

2022-12-26 14:31:47 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
2022-12-26 14:31:48 [INFO] The manifest file: "/home/admin/test_migrate_data/ddl_data/data/MANIFEST.bin" has been saved
2022-12-26 14:31:48 [INFO] Init writer thread pool finished
2022-12-26 14:31:48 [WARN] The object type : "SEQUENCE" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "TABLE_GROUP" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [INFO] Start 128 schema file loader threads successed
2022-12-26 14:31:48 [INFO] No.1 sql of the file: "/home/admin/test_migrate_data/ddl_data/data/test_data/TABLE/test_tbl2-schema.sql" exec success. Elapsed: 127.1 ms
2022-12-26 14:31:48 [INFO] Load file: "test_tbl2-schema.sql" succeeded
2022-12-26 14:31:48 [INFO] No.1 sql of the file: "/home/admin/test_migrate_data/ddl_data/data/test_data/TABLE/test_tbl1-schema.sql" exec success. Elapsed: 177.2 ms
2022-12-26 14:31:48 [INFO] Load file: "test_tbl1-schema.sql" succeeded
2022-12-26 14:31:48 [WARN] The object type : "VIEW" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "FUNCTION" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "PROCEDURE" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "TRIGGER" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "PACKAGE" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "TYPE" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "PACKAGE_BODY" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "TYPE_BODY" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "SYNONYM" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "PUBLIC_SYNONYM" doesn't exist in the -schema.sql files
2022-12-26 14:31:48 [WARN] The object type : "FILE" doesn't exist in the -schema.sql files
2022-12-26 14:31:49 [INFO] Close connection count: 1 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_528891866_test_data
2022-12-26 14:31:49 [INFO] Shutdown task context finished
2022-12-26 14:31:49 [INFO] ----------   Finished Tasks: 2       Running Tasks: 0        Progress: 100.00%                                                            ----------
2022-12-26 14:31:49 [INFO]

All Load Tasks Finished:

----------------------------------------------------------------------------------------------------------------------------
        No.#        |        Type        |             Name             |            Count             |       Status
----------------------------------------------------------------------------------------------------------------------------
         1          |       TABLE        |          test_tbl1           |            1 -> 1            |      SUCCESS
         2          |       TABLE        |          test_tbl2           |            1 -> 1            |      SUCCESS
----------------------------------------------------------------------------------------------------------------------------

Total Count: 2          End Time: 2022-12-26 14:31:49


2022-12-26 14:31:49 [INFO] Load schema finished. Total Elapsed: 1.073 s
2022-12-26 14:31:49 [INFO] System exit 0
```

### 表数据迁移

以下将以导出 CSV 数据文件和导入 CSV 数据文件为例进行介绍使用 obdumper 和 obloader 进行表数据迁移。

#### 导出 CSV 数据文件

文件类型定义：CSV 数据文件（后缀名 `.csv`）是逗号分隔值文件格式，CSV 数据文件以纯文本形式存储表格数据，可通过文本编辑器等工具或者 Excel 打开。

场景描述：从集群 `test4000` 下的租户 `mysql001` 里的 Schema `test_data` 中，导出所有已支持对象的数据到 `/home/admin/test_migrate_data/csv_data` 目录，数据格式为 CSV 格式。

* 示例语句如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $./obdumper -h xxx.xxx.xxx.xxx -P 2883 -u obdumper_user01 -p ****** -c test4000 -t mysql001 -D test_data --sys-user root --sys-password ****** --csv --table '*' -f /home/admin/test_migrate_data/csv_data
  2022-12-26 14:51:18 [INFO] Parsed args:
  [--csv] true
  [--file-path] /home/admin/test_migrate_data/csv_data
  [--host] xxx.xxx.xxx.xxx
  [--port] 2883
  [--user] obdumper_user01
  [--tenant] mysql001
  [--cluster] test4000
  [--password] ******
  [--database] test_data
  [--sys-user] root
  [--sys-password] ******
  [--table] [*]

  2022-12-26 14:51:18 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
  2022-12-26 14:51:18 [INFO] The manifest file: "/home/admin/test_migrate_data/csv_data/data/MANIFEST.bin" has been saved
  2022-12-26 14:51:18 [INFO] Query column metadata for the table: "test_tbl1" finished
  2022-12-26 14:51:18 [INFO] Query column metadata for the table: "test_tbl2" finished
  2022-12-26 14:51:18 [INFO] Query partition names for table: "test_tbl1" success. (Non-partitioned)
  2022-12-26 14:51:18 [INFO] Query partition names for table: "test_tbl2" success. (Non-partitioned)
  2022-12-26 14:51:18 [INFO] Query primary key for table: "test_tbl1" success. Elapsed: 12.14 ms
  2022-12-26 14:51:18 [INFO] Query primary key for table: "test_tbl2" success. Elapsed: 12.24 ms
  2022-12-26 14:51:18 [INFO] Query table entry for table: "test_tbl1" success. Remain: 0. Elapsed: 2.868 ms
  2022-12-26 14:51:18 [INFO] Query table entry for table: "test_tbl2" success. Remain: 0. Elapsed: 2.868 ms
  2022-12-26 14:51:18 [INFO] Query all table entries success. Total: 2. Elapsed: 61.20 ms
  2022-12-26 14:51:18 [INFO] ....Splitting rows for non-partitioned table: "test_tbl1" success. Batch: 1
  2022-12-26 14:51:18 [INFO] ....Splitting rows for non-partitioned table: "test_tbl2" success. Batch: 1
  2022-12-26 14:51:18 [INFO] Split rows for non-partitioned table(with primary key): "test_tbl2" success. Ranges: 1. Elapsed: 38.42 ms
  2022-12-26 14:51:18 [INFO] Split rows for non-partitioned table(with primary key): "test_tbl1" success. Ranges: 1. Elapsed: 38.57 ms
  2022-12-26 14:51:18 [INFO] Generate 2 dump tasks finished. Total Elapsed: 53.46 ms
  2022-12-26 14:51:18 [INFO] Start 128 record dump threads for 2 dump tasks finished
  2022-12-26 14:51:18 [INFO] Dump 5 rows test_data.test_tbl2 to "/home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl2.1.*.csv" finished
  2022-12-26 14:51:18 [INFO] Dump 5 rows test_data.test_tbl1 to "/home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl1.1.*.csv" finished
  2022-12-26 14:51:19 [INFO] Close connection count: 12 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_2105466567_test_data
  2022-12-26 14:51:20 [INFO] Shutdown task context finished
  2022-12-26 14:51:20 [INFO] ----------   Finished Tasks: 2       Running Tasks: 0        Progress: 100.00%                                                            ----------
  2022-12-26 14:51:20 [INFO]

  All Dump Tasks Finished:

  ----------------------------------------------------------------------------------------------------------------------------
        No.#        |        Type        |             Name             |            Count             |       Status
  ----------------------------------------------------------------------------------------------------------------------------
           1          |       TABLE        |          test_tbl1           |              5               |      SUCCESS
           2          |       TABLE        |          test_tbl2           |              5               |      SUCCESS
  ----------------------------------------------------------------------------------------------------------------------------

  Total Count: 10         End Time: 2022-12-26 14:51:20


  2022-12-26 14:51:20 [INFO] Unnecessary to merge the data files. As --file-name is missing
  2022-12-26 14:51:20 [INFO] Dump record finished. Total Elapsed: 1.206 s
  2022-12-26 14:51:20 [INFO] Unnecessary to upload the data files to the remote cloud storage service
  2022-12-26 14:51:20 [INFO] System exit 0
  ```
* 导出目录结构如下。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $tree /home/admin/test_migrate_data/csv_data
  /home/admin/test_migrate_data/csv_data
  ├── data
  │   ├── CHECKPOINT.bin
  │   ├── MANIFEST.bin
  │   └── test_data
  │       └── TABLE
  │           ├── test_tbl1.1.0.csv
  │           └── test_tbl2.1.0.csv
  └── logs
     ├── ob-loader-dumper.error
     ├── ob-loader-dumper.info
     └── ob-loader-dumper.warn

  4 directories, 7 files
  ```
* 查看导出结果文件。

  ```
  [xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
  $cat /home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl1.1.0.csv
  'col1','col2','col3'
  1,'China',86
  2,'Taiwan',886
  3,'Hong Kong',852
  4,'Macao',853
  5,'North Korea',850
  ```

#### 导入 CSV 数据文件

场景描述：将从集群 `test4000` 下的租户 `mysql001` 里的 Schema `test_data` 导出到 `/home/admin/test_migrate_data/csv_data` 目录下所有已支持的 CSV 数据文件，导入到集群 `test4000` 下的租户 `mysql002` 里的 Schema `test_data` 中。

示例语句如下：

```
[xxx@xxx /ob-loader-dumper-4.0.0-RELEASE/bin]
$./obloader -h xxx.xxx.xxx.xxx -P 2883 -u obloader_user01 -p ****** --sys-user root --sys-password ****** -c test4000 -t mysql002 -D test_data --csv --table '*' -f /home/admin/test_migrate_data/csv_data
2022-12-26 14:52:55 [INFO] Parsed args:
[--csv] true
[--file-path] /home/admin/test_migrate_data/csv_data
[--host] xxx.xxx.xxx.xxx
[--port] 2883
[--user] obloader_user01
[--tenant] mysql002
[--cluster] test4000
[--password] ******
[--database] test_data
[--sys-user] root
[--sys-password] ******
[--table] [*]

2022-12-26 14:52:55 [INFO] Load jdbc driver class: "com.oceanbase.jdbc.Driver" finished
2022-12-26 14:52:55 [INFO] The manifest file: "/home/admin/test_migrate_data/csv_data/data/MANIFEST.bin" has been saved
2022-12-26 14:52:55 [INFO] Query column metadata for the table: "test_tbl1" finished
2022-12-26 14:52:55 [INFO] Query column metadata for the table: "test_tbl2" finished
2022-12-26 14:52:55 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/CHECKPOINT.bin" is unmatched on the suffix[.csv], ignore it
2022-12-26 14:52:55 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/MANIFEST.bin" is unmatched on the suffix[.csv], ignore it
2022-12-26 14:52:55 [INFO] Binding table: "test_tbl2" to the file: "/home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl2.1.0.csv" finished
2022-12-26 14:52:55 [INFO] Binding table: "test_tbl1" to the file: "/home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl1.1.0.csv" finished
2022-12-26 14:52:55 [INFO] Splitted 2 csv subfiles by 64.0 MB. Elapsed: 19.43 ms
2022-12-26 14:52:55 [INFO] Generate 2 subfiles finished
2022-12-26 14:52:55 [INFO] Ignore to clean any tables as --truncate-table or --delete-from-table is not specified
2022-12-26 14:52:55 [INFO] Query table entry and primary key for table: "test_tbl2" finished. Remain: 1
2022-12-26 14:52:55 [INFO] Query table entry and primary key for table: "test_tbl1" finished. Remain: 0
2022-12-26 14:52:55 [INFO] Query the leader location of "test_tbl2" finished. Remain: 0
2022-12-26 14:52:55 [INFO] Query the leader location of "test_tbl1" finished. Remain: 0
2022-12-26 14:52:55 [INFO] Calculate leader: xxx.xxx.xxx.xxx:2881 of table: "test_tbl1", part: 0. Remain: 1
2022-12-26 14:52:55 [INFO] Calculate leader: xxx.xxx.xxx.xxx:2881 of table: "test_tbl2", part: 0. Remain: 0
2022-12-26 14:52:55 [INFO] Waiting to refresh observer load status ......
2022-12-26 14:52:55 [INFO] Refresh observer load status success. Table: "test_tbl1". Remain: 1
2022-12-26 14:52:55 [INFO] Refresh observer load status success. Table: "test_tbl2". Remain: 0
2022-12-26 14:52:55 [INFO] Refresh observer load status finished. Elapsed: 29.35 ms
2022-12-26 14:52:55 [INFO] Use c.l.d.PhasedBackoffWaitStrategy as available cpu(s) is 64
2022-12-26 14:52:55 [INFO] Create 4096 slots for ring buffer finished. [xxx.xxx.xxx.xxx:2881]
2022-12-26 14:52:56 [INFO] Start 128 database writer threads finished. [xxx.xxx.xxx.xxx:2881]
2022-12-26 14:52:56 [INFO] Start 128 csv file reader threads successed
2022-12-26 14:52:56 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl1.1.0.csv" has been parsed finished
2022-12-26 14:52:56 [INFO] File: "/home/admin/test_migrate_data/csv_data/data/test_data/TABLE/test_tbl2.1.0.csv" has been parsed finished
2022-12-26 14:52:57 [INFO] Wait for the all the workers to drain of published events then halt the workers
2022-12-26 14:52:57 [INFO] Close connection count: 36 of the DataSource. Key: xxx.xxx.xxx.xxx_11532_528891866_test_data
2022-12-26 14:52:57 [INFO] Shutdown task context finished
2022-12-26 14:52:57 [INFO] ----------   Finished Tasks: 2       Running Tasks: 0        Progress: 100.00%                                                            ----------
2022-12-26 14:52:57 [INFO]

All Load Tasks Finished:

----------------------------------------------------------------------------------------------------------------------------
        No.#        |        Type        |             Name             |            Count             |       Status
----------------------------------------------------------------------------------------------------------------------------
         1          |       TABLE        |          test_tbl1           |            5 -> 5            |      SUCCESS
         2          |       TABLE        |          test_tbl2           |            5 -> 5            |      SUCCESS
----------------------------------------------------------------------------------------------------------------------------

Total Count: 10         End Time: 2022-12-26 14:52:57


2022-12-26 14:52:57 [INFO] Load record finished. Total Elapsed: 1.973 s
2022-12-26 14:52:57 [INFO] System exit 0
```