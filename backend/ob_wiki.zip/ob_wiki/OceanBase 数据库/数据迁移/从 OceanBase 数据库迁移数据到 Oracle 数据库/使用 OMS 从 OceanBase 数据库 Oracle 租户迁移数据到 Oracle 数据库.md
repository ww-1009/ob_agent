---
title: 使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库
description: 提供关于使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库的相关内容，
keywords: 使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库,OceanBase 数据库,数据迁移,从 OceanBase 数据库迁移数据到 Oracle 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:56:58.000+00:00
---

# 使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库

本文将简单介绍使用 OceanBase 迁移服务（OceanBase Migration Service，OMS）从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库中的背景信息。

## 背景信息

在 OMS 控制台创建从 OceanBase 数据库 Oracle 租户迁移数据至 Oracle 数据库的数据迁移项目，您可以通过结构迁移、全量迁移和增量同步，无缝迁移源端数据库中的存量业务数据和增量数据至 Oracle 数据库。

Oracle 数据库支持单主库、单备库和主备库等模式。迁移 OceanBase 数据库 Oracle 租户的数据至 Oracle 数据库时，不同类型的数据源支持的操作也不同。

| 类型 | 支持的操作 |
| --- | --- |
| 单主库 | 结构迁移 + 全量迁移 + 增量同步+ 全量校验 + 反向增量 |
| 单备库 | 不支持将单备库的 Oracle 数据源作为数据迁移的目标端 |
| 主备库 | 主库：支持结构迁移 + 全量迁移 + 增量同步   备库：支持全量校验 + 反向增量 |

同时，OMS 支持将多个 OceanBase 数据库 Oracle 租户的表数据汇聚至 Oracle 数据库的同一张表中，其中无需结构迁移，只需要进行全量迁移和增量同步。该汇聚同步功能的使用限制如下：

* 对于全量迁移和增量同步，源端有的列，目标端必须有。如果不满足该要求，OMS 会报错。
* 主键列在源端表中必须存在。
* 目标表中的列，可以存在源端不存在的列。

## 相关文档

更多使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库的操作信息，请参见 [迁移 OceanBase 数据库 Oracle 租户的数据至 Oracle 数据库](https://www.oceanbase.com/docs/enterprise-oms-doc-cn-1000000000091379)。