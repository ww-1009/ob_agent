---
title: 使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户
description: 提供关于使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户的相关内容，
keywords: 使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户,OceanBase 数据库,数据迁移,从 DB2 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户

本文将简单介绍使用 OceanBase 迁移服务（OceanBase Migration Service，OMS）从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户中的背景信息。

## 背景信息

在 OMS 控制台创建从 DB2 LUW 数据库迁移数据至 OceanBase 数据库 MySQL 租户的数据迁移项目，您可以通过结构迁移、全量迁移和增量同步，迁移源端 DB2 LUW 数据库中的数据至 OceanBase 数据库 MySQL 租户。

## 相关文档

更多使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户的操作信息，请参见 [迁移 DB2 LUW 数据库的数据至 OceanBase 数据库 MySQL 租户](https://www.oceanbase.com/docs/enterprise-oms-doc-cn-1000000000091375)。