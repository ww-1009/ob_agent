# 叶子索引：从 Oracle 数据库迁移数据到 OceanBase 数据库

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [数据迁移](../../index.md) / [从 Oracle 数据库迁移数据到 OceanBase 数据库](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [使用 DataX 迁移 Oracle 表数据到 OceanBase 数据库.md](./使用 DataX 迁移 Oracle 表数据到 OceanBase 数据库.md) | 提供关于使用 DataX 迁移 Oracle 表数据到 OceanBase 数据库的相关内容， | 使用 DataX 迁移 Oracle 表数据到 OceanBase 数据库,OceanBase 数据库,数据迁移,从 Oracle 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 MySQL 租户.md](./使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 MySQL 租户.md) | 提供关于使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 MySQL 租户的相关内容， | 使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 MySQL 租户,OceanBase 数据库,数据迁移,从 Oracle 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 Oracle 租户.md](./使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 Oracle 租户.md) | 提供关于使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 Oracle 租户的相关内容， | 使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 Oracle 租户,OceanBase 数据库,数据迁移,从 Oracle 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用 DBCAT 迁移 Oracle 表结构到 OceanBase 数据库.md](./使用 DBCAT 迁移 Oracle 表结构到 OceanBase 数据库.md) | 提供关于使用 DBCAT 迁移 Oracle 表结构到 OceanBase 数据库的相关内容， | 使用 DBCAT 迁移 Oracle 表结构到 OceanBase 数据库,OceanBase 数据库,数据迁移,从 Oracle 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
