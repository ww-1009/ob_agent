# 叶子索引：旁路导入

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [数据迁移](../../index.md) / [旁路导入](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [使用 INSERT INTO SELECT 语句旁路导入数据.md](./使用 INSERT INTO SELECT 语句旁路导入数据.md) | 提供关于使用 INSERT INTO SELECT 语句旁路导入数据的相关内容， | 使用 INSERT INTO SELECT 语句旁路导入数据,OceanBase 数据库,数据迁移,旁路导入,文档,使用帮助,OceanBase,分布式,数据库 |
| [旁路导入概述.md](./旁路导入概述.md) | 提供关于旁路导入概述的相关内容， | 旁路导入概述,OceanBase 数据库,数据迁移,旁路导入,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用 LOAD DATA 语句旁路导入数据.md](./使用 LOAD DATA 语句旁路导入数据.md) | 提供关于使用 LOAD DATA 语句旁路导入数据的相关内容， | 使用 LOAD DATA 语句旁路导入数据,OceanBase 数据库,数据迁移,旁路导入,文档,使用帮助,OceanBase,分布式,数据库 |
