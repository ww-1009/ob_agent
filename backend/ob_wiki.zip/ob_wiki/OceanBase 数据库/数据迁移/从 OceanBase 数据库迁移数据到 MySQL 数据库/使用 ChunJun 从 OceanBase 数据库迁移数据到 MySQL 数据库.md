---
title: 使用 ChunJun 从 OceanBase 数据库迁移数据到 MySQL 数据库
description: 提供关于使用 ChunJun 从 OceanBase 数据库迁移数据到 MySQL 数据库的相关内容，
keywords: 使用 ChunJun 从 OceanBase 数据库迁移数据到 MySQL 数据库,OceanBase 数据库,数据迁移,从 OceanBase 数据库迁移数据到 MySQL 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 ChunJun 从 OceanBase 数据库迁移数据到 MySQL 数据库

纯钧（ChunJun，原名 FlinkX）是一款稳定、易用、高效、批流一体的数据集成框架，目前基于实时计算引擎 Flink 实现多种异构数据源之间的数据同步与计算。OceanBase Binlog 服务（OceanBase Binlog Service，简称 Binlog 服务）能收集 OceanBase 数据库的事务日志，并将其转换为 MySQL Binlog，主要用于实时数据订阅等场景。

chunjun-connector-oceanbasecdc 在内部集成了 oblogclient 来连接 Binlog 服务，获取相关的日志数据，可以进行 OceanBase 数据库的增量数据迁移。

以下将介绍使用 ChunJun 的 Local 模式从 OceanBase 数据库（MySQL 模式）迁移数据到 MySQL 数据库。

## 场景描述

将 OceanBase 数据库表 `test_tbl1` 的数据迁移至 MySQL 数据库表 `tbl1` 中，数据库信息如下：

| OceanBase 数据库信息（源库） | 示例值 |
| --- | --- |
| 集群名 | test4000 |
| 主机地址 | 10.10.10.2 |
| 端口号 | 2881 |
| Binlog 服务 IP | 10.10.10.3 |
| Binlog 服务端口 | 2983 |
| 业务租户名称（MySQL 模式） | mysql001 |
| 用户名称 | root |
| 用户的密码 | \*\*\*\*\*\* |
| Schema 库名称 | test\_data |
| 表名 | test\_tbl1 |

| MySQL 数据库信息（目标库） | 示例值 |
| --- | --- |
| 主机地址 | 10.10.10.1 |
| 端口号 | 3306 |
| 用户名称 | root |
| 用户的密码 | \*\*\*\*\*\* |
| Schema 库名称 | test\_ob\_to\_mysql |
| 表名 | tbl1 |

## 前提条件

* 安装 JDK 1.8，并配置好 `JAVA_HOME` 环境变量。
* 完成 Binlog 服务 的安装部署。参考 [创建 Binlog 集群](https://www.oceanbase.com/docs/common-ocp-1000000001739745) 完成 OceanBase Binlog 服务的安装部署。

## 操作步骤

### 步骤一：ChunJun 环境准备

1. 下载 ChunJun 压缩包并解压。

   下载 [chunjun-dist.tar.gz](https://github.com/DTStack/chunjun/releases/download/v1.12.6/chunjun-dist.tar.gz)。

   ```
   wget https://github.com/DTStack/chunjun/releases/download/v1.12.6/chunjun-dist.tar.gz
   ```

   将压缩包解压至目录 `/chunjun_Home/chunjun`。

   ```
   mkdir /ChunJun_Home/chunjun && tar zxvf chunjun-dist.tar.gz -C /ChunJun_Home/chunjun
   ```
2. 配置 ChunJun 环境变量。

   ```
   export ChunJun_HOME=/ChunJun_Home/chunjun-dist
   ```

### 步骤二：配置 json 文件

根据环境信息配置将 OceanBase 数据库表 `test_tbl1` 的数据迁移至 MySQL 数据库表 `tbl1` 的 json 文件。

示例如下：

```
[root@xxx /]
$cd /ChunJun_Home/chunjun-dist/chunjun-examples/json

[root@xxx /ChunJun_Home/chunjun-dist/chunjun-examples/json]
$mkdir test_data

[root@xxx /ChunJun_Home/chunjun-dist/chunjun-examples/json]
$cd mkdir test_data

[root@xxx /ChunJun_Home/chunjun-dist/chunjun-examples/json/test_data]
$vi test_ob_to_mysql.json

{
  "job": {
    "setting": {
      "errorLimit": {
        "record": 0,
        "percentage": 0.02},
      "speed": {"bytes": 0,
      "channel": 1}
    },
    "content": [
      {
        "reader": {
          "name": "oceanbasecdcreader",
          "table": {
            "tableName": "test_tbl1"},
          "parameter": {
            "logProxyHost": "10.10.10.3",
            "logProxyPort": 2983,
            "obReaderConfig": {
              "rsList": "10.10.10.2:2882:2881",
              "username": "root",
              "password": "******"
            },
            "cat": "insert,delete,update",
            "column": [
              "*"
            ]
          }
        },
        "writer": {
          "name": "mysqlwriter",
          "parameter": {
            "column": [
              "*"
            ],
            "connection": [
              {
                "jdbcUrl": "jdbc:mysql://10.10.10.1:3306/test_ob_to_mysql",
                "table": [
                  "tbl1"
                ]
              }
            ],
            "username": "root",
            "password": "******"
          }
        }
      }
    ]
  }
}
```

### 步骤三：运行 json 配置文件

启动一个 JVM 进程执行 ChunJun 任务。

进入到 `/ChunJun_Home/chunjun-dist` 目录，执行命令以下命令：

```
[root@xxx /]
$cd /ChunJun_Home/chunjun-dist

[admin@xxx /ChunJun_Home/chunjun-dist]
$sh bin/chunjun-local.sh -job chunjun-examples/json/test_data/test_ob_to_mysql.json

          #                               #
          #                               #
          #
  #####   ######   #     #  # ####     ####   #     #  # ####
 #        #     #  #     #  ##    #       #   #     #  ##    #
 #        #     #  #     #  #     #       #   #     #  #     #
 #        #     #  #    ##  #     #       #   #    ##  #     #
  #####   #     #   #### #  #     #       #    #### #  #     #
                                          #
                                      ####

Reference site: https://dtstack.github.io/chunjun

chunjun is starting ...
CHUNJUN_HOME is auto set /ChunJun_Home/chunjun-dist/
FLINK_HOME is empty!
HADOOP_HOME is empty!
...
<ellipsis>
...
*********************************************
numWrite                  |  3
last_write_num_0          |  0
conversionErrors          |  0
writeDuration             |  20149
duplicateErrors           |  0
numRead                   |  3
snapshotWrite             |  0
otherErrors               |  0
readDuration              |  95
byteRead                  |  389
last_write_location_0     |  0
byteWrite                 |  389
nullErrors                |  0
nErrors                   |  0
*********************************************

2023-01-06 20:34:47,448 - 50317 INFO  [main] com.dtstack.chunjun.Main:program Flink_Job execution success
```

### 步骤四：对 OceanBase 数据库数据增量修改

登录到 OceanBase 数据库（MySQL 模式），并在表 `test_tbl1` 中插入一条数据。

```
[admin@xxx /home/admin]
$obclient -h10.10.10.2 -P2881 -uroot@mysql001 -p****** -Dtest_data
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Welcome to the OceanBase.  Commands end with ; or \g.
Your OceanBase connection id is 3221709678
Server version: OceanBase 4.0.0.0 (r101000022022120716-0d7927892ad6d830e28437af099f018b0ad9a322) (Built Dec  7 2022 16:22:15)

Copyright (c) 2000, 2018, OceanBase and/or its affiliates. All rights reserved.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

obclient [test_data]> INSERT INTO test_tbl1 VALUES(4,'Macao',853);
Query OK, 1 row affected
```

### 步骤五：查看数据迁移情况

登录到 MySQL 数据库查看数据迁移情况。

```
[admin@xxx /home/admin]
$mysql -h10.10.10.1 -P3306 -uroot -p******
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MySQL connection id is 189769
Server version: 5.7.26-log MySQL Community Server (GPL)

<ellipsis>

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MySQL [(none)]> use test_ob_to_mysql;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
MySQL [test_ob_to_mysql]> SELECT * FROM tbl1;
+------+-----------+------+
| col1 | col2      | col3 |
+------+-----------+------+
|    1 | China     |   86 |
|    2 | Taiwan    |  886 |
|    3 | Hong Kong |  852 |
|    4 | Macao     |  853 |
+------+-----------+------+
4 rows in set
```

## 相关文档

* ChunJun 快速入门的详细信息，请参见 [快速开始](https://dtstack.github.io/chunjun/documents/zh/%E5%BF%AB%E9%80%9F%E5%BC%80%E5%A7%8B?lang=zh)。
* MySQL 数据库作为目标库配置 json 文件的详细信息，请参见 [MySQL Sink](https://dtstack.github.io/chunjun/documents/zh/ChunJun%E8%BF%9E%E6%8E%A5%E5%99%A8@mysql@mysql-sink?lang=zh)。
* 更多脚本示例，请参见项目内 `/chunjun-dist/chunjun-examples` 文件夹下的文件。