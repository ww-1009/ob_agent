---
title: 使用 Canal 从 OceanBase 数据库同步数据到 MySQL 数据库
description: 提供关于使用 Canal 从 OceanBase 数据库同步数据到 MySQL 数据库的相关内容，
keywords: 使用 Canal 从 OceanBase 数据库同步数据到 MySQL 数据库,OceanBase 数据库,数据迁移,从 OceanBase 数据库迁移数据到 MySQL 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 Canal 从 OceanBase 数据库同步数据到 MySQL 数据库

本文档主要介绍使用 Canal 和 OceanBase Binlog 服务从 OceanBase 数据库同步数据至 MySQL 数据库。

## OceanBase CDC 实现逻辑

OceanBase Binlog 服务是 OceanBase 数据库的增量日志代理服务。基于 libobcdc（原名：liboblog），以服务的形式提供实时增量链路接入和管理能力，方便应用接入 OceanBase 增量日志。能够解决在网络隔离的情况下，订阅增量日志的需求，并提供多种链路接入方式。

Canal 通过解析 MySQL 的 Binlog 日志，将数据库的增量数据抽取出来，并将其发送到订阅者进行消费和处理。这使得用户可以方便地实现数据的实时同步、实时分析等需求。

数据链路：

```
ob_cluster -> obbinlog -> canal_client -> mysql
```

组件介绍：

* OceanBase 数据库：需要生成 Binlog 日志的业务数据库。
* OceanBase 数据库代理：业务数据库的 ODP（也称 OBProxy），由它为订阅 Binlog 的客户端提供连接服务。
* OceanBase Binlog 工具：OceanBase Binlog 服务的核心组件 obbinlog（原 oblogproxy），由它完成拉取 clog 和生成 Binlog 日志的操作

## 操作步骤

### 步骤一：安装 OceanBase Binlog 服务

请参考 [创建 Binlog 集群](https://www.oceanbase.com/docs/common-ocp-1000000001739745) 完成 OceanBase Binlog 服务的安装部署。

### 步骤二：安装 canal server

1. 下载软件包。

   下载 [canal-for-ob.deployer.tar.gz](https://github.com/oceanbase/canal/releases/download/canal-for-ob-1.1.6-alpha/canal-for-ob.deployer.tar.gz)。

   ```
   wget https://github.com/oceanbase/canal/releases/download/canal-for-ob-1.1.6-alpha/canal-for-ob.deployer.tar.gz
   ```
2. 将压缩包解压至目录 `/Canal_Home/canal-for-ob`。

   ```
   mkdir /Canal_Home/canal-for-ob && tar zxvf canal-for-ob.deployer.tar.gz  -C /Canal_Home/canal-for-ob
   ```
3. 修改配置文件 `canal.properties`。

   修改 /Canal\_Home/canal-for-ob/conf/canal.properties。

   ```
   canal.serverMode = tcp
   canal.destinations = example
   canal.instance.global.spring.xml = classpath:spring/ob-default-instance.xml
   ```
4. 配置 canal instance。

   将 /Canal\_Home/canal-for-ob/conf/example 下的 instance.properties 删除，然后将 ob-instance.properties 重命名为 instance.properties。

   修改 `instance.properties`，示例如下：

   ```
   cd /Canal_Home/canal-for-ob/conf/example
   vi instance.properties

   # OceanBase集群参数
   canal.instance.oceanbase.rsList=10.10.10.1:2882:2881;10.10.10.2:2882:2881;10.10.10.3:2882:2881
   canal.instance.oceanbase.username=root@mysql001#test4000
   canal.instance.oceanbase.password=******
   canal.instance.oceanbase.startTimestamp=0

   # oceanbase logproxy参数
   canal.instance.oceanbase.logproxy.address=10.10.10.1:2983
   canal.instance.oceanbase.logproxy.sslEnabled=false
   canal.instance.oceanbase.logproxy.serverCert=../conf/${canal.instance.destination:}/ca.crt
   canal.instance.oceanbase.logproxy.clientCert=../conf/${canal.instance.destination:}/client.crt
   canal.instance.oceanbase.logproxy.clientKey=../conf/${canal.instance.destination:}/client.key

   # 是否要在库名中去掉租户前缀。logproxy 输出的日志中库名默认为 [tenant].[db]
   canal.instance.oceanbase.tenant=mysql001
   canal.instance.parser.excludeTenantInDbName=true

   # 日志过滤。格式为 [tenant].[database].[table]，支持正则
   canal.instance.filter.regex=mysql001.*.*
   ```
5. 启动 Canal Server。

   ```
   cd /Canal_Home/canal-for-ob && sh bin/startup.sh
   ```

### 步骤三：配置 RDB 适配器

1. 下载软件包。

   下载 [canal-for-ob.adapter.tar.gz](https://github.com/oceanbase/canal/releases/download/canal-for-ob-1.1.6-alpha/canal-for-ob.adapter.tar.gz)。

   ```
   wget https://github.com/oceanbase/canal/releases/download/canal-for-ob-1.1.6-alpha/canal-for-ob.adapter.tar.gz
   ```
2. 将压缩包解压至目录 `/Canal_Home/canal-adapter-for-ob`。

   ```
   mkdir /Canal_Home/canal-adapter-for-ob && tar zxvf canal-for-ob.adapter.tar.gz -C /Canal_Home/canal-adapter-for-ob
   ```
3. 修改 `application.yml`。

   ```
   cd /Canal_Home/canal-adapter-for-ob/conf
   vi application.yml

   canalAdapters:
   - instance: example # canal instance Name or mq topic name
     groups:
     - groupId: g1
       outerAdapters:
       - name: logger
       - name: rdb
         key: mysql1
         properties:
           jdbc.driverClassName: com.mysql.jdbc.Driver
           jdbc.url: jdbc:mysql://10.10.10.1:3306/test_data?useUnicode=false
           jdbc.username: root
           jdbc.password: ******
   ```
4. 修改适配器库/表映射（以库映射为例）。

   ```
   cd /Canal_Home/canal-adapter-for-ob/conf/rdb
   vi application.yml

   ## Mirror schema synchronize config
   dataSourceKey: defaultDS
   destination: example
   groupId: g1
   outerAdapterKey: mysql1
   concurrent: true
   dbMapping:
   mirrorDb: true
   database: test_data
   ```
5. 启动 canal client。

   ```
   cd /Canal_Home/canal-adapter-for-ob && sh bin/startup.sh
   ```
6. 查看数据同步情况。

   在 OceanBase 源端写入数据，在 MySQL 目标端查看数据同步。

## 功能限制

* 同步的表必须有主键。否则，源端删除无主键表的任意一笔记录，同步到目标端会导致整个表被删除。
* DDL 支持新建表、新增列。