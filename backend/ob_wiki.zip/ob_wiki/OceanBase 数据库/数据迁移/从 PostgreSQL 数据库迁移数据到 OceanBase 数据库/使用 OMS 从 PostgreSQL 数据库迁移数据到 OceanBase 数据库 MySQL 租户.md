---
title: 使用 OMS 从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户
description: 提供关于使用 OMS 从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户的相关内容，
keywords: 使用 OMS 从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户,OceanBase 数据库,数据迁移,从 PostgreSQL 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 OMS 从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户

本文将简单介绍使用 OceanBase 迁移服务（OceanBase Migration Service，OMS）从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户中的背景信息。

## 背景信息

在 OMS 控制台创建从 PostgreSQL 数据库迁移数据至 OceanBase 数据库 MySQL 租户的数据迁移项目，您可以通过结构迁移、全量迁移和增量同步，无缝迁移源端数据库中的存量业务数据和增量数据至 OceanBase 数据库 MySQL 租户。

PostgreSQL 数据库支持单主库、单备库和主备库等模式。迁移 PostgreSQL 数据库的数据至 OceanBase 数据库 MySQL 租户时，不同类型的数据源支持的操作也不同。

| 类型 | 支持的操作 |
| --- | --- |
| 单主库 | 结构迁移 + 全量迁移 + 增量同步+ 全量校验 + 反向增量 |
| 单备库 | 结构迁移 + 全量迁移 + 全量校验 |
| 主备库 | 主库：支持增量同步 + 反向增量  备库：支持结构迁移 + 全量迁移 + 全量校验 |

## 相关文档

更多使用 OMS 从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户的操作信息，请参见 [迁移 PostgreSQL 数据库的数据至 OceanBase 数据库 MySQL 租户](https://www.oceanbase.com/docs/enterprise-oms-doc-cn-1000000000091367)。