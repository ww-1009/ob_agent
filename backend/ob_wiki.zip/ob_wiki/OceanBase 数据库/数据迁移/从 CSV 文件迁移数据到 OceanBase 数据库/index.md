# 叶子索引：从 CSV 文件迁移数据到 OceanBase 数据库

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [数据迁移](../../index.md) / [从 CSV 文件迁移数据到 OceanBase 数据库](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [使用 LOAD DATA 语句导入数据.md](./使用 LOAD DATA 语句导入数据.md) | 提供关于使用 LOAD DATA 语句导入数据的相关内容， | 使用 LOAD DATA 语句导入数据,OceanBase 数据库,数据迁移,从 CSV 文件迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用 DataX 迁移 CSV 文件到 OceanBase 数据库.md](./使用 DataX 迁移 CSV 文件到 OceanBase 数据库.md) | 提供关于使用 DataX 迁移 CSV 文件到 OceanBase 数据库的相关内容， | 使用 DataX 迁移 CSV 文件到 OceanBase 数据库,OceanBase 数据库,数据迁移,从 CSV 文件迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库 |
