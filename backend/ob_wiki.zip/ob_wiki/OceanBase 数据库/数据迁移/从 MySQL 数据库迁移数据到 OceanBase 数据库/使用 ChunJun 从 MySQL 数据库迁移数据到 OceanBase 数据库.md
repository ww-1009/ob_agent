---
title: 使用 ChunJun 从 MySQL 数据库迁移数据到 OceanBase 数据库
description: 提供关于使用 ChunJun 从 MySQL 数据库迁移数据到 OceanBase 数据库的相关内容，
keywords: 使用 ChunJun 从 MySQL 数据库迁移数据到 OceanBase 数据库,OceanBase 数据库,数据迁移,从 MySQL 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 ChunJun 从 MySQL 数据库迁移数据到 OceanBase 数据库

纯钧（ChunJun，原名 FlinkX）是一款稳定、易用、高效、批流一体的数据集成框架，基于实时计算引擎 Flink，支持 JSON 模版配置任务，兼容 Flink SQL 语法、支持分布式运行，支持 flink-standalone、yarn-session、yarn-per job 等多种提交方式和支持全量同步、增量同步等特点。

以下将介绍使用 ChunJun 的 Local 模式从 MySQL 数据库迁移数据到 OceanBase 数据库（MySQL 模式）。

## 场景描述

将 MySQL 数据库表 `tbl1` 的数据迁移至 OceanBase 数据库表 `test_tbl1` 中，数据库信息如下：

| MySQL 数据库信息（源库） | 示例值 |
| --- | --- |
| 主机地址 | xxx.xxx.xxx.xxx |
| 端口号 | 3306 |
| 用户名称 | root |
| 用户的密码 | \*\*\*\*\*\* |
| Schema 库名称 | test\_mysql\_to\_ob |
| 表名 | tbl1 |

| OceanBase 数据库信息（目标库） | 示例值 |
| --- | --- |
| 集群名 | test4000 |
| 主机地址 | 10.10.10.2 |
| 端口号 | 2881 |
| 业务租户名称（MySQL 模式） | mysql001 |
| 用户名称 | root |
| 用户的密码 | \*\*\*\*\*\* |
| Schema 库名称 | test\_data |
| 表名 | test\_tbl1 |

## 前提条件

安装 JDK 1.8，并配置好 `JAVA_HOME` 环境变量。

## 操作步骤

### 步骤一：ChunJun 环境准备

1. 下载 ChunJun 压缩包并解压。

   下载 [chunjun-dist.tar.gz](https://github.com/DTStack/chunjun/releases/download/v1.12.6/chunjun-dist.tar.gz)。

   ```
   wget https://github.com/DTStack/chunjun/releases/download/v1.12.6/chunjun-dist.tar.gz
   ```

   将压缩包解压至目录 `/chunjun_Home/chunjun`。

   ```
   mkdir /ChunJun_Home/chunjun && tar zxvf chunjun-dist.tar.gz -C /ChunJun_Home/chunjun
   ```
2. 配置 ChunJun 环境变量。

   ```
   export ChunJun_HOME=/ChunJun_Home/chunjun-dist
   ```

### 步骤二：配置 json 文件

根据环境信息配置将 MySQL 数据库表 `tbl1` 的数据迁移至 OceanBase 数据库表 `test_tbl1` 的 json 文件。

示例如下：

```
[root@xxx /]
$cd /ChunJun_Home/chunjun-dist/chunjun-examples/json

[root@xxx /ChunJun_Home/chunjun-dist/chunjun-examples/json]
$mkdir test_data

[root@xxx /ChunJun_Home/chunjun-dist/chunjun-examples/json]
$cd mkdir test_data

[root@xxx /ChunJun_Home/chunjun-dist/chunjun-examples/json/test_data]
$vi test_mysql_to_ob.json

{
  "job": {
    "setting": {
      "errorLimit": {
        "record": 0,
        "percentage": 0.02},
      "speed": {"bytes": 0,
      "channel": 1}
    },
    "content": [
      {
        "reader": {
          "name": "mysqlreader",
          "parameter": {
            "username": "root",
            "password": "******",
            "column": [
              "*"
            ],
            "connection": [
              {
                "jdbcUrl": [
                  "jdbc:mysql://xxx.xxx.xxx.xxx:3306/test_mysql_to_ob"
                ],
                "table": [
                  "tbl1"
                ]
              }
            ]
          }
        },
        "writer": {
          "name": "mysqlwriter",
          "parameter": {
            "column": [
              "*"
            ],
            "connection": [
              {
                "jdbcUrl": "jdbc:mysql://10.10.10.2:2881/test_data",
                "table": [
                  "test_tbl1"
                ]
              }
            ],
            "username": "root@mysql001",
            "password": "******"
          }
        }
      }
    ]
  }
}
```

### 步骤三：运行 json 配置文件

启动一个 JVM 进程执行 ChunJun 任务。

进入到 `/ChunJun_Home/chunjun-dist` 目录，执行命令以下命令：

```
[root@xxx /]
$cd /ChunJun_Home/chunjun-dist

[admin@xxx /ChunJun_Home/chunjun-dist]
$sh bin/chunjun-local.sh -job chunjun-examples/json/test_data/test_mysql_to_ob.json

          #                               #
          #                               #
          #
  #####   ######   #     #  # ####     ####   #     #  # ####
 #        #     #  #     #  ##    #       #   #     #  ##    #
 #        #     #  #     #  #     #       #   #     #  #     #
 #        #     #  #    ##  #     #       #   #    ##  #     #
  #####   #     #   #### #  #     #       #    #### #  #     #
                                          #
                                      ####

Reference site: https://dtstack.github.io/chunjun

chunjun is starting ...
CHUNJUN_HOME is auto set /ChunJun_Home/chunjun-dist
FLINK_HOME is empty!
HADOOP_HOME is empty!
...
<ellipsis>
...
*********************************************
numWrite                  |  3
last_write_num_0          |  0
conversionErrors          |  0
writeDuration             |  20130
duplicateErrors           |  0
numRead                   |  3
snapshotWrite             |  0
otherErrors               |  0
readDuration              |  78
byteRead                  |  389
last_write_location_0     |  0
byteWrite                 |  389
nullErrors                |  0
nErrors                   |  0
*********************************************

2023-01-06 19:18:57,306 - 50207 INFO  [main] com.dtstack.chunjun.Main:program Flink_Job execution success
```

### 步骤四：查看数据迁移情况

登录到 OceanBase 数据库查看数据是否迁移成功。

```
[admin@xxx /home/admin]
$obclient -h10.10.10.2 -P2881 -uroot@mysql001 -p -A
Enter password:
Welcome to the OceanBase.  Commands end with ; or \g.
Your OceanBase connection id is 3221630190
Server version: OceanBase 4.0.0.0 (r101000022022120716-0d7927892ad6d830e28437af099f018b0ad9a322) (Built Dec  7 2022 16:22:15)

Copyright (c) 2000, 2018, OceanBase and/or its affiliates. All rights reserved.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

obclient [(none)]> use test_data;
Database changed
obclient [test_data]> SELECT * FROM test_tbl1;
+------+-----------+------+
| COL1 | COL2      | COL3 |
+------+-----------+------+
|    1 | China     |   86 |
|    2 | Taiwan    |  886 |
|    3 | Hong Kong |  852 |
+------+-----------+------+
3 rows in set
```

## 相关文档

* 更多 ChunJun 特点的信息介绍，请参见 [Features of ChunJun](https://github.com/DTStack/chunjun#features-of-chunjun)。
* ChunJun 快速入门的详细信息，请参见 [快速开始](https://dtstack.github.io/chunjun/documents/zh/%E5%BF%AB%E9%80%9F%E5%BC%80%E5%A7%8B?lang=zh)。
* MySQL 数据库作为源库配置 json 文件的详细信息，请参见 [MySQL Source](https://dtstack.github.io/chunjun/documents/zh/ChunJun%E8%BF%9E%E6%8E%A5%E5%99%A8@mysql@mysql-source?lang=zh)。
* 更多脚本示例，请参见项目内 `/chunjun-dist/chunjun-examples` 文件夹下的文件。