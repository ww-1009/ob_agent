---
title: 使用 mydumper 和 myloader 从 MySQL 数据库迁移数据到 OceanBase 数据库
description: 提供关于使用 mydumper 和 myloader 从 MySQL 数据库迁移数据到 OceanBase 数据库的相关内容，
keywords: 使用 mydumper 和 myloader 从 MySQL 数据库迁移数据到 OceanBase 数据库,OceanBase 数据库,数据迁移,从 MySQL 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 mydumper 和 myloader 从 MySQL 数据库迁移数据到 OceanBase 数据库

本文将介绍如何使用 mydumper 和 myloader 从 MySQL 数据库迁移数据至 OceanBase 数据库（MySQL 模式）。

## mydumper 和 myloader 简介

* **mydumper：** 是一款开源的多线程备份工具，用于备份 MySQL 数据库。mydumper 支持备份整个数据库、单个表或多个表，支持多线程备份，可以加速数据备份过程。mydumper 还支持备份数据的压缩和加密，可以从备份文件中恢复数据。mydumper 是一款命令行工具，需要安装并使用命令行进行操作。
* **myloader：** 是一款用于恢复 mydumper 备份文件的工具。myloader 可以快速恢复备份的 MySQL 数据库，并支持从备份文件中恢复数据，不需要先创建数据库。myloader 还支持恢复到指定时间点的备份文件，可以指定要恢复的数据表和数据行。myloader 是一款命令行工具，需要安装并使用命令行进行操作。

mydumper 和 myloader 都是开源的工具，具有高效、安全、可靠的特点，并且支持多种备份方式和备份数据的压缩和加密。

#### 注意

使用 MyDumper 仅支持导出 OceanBase 数据库 MySQL 模式租户中的数据。

## 操作步骤

1. 环境准备。
2. 备份操作。

   备份 MySQL 数据库数据示例语句如下：

   ```
   mydumper -h xx.xx.xx.xx -P3306 -u username -p ****** -B test_db -o /data/backup/mysql/
   ```

   mydumper 命令常用参数说明：

   | 参数 | 参数全称 | 说明 |
   | --- | --- | --- |
   | -h | --host | 连接的主机名或 IP 地址 |
   | -P | --port | 连接的端口 |
   | -u | --user | 备份使用的用户名 |
   | -p | --password | 备份使用的用户密码 |
   | -B | --database | 备份的数据库名，默认备份所有库 |
   | -T | --tables-list | 备份的表名，多张表名字用逗号隔开 |
   | -i | --ignore-engines | 备份忽略的存储引擎，用逗号分割 |
   | -m | --no-schemas | 不备份表结构 |
   | -t | --threads | 开启的并行备份线程数，默认是 4 |
   | -c | --compress | 对输出文件进行压缩 |
   | -o | --outputdir | 备份文件输出目录 |
3. 恢复操作。

   备份数据后，您可通过 `source` 命令或 `myloader` 命令恢复数据。

   * 使用 source 命令恢复数据。

     若无法直接还原单表，可以找到对应的单表 sql 文件，进入命令行，使用 `source` 命令恢复数据。

     ```
     source <表名>-schema.sql #还原表结构

     source <表名>.sql #还原表数据
     ```
   * 下述示例语句展示了如何使用 myloader 恢复 OceanBase 数据库中的数据：

     ```
     myloader -h xx.xx.xx.xx -P2883 -u 'user@tenantname#clustenamer' -p ****** -o -d /data/backup/mysql/
     ```

     myloader 命令常用参数说明：

     | 参数 | 参数全称 | 说明 |
     | --- | --- | --- |
     | -h | --host | 连接的主机名 |
     | -P | --port | 连接的端口 |
     | -u | --user | 恢复使用的用户名 |
     | -p | --password | 恢复使用的用户密码 |
     | -B | --database | 恢复的数据库名 |
     | -d | --directory | 恢复文件的目录 |
     | -o | --overwrite-tables | 如果要恢复的表存在，则先 drop 掉该表；使用该参数，需要备份时候要备份表结构 |
     | -B | --database | 需要还原的数据库 |

### 步骤一：环境准备

1. 下载安装包。

   请根据需要在 [下载安装包地址](https://github.com/mydumper/mydumper/tags) 中，下载对应的安装包并安装。
2. 在数据库主机上解压缩安装包。

   以 `mydumper-0.12.7-2-zstd.el7.x86_64.rpm` 为示例。

   ```
   rpm2cpio mydumper-0.12.7-2-zstd.el7.x86_64.rpm | cpio -div
   ```
3. 验证是否正确安装。

   ```
   ./usr/bin/mydumper --help
   ```

   在备份目的文件夹中, 会生成 `metadata` 文件和对应的表结构或表数据文件。

### 步骤二：备份操作

#### 备份全库

```
mydumper -h xx.xx.xx.xx -P3306 -u username -p ****** -o /data/backup/mysql/
```

#### 备份指定数据库 test

```
mydumper -h xx.xx.xx.xx -P3306 -u username -p ******  -B test -o /data/backup/mysql/
```

#### 备份指定数据库指定表(t1,t2)

```
mydumper -h xx.xx.xx.xx -P3306 -u username -p ****** -B test -T t1,t2 -o /data/backup/mysql/
```

#### 仅备份表数据

```
mydumper -h xx.xx.xx.xx -P3306 -u username -p ****** -B test -T t1 -m -o /data/backup/mysql/
```

#### 备份 t1 表的数据，开并行和数据压缩

```
mydumper -h xx.xx.xx.xx -P3306 -u username -p ****** -B test -T t1 -t 6 -c -o /data/backup/mysql/
```

### 步骤三：恢复操作

#### 禁用外键检查约束

在备份的表结构语句里，可能包含外键。在导入 OceanBase MySQL 里时，如果外键依赖的表没有创建，导入脚本会报错，因此在导入之前需要禁用外键检查约束。

```
MySQL [oceanbase]> SET GLOBAL foreign_key_checks=off;
Query OK, 0 rows affected

MySQL [oceanbase]> SHOW GLOBAL VARIABLES LIKE '%foreign%';
+--------------------+-------+
| Variable_name      | Value |
+--------------------+-------+
| foreign_key_checks | OFF   |
+--------------------+-------+
1 row in set
```

备份数据后，您可通过 `source` 命令或 `myloader` 命令恢复数据。

#### 使用 source 命令恢复数据

若无法直接还原单表，可以找到对应的单表 sql 文件，进入命令行，使用 `source` 命令恢复数据。

```
source test.t1-schema.sql 还原表结构

source test.t1.00000.sql 还原表数据
```

#### 使用 myloader 命令恢复数据

* 导入表结构和数据。

  ```
  myloader -h xx.xx.xx.xx -P2883 -u 'user@tenantname#clustenamer' -p ******  -B test -o -d /data/backup/mysql/
  ```
* 导入数据库（若目标库不存在则会新建）。

  ```
  myloader -h xx.xx.xx.xx -P2883 -u 'user@tenantname#clustenamer' -p ******  -B test -s test1 -o -d /data/backup/mysql/
  ```

更多关于 mydumper 和 myloader 的使用方法，请参见 <https://github.com/mydumper/mydumper>。