---
title: 使用 DBCAT 迁移 MySQL 表结构到 OceanBase 数据库
description: 提供关于使用 DBCAT 迁移 MySQL 表结构到 OceanBase 数据库的相关内容，
keywords: 使用 DBCAT 迁移 MySQL 表结构到 OceanBase 数据库,OceanBase 数据库,数据迁移,从 MySQL 数据库迁移数据到 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 使用 DBCAT 迁移 MySQL 表结构到 OceanBase 数据库

DBCAT 是一款轻量级的命令行工具，可用于提供数据库之间 DDL 转换和 `Schema` 比对等功能。这里以 DBCAT 迁移表结构为示例进行介绍。

DBCAT 安装包文件名为 `dbcat-[版本号]-SNAPSHOT.tar.gz`，下载后解压缩即可使用，可执行文件名为 `dbcat`。

#### 注意

DBCAT 是 OMS 的一个组件，在社区版环境中推荐使用 OMS 导出。

## 环境准备

DBCAT 能运行在 CentOS、macOS 和 Windows 下。需要安装 `JDK 1.8` 以上（含）版本。可以使用 `OpenJDK`，安装好后配置环境变量 `JAVA_HOME`。

CentOS 安装 `OpenJDK` 示例：

```
$sudo yum -y install java-1.8.0-openjdk.x86_64

$which java
/usr/local/java/jdk1.8.0_261/bin/java

echo 'export JAVA_HOME=/usr/local/java/jdk1.8.0_261/' >> ~/.bash_profile
. ~/.bash_profile
```

解压安装文件：

```
tar zxvf dbcat-1.8.0-SNAPSHOT.tar.gz
cd dbcat-1.8.0-SNAPSHOT/
chmod +x bin/dbcat

$tree -L 3 --filelimit 30
.
├── bin
│   ├── dbcat
│   ├── dbcat.bat
│   └── dbcat-debug
├── conf
│   ├── dbcat.properties
│   └── logback.xml
├── docs
│   ├── README.docx
│   ├── README.md
│   └── README.txt
├── LEGAL.md
├── lib [45 entries exceeds filelimit, not opening dir]
├── LICENSE
├── meta
│   └── README
└── NOTICE

5 directories, 12 files
```

安装文件中有以下几个目录需要了解：

| 目录名 | 说明 |
| --- | --- |
| bin | 可执行文件目录。 |
| conf | 日志文件配置目录。 |
| lib | 运行时期依赖的包。 |
| meta | 离线转换场景下，导出字典表数据。 |
| ~/output | SQL 文件与报告文件，运行时生成。 |

## 导出 MySQL 数据库的表结构

DBCAT 具有在线转换功能，该功能是指 DBCAT 能直连源端数据库，将数据库中的对象导出。当对象非常多时（如超过 1 万），导出过程可能会有点慢。

dbcat 导出命令如下：

```
bin/dbcat convert -H<host> -P<port> -u<user> -p<password>  -D <database> --from <from> --to <to> --all
```

您可运行命令 `bin/dbcat help convert` 查看更多参数信息。

必选参数：

| 选项 | 有无参数 | 中文描述 |
| --- | --- | --- |
| -H/--host | Y | 数据库服务器的 IP 地址 |
| -P/--port | Y | 数据库服务器的端口 |
| -u/--user | Y | 登录数据库的用户名 |
| -t/--tenant | Y | 连接 OceanBase 集群需要提供租户名 |
| -c/--cluster | Y | 连接 OceanBase 集群需要提供集群名 |
| -p/--password | Y | 登录数据库的密码 |
| -D/--database | Y | 数据库名（源库），DB2 须区分数据库名和模式名 |
| --service-id | Y | 连接 Oracle 数据库需要提供服务 ID |
| --service-name | Y | 连接 Oracle 数据库需要提供服务名 |
| --as-sysdba | N | 连接 Oracle 数据库 sysdba 角色 |
| --sys-user | Y | 连接 OceanBase 集群系统租户的用户名 |
| --sys-password | Y | 连接 OceanBase 集群系统租户的密码 |
| --schema | Y | 模式名（源库），非 DB2，模式名与数据名相同 |
| --from | Y | 源库的类型 |
| --to | Y | 目标库的类型 |
| --all | N | 所有的数据库对象 |

可选参数：

| 选项 | 有无参数 | 中文描述 |
| --- | --- | --- |
| -f/--file | Y | sql 文件的输出路径 |
| --offline | N | 使用离线模式 |
| --target-schema | Y | 模式名（目标库） |
| --table | Y | 导出的表 |
| --view | Y | 导出的视图 |
| --trigger | Y | 导出的触发器 |
| --synonym | Y | 导出的同义词 |
| --sequence | Y | 导出的序列 |
| --function | Y | 导出的函数 |
| --procedure | Y | 导出的存储过程 |
| --dblink | Y | 导出所有的 DBLink |
| --type | Y | 导出的 type |
| --type-body | Y | 导出的 type body |
| --package | Y | 导出的 package |
| --package-body | Y | 导出的 package body |
| --no-quote | N | 产生的 DDL 不带引号 |
| --no-schema | N | 产生的 DDL 不带模式名 |
| --target-schema | Y | 产生的 DDL 中使用指定的模式名 |
| --exclude-type | Y | 搭配 --all 使用，如：--all --exclude-type 'TABLE' 表示排除 TABLE 类型 |

这里以导出 MySQL 5.7 版本下 database 为 test 的所有对象的结构，并将其迁移到 4.0.0 版本的 OceanBase 集群中的 MySQL 租户为示例。

```
bin/dbcat convert -H 11.161.xxx.xxx -P 3306 -uroot -pxxxxxx -D test --from mysql57 --to obmysql40 --all
```

特别说明：

* dbcat 不需要直接安装在数据库主机上，安装在可直连数据库主机的主机上即可。
* 参数中的 --from 和 --to 为源端和目的端的数据库类型，需要详细到版本号。当前 dbcat 支持的源端和目标端数据库详细如下：

  | 源端数据库类型 | 目标端数据库类型 |
  | --- | --- |
  | TiDB | OBMYSQL |
  | PG | OBMYSQL |
  | SYBASE | OBORACLE |
  | MYSQL | OBMYSQL |
  | ORACLE | OBORACLE |
  | ORACLE | OBMYSQL |
  | DB2 IBM i | OBORACLE |
  | DB2 LUW | OBORACLE |
  | DB2 LUW | OBMYSQL |
  | OBMYSQL | MYSQL |
  | OBORACLE | ORACLE |

  其中 OBMYSQL 为 OceanBase 数据库的 MySQL租户，OBORACLE 为 OceanBase 数据库的 Oracle 租户。
* 当前支持的源端和目标端数据库详细的版本，详情如下。

  | 数据库类型 | 数据库版本 |
  | --- | --- |
  | TiDB | tidb4   tidb5 |
  | PG | pgsql10 |
  | SYBASE | sybase15 |
  | DB2 IBM i | db2ibmi71 |
  | DB2 LUW | db2luw970 db2luw1010 db2luw1050 db2luw111 db2luw115 |
  | MYSQL | mysql56 mysql57 mysql</80> |
  | ORACLE | oracle9i oracle10g oracle11g oracle12c oracle18c oracle19c |
  | OBMYSQL | obmysql14x obmysql21x obmysql22x obmysql200 obmysql211 obmysql2210 obmysql2230 obmysql2250 obmysql2271 ~ obmysql2277 obmysql30x obmysql31x obmysql32x obmysql322 obmysql40 |
  | OBORACLE | oboracle2220 oboracle2230 oboracle2250 oboracle2270 ~ oboracle2277 oboracle21x oboracle22x oboracle30x oboracle31x oboracle32x oboracle322 oboracle40 |

运行后的输出文件在用户 `home` 目录的 `output` 下。

```
$tree ~/output/dbcat-20xx-xx-xx-164533/
/home/qing.meiq/output/dbcat-20xx-xx-xx-164533/
├── tpccdb
│   └── TABLE-schema.sql
└── tpccdb-conversion.html

1 directory, 2 files
```

## 导入 OceanBase 数据库

使用 DBCAT 导出的文件格式为 SQL 文件，这里可以通过 ODC 的导入功能批量将表结构导入 OceanBase 数据库，更多信息请参考 [批量导出与导入](https://www.oceanbase.com/docs/enterprise-odc-doc-cn-10000000001033324)。

也可以使用 `source` 命令将 SQL 文件数据导入 OceanBase 数据库，示例如下：

```
obclient [test]> source TABLE-schema.sql
Query OK, 0 rows affected (0.044 sec)
```

#### 注意

如果 SQL 文件不在当前目录下，则需要使用绝对地址。

## 导数结果验证

示例：查看一个表结构在 MySQL 里的书写方式 和 OceanBase 数据库里的表结构。

查看源数据库 MySQL 的表 bmsql\_customer 的建表 SQL：

```
MySQL [test]> show create table bmsql_customer \G
*************************** 1. row ***************************
       Table: bmsql_customer
Create Table: CREATE TABLE `bmsql_customer` (
  `c_w_id` bigint(20) NOT NULL,
  `c_d_id` bigint(20) NOT NULL,
  `c_id` bigint(20) NOT NULL,
  `c_discount` decimal(4,4) DEFAULT NULL,
  `c_credit` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_last` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_first` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_credit_lim` decimal(12,2) DEFAULT NULL,
  `c_balance` decimal(12,2) DEFAULT NULL,
  `c_ytd_payment` decimal(12,2) DEFAULT NULL,
  `c_payment_cnt` bigint(20) DEFAULT NULL,
  `c_delivery_cnt` bigint(20) DEFAULT NULL,
  `c_street_1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_street_2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_city` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_state` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_zip` char(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_phone` char(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_since` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `c_middle` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_data` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`c_w_id`,`c_d_id`,`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
1 row in set (0.01 sec)
```

查看目标库数据库 OceanBase 的表 bmsql\_customer 的表结构：

```
obclient [test]> desc bmsql_customer;
+----------------+---------------+------+-----+-------------------+-----------------------------+
| Field          | Type          | Null | Key | Default           | Extra                       |
+----------------+---------------+------+-----+-------------------+-----------------------------+
| c_w_id         | bigint(20)    | NO   | PRI | NULL              |                             |
| c_d_id         | bigint(20)    | NO   | PRI | NULL              |                             |
| c_id           | bigint(20)    | NO   | PRI | NULL              |                             |
| c_discount     | decimal(4,4)  | YES  |     | NULL              |                             |
| c_credit       | char(2)       | YES  |     | NULL              |                             |
| c_last         | varchar(16)   | YES  |     | NULL              |                             |
| c_first        | varchar(16)   | YES  |     | NULL              |                             |
| c_credit_lim   | decimal(12,2) | YES  |     | NULL              |                             |
| c_balance      | decimal(12,2) | YES  |     | NULL              |                             |
| c_ytd_payment  | decimal(12,2) | YES  |     | NULL              |                             |
| c_payment_cnt  | bigint(20)    | YES  |     | NULL              |                             |
| c_delivery_cnt | bigint(20)    | YES  |     | NULL              |                             |
| c_street_1     | varchar(20)   | YES  |     | NULL              |                             |
| c_street_2     | varchar(20)   | YES  |     | NULL              |                             |
| c_city         | varchar(20)   | YES  |     | NULL              |                             |
| c_state        | char(2)       | YES  |     | NULL              |                             |
| c_zip          | char(9)       | YES  |     | NULL              |                             |
| c_phone        | char(16)      | YES  |     | NULL              |                             |
| c_since        | timestamp     | NO   |     | CURRENT_TIMESTAMP | ON UPDATE CURRENT_TIMESTAMP |
| c_middle       | char(2)       | YES  |     | NULL              |                             |
| c_data         | varchar(500)  | YES  |     | NULL              |                             |
+----------------+---------------+------+-----+-------------------+-----------------------------+
21 rows in set (0.004 sec)
```

经对比是一致的。