# 分类索引：数据迁移

> 位置：[ob_wiki](../../index.md) / [OceanBase 数据库](../index.md) / 数据迁移 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **OceanBase 数据库之间迁移数据** | 涵盖 使用 OceanBase 导数工具在 OceanBase 集群 MySQL 租户间迁移数据、使用 OceanBase 导数工具从 OceanBase 集群 Oracle 租户迁移数据到 MySQL 租户、使用 OceanBase 导数工具从 OceanBase 集群 MySQL 租户迁移数据到 Oracle 租户、使用 OMS 创建 OceanBase 数据库同类型租户容灾双活项目 等 6 项。 | `OceanBase 数据库之间迁移数据` | [进入目录](./OceanBase 数据库之间迁移数据/index.md) |
| **从 CSV 文件迁移数据到 OceanBase 数据库** | 涵盖 使用 LOAD DATA 语句导入数据、使用 DataX 迁移 CSV 文件到 OceanBase 数据库。 | `从 CSV 文件迁移数据到 OceanBase 数据库` `使用 LOAD DATA 语句导入数据` | [进入目录](./从 CSV 文件迁移数据到 OceanBase 数据库/index.md) |
| **从 DB2 数据库迁移数据到 OceanBase 数据库** | 涵盖 使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 MySQL 租户、使用 DBCAT 迁移 DB2 LUW 表结构到 OceanBase 数据库、使用 OMS 从 DB2 LUW 数据库迁移数据到 OceanBase 数据库 Oracle 租户。 | `从 DB2 数据库迁移数据到 OceanBase 数据库` | [进入目录](./从 DB2 数据库迁移数据到 OceanBase 数据库/index.md) |
| **从 MySQL 数据库迁移数据到 OceanBase 数据库** | 涵盖 使用 Canal 从 MySQL 数据库同步数据到 OceanBase 数据库、使用 ChunJun 从 MySQL 数据库迁移数据到 OceanBase 数据库、使用 OMS 从 MySQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户、使用 Flink CDC 从 MySQL 数据库同步数据到 OceanBase 数据库 等 8 项。 | `从 MySQL 数据库迁移数据到 OceanBase 数据库` | [进入目录](./从 MySQL 数据库迁移数据到 OceanBase 数据库/index.md) |
| **从 OceanBase 数据库迁移数据到 DB2 数据库** | 涵盖 使用 OMS 从 OceanBase 数据库 MySQL 租户迁移数据到 DB2 LUW 数据库、使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 DB2 LUW 数据库。 | `从 OceanBase 数据库迁移数据到 DB2 数据库` | [进入目录](./从 OceanBase 数据库迁移数据到 DB2 数据库/index.md) |
| **从 OceanBase 数据库迁移数据到 MySQL 数据库** | 涵盖 使用 Canal 从 OceanBase 数据库同步数据到 MySQL 数据库、使用 OMS 从 OceanBase 数据库 Oracle 租户迁移增量数据到 MySQL 数据库、使用 Flink CDC 从 OceanBase 数据库迁移数据到 MySQL 数据库、使用 CloudCanal 从 OceanBase 数据库迁移数据到 MySQL 数据库 等 8 项。 | `从 OceanBase 数据库迁移数据到 MySQL 数据库` | [进入目录](./从 OceanBase 数据库迁移数据到 MySQL 数据库/index.md) |
| **从 OceanBase 数据库迁移数据到 Oracle 数据库** | 涵盖 使用 OMS 从 OceanBase 数据库 Oracle 租户迁移数据到 Oracle 数据库、使用 Datax 迁移 OceanBase 表数据到 Oracle 数据库、使用 DBCAT 迁移 OceanBase 表结构到 Oracle 数据库。 | `从 OceanBase 数据库迁移数据到 Oracle 数据库` | [进入目录](./从 OceanBase 数据库迁移数据到 Oracle 数据库/index.md) |
| **从 Oracle 数据库迁移数据到 OceanBase 数据库** | 涵盖 使用 DataX 迁移 Oracle 表数据到 OceanBase 数据库、使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 MySQL 租户、使用 OMS 从 Oracle 数据库迁移数据到 OceanBase 数据库 Oracle 租户、使用 DBCAT 迁移 Oracle 表结构到 OceanBase 数据库。 | `从 Oracle 数据库迁移数据到 OceanBase 数据库` | [进入目录](./从 Oracle 数据库迁移数据到 OceanBase 数据库/index.md) |
| **从 PostgreSQL 数据库迁移数据到 OceanBase 数据库** | 涵盖 使用 OMS 从 PostgreSQL 数据库迁移数据到 OceanBase 数据库 MySQL 租户。 | `从 PostgreSQL 数据库迁移数据到 OceanBase 数据库` | [进入目录](./从 PostgreSQL 数据库迁移数据到 OceanBase 数据库/index.md) |
| **从 TiDB 数据库迁移数据到 OceanBase 数据库** | 涵盖 使用 OMS 从 TiDB 数据库迁移数据到 OceanBase 数据库 MySQL 租户。 | `从 TiDB 数据库迁移数据到 OceanBase 数据库` | [进入目录](./从 TiDB 数据库迁移数据到 OceanBase 数据库/index.md) |
| **旁路导入** | 先概述 旁路导入，再分项介绍 使用 INSERT INTO SELECT 语句旁路导入数据、使用 LOAD DATA 语句旁路导入数据。 | `旁路导入` `使用 LOAD DATA 语句旁路导入数据` | [进入目录](./旁路导入/index.md) |
| **使用 SQL 语句迁移数据** | 涵盖 表与表之间的数据迁移、使用 OUTFILE 语句导出数据、资源单元迁移。 | `使用 SQL 语句迁移数据` `表与表之间的数据迁移` `使用 OUTFILE 语句导出数据` `资源单元迁移` | [进入目录](./使用 SQL 语句迁移数据/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [从 SQL 文件导入数据到 OceanBase 数据库.md](./从 SQL 文件导入数据到 OceanBase 数据库.md) | 提供关于从 SQL 文件导入数据到 OceanBase 数据库的相关内容， | 从 SQL 文件导入数据到 OceanBase 数据库,OceanBase 数据库,数据迁移,文档,使用帮助,OceanBase,分布式,数据库 |
| [数据迁移概述.md](./数据迁移概述.md) | 提供关于数据迁移概述的相关内容， | 数据迁移概述,OceanBase 数据库,数据迁移,文档,使用帮助,OceanBase,分布式,数据库 |
