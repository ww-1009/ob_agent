---
title: 部署 NFS
description: 提供关于部署 NFS的相关内容，
keywords: 部署 NFS,OceanBase 数据库,管理数据库,备份恢复,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-10T03:28:39.000+00:00
---

# 部署 NFS

在选择备份介质时，建议使用 OSS 作为备份的目的端，OSS 有更高的稳定性。

如果需要使用 NFS 作为备份目的端，可参考本节内容部署 NFS。NFS 分软件和硬件两种，由于软件 NFS 不稳定，容易出现 NFS Hang 的情况，导致备份任务卡住或挂载 NFS 的机器无法正常工作，建议使用专用的 NFS 硬件设备。

## 注意事项

* 使用 NFS 环境时，需要保证先挂载 NFS，再开启备份。如果备份期间 NFS 出现问题，需要先停止数据备份和日志归档，再解决 NFS 的问题。
* OceanBase 数据库支持 NFS 3 及以上版本。
* 建议使用 SSD 的 NFS 服务，避免出现 NFS 性能不足导致的 NFS 不稳定问题。
* 在使用 NFS 作为备份介质时，必须保证所有 OBServer 节点都挂载了同一个服务器的 NFS。同时，为保证备份的顺利进行，务必使用本文档中建议的参数挂载 NFS。挂载 NFS 具体操作请参见本节 **部署 NFS 客户端**。
* 在重启 OBServer 节点时，需要先启动 NFS，再启动 OBServer 节点。
* 添加新的机器后，在启动 OBServer 节点前，需要保证新的机器挂载 NFS 成功或者可以备份到其他介质。

## 部署 NFS 软件的服务器端

#### 注意

如果您使用的是 NFS 硬件设备，则可跳过本操作，直接部署 NFS 客户端。

1. 登录 NFS 服务器。
2. 执行以下命令，通过 YUM 包管理器安装 NFS。

   ```
   sudo yum install nfs-utils
   ```
3. 设置 Exports。

   1. 选择一个合适的目录作为共享目录，在选择时需要考虑备份所需的空间和性能。

      例如，本文档中选择的共享目录为 `/data/nfs_server/`。
   2. 使用 `sudo vim /etc/exports` 命令打开配置文件，设置以下信息。

      ```
      /data/nfs_server/ xx.xx.xx.xx/16(rw,sync,all_squash)
      ```

      其中，`xx.xx.xx.xx` 表示允许访问的网段。
   3. 执行以下命令，为匿名用户赋权，确保其有权限访问 `exports` 中指定的目录。

      CentOS 7

      CentOS 8

      对于 CentOS 7 版本，NFS 默认使用 `nfsnoboody` 作为默认的匿名用户，命令如下：

      ```
      sudo chown nfsnobody:nfsnobody -R /data/nfs_server
      ```

      CentOS 8 及之后版本，NFS 默认使用 `noboody` 作为默认的匿名用户，命令如下：

      ```
      sudo chown nobody:nobody -R /data/nfs_server
      ```
4. 执行以下命令，重新启动 NFS。

   ```
   sudo systemctl restart nfs-server
   ```
5. 设置 Slot Table。

   1. 执行 `sudo vim /etc/sysctl.conf` 命令，打开 `sysctl.conf` 配置文件，在文件中添加一行如下信息：

      ```
      sunrpc.tcp_max_slot_table_entries=128
      ```
   2. 执行以下命令，将同时发起的 NFS 请求数量修改为 128。

      ```
      sudo sysctl -w sunrpc.tcp_max_slot_table_entries=128
      ```

      命令执行成功后，可以通过 `cat /proc/sys/sunrpc/tcp_max_slot_table_entries` 命令查看设置是否生效，如果返回值为 128，则说明修改成功。
   3. （可选）重启机器。

## 部署 NFS 客户端

部署 NFS 客户端时，需要在所有 OBServer 节点上进行操作。

以下以在某一台 OBServer 节点上的操作为例，提供操作指导。

1. 登录 OBServer 节点。
2. 执行以下命令，通过 YUM 包管理器安装 NFS。

   ```
   sudo yum install nfs-utils
   ```
3. 设置 Slot Table。

   1. 执行 `sudo vim /etc/sysctl.conf` 命令，打开`sysctl.conf` 配置文件，在文件中添加一行如下信息：

      ```
      sunrpc.tcp_max_slot_table_entries=128
      ```
   2. 执行以下命令，将同时发起的 NFS 请求数量修改为 128。

      ```
      sudo sysctl -w sunrpc.tcp_max_slot_table_entries=128
      ```

      命令执行成功后，可以通过 `cat /proc/sys/sunrpc/tcp_max_slot_table_entries` 命令查看设置是否生效，如果返回值为 128，则说明修改成功。
   3. （可选）重启机器。
4. 选择一个合适的目录作为 Mount 点，执行以下命令，挂载 NFS。

   NFS 3.x

   NFS 4.x

   例如，本文档中假设 Mount 到 `/data/nfs` 目录，如果没有合适的目录可以新建一个目录。

   ```
   sudo mount -tnfs -o rw,nfsvers=3,sync,lookupcache=positive,hard,nolock,timeo=600,wsize=1048576,rsize=1048576,namlen=255 10.10.10.1:/data/nfs_server /data/nfs
   ```

   例如，本文档中假设 Mount 到 `/data/nfs` 目录，如果没有合适的目录可以新建一个目录。

   ```
   sudo mount -tnfs -o rw,nfsvers=4.1,sync,lookupcache=positive,hard,timeo=600,wsize=1048576,rsize=1048576,namlen=255 10.10.10.1:/data/nfs_server /data/nfs
   ```

   语句中：

   * `nfsvers`：表示使用的 NFS 版本。使用 NFS 4.x 时，使用 NFS 4.x 时，建议选择 NFS 4.1 及以上版本。NFS 4.0 存在重命名文件以后可能会读到旧文件的风险，建议不要使用。
   * `sync`：使用同步写保证数据能及时刷到服务端，从而保证数据的一致性。
   * `lookupcache=positive`：指定操作系统内核管理给定挂载点的目录缓存的方式，有效参数为 `all` / `none` / `pos` / `postive`。`postive` 用于避免并发访问目录或者文件时误报目录或文件不存在的问题，保证数据的一致性。
   * `hard`：在 NFS 不可用的情况下，系统会卡住应用的读写请求，以保证数据的一致性。不能使用 `soft` 选项，会有数据错误的风险。
   * `lock/nolock`：选择是否使用 NLM 协议在服务器上锁文件。默认为 `lock`。由于 NFS 4.x 协议集成了文件锁，而 NFS 3.x 协议本身并不支持文件锁。在使用 NFS 3.x 协议时，建议挂载时添加 `nolock` 值。
   * `timeo`：用于指定重试的等待时间，单位为 0.1s。在设置时，建议不要设置得过大，建议值为 `600`。
   * `wsize`：表示写的数据块大小，建议设置为 `1048576`。
   * `rsize`：表示读的数据块大小，建议设置为 `1048576`。
   * `namlen`：建议设置为 `255`。
   * `10.10.10.1`：表示 NFS 服务器的 IP 地址。

   #### 注意

   * 在挂载 NFS 3/4 时，必须保证备份挂载环境的参数中包含示例中建议的参数。
   * Docker 环境需要在宿主机上挂载 NFS，然后映射到 Docker 里面。如果 Docker 内部直接挂载 NFS，可能会出现客户端 Hang 住的场景。
5. 挂载完成后，可执行以下命令，验证 NFS 的性能。

   ```
   fio -filename=/data/nfs/fio_test -direct=1  -rw=randwrite -bs=2048K -size=100G  -runtime=300 -group_reporting -name=mytest  -ioengine=libaio -numjobs=1 -iodepth=64 -iodepth_batch=8 -iodepth_low=8 -iodepth_batch_complete=8
   ```

   例如，执行结果如下：

   ```
   Run status group 0 (all jobs):
   WRITE: io=322240MB, aggrb=1074.2MB/s, minb=1074.2MB/s, maxb=1074.2MB/s, mint=300006msec, maxt=300006msec
   ```

## Mount NFS 3 时报错的处理方法

在部署 NFS 时，在 Mount NFS 3 时如果出现 `requested NFS version or transport protocol is not supported` 的报错，可以参考如下方式进行处理。

1. 登录 NFS 服务器。
2. 检查 NFS 服务器支持的版本。

   ```
   sudo cat /proc/fs/nfsd/versions
   ```

   发现返回以下信息：

   ```
   -2 -3 +4 +4.1 +4.2
   ```

   其中，`-3` 表示 NFS 3 被禁用。
3. 调整配置。

   进行如下操作，以启用 NFS 3：

   1. 检查是否存在 `/etc/nfs.conf` 文件，如果存在，需要将 `/etc/nfs.conf` 文件中 `vers3=y` 前的 `#` 去掉。

      修改后的示例文件如下：

      ```
      [nfsd]
      # debug=0 
      # threads=8
      # host=
      # port=0
      # grace-time=90
      # Tease-time=90
      # udp=y
      # tcp=y
      # vers2=n
         vers3=y
      # vers4=y
      # vers4.0=y
      # vers4.1=y
      # vers4.2=y
      # rdma=n
      ##
      ```
   2. 检查是否存在 `/etc/sysconfig/nfs` 文件，如果存在，则查看 `/etc/sysconfig/nfs` 文件的 `RPCNFSDARGS` 参数中是否指定了 `-N 3`， 如果指定了，需要去掉 `-N 3`。

      例如，去掉 `-N 3` 后，`RPCNFSDARGS` 参数中的值如下：

      ```
      RPCNFSDARGS="-N 2 -N 4"
      ```
4. 执行以下命令，重新启动 NFS。

   ```
   sudo systemctl restart nfs-server
   ```
5. 再次检查 NFS 服务器支持的版本。

   ```
   sudo cat /proc/fs/nfsd/versions
   ```

   发现返回以下信息：

   ```
   -2 +3 -4 -4.1 -4.2
   ```

   其中，`+3` 表示 NFS 3 已启用。