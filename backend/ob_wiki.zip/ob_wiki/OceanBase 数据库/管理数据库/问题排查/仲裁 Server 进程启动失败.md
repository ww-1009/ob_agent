---
title: 仲裁 Server 进程启动失败
description: 提供关于仲裁 Server 进程启动失败的相关内容，
keywords: 仲裁 Server 进程启动失败,OceanBase 数据库,管理数据库,问题排查,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 仲裁 Server 进程启动失败

## 仲裁 Server 进程启动失败，提示找不到网卡

### 问题现象

使用命令行启动仲裁 Server 时，出现如下报错信息：

```
[2023-11-08 11:01:54.555369] ERROR issue_dba_error (ob_log.cpp:1841) [2649528][observer][T0][Y0-0000000000000000-0-0] [lt=3][errcode=-4388] Unexpected internal error happen, please checkout the internal errcode(errcode=-4182, file="ob_net_util.cpp", line_no=212, info="can not find ifname by local ip")
[2023-11-08 11:01:54.555407] EDIAG [LIB] get_ifname_by_addr (ob_net_util.cpp:212) [2649528][observer][T0][Y0-0000000000000000-0-0] [lt=37][errcode=-4182] can not find ifname by local ip(local_ip=0.0.0.0) BACKTRACE:0x10a24a3c 0x5e92550 0xb0a0c38 0x5e9228c 0x5e8b32c 0x10f7503c 0x10f74ac8 0x8e3a8bc 0x8e31a30 0x5e8c4c4 0xffffaad3485c 0x453d958
[2023-11-08 11:01:54.555846] ERROR init_config (ob_server.cpp:1840) [2649528][observer][T0][Y0-0000000000000000-0-0] [lt=434][errcode=-4393] observer start process failure(local_ip is not a valid IP for this machine, local_ip="0.0.0.0")
```

### 问题分析

根据报错信息，`local_ip` 为 `0.0.0.0`，可能是由于第一次通过命令行启动仲裁 Server 进程时，未指定网卡名（通过 `-i eth0` 指定）或 IP 地址（通过 `-I 10.xx.xx.xx` 指定），仲裁 Server 尝试 guess devname，但是失败了，于是使用了默认的 bond0。同时，又因为未指定 `-I` 参数，导致 `local_ip` 的值使用了系统默认的空串（`0.0.0.0`），并且该 IP 地址被保存到了配置项文件中。之后，再次启动仲裁 Server 进程时，即使指定了网卡名，仍然会因为之前所保存的错误 IP 地址而报错。这是因为，仲裁 Server 会强制检查 `local_ip` 是否合法，方法是确认是否能通过该 `local_ip` 获取到网卡名，而 `local_ip=0.0.0.0`，无法获取到网卡名，`local_ip` 检查失败，最终导致仲裁 Server 进程启动失败。

### 处理方法

方法一：将 `/etc` 目录下的持久化文件删除后，在命令行中通过指定 `-i eth0` 的方式重新启动仲裁 Server 进程。

方法二：不删除持久化文件，直接在命令行中通过指定 `-I 10.xx.xx.xx` 的方式重新启动仲裁 Server 进程。

## 仲裁 Server 进程启动失败，进程拉起时报 killed

### 问题现象及分析

如果仲裁 Server 进程启动失败，并且执行启动命令后，系统一直报 `killed`，则需要检查本机的 `vm.min_free_kbyte` 参数的配置。内核参数 `vm.min_free_kbyte` 用于配置系统保留的最小空闲内存量，以防止内存碎片化。如果新启动的进程导致机器剩余的内存低于该值，则该进程可能会被操作系统 Kill 掉。

### 处理方法

可以适当调小 `vm.min_free_kbyte` 参数的值。对于小规格机器（服务器的物理内存不超过 8 GB）部署仲裁服务的场景，建议将该配置值保持为系统默认值。

查看和修改 `vm.min_free_kbyte` 参数值的方法如下：

1. 使用 `root` 用户登录仲裁 Server 所在的机器。
2. 查看系统最低空闲内存的水位值，该参数值对应的单位为 KB。

```
[root@xxx admin]# cat /proc/sys/vm/min_free_kbytes
```

3. 根据实际环境，修改系统最低空闲内存的水位值。

   例如，将系统最低空闲内存的水位值调至 256 MB 即 262144 KB。

   ```
   [root@xxx admin]# echo 262144 > /proc/sys/vm/min_free_kbytes
   ```

## 相关文档

更多仲裁服务相关的运维操作，参见 [仲裁高可用](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499778) 章节。