---
title: BootStrap
description: 提供关于BootStrap的相关内容，
keywords: BootStrap,OceanBase 数据库,管理数据库,问题排查,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-28T09:20:55.000+00:00
---

# BootStrap

## 磁盘空间不足（错误码 -4290）

OceanBase 数据库 V3.x 及之前的版本中，要求日志盘独立部署，并独占所在盘。OceanBase 数据库 V4.0 开始，支持日志和其他文件放在一起，因此需要用户配置日志盘空间的具体大小。OceanBase 数据库会根据用户的配置，在 OBServer 启动时预分配数据盘和 CLOG 盘的磁盘空间。

因此引入配置项 `log_disk_size`/`log_disk_percentage`，两个配置项需要配合使用。

* `log_disk_size`: 表示日志盘大小，也就是本 OBServer 可以使用的日志盘总空间大小，默认是 0，表示需要根据本地日志盘实际空间进行计算（兼容 OceanBase 数据库 V3.x 的行为）。
* `log_disk_percentage`: 表示日志盘占用百分比。当用户配置 `log_disk_size = 0` 时，根据 `log_disk_percentage` 来分配日志盘空间。默认值为 0，表示根据是否和数据共用一块盘来自动计算 在两个配置项同时配置的场景下，`log_disk_size` 有更高的优先级。

如果 `log_disk_size` 和 `log_disk_percentage` 均为 0（默认值），盘空间计算方式如下：

* 数据和 CLOG 同盘的情况下，数据占用盘的 60%，CLOG 占用盘的30%。
* 数据和 CLOG 不同盘的情况下，数据占用盘的 90%，CLOG 占用盘的90%。

在 Bootstrap 过程中，若出现以下报错，则表示磁盘空间不足：

```
grep 'ret=-4290' observer.log
```

**解决方式：**

正确的指定 `log_disk_percentage` 或 `log_disk_size`。例如，启动时指定 `-o log_disk_percentage=10`。