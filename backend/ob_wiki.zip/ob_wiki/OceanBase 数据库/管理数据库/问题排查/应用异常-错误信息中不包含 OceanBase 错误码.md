---
title: 应用异常-错误信息中不包含 OceanBase 错误码
description: 提供关于应用异常--错误信息中不包含 OceanBase 错误码的相关内容，
keywords: 应用异常--错误信息中不包含 OceanBase 错误码,OceanBase 数据库,管理数据库,问题排查,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 应用异常--错误信息中不包含 OceanBase 错误码

数据库在运行期间经常会有各种异常情况出现，例如，应用程序错误、数据库连接错误、数据库权限问题、数据库资源问题、网络问题等。在这所有的情况中，有一种就是应用异常，但是错误信息中不包含 OB 的错误码，这类问题一般较难判断问题与 OceanBase 数据库的相关性从而导致排查方向不明确。

为了帮助大家快速定位这种场景下的问题根源并高效解决，这里总结了一套清晰、实用的应用异常且报错信息不包含 OceanBase 错误码的报错排查流程。该流程提供了明确的操作步骤，旨在提升问题处理效率，尽可能降低对业务的影响，为日常运维工作提供有力的支持。

应用执行报错且错误信息中不包含 OceanBase 错误码的问题排查流程如下图所示。

![应用异常报错不包含OB错误码的排查流程](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.3.5/troublethooting/app-exception-without-error-code-new1.png)

## 流程介绍

当遇到应用执行异常且报错信息中不包含 OceanBase 错误码信息的场景，可以按照该流程进行问题排查。

分析应用程序侧的报错逻辑，判断是否为断链异常问题：

* 是，则参考 [应用断连问题排查](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000003465937) 文档进行排查。
* 否，则进一步判断是否可以复现：

  + 是，通过程序代码调试、网络抓包分析（例如：tcpdump）等手段分析程序代码报错原因，从而确认问题触发逻辑明确分析方向。
  + 否，尝试通过现有信息结合程序自身逻辑推测报错原因，从而确认问题触发逻辑明确分析方向。

## 典型案例

通用（不区分模式）

MySQL 模式

Oracle 模式

* 数据库连接异常断开。具体排查操作参见 [SQL 执行报错连接已断开](https://www.oceanbase.com/knowledge-base/odc-1000000000262290?back=kb)。
* 用户在一个分布式集群环境里面配置了多个 IP 地址，想通过多个 IP 连接登录集群。具体排查操作参见 [OBClient 客户端工具如何支持多 IP 连接登录](https://www.oceanbase.com/knowledge-base/oceanbase-database-1000000000683684)。
* OceanBase 数据库在进行业务 `commit` 时，遇到如下异常报错：`Transaction resolution unknown`。具体排查操作参见 [应用报错：Transaction resolution unknown](https://www.oceanbase.com/knowledge-base/oceanbase-database-1000000000322510)。
* 应用程序端反馈：在进行大数据量导入时，应用日志报错 `Connection is closed & Connection reset`。具体排查操作参见 [OBProxy 由于内存使用超限导致应用报错：Connection reset](https://www.oceanbase.com/knowledge-base/oceanbase-database-proxy-1000000000210042?back=kb)。
* 业务在测试环境执行时，从应用侧观测到 SQL 平均耗时 2ms，而在生产环境执行时耗时变成了 30~40ms，但数据库内的 SQL 耗时并没有增长。具体排查操作参见 [应用侧 SQL 执行耗时远高于数据库内的问题](https://www.oceanbase.com/knowledge-base/oceanbase-database-proxy-1000000000210045?back=kb)。

* 客户端在执行 SQL 时直接报错 `Lost connection to MySQL server during query`。通常，此类报错是因为服务器端出现异常导致，导致链接中断。具体排查操作参见 [客户端报错 Lost connection to MySQL server during query 的几种原因](https://www.oceanbase.com/knowledge-base/oceanbase-database-1000000000210010?back=kb)。

* 系统从 Oracle 数据库切换到 OceanBase 数据库的 Oracle 租户后，使用 JBoss 部署的 JDBC 应用出现连接数不足的问题。具体排查操作参见 [JBoss 部署的 JDBC 应用出现连接数不足的问题](https://www.oceanbase.com/knowledge-base/oceanbase-connector-j-1000000000217899?back=kb)。

## 相关文档

* [使用 tcpdump 抓包](https://www.oceanbase.com/docs/common-odc-1000000002072960)
* [OceanBase 数据库和应用之间的通讯 TCP 原理](https://www.oceanbase.com/knowledge-base/oceanbase-database-1000000003039512?back=kb)