---
title: 检查 OBServer 状态
description: 提供关于检查 OBServer 状态的相关内容，
keywords: 检查 OBServer 状态,OceanBase 数据库,管理数据库,日常巡检,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 检查 OBServer 状态

本文介绍了检查 OBServer 状态的方式，您可根据自身情况选择。

## 通过宿主机查看 OBServer 状态

1. 登录 OBServer 所在的宿主机。
2. 在命令行工具中运行以下命令查看 observer 进程。

   ```
   ps -ef |grep observer
   root       6136      0 99 11:23 ?        08:53:50 ./bin/observer
   root      20514  19521  0 16:09 pts/25   00:00:00 grep --color=auto observer
   ```

## 通过视图查看 OBServer 状态

```
obclient> SELECT status FROM oceanbase.DBA_OB_SERVERS;
+--------+
| status |
+--------+
| active |
| active |
+--------+
2 rows in set (0.00 sec)
```

* 如果返回结果为 `active`，说明 OBServer 处于正常运行状态。
* 如果返回结果为 `inactive`，说明 OBServer 处于下线状态。
* 如果返回结果为 `deleting`，说明 OBServer 处于正在被删除状态。