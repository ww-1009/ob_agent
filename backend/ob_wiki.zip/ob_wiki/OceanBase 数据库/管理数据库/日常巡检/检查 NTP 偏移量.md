---
title: 检查 NTP 偏移量
description: 提供关于检查 NTP 偏移量的相关内容，
keywords: 检查 NTP 偏移量,OceanBase 数据库,管理数据库,日常巡检,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 检查 NTP 偏移量

网络时间协议 (Network Time Protocol，NTP )，可通过网络同步计算机系统之间的时钟。NTP 服务器可使组织中的所有服务器的时间保持同步。

OceanBase 数据库是一个分布式数据库，故集群的多个节点以及 OCP 节点的时钟必须配置时钟同步服务 NTP 或者 chrony，保证所有节点的时钟偏差在 2s 以内。

运行 OBServer 的服务器上，系统时间是通过 NTP 服务进行同步的，但是当时间差过大的情况下，NTP 服务不会更改和矫正系统时间。如果集群时间不同步，则会影响集群的可用性。本文主要介绍如何调整 OBServer 的操作系统时间。

## 查看 NTP 偏移量

您可通过以下方法查看 NTP 偏移量：

### 通过宿主机查看

您可执行以下命令来检查时钟偏移量。

```
[root@hostname /]# ntpq -p|grep -E "\*|\=|remote"
   remote         refid           st t when poll reach    delay     offset     jitter
==========================================================================
xxxxxxxxxxx       xxxxx           2 u   16  64  377       1.333     0.046   0.033
```

### 设置 NTP 偏移量

### 判断标准

NTP 偏移量值超出 2s，需对其进行设置。

### OBServer 的节点系统时间比标准时间慢的情况

对于 OBServer 节点的系统时间比标准时间慢的情况，可以直接将服务器系统时间修改为标准时间。 例如当前标准时间为 20:00，OBServer 时间慢了 1 个小时，系统时间为 19:00。

1. 停止 OBServer。
2. OBServer 停止后，通过 SSH 登录到宿主机手动更改系统时间。

   其中，`ntp_server_ip` 为时钟服务器的 IP 地址。

   ```
   [root@hostname /]# ntpdate <ntp_server_ip>
   ```
3. 启动 OBServer。

### OBServer 的节点系统时间比标准时间快的情况

对于 OBServer 的节点系统时间比标准时间快的情况，不可以直接回调系统时间，而应当通过停机并等待系统时间与标准时间同步后再进行修改。例如当前标准时间为 20:00，OBServer 时间快了 1 个小时，系统时间为 21:00。

1. 停止 OBServer。
2. 进程停止后，等待标准时间超过 21:00，例如标准时间为 21:05 时，通过 SSH 登录到宿主机手动更改系统时间。

   其中，`ntp_server_ip` 为时钟服务器的 IP 地址。

   ```
   [root@hostname /]# ntpdate ntp_server_ip
   ```
3. 启动 OBServer。