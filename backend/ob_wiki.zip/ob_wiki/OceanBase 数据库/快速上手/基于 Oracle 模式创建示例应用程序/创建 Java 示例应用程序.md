---
title: 创建 Java 示例应用程序
description: 提供关于创建 Java 示例应用程序的相关内容，
keywords: 创建 Java 示例应用程序,OceanBase 数据库,快速上手,基于 Oracle 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:56:58.000+00:00
---

# 创建 Java 示例应用程序

本文介绍了 Java 应用程序如何使用 OceanBase Connector/J 驱动连接并使用 OceanBase 数据库。

#### 功能适用性

该内容仅适用于 OceanBase 数据库企业版。OceanBase 数据库社区版仅提供 MySQL 模式。

## 前提条件

* 确保设置了基本的数据库开发环境。
* 确保计算机上的 Java 环境为 Java JDK 8 版本。
* 获取 OceanBase Connector/J 驱动程序安装包。请在 OceanBase 官方网站的 **资源 -> 下载中心 -> 企业版 -> 驱动和中间件** 下的 [OceanBase JDBC 驱动程序](https://www.oceanbase.com/softwarecenter-enterprise) 中单击对应的版本，填写信息后自助下载 OceanBase Connector/J 驱动程序安装包。

## 创建 Java 应用程序

### 步骤一：获取数据库连接串

联系 OceanBase 数据库部署人员或者管理员获取相应的数据库连接串，例如：

```
obclient  -h100.88.xx.xx -usys@oracle -p****** -P2883
```

数据库连接串包含了访问数据库所需的参数信息，在创建应用程序前，可通过数据库连接串验证登录数据库，保证连接串参数信息正确。

参数说明：

* **-h**：OceanBase 数据库连接 IP，有时候是一个 ODP 地址。
* **-u**：租户的连接用户名，格式为 **用户@租户#集群名称**，租户的连接用户，Oracle 模式的管理员用户名默认是 `sys`。直连数据库时不填集群名称，通过 ODP 连接时需要填写。
* **-p**：用户密码。
* **-P**：OceanBase 数据库连接端口，也是 ODP 的监听端口。

### 步骤二：安装 OceanBase Connector/J 驱动

将 OceanBase Connector/J 的 JAR 包解压后放入本地 `/usr/share/java` 路径中，并设置临时环境变量。

```
mv ./oceanbase-client-{version}.jar /usr/share/java
export CLASSPATH=/usr/share/java/oceanbase-client-{version}.jar:$CLASSPATH
```

#### 说明

根据下载的实际文件版本进行相应操作。

### 步骤三：编写应用程序

编写 Java 示例文件 `Test.java`。

```
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

public class Test {
    public static void main(String[] args) {
        try {

            Class.forName("com.oceanbase.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:oceanbase://172.30.xx.xx:2881/?pool=false&user=s**@oracle&password=******");
            System.out.println(connection.getAutoCommit());
            Statement sm = connection.createStatement();
            //新建表 t_meta_form
            sm.executeUpdate("CREATE TABLE t_meta_form (name varchar(36) , id int)");
            //插入数据
            sm.executeUpdate("insert into t_meta_form values ('an','1')");
            //查询数据，并输出结果
            ResultSet rs = sm.executeQuery("select * from t_meta_form");
            while (rs.next()) {
                String name = rs.getString("name");
                String id = rs.getString("id");
                System.out.println(name + ','+ id);
            }
            //删除表
            sm.executeUpdate("drop table t_meta_form");
        }catch (SQLException ex) {
            System.out.println("error!");
            ex.printStackTrace() ;
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
```

修改代码中的数据库连接参数。参考如下字段，对应的值，则取自步骤一获取的数据库连接串。

* **url**：取自 `-h` 和 `-P` 参数，`jdbc:oceanbase://IP:port/?pool=false`。OceanBase 数据库连接 IP，通常是一个 ODP 地址，以及访问所用的端口号。
* **user**：取自 `-u` 参数，租户的连接用户名，格式为 **用户@租户#集群名称**，Oracle 模式的管理员用户名默认是 `sys`。直连数据库时不填集群名称，通过 ODP 连接时需要填写。
* **password**：取自 `-p` 参数，用户密码。

### 步骤四：执行应用程序

代码编辑完成后，可以通过如下命令进行编译：

```
javac Test.java
```

编译完成后，执行获得如下结果，说明数据库连接成功，示例语句正确执行：

```
java Test

true
an,1
```

## 更多信息

关于 OceanBase Connector/J 的详细使用信息，请参考官方文档 《[OceanBase Connector/J](https://www.oceanbase.com/docs/enterprise-oceanbase-connector-j-cn-10000000000348466)》。