# 叶子索引：上手 OceanBase SQL

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [快速上手](../../index.md) / [上手 OceanBase SQL](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [SQL 基础操作（Oracle 模式）.md](./SQL 基础操作（Oracle 模式）.md) | 提供关于SQL 基础操作（Oracle 模式）的相关内容， | SQL 基础操作（Oracle 模式）,OceanBase 数据库,快速上手,上手 OceanBase SQL,文档,使用帮助,OceanBase,分布式,数据库 |
| [SQL 基础操作（MySQL 模式）.md](./SQL 基础操作（MySQL 模式）.md) | 提供关于SQL 基础操作（MySQL 模式）的相关内容， | SQL 基础操作（MySQL 模式）,OceanBase 数据库,快速上手,上手 OceanBase SQL,文档,使用帮助,OceanBase,分布式,数据库 |
| [在您开始前.md](./在您开始前.md) | 提供关于在您开始前的相关内容， | 在您开始前,OceanBase 数据库,快速上手,上手 OceanBase SQL,文档,使用帮助,OceanBase,分布式,数据库 |
