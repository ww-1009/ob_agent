---
title: 快速体验 OceanBase 社区版
description: 提供关于快速体验 OceanBase 社区版的相关内容，
keywords: 快速体验 OceanBase 社区版,OceanBase 数据库,快速上手,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 快速体验 OceanBase 社区版

本文根据使用场景详细介绍了 OceanBase 数据库的两种部署方案——快速体验 OceanBase 数据库、部署生产环境，旨在帮助您快速掌握并成功使用 OceanBase 数据库。

## 组件介绍

* obd

  OceanBase Deployer，OceanBase 安装部署工具，简称为 obd。详细信息请参考官网文档 [OceanBase 安装部署工具](https://www.oceanbase.com/docs/obd-cn)。
* ODP

  OceanBase Database Proxy，OceanBase 数据库代理，是 OceanBase 数据库专用的代理服务器，简称为 ODP（又称为 OBProxy）。详细信息请参考官网文档 [OceanBase 数据库代理](https://www.oceanbase.com/docs/odp-doc-cn)。
* OBAgent

  OBAgent 是 OceanBase 数据库监控采集框架，支持推、拉两种数据采集模式，可以满足不同的应用场景。
* Grafana

  Grafana 是一款开源的数据可视化工具，它可以将数据源中的各种指标数据进行可视化展示，以便更直观地了解系统运行状态和性能指标。详细信息可参见 [Grafana 官网](https://grafana.com/)。
* Prometheus

  Prometheus 是一个开源的服务监控系统和时序数据库，其提供了通用的数据模型以及快捷数据采集、存储和查询接口。详细信息可参见 [Prometheus 官网](https://prometheus.io/)。

## 前提条件

在参考本文安装 OceanBase 数据库之前，确保您的软硬件环境满足以下要求：

| 项目 | 描述 |
| --- | --- |
| 系统 | * Anolis OS 8.X 版本（内核 Linux 4.19 版本及以上） * Alibaba Cloud Linux 2/3 版本（内核 Linux 4.19 版本及以上） * Red Hat Enterprise Linux Server 7.X 版本、8.X 版本（内核 Linux 4.19 版本及以上） * CentOS Linux 7.X 版本、8.X 版本（内核 Linux 4.19 版本及以上） * Rocky Linux 9（内核 Linux 5.14） * Debian 9.X 版本及以上版本（内核 Linux 4.19 版本及以上） * Ubuntu 16.X 版本及以上版本（内核 Linux 4.19 版本及以上） * SUSE / openSUSE 15.X 版本及以上版本（内核 Linux 4.19 版本及以上） * openEuler 22.03 和 24.03 版本（内核 Linux 5.10.0 版本及以上） * KylinOS V10 版本 * 统信 UOS V20 版本 * 中科方德 NFSChina 4.0 版本及以上 * 浪潮 Inspur kos 5.8 版本 |
| CPU | 最低要求 2 核，推荐 4 核及以上。 |
| 内存 | 最低要求 6 GB，推荐设置在 16 GB 至 1024 GB 范围内。 |
| 磁盘类型 | 使用 SSD 存储。 |
| 磁盘存储空间 | 最低要求 20 GB。 |
| 文件系统 | EXT4 或 XFS，当数据超过 16 TB 时，使用 XFS。 |
| 端口 | 需保证组件的默认端口未被占用：  * OceanBase 数据库默认使用 2881、2882、2886 端口。 * ODP 默认使用 2883、2884、2885 端口。 * OBAgent 默认使用 8088、8089 端口。 * Prometheus 默认使用 9090 端口。 * Grafana 默认使用 3000 端口。 |
| all-in-one 安装包 | all-in-one 安装包需选择 V4.1.0 及以上版本。 |
| Docker | 使用 Docker 部署 OceanBase 数据库时需提前安装 Docker 并启动 Docker 服务，详细操作请参考 [Docker 文档](https://docs.docker.com/get-docker/)。 说明 在使用 x86 架构的 MAC 机器时，仅支持使用 V4.9.0 及以下版本的 Docker 部署 OceanBase 数据库，可点击 [链接](https://desktop.docker.com/mac/main/amd64/81317/Docker.dmg?_gl=17jelfd_gcl_auOTk5Nzk0MDUwLjE3MTE4ODMyNzM._gaNDQyMjE1MDE5LjE3MTE4ODMyNzQ._ga_XJWPQMJYHQ*MTcxOTIxOTEwMy4xMS4xLjE3MTkyMjEwMTAuNjAuMC4w) 下载 Docker。 |

#### 说明

以下内容以 x86 架构的 CentOS Linux 7.9 镜像作为环境，其他环境可能略有不同。

## 方案一：快速体验 OceanBase 数据库

#### 说明

本方案不适用于生产环境，如需在生产环境中部署 OceanBase 数据库，请参考本文档 [方案二：部署生产环境](#方案二：部署生产环境)。

此方案适用于仅有一台机器时，快速搭建一个可用的 OceanBase 数据库环境。部署的 OceanBase 数据库环境具备数据库的基本功能，可以有效地帮助您了解 OceanBase 数据库；但是该环境不具备任何分布式能力及高可用特性，不建议长期使用。 您可以使用以下三种方法快速体验 OceanBase 数据库。

### 方法一：使用 All in One 安装包

```
bash -c "$(curl -s https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/download-center/opensource/oceanbase-all-in-one/installer.sh)"
source ~/.oceanbase-all-in-one/bin/env.sh
obd demo
```

以上为快速体验命令，将 **在线下载** 最新版本的 OceanBase All in One 包并直接使用 **当前账号** 部署 OceanBase 数据库，后续可以通过 obd 命令管理 OceanBase 数据库。离线安装 OceanBase All in One 的步骤和 obd demo 命令的更多介绍可分别参见官网《OceanBase 安装部署工具》文档 [快速上手/安装 obd](https://www.oceanbase.com/docs/community-obd-cn-1000000001882001) 和 [obd 命令/快速部署命令](https://www.oceanbase.com/docs/community-obd-cn-1000000001881994)。

`obd demo` 命令执行成功后会输出部署组件的连接方式，您可复制并执行 `oceanbase-ce` 组件下的连接串，使用 root 用户登录集群的 sys 租户。登录集群后可执行 SQL 语句进行简单的功能体验，具体可参见 [SQL 基础操作（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499627)。

### 方法二：直接使用 RPM 包

#### 说明

* 本方法依赖于 systemctl 命令，请在非容器环境下进行操作。
* 通过本方法安装 OceanBase 数据库时仅支持以下系统：

  + Anolis OS 8.X 版本（内核 Linux 4.19 版本及以上）
  + CentOS Linux 8.X 版本（内核 Linux 4.19 版本及以上）
  + Debian 10、11 和 12 版本（内核 Linux 4.19 版本及以上）
  + openEuler 22.03 和 24.03 版本（内核 Linux 5.10.0 版本及以上）
  + Ubuntu 18.04、20.04 和 22.04 版本（内核 Linux 4.19 版本及以上）

```
sudo bash -c "$(curl -s https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/download-center/opensource/service/installer.sh)"
```

以上为快速体验命令，将 **在线下载** 最新版本的 RPM 包并直接使用 `root` 账号进行安装，后续可以通过 systemctl 命令管理 OceanBase 数据库。详细配置及离线安装步骤请参考官网《OceanBase 数据库》文档 [使用 systemd 部署 OceanBase 数据库](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500191)。

命令执行成功后会输出 OceanBase 数据库的连接方式，您可复制并执行输出的连接串，使用 root 用户登录集群的 sys 租户。登录集群后可执行 SQL 语句进行简单的功能体验，具体可参见 [SQL 基础操作（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499627)。

### 方法三：使用 Docker 快速体验

此方案适用于非 Linux 操作系统的用户（例如 Windows、macOS），希望通过容器实现部署、管理 OceanBase 数据库的用户。该方案未经过规模化的验证，建议谨慎使用。

#### 说明

在使用 x86 架构的 MAC 机器时，仅支持使用 V4.9.0 及以下版本的 Docker 部署 OceanBase 数据库，可点击 [链接](https://desktop.docker.com/mac/main/amd64/81317/Docker.dmg?_gl=17jelfd_gcl_auOTk5Nzk0MDUwLjE3MTE4ODMyNzM._gaNDQyMjE1MDE5LjE3MTE4ODMyNzQ._ga_XJWPQMJYHQ*MTcxOTIxOTEwMy4xMS4xLjE3MTkyMjEwMTAuNjAuMC4w) 下载 Docker。

```
sudo docker run -p 2881:2881 --name obstandalone -e MODE=MINI -d quay.io/oceanbase/oceanbase-ce
```

以上为快速体验命令，将 **在线下载** 最新的镜像并启动最小规格的 OceanBase 数据库，后续可通过 docker 命令管理 OceanBase 数据库。详细配置请参考官网《OceanBase 数据库》文档 [部署 OceanBase 数据库容器环境](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001937353)。

部署成功后可执行下述命令，使用 root 用户登录集群的 sys 租户。登录集群后可执行 SQL 语句进行简单的功能体验，具体可参见 [SQL 基础操作（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499627)。

```
#进入 Docker 容器
sudo docker exec -it obstandalone bash
#连接集群，密码默认为空
obclient -uroot@sys -h127.0.0.1 -Doceanbase -P2881 -p
```

## 方案二：部署生产环境

您可以根据实际情况选择如下任一方法部署 OceanBase 集群生产环境。

### 方法一：使用 OceanBase All in One 包部署

此方案适用于需要深入了解 OceanBase 分布式数据库架构原理及功能特性的用户，部署的 OceanBase 集群具备数据库完整能力及分布式高可用的特性。该方案需要您至少准备三台可用资源为 4vCPU、16 GB 内存、100 GB SSD 或更高性能磁盘的主机。

* （推荐）图形化管理 OceanBase 集群

  如果您想部署多套 OceanBase 集群，建议部署 OCP（OceanBase 云平台），OCP 可以帮助您更好地运维和管理 OceanBase 数据库，大幅降低运维工作。

  您需先使用三台机器部署 OCP 及其 MetaDB，具体操作可参见官网《OceanBase 安装部署工具》文档 [使用指南/图形化界面/通过图形化界面部署 OCP](https://www.oceanbase.com/docs/community-obd-cn-1000000001882005)。成功部署 OCP 后，您可通过 OCP 创建新的 OceanBase 集群以服务您的业务，具体操作可参见官网《OceanBase 云平台》文档 [集群管理](https://www.oceanbase.com/docs/common-ocp-1000000001739837) 章节。

  #### 注意

  MetaDB 仅用作 OCP 的元数据库，请勿用作您的业务集群。
* 命令行管理 OceanBase 集群

  若您暂时只打算部署一套 OceanBase 集群，您可通过 obd 部署 OceanBase 集群，之后使用 obd 命令管理 OceanBase 集群。具体部署操作可参见官网《OceanBase 数据库》文档 [通过 obd 图形化界面部署 OceanBase 集群](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502653)，obd 命令介绍可参见官网《OceanBase 安装部署工具》文档 [obd 命令/集群命令组](https://www.oceanbase.com/docs/community-obd-cn-1000000001881997)。

### 方法二：在 Kubernetes 环境中部署 OceanBase 集群

此方法适用于生产环境已经大规模上线 Kubernetes 并且对 OceanBase 数据库有一定了解和经验的用户。部署的 OceanBase 集群具备数据库完整能力及分布式高可用的特性。在开始之前，请确保您已满足以下条件：

* 您有可用的 Kubernetes 集群且至少有 9 个可用 CPU，33 GB 可用内存 和 360 GB 的可用存储空间。
* ob-operator 依赖 cert-manager，请确保您已安装 cert-manager。cert-manager 的安装方法请参考对应的 [安装文档](https://cert-manager.io/docs/installation/)。

具体操作步骤请参考官网《OceanBase 数据库》文档 [在 Kubernetes 环境中部署 OceanBase 集群](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499737)。