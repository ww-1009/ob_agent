---
title: 创建 C 示例应用程序
description: 提供关于创建 C 示例应用程序的相关内容，
keywords: 创建 C 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 创建 C 示例应用程序

本文介绍了如何通过 MySQL Connector/C (libmysqlclient) 驱动连接并使用 OceanBase 数据库。

## 前提条件

在安装使用 MySQL Connector/C (libmysqlclient) 前请确保设置了基本的数据库开发环境，要求如下：

* GCC 版本为 3.4.6 及以上，推荐使用 4.8.5 版本。
* CMake 版本为 2.8.12 及以上。

## 创建 C 应用程序

### 步骤一：获取数据库连接串

联系 OceanBase 数据库部署人员或者管理员获取相应的数据库连接串，例如：

```
obclient -h100.88.xx.xx -uroot@test -p****** -P2881 -Doceanbase
```

数据库连接串包含了访问数据库所需的参数信息，在创建应用程序前，可通过数据库连接串验证登录数据库，保证连接串参数信息正确。

参数说明：

* **-h**：OceanBase 数据库连接 IP，有时候是一个 ODP 地址。
* **-u**：租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 `sys`，租户的默认管理员用户是 `root`。直接连接数据库时不填集群名称，通过 ODP 连接时需要填写。
* **-p**：用户密码。
* **-P**：OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **-D**：需要访问的数据库名称。

### 步骤二：安装 MySQL Connector/C 驱动

#### 通过 yum 安装 mariadb client

1. 安装 mariadb client。

   ```
   sudo yum install mariadb-devel
   ```

### 步骤三：编写应用程序

应用程序通过 MySQL Connector/C 与数据库服务器 OBServer 节点交互的基本方式如下：

1. 调用 `mysql_library_init()` 初始化 MySQL 库。

   ```
   mysql_library_init(0, NULL, NULL);
   ```
2. 调用 `mysql_init()` 初始化一个连接句柄。

   ```
   MYSQL *mysql = mysql_init(NULL);
   ```
3. 调用 `mysql_real_connect()` 连接到 OBServer 节点。

   ```
   mysql_real_connect (mysql, host_name, user_name, password,
   db_name, port_num, socket_name, CLIENT_MULTI_STATEMENTS)
   ```
4. 调用 `mysql_real_query()` 或 `mysql_query()` 向 OBServer 节点发送 SQL 语句。

   ```
   mysql_query(mysql,"sql_statement");
   ```
5. 调用 `mysql_store_result()` 或 `mysql_use_result()` 处理其结果。

   ```
   result=mysql_store_result(mysql);
   ```
6. 调用 `mysql_free_result()` 释放内存。

   ```
   mysql_free_result(result);
   ```
7. 调用 `mysql_close()` 关闭与 OBServer 节点的连接。

   ```
   mysql_close(mysql);
   ```
8. 调用 `mysql_library_end()` 结束 MariaDB client 的使用。

   ```
   mysql_library_end();
   ```

#### 示例代码

以 `mysql_test.c` 文件为例，代码如下：

```
#include "mysql.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
  mysql_library_init(0, NULL, NULL);
  MYSQL *mysql = mysql_init(NULL);
  char* host_name = "xxx.xxx.xxx.xxx";//set your mysql host
  char* user_name = "******"; //set your user_name
  char* password = "******"; //set your password
  char* db_name = "test"; //set your databasename
  int port_num = 2883; //set your mysql port
  char* socket_name = NULL;
  MYSQL_RES* result;
  MYSQL_FIELD* fields;
  MYSQL_ROW row;
  int status = 0;
  /* connect to server with the CLIENT_MULTI_STATEMENTS option */
  if (mysql_real_connect (mysql, host_name, user_name, password,
    db_name, port_num, socket_name, CLIENT_MULTI_STATEMENTS) == NULL)
  {
    printf("mysql_real_connect() failed\n");
    mysql_close(mysql);
    exit(1);
  }

  /* execute multiple statements */
  status = mysql_query(mysql, "DROP TABLE IF EXISTS test_table;");
                      
  if (status)
  {
    printf("Could not execute statement(s)");
    mysql_close(mysql);
    exit(0);
  }

  status = mysql_query(mysql, "CREATE TABLE test_table(id INT,name varchar(24));");
  status = mysql_query(mysql, "INSERT INTO test_table VALUES(10,'hangzhou'),(20,'shanghai');");
  status = mysql_query(mysql, "UPDATE test_table SET id=20 WHERE id=10;");
  status = mysql_query(mysql, "SELECT * FROM test_table;");

  /* did current statement return data? */
  result = mysql_store_result(mysql);

  if (result)
  {
    /* yes; process rows and free the result set */
    //process_result_set(mysql, result);

    int num_fields = mysql_num_fields(result);
    int num_rows = mysql_num_rows(result);

    printf("result: %d rows %d fields\n", num_rows, num_fields);
    printf("---------------------\n");

    fields = mysql_fetch_fields(result);

    for (int i = 0; i < num_fields; ++i)
    {
      printf("%s\t", fields[i].name);
    }

    printf("\n---------------------\n");

    while ((row = mysql_fetch_row(result)))
    {
      for (int i = 0; i < num_fields; ++i)
      {
        printf("%s\t", row[i] ? row[i] : "NULL");
      }

      printf("\n");
    }

    printf("---------------------\n");

    mysql_free_result(result);
  }
  else          /* no result set or error */
  {
    if (mysql_field_count(mysql) == 0)
     {
       printf("%lld rows affected\n",
            mysql_affected_rows(mysql));
     }
     else  /* some error occurred */
     {
       printf("Could not retrieve result set\n");
     }
  }
  
  status = mysql_query(mysql, "DROP TABLE test_table;");

  mysql_close(mysql);
  return 0;
}
```

修改代码中的数据库连接参数。参考如下字段，对应的值，则取自步骤一获取的数据库连接串。

* **host\_name**：取自 `-h` 参数，OceanBase 数据库连接地址，有时候是 ODP 地址。
* **user\_name**：取自 `-u` 参数，租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 `root`。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **password**：取自 `-p` 参数，用户密码。
* **db\_name**：取自 `-D` 参数，需要访问的数据库名称。
* **port\_num**：取自 `-P` 参数，OceanBase 数据库连接端口，也是 ODP 的监听端口。

### 步骤四：运行应用程序

1. 代码编辑完成后，可以通过如下命令进行编译。

   ```
   g++ -I/usr/include/mysql/ -L/usr/lib64/mysql/ -lmysqlclient mysql_test.c -o mysql_test
   ```

   选项说明：

   * `-I` 选项：指定编译器的搜索路径，以便让编译器能够找到头文件。例如将 `mysql.h` 头文件所在的目录 `/usr/include/mysql` 添加到编译器的搜索路径中，使编译器能够找到 `mysql.h` 头文件。可以使用 `find / -name mysql.h 2>/dev/null` 这个命令查找 `mysql.h` 文件路径。
   * `-L` 选项：指定动态链接库的搜索路径。
   * `-l` 选项：指定需要链接的库文件。使用 `-l` 选项时，库文件名应该去掉 `lib` 前缀和 `.so` 后缀，例如上面的命令中库文件名为 `libmysqlclient.so`，但是使用 -l 选项时只需要指定 `mysqlclient`。
2. 指定运行路径。

   ```
   export LD_LIBRARY_PATH=/usr/lib64/mysql
   ```
3. 通过如下命令运行应用程序。

   ```
   ./mysql_test
   ```

   输出结果如下，输出如下结果，说明数据库连接成功，示例语句正确执行。

   ```
   ---------------------
   id      name
   ---------------------
   20      hangzhou
   20      shanghai
   ---------------------
   ```