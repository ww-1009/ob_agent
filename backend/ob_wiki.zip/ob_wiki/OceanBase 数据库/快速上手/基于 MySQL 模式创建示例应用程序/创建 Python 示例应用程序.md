---
title: 创建 Python 示例应用程序
description: 提供关于创建 Python 示例应用程序的相关内容，
keywords: 创建 Python 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 创建 Python 示例应用程序

本文介绍如何通过 Python 驱动连接和使用 OceanBase 数据库。不同版本的 Python 环境需要使用不同的驱动，Python 3.x 系列需要使用 PyMySQL 驱动，Python 2.x 系列需要使用 MySQL-python 驱动。

## 前提条件

确保本地已部署 Python 语言运行环境。

## Python 3.x 创建应用程序

Python 3.x 创建应用程序时，需要 PyMySQL 驱动进行数据库连接及使用。

### 步骤一：获取数据库连接串

联系 OceanBase 数据库部署人员或者管理员获取相应的数据库连接串，例如：

```
obclient  -h100.88.xx.xx -uroot@test -p****** -P2881 -Doceanbase
```

数据库连接串包含了访问数据库所需的参数信息，在创建应用程序前，可通过数据库连接串验证登录数据库，保证连接串参数信息正确。

参数说明：

* **-h**：OceanBase 数据库连接 IP，有时候是一个 ODP 地址。
* **-u**：租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **-p**：用户密码。
* **-P**：OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **-D**：需要访问的数据库名称。

### 步骤二：安装 PyMySQL 驱动

PyMySQL 是在 Python3.x 版本中用于连接 MySQL 服务器的一个库。PyMySQL 遵循 Python 数据库 API v2.0 规范，并包含了 pure-Python MySQL 客户端库。

有关 PyMySQL 的详细信息，请参考 [PyMySQL 官网](https://pypi.org/project/PyMySQL/) 和 [相关 API 参考文档](https://pymysql.readthedocs.io/en/latest/modules/index.html)。

PyMySQL 有以下两种安装方式：

* 使用命令行安装

  ```
  python3 -m pip install PyMySQL
  ```
* 源码编译安装

  ```
  git clone https://github.com/PyMySQL/PyMySQL
  cd PyMySQL/
  python3 setup.py install
  ```

### 步骤三：编写应用程序

编辑运行示例 `test.py`，代码如下：

```
#!/usr/bin/python3

import pymysql

conn = pymysql.connect(host="localhost", port=2881,
                       user="root", passwd="", db="test")

cur = conn.cursor()

try:

    #创建表 cities
    sql = 'create table cities (id int, name varchar(24))'
    cur.execute(sql)

    #往 cities 表中插入两组数据
    sql = "insert into cities values(1,'hangzhou'),(2,'shanghai')"
    cur.execute(sql)

    #查询 cities 表中的所有数据
    sql = 'select * from cities'
    cur.execute(sql)
    ans = cur.fetchall()
    print(ans)

    #删除表 cities
    sql = 'drop table cities'
    cur.execute(sql)

finally:
    cur.close()
    conn.close()
```

修改代码中的数据库连接参数。参考如下字段，对应的值，则取自步骤一获取的数据库连接串。

* **user**：取自 `-u` 参数，租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **password**：取自 `-p` 参数，用户密码。
* **host**：取自 `-h` 参数，OceanBase 数据库连接地址，有时候是 ODP 地址。
* **port**：取自 `-P` 参数，OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **db**：取自 `-D` 参数，需要访问的数据库名称。

### 步骤四：运行应用程序

代码编辑完成后，运行 `test.py`。

```
python3 test.py
#返回以下结果，说明数据库连接成功，示例语句正确执行
((1, 'hangzhou'), (2, 'shanghai'))
```

## Python 2.x 创建应用程序

Python 2.x 创建应用程序时，需要 MySQL-python 驱动进行数据库连接及使用。MySQL-python 是 Python2.X 版本中用于连接数据库的一个库。

### 步骤一：获取数据库连接串

联系 OceanBase 数据库部署人员或者管理员获取相应的数据库连接串，例如：

```
obclient  -h100.88.xx.xx -uroot@test -p****** -P2881 -Doceanbase
```

数据库连接串包含了访问数据库所需的参数信息，在创建应用程序前，可通过数据库连接串验证登录数据库，保证连接串参数信息正确。

参数说明：

* **-h**：OceanBase 数据库连接 IP，有时候是一个 ODP 地址。
* **-u**：租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **-p**：用户密码。
* **-P**：OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **-D**：需要访问的数据库名称。

### 步骤二：安装 MySQL-python 驱动

MySQL-python 是 Python 连接 MySQL 数据库的接口，它实现了 Python 数据库 API 规范 V2.0，基于 MySQL C API 建立。

有关 MySQL-python 的详细信息，您可参考 [MySQL-python 官网](https://pypi.org/project/MySQL-python/) 和 [Github 文档](https://github.com/farcepest/MySQLdb1).

MySQL-python 驱动可以通过 yum 安装，命令如下：

```
yum install MySQL-python
```

### 步骤三：编写应用程序

编辑运行示例 `test2.py`，代码如下：

```
#!/usr/bin/python2

import MySQLdb

conn= MySQLdb.connect(
    host='127.0.0.1',
    port = 2881,
    user='root',
    passwd='',
    db ='test'
)


cur = conn.cursor()

try:

    #创建表 cities
    sql = 'create table cities (id int, name varchar(24))'
    cur.execute(sql)

    #往 cities 表中插入两组数据
    sql = "insert into cities values(1,'hangzhou'),(2,'shanghai')"
    cur.execute(sql)

    #查询 cities 表中的所有数据
    sql = 'select * from cities'
    cur.execute(sql)
    ans = cur.fetchall()
    print(ans)

    #删除表 cities
    sql = 'drop table cities'
    cur.execute(sql)

finally:
    cur.close()
    conn.close()
```

修改代码中的数据库连接参数。参考如下字段，对应的值，则取自步骤一获取的数据库连接串。

* **host**：取自 `-h` 参数，OceanBase 数据库连接地址，有时候是 ODP 地址。
* **user**：取自 `-u` 参数，租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **passwd**：取自 `-p` 参数，用户密码。
* **port**：取自 `-P` 参数，OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **db**：取自 `-D` 参数，需要访问的数据库名称。

### 步骤四：运行应用程序

代码编辑完成后，运行 `test.py`。

```
python test.py
#返回以下结果，说明数据库连接成功，示例语句正确执行
((1L, 'hangzhou'), (2L, 'shanghai'))
```

## 更多信息

创建 Python 3.x 示例应用程序在 OceanBase 数据库开源社区中也有相关的完整示例，详情请参考 [Python3 示例应用程序](https://github.com/oceanbase/ob-example/tree/master/examples/driver/python3-pymysql)。