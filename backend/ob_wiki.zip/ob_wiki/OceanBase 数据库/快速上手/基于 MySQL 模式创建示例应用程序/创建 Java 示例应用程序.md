---
title: 创建 Java 示例应用程序
description: 提供关于创建 Java 示例应用程序的相关内容，
keywords: 创建 Java 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 创建 Java 示例应用程序

OceanBase 数据库支持通过 MySQL 官方 JDBC 驱动连接。本文介绍了如何通过 MySQL Connector/J 连接并使用 OceanBase 数据库。

## 前提条件

* 确保计算机上的 Java 环境为 Java JDK 8 及以上版本。
* 安装 MySQL Connector/J，并配置运行环境。

  推荐使用 MySQL Connector/J 5.1.47 版本。详细的下载及安装方法，请参考 [Connector/J 下载](https://downloads.mysql.com/archives/c-j/)、[Connector/J 安装](https://dev.mysql.com/doc/connector-j/en/connector-j-installing.html)。

## 创建 Java 应用程序

### 步骤一：获取数据库连接串

联系 OceanBase 数据库部署人员或者管理员获取相应的数据库连接串，例如：

```
obclient  -h100.88.xx.xx -uroot@test -p****** -P2883 -Doceanbase
```

数据库连接串包含了访问数据库所需的参数信息，在创建应用程序前，可通过数据库连接串验证登录数据库，保证连接串参数信息正确。

参数说明：

* **-h**：OceanBase 数据库连接 IP，有时候是一个 ODP 地址。
* **-u**：租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直接连接数据库时不填集群名称，通过 ODP 连接时需要填写。
* **-p**：用户密码。
* **-P**：OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **-D**：需要访问的数据库名称。

### 步骤二：编写应用程序

下文以 Linux 中通过 Java 驱动 `Connector/J 5.1.47` 连接数据库为例。

在正确安装 MySQL Connector/J 5.1.47 驱动并配置环境之后，可以通过以下 `Test.java` 文件的示例代码进行数据库连接及使用。

#### 注意

如果是 MySQL Connector/J 8.x 版本，`Class.forName("com.mysql.jdbc.Driver")` 中的 `com.mysql.jdbc.Driver` 需要替换成 `com.mysql.cj.jdbc.Driver`。

```
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
   public static void main(String[] args) {
       try {

            Class.forName("com.mysql.jdbc.Driver").newInstance();

            try{
                
                Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:2881/test?user=r***&password=");
                System.out.println(connection.getAutoCommit());
                Statement sm = connection.createStatement();
                //新建表 t_meta_form
                sm.executeUpdate("CREATE TABLE t_meta_form (name varchar(36) , id int)");
                //插入数据
                sm.executeUpdate("insert into t_meta_form values ('an','1')");
                //查询数据，并输出结果
                ResultSet rs = sm.executeQuery("select * from t_meta_form");
                while (rs.next()) {
                    String name = rs.getString("name");
                    String id = rs.getString("id");
                    System.out.println(name + ','+ id);
                }
                //删除表
                sm.executeUpdate("drop table t_meta_form");                

            }catch(SQLException se){
                System.out.println("error!");
                se.printStackTrace() ;
            }
            }catch (Exception ex) {
                ex.printStackTrace();
        }
    }
}
```

修改代码中的数据库连接参数。参考如下字段及拼接方法，对应的值，则取自步骤一获取的数据库连接串。

```
connection = DriverManager.getConnection("jdbc:mysql://{host}:{port}/{dbname}?user={username}&password={******}")

//示例
jdbc:mysql://100.88.xx.xx:2881/test?user=r***&password=******`
```

* **host**：取自 `-h` 参数，OceanBase 数据库连接地址，有时候是 ODP 地址。
* **port**：取自 `-P` 参数，OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **dbname**：取自 `-D` 参数，需要访问的数据库名称。
* **username**：取自 `-u` 参数，租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **password**：取自 `-p` 参数，用户密码。

### 步骤三：运行应用程序

代码编辑完成后，可以通过如下命令进行编译：

```
#配置临时环境配置，根据 mysql-connector-java-5.1.47.jar 实际安装路径填写
export CLASSPATH=/usr/share/java/mysql-connector-java-5.1.47.jar:$CLASSPATH
#编译
javac Test.java
```

编译完成后，通过如下命令运行 `Test`：

```
java Test
#输出以下结果说明数据库连接成功，示例语句正确执行
true
an,1
```

## 更多信息

创建 Java 示例应用程序在 OceanBase 数据库开源社区中也有相关的完整示例，详情请参考 [Java 示例应用程序](https://github.com/oceanbase/ob-example/tree/master/examples/driver/java-mysql-connector-java)。