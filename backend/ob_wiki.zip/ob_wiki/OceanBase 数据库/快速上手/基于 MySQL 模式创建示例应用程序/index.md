# 叶子索引：基于 MySQL 模式创建示例应用程序

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [快速上手](../../index.md) / [基于 MySQL 模式创建示例应用程序](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [创建 Go 示例应用程序.md](./创建 Go 示例应用程序.md) | 提供关于创建 Go 示例应用程序的相关内容， | 创建 Go 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库 |
| [创建 Python 示例应用程序.md](./创建 Python 示例应用程序.md) | 提供关于创建 Python 示例应用程序的相关内容， | 创建 Python 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库 |
| [创建 C 示例应用程序.md](./创建 C 示例应用程序.md) | 提供关于创建 C 示例应用程序的相关内容， | 创建 C 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库 |
| [创建 Java 示例应用程序.md](./创建 Java 示例应用程序.md) | 提供关于创建 Java 示例应用程序的相关内容， | 创建 Java 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库 |
