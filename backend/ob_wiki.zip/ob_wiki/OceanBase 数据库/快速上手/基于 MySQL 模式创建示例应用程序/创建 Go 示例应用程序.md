---
title: 创建 Go 示例应用程序
description: 提供关于创建 Go 示例应用程序的相关内容，
keywords: 创建 Go 示例应用程序,OceanBase 数据库,快速上手,基于 MySQL 模式创建示例应用程序,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 创建 Go 示例应用程序

本文介绍 Go 应用程序示例如何通过驱动 Go-SQL-Driver/MySQL 连接并使用 OceanBase 数据库。

## 前提条件

确保本地已部署 Go 语言环境。

## 创建 Go 应用程序

### 步骤一：获取数据库连接串

联系 OceanBase 数据库部署人员或者管理员获取相应的数据库连接串，例如：

```
obclient  -h100.88.xx.xx -uroot@test -p****** -P2881 -Doceanbase
```

数据库连接串包含了访问数据库所需的参数信息，在创建应用程序前，可通过数据库连接串验证登录数据库，保证连接串参数信息正确。

参数说明：

* **-h**：OceanBase 数据库连接 IP，有时候是一个 ODP 地址。
* **-u**：租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直接连接数据库时不填集群名称，通过 ODP 连接时需要填写。
* **-p**：用户密码。
* **-P**：OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **-D**：需要访问的数据库名称。

### 步骤二：安装 Go-SQL-Driver/MySQL

根据 Go 语言的不同版本，可以选择不同的安装方式。

#### 通过 go get 安装（适用于Go V1.13 - V1.16）

安装命令如下：

```
go get -u github.com/go-sql-driver/mysql
```

关于 `Go-SQL-Driver/MySQL` 的详细信息，您可参考 [Github](https://github.com/go-sql-driver/mysql)。

#### 通过 go install 安装

如果由于版本或网络的原因，无法通过 `go get` 命令安装时，可通过如下方法进行 `go-sql-driver/mysql` 安装。

1. 在 `go/src` 目录克隆 github 中的 `go-sql-driver/mysql` 仓库。

   ```
   cd /usr/local/go/src   
   git clone https://github.com/go-sql-driver/mysql.git
   ```

   #### 注意

   `/usr/local/go/src` 需要替换成 Go 实际安装目录操作。
2. 通过 `go install` 进行安装。

   ```
   go install mysql
   ```

   #### 注意

   部分版本 `go install` 的默认执行目录可能不是 `/src`，可以通过 `go install` 执行后的报错判断实际目录。例如，报错 `cannot find package "mysql" in: /usr/local/go/src/vendor/mysql`，则应该将 mysql 文件夹放在 `/src/vendor` 目录下再执行安装命令。

### 步骤三：编写应用程序

将下文编写示例文件 `test.go`，代码如下：

```
package main

import (
    "database/sql"
    "fmt"
    "log"
    
    _ "mysql" 
    //填写 go-sql-driver/mysql 安装的准确路径。如果安装在 src 目录下，可以直接填 "mysql"。
)

type Str struct {
    Name       string
}

func main() {
    select_all()
    }

func select_all() {
    conn := "root:@tcp(127.0.0.1:2881)/test"
    db, err := sql.Open("mysql", conn)
    if err != nil {
        log.Fatal(err)
    }
    
    defer db.Close()
    
    if err != nil {
        log.Fatal(err)
    }
    fmt.Printf("success to connect OceanBase with go_mysql driver\n")
    //创建表 t1
    db.Query("create table t1(str varchar(256))") 
    //插入数据
    db.Query("insert into  t1 values ('Hello OceanBase')") 
    //查询数据
    res, err := db.Query("SELECT * FROM t1")
    //删除表 t1
    db.Query("drop table t1") 
    if err != nil {
        log.Fatal(err)
    }
    
    defer res.Close()
    
    if err != nil {
        log.Fatal(err)
    }
    
    for res.Next() {
        
        var str Str
        res.Scan(&str.Name)
        fmt.Printf("%s\n", str.Name)
    }
}
```

修改代码中的数据库连接参数。参考如下字段及拼接方法，对应的值，则取自步骤一获取的数据库连接串。

```
//格式
conn := "{username}:{password}@tcp({hostname}:{port})/{dbname}"
//示例
conn := "root:@tcp(127.0.0.1:2881)/test"
```

参数说明：

* **username**：取自 `-u` 参数，租户的连接用户名，格式为 **用户@租户#集群名称**，集群的默认租户是 'sys'，租户的默认管理员用户是 'root'。直连数据库时不填写集群名称，通过 ODP 连接时需要填写。
* **password**：取自 `-p` 参数，用户密码。
* **hostname**：取自 `-h` 参数，OceanBase 数据库连接地址，有时候是 ODP 地址。
* **port**：取自 `-P` 参数，OceanBase 数据库连接端口，也是 ODP 的监听端口。
* **dbname**：取自 `-D` 参数，需要访问的数据库名称。

### 步骤四：执行应用程序

代码编辑完成后，可以通过如下命令运行：

```
//配置临时环境变量，根据 Go 语言实际安装路径填写
export PATH=$PATH:/usr/local/go/bin

//通过 go run 直接运行 go 文件
go run test.go

//或者通过 go build 生成二进制文件后运行
go build test.go
./test
```

运行后返回如下内容，说明数据库连接成功，示例语句正确执行：

```
success to connect OceanBase with go_mysql driver
Hello OceanBase
```

## 更多信息

创建 Go 示例应用程序在 OceanBase 数据库开源社区中也有相关的完整示例，详情请参考 [Go 示例应用程序](https://github.com/oceanbase/ob-example/tree/master/examples/driver/golang-go-sql-driver)。