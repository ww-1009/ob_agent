# 分类索引：快速上手

> 位置：[ob_wiki](../../index.md) / [OceanBase 数据库](../index.md) / 快速上手 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **基于 MySQL 模式创建示例应用程序** | 涵盖 创建 Go 示例应用程序、创建 Python 示例应用程序、创建 C 示例应用程序、创建 Java 示例应用程序。 | `基于 MySQL 模式创建示例应用程序` `创建 Go 示例应用程序` `创建 Python 示例应用程序` `创建 C 示例应用程序` | [进入目录](./基于 MySQL 模式创建示例应用程序/index.md) |
| **基于 Oracle 模式创建示例应用程序** | 涵盖 创建 C 示例应用程序、创建 Java 示例应用程序。 | `基于 Oracle 模式创建示例应用程序` `创建 C 示例应用程序` `创建 Java 示例应用程序` | [进入目录](./基于 Oracle 模式创建示例应用程序/index.md) |
| **上手 OceanBase SQL** | 涵盖 SQL 基础操作（Oracle 模式）、SQL 基础操作（MySQL 模式）、在您开始前。 | `上手 OceanBase SQL` `SQL 基础操作（Oracle 模式）` `SQL 基础操作（MySQL 模式）` `在您开始前` | [进入目录](./上手 OceanBase SQL/index.md) |
| **体验 OceanBase 高级特性** | 下设 体验 Scalable OLTP，共 1 个子分类。 | `体验 OceanBase 高级特性` `体验 Scalable OLTP` | [进入目录](./体验 OceanBase 高级特性/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [快速入门系列教程.md](./快速入门系列教程.md) | 提供关于快速入门系列教程的相关内容， | 快速入门系列教程,OceanBase 数据库,快速上手,文档,使用帮助,OceanBase,分布式,数据库 |
| [快速体验 OceanBase 社区版.md](./快速体验 OceanBase 社区版.md) | 提供关于快速体验 OceanBase 社区版的相关内容， | 快速体验 OceanBase 社区版,OceanBase 数据库,快速上手,文档,使用帮助,OceanBase,分布式,数据库 |
