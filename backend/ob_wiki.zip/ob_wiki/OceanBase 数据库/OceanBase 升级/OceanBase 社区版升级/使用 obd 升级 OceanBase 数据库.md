---
title: 使用 obd 升级 OceanBase 数据库
description: 提供关于使用 obd 升级 OceanBase 数据库的相关内容，
keywords: 使用 obd 升级 OceanBase 数据库,OceanBase 数据库,OceanBase 升级,OceanBase 社区版升级,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-08-07T03:22:32.000+00:00
---

# 使用 obd 升级 OceanBase 数据库

本文介绍如何使用 obd 命令升级 OceanBase 数据库。

## 方案介绍

使用 obd 升级 OceanBase 数据库有以下两种方式，您可根据您的实际情况进行选择：

* 方案一：如果您的机器可以连通公网或者您配置的镜像仓库中有用于更新的 OceanBase 数据库的 RPM 包，您可参考在线升级方案升级 OceanBase 数据库，详细操作步骤请参考 **方案一：在线升级**。
* 方案二：如果您的机器不能连通公网且您配置的镜像仓库中没有用于更新的 OceanBase 数据库的 RPM 包，请先通过 `obd mirror clone` 将用于更新的 OceanBase 数据库的 RPM 包添加到本地镜像库中，或下载安装 OceanBase 数据库对应版本的 all-in-one 安装包，之后再对 OceanBase 数据库进行升级操作。详细操作步骤请参考 **方案二：离线升级**。

## 操作步骤

#### 说明

* 待升级集群租户存在备租户的情况下，您需先升级备租户所在集群，或执行 switchover 进行主备切换。
* obd 目前支持升级企业版和社区版 OceanBase 集群，本节以升级社区版 OceanBase 集群为例介绍升级 OceanBase 集群的操作。

方案一：在线升级

方案二：离线升级

1. 执行以下命令开启远程镜像仓库

   ```
   obd mirror enable remote
   ```
2. （可选）执行以下命令升级 obd 到最新版本

   ```
   obd update
   ```
3. 执行以下命令查询远程镜像仓库中 OceanBase 数据库版本

   ```
   obd mirror list oceanbase.community.stable | grep oceanbase-ce
   ```

   输出如下，最后一列字符串即为 oceanbase-ce 对应版本的 hash 值。

   ```
   | oceanbase-ce                      | 3.1.0   | 1.el7                  | x86_64 | 9decc4788a7fc6cc2082ac1668f287f60f4a3b8d05a58da094605aa2f19d18fc |
   | oceanbase-ce                      | 3.1.0   | 2.el7                  | x86_64 | 642cceea884f64860f231701351efb9a1156c46664b49a65f82806f9dab704a2 |
   | oceanbase-ce                      | 3.1.0   | 3.el7                  | x86_64 | 9a21232c8ee420f6a5dad043ee12aed2efe9796478780ea04077622300b6bac8 |
   | oceanbase-ce                      | 3.1.1   | 1.el7                  | x86_64 | 37be8ed5ea3a263a5a509f0ee553a208a3d4b63887a8c81a2efda7256e4838e9 |
   | oceanbase-ce                      | 3.1.1   | 4.el7                  | x86_64 | d94d9856ec521fe0a54f21bb2a33739c20367e8388da937fd0fcd2e54364ae96 |
   | oceanbase-ce                      | 3.1.2   | 10000392021123010.el7  | x86_64 | f38723204d49057d3e062ffad778edc1552a7c114622bf2a86fea769fbd202ea |
   | oceanbase-ce                      | 3.1.3   | 10000292022032916.el7  | x86_64 | bb5dcd5d56e84a30bfecd4173455c84952819db7c37619c1cedbb375054f1acb |
   | oceanbase-ce                      | 3.1.3   | 10100032022041510.el7  | x86_64 | 589c4f8ed2662835148a95d5c1b46a07e36c2d346804791364a757aef4f7b60d |
   | oceanbase-ce                      | 3.1.4   | 100000112022102717.el7 | x86_64 | 25b25df19e27d0844fd3d0632da010b7ac33ac454144107ca8b10d337e2f4f68 |
   | oceanbase-ce                      | 3.1.4   | 10000092022071511.el7  | x86_64 | 30a7241f8781d306dc4d008f266e9321876b1e6448bbc4aaf15ab6631b5d2715 |
   | oceanbase-ce                      | 3.1.4   | 102000012022120715.el7 | x86_64 | 033f86169a145d76499eb2730dbd49c4e657ffbacd7bd7a860522d7981a68d6d |
   | oceanbase-ce                      | 3.1.4   | 103000102023020719.el7 | x86_64 | 6980507073d6e7b91fceb9549c0e68a767f47194d961112d73106e2f26952077 |
   | oceanbase-ce                      | 3.1.5   | 100000252023041721.el7 | x86_64 | d3629804ab753a7248a9ba80fb111f6594411820000aa7b3f958cda3f8b12dd4 |
   | oceanbase-ce                      | 4.0.0.0 | 100000272022110114.el7 | x86_64 | 759074414c7b7b723013855353f62a7ba0aae0f493216ef2511825850ce77b51 |
   | oceanbase-ce                      | 4.0.0.0 | 100000282022112511.el7 | x86_64 | debb18ab3c0b3d16f145c41cd21c30686863580b721d45ddaa068e6309e03b64 |
   | oceanbase-ce                      | 4.0.0.0 | 102000032022120718.el7 | x86_64 | c63bb73384b17d74299b34fe3aceb0ae310fd319d2ccdb1acd39f31ba6673198 |
   | oceanbase-ce                      | 4.0.0.0 | 103000022023011215.el7 | x86_64 | ca467ed00a5e717f40d360ba9d08252595f4ce9de87c81e6006858fbae5755fa |
   | oceanbase-ce                      | 4.1.0.0 | 100000192023032010.el7 | x86_64 | a4a092156b5cfe6708a25813633145e0bbd75170e01e30b5c4b88fb230e10903 |
   | oceanbase-ce                      | 4.1.0.0 | 100000202023040520.el7 | x86_64 | b56ec3d6e75fd01da65abe0ebb8f8b6455d6a8563c77491ee3d19b33abc40e53 |
   | oceanbase-ce                      | 4.1.0.0 | 101000022023050809.el7 | x86_64 | fe7c4d26f18534e4116f75ddf8ecea59bfdba221e6d43c0f7ea6a24c118c3858 |
   | oceanbase-ce                      | 4.1.0.0 | 101010022023051821.el7 | x86_64 | 66882706a45d94c379dce7fd6c0b3c9c33cd780e95658d3a475029013a4b3451 |
   | oceanbase-ce                      | 4.1.0.1 | 102000042023061314.el7 | x86_64 | 126aa046ed03e191aad2481b1e4f82f43bb0017befc3b9569f4c8e215313c8ef |
   | oceanbase-ce                      | 4.1.0.2 | 103010012023082519.el7 | x86_64 | 3473fe01f6c5325a29bd325183377d102ea1f9cf1cd8bb5a0f36fac9852983cf |
   | oceanbase-ce                      | 4.2.0.0 | 100000152023080109.el7 | x86_64 | 1cbd1fde8c6d7695015265da09738478c97e0e2f908fca6745dc9cc531860e74 |
   | oceanbase-ce                      | 4.2.0.0 | 100010022023081817.el7 | x86_64 | 5cb4adf7a98754c09a82edadaf8f9485bfd6376184e4fe3109e8f607899cf8cf |
   | oceanbase-ce                      | 4.2.0.0 | 100010032023083021.el7 | x86_64 | 790596d146bd22abfbd87faf6bcacddd0d6936dafe0ff6958640bdb833256a48 |
   # 省略后续输出
   ```
4. （可选）查看集群中租户的 primary\_zone 配置

   #### 说明

   仅在升级目标版本为 V4.0.x、V4.1.x 和 V4.2.0 BETA 版本时需执行该步骤。

   使用 root 用户登录到数据库的 sys 租户，执行如下命令查看 primary\_zone 配置。

   ```
   obclient [oceanbase]> select * from __all_tenant;
   ```

   输出如下：

   ```
   +----------------------------+----------------------------+-----------+-------------+-------------------+--------------+--------+----------------+---------------+---------------------------------------------+-------------------+-----------------------+--------------------+------------------+--------+---------------+----------------------------+
   | gmt_create                 | gmt_modified               | tenant_id | tenant_name | zone_list         | primary_zone | locked | collation_type | info          | locality                                    | previous_locality | default_tablegroup_id | compatibility_mode | drop_tenant_time | status | in_recyclebin | arbitration_service_status |
   +----------------------------+----------------------------+-----------+-------------+-------------------+--------------+--------+----------------+---------------+---------------------------------------------+-------------------+-----------------------+--------------------+------------------+--------+---------------+----------------------------+
   | 2023-09-08 15:04:32.205665 | 2023-09-08 15:04:32.205665 |         1 | sys         | zone1;zone2;zone3 | RANDOM       |      0 |              0 | system tenant | FULL{1}@zone1, FULL{1}@zone2, FULL{1}@zone3 |                   |                    -1 |                  0 |               -1 | NORMAL |             0 | DISABLED                   |
   | 2023-09-08 15:13:49.119008 | 2023-09-08 15:14:09.573693 |      1001 | META$1002   | zone1;zone2;zone3 | RANDOM       |      0 |              0 |               | FULL{1}@zone1, FULL{1}@zone2, FULL{1}@zone3 |                   |                    -1 |                  0 |               -1 | NORMAL |             0 | DISABLED                   |
   | 2023-09-08 15:13:49.126607 | 2023-09-08 15:14:09.733515 |      1002 | ocp         | zone1;zone2;zone3 | RANDOM       |      0 |              0 |               | FULL{1}@zone1, FULL{1}@zone2, FULL{1}@zone3 |                   |                    -1 |                  0 |               -1 | NORMAL |             0 | DISABLED                   |
   +----------------------------+----------------------------+-----------+-------------+-------------------+--------------+--------+----------------+---------------+---------------------------------------------+-------------------+-----------------------+--------------------+------------------+--------+---------------+----------------------------+
   ```

   输出中需关注除 sys 租户外其他租户对应 primary\_zone 列的值是否为 RANDOM，若是则需执行如下命令为租户中的 Zone 配置不同的优先级。

   ```
   obclient [oceanbase]> ALTER TENANT ocp primary_zone='zone1';
   ```

   ALTER TENANT 命令的详细介绍可参见 [ALTER TENANT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501955) 一文。
5. 对 OceanBase 数据库进行合并操作

   使用 root 用户登录到数据库的 sys 租户，执行如下命令进行合并操作。

   ```
   obclient [oceanbase]> ALTER SYSTEM MAJOR FREEZE;
   ```

   执行如下命令查看是否合并完成。

   ```
   obclient [oceanbase]> select name,value from oceanbase.__all_zone where name='frozen_version' or name='last_merged_version';
   #或者
   obclient [oceanbase]> SELECT * FROM oceanbase.CDB_OB_MAJOR_COMPACTION\G
   ```

   `oceanbase.CDB_OB_MAJOR_COMPACTION` 视图的输出字段介绍可参见 [oceanbase.CDB\_OB\_MAJOR\_COMPACTION](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501173)。
6. 合并完成后，执行如下命令升级 OceanBase 数据库

   ```
   obd cluster upgrade obtest -c oceanbase-ce -V 4.2.0.0 --usable=790596d146bd22abfbd87faf6bcacddd0d6936dafe0ff6958640bdb833256a48
   ```

   此处以部署集群名为 obtest，目标升级版本为 4.2.0 为例，您需根据实际部署集群名及目标升级版本进行替换。本步骤中所用命令详细介绍请参见 [集群命令组](https://www.oceanbase.com/docs/common-obd-cn-1000000003415263) 中 `obd cluster upgrade` 命令。
7. 验证是否升级成功

   使用 root 用户登录 OceanBase 数据库的 sys 租户，执行如下命令查看数据库版本。

   ```
   obclient [oceanbase]> SELECT version();
   ```

1. 配置 RPM 包

   您可通过 `obd mirror clone` 将用于更新的 OceanBase 数据库的 RPM 包添加到本地镜像库中，或下载安装 OceanBase 数据库对应版本的 all-in-one 安装包两种方式配置 OceanBase 数据库的 RPM 包。

   * 方法一：从 GitHub 仓库中的 [releases note](https://github.com/oceanbase/oceanbase/releases) 或者 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 获取所需 OceanBase 数据库和对应依赖库的 RPM 包，并将 RPM 包复制到安装 obd 的机器中，在 RPM 包所在目录下执行如下命令将下载好的安装包加入到本地镜像仓库中。

     ```
     obd mirror clone oceanbase-ce-*.rpm
     ```
   * 方法二：从 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 下载所需 OceanBase 数据库对应版本的 all-in-one 安装包，并将安装包复制到安装 obd 的机器中，执行如下命令解压并安装。

     #### 注意

     您需使用部署 OceanBase 数据库时所用的主机账号（比如 admin）安装 all-in-one 安装包。

     ```
     [admin@test001 ~]$ tar -xzf oceanbase-all-in-one-*.tar.gz
     [admin@test001 ~]$ cd oceanbase-all-in-one/bin/
     [admin@test001 bin]$ ./install.sh
     [admin@test001 bin]$ source ~/.oceanbase-all-in-one/bin/env.sh
     ```
2. 执行如下命令关闭远程镜像仓库

   ```
   obd mirror disable remote
   ```
3. 执行如下命令查询本地镜像仓库中 OceanBase 数据库版本

   ```
   obd mirror list local | grep oceanbase-ce
   ```

   输出如下，最后一列字符串即为 oceanbase-ce 对应版本的 hash 值。

   ```
   | oceanbase-ce      | 4.1.0.1 | 102000042023061314.el7 | x86_64 | d03fafa6fa8ceb0636e4db05b5b5f6c3ac2256a3 |
   | oceanbase-ce-libs | 4.1.0.1 | 102000042023061314.el7 | x86_64 | c3f797aae1ce258ec9be77898b94e4e7a501cd0f |
   | oceanbase-ce      | 4.2.0.0 | 100010022023081817.el7 | x86_64 | bf178e82c99ca1324a3df9e1a21cbbb8f8c4d46c |
   | oceanbase-ce-libs | 4.2.0.0 | 100010022023081817.el7 | x86_64 | f77ba7e678acf0645889967391c847ca9cf684b6 |
   ```
4. （可选）查看集群中租户的 primary\_zone 配置

   #### 说明

   仅在升级目标版本为 V4.0.x、V4.1.x 和 V4.2.0 BETA 版本时需执行该步骤。

   使用 root 用户登录到数据库的 sys 租户，执行如下命令查看 primary\_zone 配置。

   ```
   obclient [oceanbase]> select * from __all_tenant;
   ```

   输出如下：

   ```
   +----------------------------+----------------------------+-----------+-------------+-------------------+--------------+--------+----------------+---------------+---------------------------------------------+-------------------+-----------------------+--------------------+------------------+--------+---------------+----------------------------+
   | gmt_create                 | gmt_modified               | tenant_id | tenant_name | zone_list         | primary_zone | locked | collation_type | info          | locality                                    | previous_locality | default_tablegroup_id | compatibility_mode | drop_tenant_time | status | in_recyclebin | arbitration_service_status |
   +----------------------------+----------------------------+-----------+-------------+-------------------+--------------+--------+----------------+---------------+---------------------------------------------+-------------------+-----------------------+--------------------+------------------+--------+---------------+----------------------------+
   | 2023-09-08 15:04:32.205665 | 2023-09-08 15:04:32.205665 |         1 | sys         | zone1;zone2;zone3 | RANDOM       |      0 |              0 | system tenant | FULL{1}@zone1, FULL{1}@zone2, FULL{1}@zone3 |                   |                    -1 |                  0 |               -1 | NORMAL |             0 | DISABLED                   |
   | 2023-09-08 15:13:49.119008 | 2023-09-08 15:14:09.573693 |      1001 | META$1002   | zone1;zone2;zone3 | RANDOM       |      0 |              0 |               | FULL{1}@zone1, FULL{1}@zone2, FULL{1}@zone3 |                   |                    -1 |                  0 |               -1 | NORMAL |             0 | DISABLED                   |
   | 2023-09-08 15:13:49.126607 | 2023-09-08 15:14:09.733515 |      1002 | ocp         | zone1;zone2;zone3 | RANDOM       |      0 |              0 |               | FULL{1}@zone1, FULL{1}@zone2, FULL{1}@zone3 |                   |                    -1 |                  0 |               -1 | NORMAL |             0 | DISABLED                   |
   +----------------------------+----------------------------+-----------+-------------+-------------------+--------------+--------+----------------+---------------+---------------------------------------------+-------------------+-----------------------+--------------------+------------------+--------+---------------+----------------------------+
   ```

   输出中需关注除 sys 租户外其他租户对应 primary\_zone 列的值是否为 RANDOM，若是则需执行如下命令为租户中的 Zone 配置不同的优先级。

   ```
   obclient [oceanbase]> ALTER TENANT ocp primary_zone='zone1';
   ```

   ALTER TENANT 命令的详细介绍可参见 [ALTER TENANT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501955) 一文。
5. 对 OceanBase 数据库进行合并操作

   使用 root 用户登录到数据库的 sys 租户，执行如下命令进行合并操作。

   ```
   obclient [oceanbase]> ALTER SYSTEM MAJOR FREEZE;
   ```

   执行如下命令查看是否合并完成。

   ```
   obclient [oceanbase]> select name,value from oceanbase.__all_zone where name='frozen_version' or name='last_merged_version';
   #或者
   obclient [oceanbase]> SELECT * FROM oceanbase.CDB_OB_MAJOR_COMPACTION\G
   ```

   `oceanbase.CDB_OB_MAJOR_COMPACTION` 视图的输出字段介绍可参见 [oceanbase.CDB\_OB\_MAJOR\_COMPACTION](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501173)。
6. 合并完成后，执行如下命令升级 OceanBase 数据库

   ```
   obd cluster upgrade obtest -c oceanbase-ce -V 4.2.0.0 --usable=bf178e82c99ca1324a3df9e1a21cbbb8f8c4d46c
   ```

   此处以部署集群名为 obtest，目标升级版本为 4.2.0 为例，您需根据实际部署集群名及目标升级版本进行替换。本步骤中所用命令详细介绍请参见 [集群命令组](https://www.oceanbase.com/docs/common-obd-cn-1000000003415263) 中 `obd cluster upgrade` 命令。
7. 验证是否升级成功

   使用 root 用户登录 OceanBase 数据库的 sys 租户，执行如下命令查看数据库版本。

   ```
   obclient [oceanbase]> SELECT version();
   ```