# 叶子索引：OceanBase 社区版升级

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [OceanBase 升级](../../index.md) / [OceanBase 社区版升级](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [使用 obd 升级 OceanBase 数据库.md](./使用 obd 升级 OceanBase 数据库.md) | 提供关于使用 obd 升级 OceanBase 数据库的相关内容， | 使用 obd 升级 OceanBase 数据库,OceanBase 数据库,OceanBase 升级,OceanBase 社区版升级,文档,使用帮助,OceanBase,分布式,数据库 |
