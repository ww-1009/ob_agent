# 分类索引：OceanBase 升级

> 位置：[ob_wiki](../../index.md) / [OceanBase 数据库](../index.md) / OceanBase 升级 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **OceanBase 企业版升级** | 涵盖 升级概述、升级后检查、升级仲裁服务、升级 OceanBase 集群。 | `OceanBase 企业版升级` `升级概述` `升级后检查` `升级仲裁服务` | [进入目录](./OceanBase 企业版升级/index.md) |
| **OceanBase 社区版升级** | 涵盖 使用 obd 升级 OceanBase 数据库。 | `OceanBase 社区版升级` | [进入目录](./OceanBase 社区版升级/index.md) |
