---
title: What's New
description: 提供关于What's New的相关内容，
keywords: What's New,OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-16T05:09:50.000+00:00
---

# What's New

OceanBase 数据库 V4.2.5 版本是面向 TP/KV 的全新 LTS 版本。新版本完成了 MySQL 5.7 全面兼容的目标，使得更多 MySQL 三方生态工具可以无缝适配，也会让云上 RDS 应用迁移到 OB 变的更加平顺。

在兼容性方面，OceanBase 数据库 MySQL 租户下新增支持了表锁和锁函数、XA 事务、兼容 MySQL 非法日期，并兼容了一批管理语句、系统变量和系统视图；OceanBase 数据库 Oracle 租户下，完善了 DBMS\_LOCK 包、支持快速删列，同时 OB-Oracle 租户间的存储过程远程调用支持了复杂类型。

在易用性方面，OceanBase 数据库全面增强等待事件框架，重构统计监控框架，新增资源组级别统计视图，ASH 诊断报告新增行锁等待和重试等待事件，覆盖更多场景。提供响应时间直方图、日志传输链路视图等提升系统的可观测性。优化系统日志，新增 alert.log 用于记录 DBA 关注的日志信息。同时 OBKV 推出了全新的 OBKV-Redis 兼容形态，兼容 Redis 协议，提供了成本低廉的键值缓存服务。该形态进一步丰富了产品线，可用于 PoC。OBKV-HBase 的兼容性和性能都有提升。

在稳定性方面，优化 DDL 执行、统计信息采集等的资源管控。支持对单条 SQL 的执行内存进行限制。OBCDC 同步备租户，减小对主库产生的影响。与 ODP 配合支持了全局唯一的会话 ID，解决了长久以来会话 ID 不唯一导致的极端情况下 kill session 不准确的难题。增强高可用能力，支持双机房 2F+2F+1A 部署时，少数派所在机房强制拉起。

有关 V4.2.5 版本全量的新功能、能力增强以及产品行为变更、使用限制等信息，可以查看 V4.2.5 版本 [Release Notes](https://www.oceanbase.com/product/oceanbase-database-rn/releaseNote#V4.2.5)。

以下为新版本迭代的主要内容。

## 高性能内核

* **全局索引绑定主表 sharding = none 表组**

  对于和全局索引相关的 DDL 操作如 `create table`、`create table like`、`create index`、`alter table add index`、`truncate table`、`truncate partition` 等，如果主表在 `sharding = none` 的表组，强制要求全局索引表的分布和主表一致。同时如果通过 `alter table` 语句将主表放进了 `sharding = none` 的表组，则全局索引表会绑定主表进行表组对齐。相关文档参见 [全局索引](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502948)。
* **自适应连接功能（Adaptive Join）**

  引入自适应连接（Adaptive Join, AJ）功能，该功能允许数据库在执行期间动态地选择最合适的连接方法，而非完全依赖事先的统计信息。
* **优化器估行系统改进**

  对估行系统进行了强化，提升了估行系统在部分场景下的准确性：

  + 通过界定包含多种类型的连接条件或涉及多张表的环状连接等复杂连接的选择率下界，设定当 INNER/OUTER JOIN 的连接条件复杂时，小表的每一行都至少连接大表一行，即选择率不低于大表当前行数分之一，解决环状连接估行过小的问题。
  + 通过修正连接在 filter 后的行数，提高连接行数估算的准确性。
  + 对于带有谓词过滤的基于 `t1` 和 `t2` 的 ANTI JOIN 查询，对于t1上的谓词带有较强过滤性的场景，将基于简单包含的假设调整为基础包含假设，提升该场景下的估行准确性。

  相关文档参见 [并行执行分类与优化](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500468)。
* **弱读能力扩展**

  支持弱读事务持有统一的快照，保证事务内的弱读读到的版本一致，从而支持在 Repeatable Read 和 Serializable 隔离级别下执行弱读请求。
* **DBLink 能力增强**

  OceanBase 数据库支持域名解析及 Binary 数据远端写能力。通过 DBLink 访问远端数据库，V4.2.5 增加支持配置域名地址。同时 DBLink 具备了写 Binary 数据到远端的能力。相关文档参见 [通过 DBLink 访问远端数据库中的数据](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501879)。
* **severless 优化**

  为了更好的适配 severless 架构，V4.2.5 数据库做了三个专项优化：

  + Meta 租户和用户租户内存共享。解决大规格租户 Meta 内存不够用、小规格租户 Meta 租户内存利用率低的问题。
  + 常用线程池 ObSimpleThreadPool 支持动态创建线程。线程数从静态设置方式更改为根据请求队列自适应增加或减少，同时将部分后台线程池修改为使用该线程池。
  + 线程局部内存精简。通过去除不必要的线程局部变量、降低局部变量的内存占用，最小化局部变量的生命周期等措施降低线程局部内存使用。
* **分布式晚期物化**

  晚期物化是单表查询满足有索引可以同时进行过滤条件、排序和 Limit 计算时，回查主表时就不再进行索引回表后的排序和 Limit 计算。
* **SQL Query Interface 增强**

  实现只读副本访问隔离功能。该功能主要定义了内部的数据请求路由规则，该规则严格禁止将发送到只读副本中的请求转发到非只读副本，从而实现 TP 和 AP 的资源隔离，保证 HTAP 场景下的长期稳定运行，非只读请求的副本路由不受该规则的限制。同时，对 SQL 协议结果集元数据信息构建进行了改造，OBServer 服务端基于租户兼容模式，获取服务器端元数据。JDBC 侧根据获取的服务端元数据，正确推导出 JDBC 侧元数据，进而服务于用户的元数据访问请求。
* **锁冲突管理增强**

  优化本地执行锁冲突管理，解除对兜底唤醒机制的依赖，消除不必要的等待延迟。
* **日志流副本迁移优化**

  对无意义的迁移进行了优化，日志流副本迁移过程中，如果发现有无需再执行的副本迁移任务，则自动取消，减少无用功，提升副本迁移效率。
* **消费日志支持强关归档**

  支持强关归档功能，不强制要求写入结束归档元信息，也可将归档任务状态推进到 STOP。相关文档参见 [关闭归档模式](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499889)。
* **全局唯一 Client Session ID**

  重构 Client Session ID 生成和维护流程，在 OBServer 版本不低于 V4.2.5 且 ODP 版本不低于 V4.2.3 BP1 时，通过各种渠道如 SHOW PROCESSLIST 命令、`information_schema.PROCESSLIST` 或 `GV$OB_PROCESSLIST` 等视图、`CONNECTION_ID`、`userenv('sid')`/`userenv('sessionid')`、`sys_context('userenv','sid')`/`sys_context('userenv','sessionid')` 等表达式，查询到的会话 ID 均为 Client 端会话 ID，用户可通过指定 SQL 或 PL 中的 kill 命令来管理用户端会话。
* **OBCDC 能力增强**

  强化 OBCDC 能力，主要包含如下功能支持：

  + 完善行外 LOB 数据的前镜像输出。
  + 优化 OBCDC 对事务日志的存储结构，重构回拉日志框架。
  + 支持表级恢复出来的表的新产生数据的同步。
  + 补齐同步虚拟生成列的能力，满足下游系统消费虚拟列数据的需求。
* **OBCDC 同步备租户**

  支持从备租户同步数据，解决如下场景的需求：

  + 消费本地数据库数据的需求。
  + 主备租户切换后消费备租户数据。
  + 通过消费备租户减小对主租户可能产生的影响，保障主租户的业务稳定性。
* **基线优先的 SPM 演进**

  新增优先使用基线计划的 SPM 演进模式。在这个模式下优化器总是会使用基线计划，除非所有的基线都无法还原。在这个模式下，所有的基线都会被认为是 Fixed。

## 更高的兼容性

### MySQL 兼容

* **锁函数**

  兼容了 MySQL `GET_LOCK`、`IS_FREE_LOCK`、`IS_USED_LOCK`、`RELEASE_ALL_LOCKS`、`RELEASE_LOCK` 等锁相关的表达式。相关文档参见 [锁函数概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504332)。
* **表锁能力**

  支持了 [LOCK TABLE](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001503349) 和 [UNLOCK TABLE](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001503270) 语法。
* **MySQL 非法日期类型兼容**

  新增对非法日期类型的兼容，允许通过 `sql_mode` 来控制是否允许存储非法日期类型。
* **中间快速加列**

  将中间加列的 DDL 操作从 OFFLINE DDL 改为 ONLINE DDL，提升了中间加列的性能。
* **XA 事务支持**

  兼容了 XA 事务语法，主要包含 XID、XA START、XA END、XA PREPARE、XA COMMIT、XA ROLLBACK 和 XA RECOVER 语句的兼容。
* **字符集完善**

  兼容 MYSQL 的日语字符集 `SJIS`、`UTF16LE` 字符集、`DEC8` 字符集以及 `BIG5` 字符集及相关字符序的支持。同时补充了 `UTF8`/`UTF16` UCA 字符序和 UCA 9.0 相关字符序。相关文档参见 [字符集](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504207)。

### Oracle 兼容

* **DBMS\_LOCK 完善**

  补充支持 `RELEASE` 及 `REQUEST(release_on_commit = FALSE)` 子程序，用于支撑手动释放锁和会话级锁需求。
* **Oracle 租户间存储过程远程调用支持复杂类型参数**

  扩展 OB-Oracle 租户间的存储过程远程调用对复杂类型参数的支持。

## OBKV 增强

* **OBKV-HBase 过期删除优化**

  对过期删除功能进行了优化，提升 "热 Key" 场景(较短时间内累计的大量的过期版本的数据)下的查询性能。
* **OBKV-HBase 支持 ColumnPaginationFilter**

  新增 ColumnPaginationFilter 过滤器，该过滤器用于限制返回列数，从指定的列开始，返回指定数量的列的最新版本的数据，常用于列分页。
* **OBKV-HBase 支持 Reverse Scan**

  支持 Reverse Scan 功能，该功能允许用户以 Rowkey 逆序（从大到小）扫描表中的数据，这与常规的正序（从小到大）扫描顺序相反。HBase 的数据是按照 RowKey（行键）排序存储的，因此 Reverse Scan 功能特别适用于需要按照 RowKey 降序访问数据的场景。
* **新增 OBKV-Redis 接口模型**

  OB-Redis 通过将数据持久化存储，降低了业务的成本，并提供了事务能力，保证数据的一致性，可以满足用户 80% 场景的 RT 和吞吐。
* **OBKV 性能优化**

  优化组提交功能，新增 INSERT、DELETE、REPLACE、UPDATE、INSERTUP、INCREMENT/APPEND 的支持。

## 性能提升

* **表级恢复性能优化**

  对表级恢复的跨租户导表阶段，对主表补数据和索引创建阶段进行了并行优化，相关文档参见 [表级恢复](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499859)。
* **升级流程性能优化**

  优化升级过程中 `post_upgrade` 的性能，优化后平均每个租户的升级耗时是优化前的十分之一左右。
* **DML 性能优化**

  对 `insert ... values ... on duplicate key update ...` 和 `replace ... values ...` 两类语句，支持 multi query 场景下的 batch 处理，提升 DML 执行性能。同时 merge into 语句更新 unique key 支持 PDML，提升大数据量下场景下的执行效率。
* **快速删列功能优化**

  支持将删列操作从真正删除变更为标记删除，从 OFFLINE DDL 优化为 online DDL，极大提升了删列性能。

## 资源优化

* **DDL 资源隔离**

  将 DDL 所使用的工作线程与其他请求使用的工作线程进行分离，在 DDL 同步等待时，对占住的工作线程进行补充，避免其他任务因为大量 DDL 导致没有工作线程可用，提升系统稳定性。相关文档参见 [配置租户内资源隔离](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502716)。
* **统计信息及 clog 日志提交接入资源隔离**

  将统计信息收集及 CLOG 日志提交接入资源隔离，进一步强化了 OceanBase 的资源隔离机制，降低了后台任务对前台用户请求造成影响。相关文档参见 [配置租户内资源隔离](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502716)。
* **SQL 内存使用限制**

  支持追踪单条 SQL 查询过程中的内存使用情况，当内存使用超过一定阈值后也能采取一些操作，如报错终端执行或打印 WARN 日志提醒。相关文档参见 [内存控制](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499972)。
* **存储过程内存优化**

  将存储过程中使用的通用内存分配器替换为定制的存储过程内存分配器，不仅可以实现主动释放内存，还缩短存储过程内存生命周期。同时优化了符号表设计、基础类型的内存使用、record 和数组复杂类型内存管理、表达式内存管理等逻辑，解决了多种场景的内存堆积问题、提升了存储过程内存使用的稳定性，同时提升了部分表达式计算的性能。

## 更高的可靠性

* **Transfer 搬迁活跃事务**

  支持 Transfer 搬迁活跃事务的能力, 允许活跃事务并发执行, 并保证并发事务不会因为 Transfer 导致异常回滚或产生一致性问题。
* **基于 IO 负载的自适应仲裁升降级**

  仲裁服务实现了基于 IO 负载的日志盘故障探测算法，能更有效地探测到云盘故障并执行仲裁降级，避免云盘故障持续影响业务请求。新增集群级配置项 [log\_storage\_warning\_trigger\_percentage](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502362) 用于控制触发日志盘故障的写入性能百分比阈值。
* **配置项及租户资源配置支持备份**

  支持集群级以及租户级配置项的备份，同时也支持备份租户的资源配置信息以及副本分布信息。相关文档参见 [备份配置项](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499896)。

## 更高的易用性

* **日志流副本并行迁移优化**

  支持一个日志流在不同 zone 上的副本可以并行迁移，可以加快扩缩容速度、提升负载均衡效率以及降低备库副本 rebuild 概率。
* **ASH 诊断新增行锁等待事件及重试等待事件**

  ASH 通过新增行锁等待时间统计，并借助 blocking session 实现等待环，补齐行锁链性能诊断能力。同时新增重试等待事件统计，并对不同的等待事件进行区分，包括：`LOCATION` 类、`SCHEMA` 类、`SQL` 类、`STORAGE` 类、`TX` 类和其他。
* **响应时间统计直方图**

  增加响应时间直方图功能，可基于 [GV$OB\_QUERY\_RESPONSE\_TIME\_HISTOGRAM](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501586) 和 [V$OB\_QUERY\_RESPONSE\_TIME\_HISTOGRAM](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501625) 系统视图计算和监控不同类型 SQL 的 P99/P95 之类的响应时间统计。
* **优化统计监控能力**

  重构统计监控框架。新框架记录所有数据库在执行过程中产生的诊断数据，并以合理的形式储存产生的诊断数据，供用户以不同的形式查询（tenant、group、session），同时控制诊断框架的内存、CPU 开销在合理水位，不阻塞、不影响正常的数据库任务。
* **系统日志优化**

  系统日志目录下，新增 `./alert/alert.log` 日志文件，用于记录 DBA 关注的日志信息，初步解决 `observer.log` 日志量大、可读性差的问题。可通过 `alert_log_level` 集群级配置项设置日志级别，包括 INFO、WARN、ERROR 等。同时提供了用于直接结构化查询 [alert.log](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499552) 日志信息。
* **动态修改 OBServer 内存资源规格实时生效**

  动态修改 OBServer 内存资源规格由之前的重启生效优化为实时生效，提升了弹性伸缩能力。
* **SPM 演进信息落盘及支持基线导入导出**

  新增视图 `DBA_OB_SPM_EVO_RESULT` 用于记录 SPM 演进任务结果的细节。此外，使用 `dbms_spm` 包的存储过程实现通过中间表导入导出 SPM 基线，包括创建基线缓存表 `DBMS_SPM.CREATE_STGTAB_BASELINES`、导出基线到缓存表 `DBMS_SPM.PACK_STGTAB_BASELINES`、从缓存表中导入基线 `DBMS_SPM.UNPACK_STGTAB_BASELINES` 的功能。同时为了便于跨租户迁移，额外支持了通过 CSV 文件导入导出基线，包括导出基线到 CSV 文件 `DBMS_SPM.PACK_CSV_BASELINES`、从 CSV 文件导入基线 `DBMS_SPM.UNPACK_CSV_BASELINES`。