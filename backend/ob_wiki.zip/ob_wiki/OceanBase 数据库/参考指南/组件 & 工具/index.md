# 分类索引：组件 & 工具

> 位置：[ob_wiki](../../../index.md) / [OceanBase 数据库](../../index.md) / [参考指南](../index.md) / 组件 & 工具 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **监控诊断** | 下设 sql_diagnoser，共 1 个子分类。 | `监控诊断` `sql_diagnoser` | [进入目录](./监控诊断/index.md) |
| **数据集成** | 下设 obcdc，共 1 个子分类。 | `数据集成` `obcdc` | [进入目录](./数据集成/index.md) |
| **运维管理** | 下设 ob_admin、obshell，共 2 个子分类。 | `运维管理` `ob_admin` `obshell` | [进入目录](./运维管理/index.md) |
