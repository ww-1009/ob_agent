---
title: obdiag
description: 提供关于obdiag的相关内容，
keywords: obdiag,OceanBase 数据库,参考指南,组件 & 工具,监控诊断,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# obdiag

OceanBase 数据库是原生分布式数据库系统，故障根因分析通常是比较繁琐的，因为涉及的因素可能有很多，如机器环境、配置参数、运行负载等等。专家在排查问题的时候需要获取大量的信息来分析故障，如何高效的采集和分析故障场景下分散在各个节点的信息，便是 obdiag（OceanBase Diagnostic Toolkit，即 OceanBase 敏捷诊断工具）需要解决的问题。obdiag 代码完全开源，[GitHub 代码仓库](https://github.com/oceanbase/oceanbase-diagnostic-tool)。

## 什么是 obdiag

obdiag 是一款适用于 OceanBase 数据库的黑屏诊断工具，obdiag 现有功能包含了对于 OceanBase 数据库日志、SQL Audit 以及 OceanBase 数据库进程堆栈等信息进行的扫描、收集和分析，可以在 OceanBase 集群不同的部署模式下（OCP，obd 或用户根据文档手工部署）实现一键执行，完成诊断信息的收集和分析。

## obdiag 功能特点

* obdiag 具有以下功能特点：

  + 一键集群巡检：obdiag 可支持黑屏命令行一键巡检，发现已存在或可能会导致集群出现异常问题的原因分析并提供运维建议。
  + 一键信息收集：obdiag 可支持黑屏命令行一键收集散落在各个节点上的诊断信息，打包回传到 obdiag 机器上。
  + 一键诊断分析：obdiag 可支持黑屏命令行一键对 OceanBase 的日志进行分析，找出发生过的错误信息，同时还支持基于 trace.log 的一键全链路追踪。

## obdiag 版本发布记录

详情参见 [OceanBase 敏捷诊断工具 Release Note](https://www.oceanbase.com/product/obdiag-rn/releaseNote)

## obdiag 文档

关于 OceanBase 诊断工具的详细介绍和使用指导，可以查看 [OceanBase 敏捷诊断工具文档](https://www.oceanbase.com/docs/obdiag-cn)。