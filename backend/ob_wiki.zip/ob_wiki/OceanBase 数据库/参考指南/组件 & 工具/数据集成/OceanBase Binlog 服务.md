---
title: OceanBase Binlog 服务
description: 提供关于OceanBase Binlog 服务的相关内容，
keywords: OceanBase Binlog 服务,OceanBase 数据库,参考指南,组件 & 工具,数据集成,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase Binlog 服务

OceanBase Binlog 服务（OceanBase Binlog Service，简称 Binlog 服务）能收集 OceanBase 数据库的事务日志，并将其转换为 MySQL Binlog，主要用于实时数据订阅等场景。

## 涉及组件

OceanBase Binlog 服务主要由以下三部分组成：

* OceanBase 数据库：需要生成 Binlog 日志的业务数据库。
* OceanBase 数据库代理：业务数据库的 ODP（也称 OBProxy），由它为订阅 Binlog 的客户端提供连接服务。
* OceanBase Binlog 工具：OceanBase Binlog 服务的核心组件 obbinlog（原 oblogproxy），由它完成拉取 clog 和生成 Binlog 日志的操作。

## Binlog 服务文档

关于 Binlog 服务的详细介绍和使用指导，可参见官网 [《OceanBase Binlog 服务》](https://www.oceanbase.com/docs/oblogproxy-doc) 文档。