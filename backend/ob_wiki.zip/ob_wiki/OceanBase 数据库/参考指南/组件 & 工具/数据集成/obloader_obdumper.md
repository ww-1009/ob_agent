---
title: obloader_obdumper
description: 提供关于obloader/obdumper的相关内容，
keywords: obloader/obdumper,OceanBase 数据库,参考指南,组件 & 工具,数据集成,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# obloader/obdumper

## 什么是 obloader

obloader（OceanBase Loader，即 OceanBase 导入工具）是一款使用 Java 语言开发的客户端工具，目前该工具仅适用于 OceanBase 数据库。用户可以将存储介质中的数据库对象的定义文件和表数据文件导入到 OceanBase 数据库中。

通常我们推荐 obloader 与 obdumper 搭配使用。如果用户希望借助于 obloader 完成数据迁移工作，它也兼容 mysqldump，Mydumper 等客户端工具导出的 CSV 格式的文件。

obloader 专门优化了数据的导入性能，内置多种数据预处理函数，自动容错保证数据导入的稳定性，以及提供较为丰富的监控信息，以便于用户实时观测到数据文件导入的性能和进度。

obloader 主要具备以下功能特性：

* 支持从本地磁盘、Apache Hadoop、Aliyun OSS 或者 AWS S3 导入数据库对象定义和表数据。
* 支持导入 mysqldump 导出的 SQL-Format 格式的文件。
* 支持导入标准的 CSV、Insert SQL、ORC、Parquet 等格式的数据文件。
* 支持配置数据预处理的控制规则以及文件与表之间的字段映射关系。
* 支持导入限速、防导爆、断点恢复和错误自动重试。
* 支持指定自定义的日志目录，导入时可以保存坏数据和冲突数据。
* 支持导入工具自动对大文件进行切分且不占用额外的存储空间，无需人工切分文件。
* 支持对命令行中指定的敏感参数进行加密。包括：数据库的账号密码，云存储的账号密钥。

## 什么是 obdumper

obdumper（OceanBase Dumper，即 OceanBase 导出工具）是一款使用 Java 语言开发的客户端工具，目前该工具仅适用于 OceanBase 数据库。用户可以使用该工具将 OceanBase 数据库中定义的对象和表数据以指定的文件格式导出到存储介质中。如果用户希望借助于 obdumper 进行逻辑备份，可以直接将该工具集成到数据库运维系统中。

#### 说明

obdumper 暂不支持增量备份。

与 mysqldump 等客户端导出工具相比，obdumper 具备以下显著的优势：

* 快速的数据导出能力，设计了多种数据查询策略，大幅提升导出的性能。
* 丰富的数据交换能力，支持将表中数据以多种格式导出到多种存储介质。
* 强大的数据处理能力，导出前对数据进行压缩，加密，脱敏，预处理等。

obdumper 主要具备以下功能特性：

* 支持导出数据库对象定义和表数据到本地磁盘，Aliyun OSS 和 AWS S3。
* 支持将表中的数据按照 CSV、Insert SQL、ORC、Parquet 等格式导出到文件中。
* 支持指定分区名，仅导出指定的表分区内的数据。
* 支持指定全局的过滤条件，仅导出满足条件的数据。
* 支持配置数据预处理规则，导出前对数据进行转换、脱敏等预处理。
* 支持指定 SCN 或者 TIMESTAMP，仅导出有效事务点或者时间点的历史快照数据。
* 支持从 OceanBase 数据库的备副本（注：区别于备集群）中导出数据。
* 支持指定自定义的查询语句，仅导出该查询语句的结果集。
* 支持通过最新的快照版本以不锁表的方式导出全局一致的数据。
* 支持对命令行中指定的敏感参数进行加密。包括：数据库的账号密码，云存储的账号密钥。