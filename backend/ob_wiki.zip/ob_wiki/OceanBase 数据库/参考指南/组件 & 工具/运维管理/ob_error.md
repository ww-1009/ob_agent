---
title: ob_error
description: 提供关于ob_error的相关内容，
keywords: ob_error,OceanBase 数据库,参考指南,组件 & 工具,运维管理,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# ob\_error

`ob_error` 是 OceanBase 数据库的一个错误码解析工具，`ob_error` 可以根据您输入的错误码返回相对应的原因和解决方案。在 `ob_error` 的帮助下，您无需查找文档即可获取基本的错误信息。

## 安装 ob\_error

### 通过 YUM 命令安装

您可以通过 YUM 命令直接安装工具集成包（OceanBase Utils），进行 ob\_error 的使用。

```
yum-config-manager --add-repo https://mirrors.aliyun.com/oceanbase/OceanBase.repo
yum install oceanbase-ce-utils
```

### 通过 OceanBase Utils 安装包

您可以通过安装工具集成包（OceanBase Utils），进行 ob\_error 的使用。

1. 访问 [OceanBase 软件下载中心](https://www.oceanbase.com/softwarecenter) 页面，搜索 `OceanBase Utils`，下载需要的版本到本地。
2. 在文件目录里执行以下命令安装 OceanBase Utils。

   ```
   rpm -ivh  oceanbase-ce-utils-<version>
   ```

   如果您只需要 `ob_error`，可使用 `rpm2cpio` 命令来获取 `ob_error`。

   ```
   rpm2cpio oceanbase-ce-utils-<version> | cpio -idmv ./usr/bin/ob_error
   cp usr/bin/ob_error /usr/local/bin
   ```

### 通过源码编译

您可通过 OceanBase 数据库的源码自行编译。

1. 克隆 [OceanBase 数据库](https://github.com/oceanbase/oceanbase) 的开源代码到本地。

   ```
   git clone https://github.com/oceanbase/oceanbase
   ```
2. 两种模式编译 ob\_error。

   * Debug 模式

     ```
     bash build.sh debug --init
     cd build_debug
     make ob_error
     cp tools/ob_error/src/ob_error /usr/local/bin
     ```

     `ob_error` 的编译产物默认存储在 `DEBUG_BUILD_DIR/tools/ob_error/src/ob_error` 中。其中，`DEBUG_BUILD_DIR` 表示编译目录，在本示例中是 `build_debug`。
   * Release 模式

     ```
     bash build.sh release --init
     cd build_release
     make ob_error
     cp tools/ob_error/src/ob_error /usr/local/bin
     ```

     `ob_error` 的编译产物默认存储在 `RELEASE_BUILD_DIR/tools/ob_error/src/ob_error` 中。其中，`RELEASE_BUILD_DIRR` 表示编译目录，在本示例中是 `build_release`。

## 如何使用

### 通用查询格式

您只需要输入错误码就可以得到与操作系统、Oracle 模式、MySQL 模式和 OceanBase 数据库中存在的错误相对应的错误信息。例如：

```
$ob_error 4001
OceanBase:
    OceanBase Error Code: OB_OBJ_TYPE_ERROR(-4001)
    Message: Object type error
    Cause: Internal Error
    Solution: Contact OceanBase Support
Oracle:
    Oracle Error Code: ORA-04001
    Message: sequence parameter must be an integer
    Related OceanBase Error Code:
        OB_ERR_SEQ_OPTION_MUST_BE_INTEGER(-4317)
```

### 指定模式查询

您也可以通过添加前缀（也称为**错误类别**）来搜索特定模式的错误码信息。

#### 说明

查询 Oracle 模式的错误码时，可指定的错误类别与 oerr 工具的 `facility name` 一致。

* 当错误类别为 `my` 时，如果错误码不是 MySQL 模式中的错误，您将得到 OceanBase 数据库的错误信息（前提是输入的错误码在 OceanBase 数据库中存在）。否则，您将得到 MySQL 模式的错误信息。

  ```
  $ob_error my 4000

  OceanBase:
      OceanBase Error Code: OB_ERROR(-4000)
      Message: Common error
      Cause: Internal Error
      Solution: Contact OceanBase Support

  $ob_error my 1210

  MySQL:
      MySQL Error Code: 1210 (HY000)
      Message: Invalid argument
      Message: Miss argument
      Message: Incorrect arguments to ESCAPE
      Related OceanBase Error Code:
          OB_INVALID_ARGUMENT(-4002)
          OB_MISS_ARGUMENT(-4277)
          INCORRECT_ARGUMENTS_TO_ESCAPE(-5832)
  ```
* 当错误类别为 `ora` 或 `pls` 时，如果输入的错误码在 Oracle 模式中存在，您将得到 Oracle 模式的错误信息。

  ```
  $ob_error ora 51
  Oracle:
      Oracle Error Code: ORA-00051
      Message: timeout occurred while waiting for a resource
      Related OceanBase Error Code:
          OB_ERR_TIMEOUT_ON_RESOURCE(-5848)
  ```
* 还有一种特殊情况，如果您使用 `-a` 选项，若输入的错误码在对应模式中存在，您将会得到 OceanBase 数据库错误信息和 Oracle 模式错误信息。

  ```
  $ob_error ora 600 -a 5727
  OceanBase:
      OceanBase Error Code: OB_ERR_PROXY_REROUTE(-5727)
      Message: SQL request should be rerouted
      Cause: Internal Error
      Solution: Contact OceanBase Support
  Oracle:
      Oracle Error Code: ORA-00600
      Message: internal error code, arguments: -5727, SQL request should be rerouted
      Related OceanBase Error Code:
          OB_ERR_PROXY_REROUTE(-5727)
  ```

  #### 说明

  `-a` 选项用来定位带变量的 `ORA-00600` 错误。`ORA-00600` 是 Oracle 的内部错误。

### 更多示例

更多测试用例，请参见 [expect\_result](https://github.com/oceanbase/oceanbase/blob/master/tools/ob_error/test/expect_result.result)。

此外，您还可以通过 `--help` 命令获得完整的用户手册。

```
ob_error --help
```

## 如何添加错误原因和解决方案

#### 说明

本节内容可供开发人员参考使用。

本节将用一个示例说明如何添加错误原因和解决方案。

### 示例

`src/oberror_errno.def` 中的错误码 `4000` 被定义为：

```
DEFINE_ERROR(OB_ERROR, -4000, -1, "HY000", "Common error");
```

如果您想添加原因和解决方案信息，您可以将定义修改为：

```
DEFINE_ERROR(OB_ERROR, -4000, -1, "HY000", "Common error", "CAUSE", "SOLUTION");
```

用命令重新生成 `src/lib/ob_errno.h`、`src/share/ob_errno.h` 和 `src/share/ob_errno.cpp`：

```
cd src/share
./gen_errno.pl
```

之后在 `BUILD_DIR` 中重新编译 `ob_error` 即可完成添加。