# 分类索引：运维管理

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [参考指南](../../index.md) / [组件 & 工具](../index.md) / 运维管理 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **ob_admin** | 下设 clog，共 1 个子分类。 | `ob_admin` `clog` | [进入目录](./ob_admin/index.md) |
| **obshell** | 下设 API 参考、obshell Dashboard、obshell 命令、SDK 参考、使用场景 等 5 个子分类。 | `obshell` `API 参考` `obshell Dashboard` `obshell 命令` | [进入目录](./obshell/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [ob_error.md](./ob_error.md) | 提供关于ob_error的相关内容， | ob_error,OceanBase 数据库,参考指南,组件 & 工具,运维管理,文档,使用帮助,OceanBase,分布式,数据库 |
| [ob-operator.md](./ob-operator.md) | 提供关于ob-operator的相关内容， | ob-operator,OceanBase 数据库,参考指南,组件 & 工具,运维管理,文档,使用帮助,OceanBase,分布式,数据库 |
| [obd.md](./obd.md) | 提供关于obd的相关内容， | obd,OceanBase 数据库,参考指南,组件 & 工具,运维管理,文档,使用帮助,OceanBase,分布式,数据库 |
