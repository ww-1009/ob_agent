---
title: obd
description: 提供关于obd的相关内容，
keywords: obd,OceanBase 数据库,参考指南,组件 & 工具,运维管理,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# obd

obd（OceanBase Deployer，即 OceanBase 安装部署工具）是 OceanBase 集群的安装部署工具，通过命令行部署或白屏界面部署的方式，将复杂配置流程标准化，降低集群部署难度。详细操作请参考 [使用命令行部署 OceanBase 数据库生产环境](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500192) 和 [通过 obd 白屏部署 OceanBase 集群](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502653)。

其中，命令行支持编辑配置文件，可以更加灵活的进行配置调整，适用于需要深度了解 OceanBase 的用户，有一定的使用门槛；白屏界面配置简单，通过页面的引导配置即可完成集群部署，适用于需要快速体验，构建标准环境的用户。

在集群部署之外，obd 还提供了包管理器、压测软件、集群管理等常用的运维能力，更好的支持用户体验使用 OceanBase 分布式数据库。