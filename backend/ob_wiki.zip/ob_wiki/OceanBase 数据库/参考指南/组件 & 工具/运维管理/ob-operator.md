---
title: ob-operator
description: 提供关于ob-operator的相关内容，
keywords: ob-operator,OceanBase 数据库,参考指南,组件 & 工具,运维管理,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# ob-operator

## 什么是 ob-operator

ob-operator（OceanBase K8s Operator，即 OceanBase K8s 运维工具）是一款基于 Kubernetes Operator 框架构建的工具，用于在 Kubernetes 中管理 OceanBase 集群。它提供了一种简单可靠的方式来实现 OceanBase 集群的容器化部署，可以简化 OceanBase 的运维。ob-operator 定义了 OceanBase 相关的各种资源并且实现相应的调协逻辑，因此您可以像管理 Kubernetes 的原生资源一样，通过声明式的方式管理 OceanBase 数据库。

#### 说明

目前仅提供社区版 OceanBase 数据库镜像。

## ob-operator 功能特点

ob-operator 具有以下功能特点：

* OceanBase 集群管理

  您可以通过创建或者修改 ob-operator 的自定义资源(CRD) `obparameters.oceanbase.oceanbase.com`，对 OceanBase 集群进行管理，具体包括创建集群、初始化集群、集群扩缩容、修改集群参数等。
* OceanBase 租户管理

  您可以通过创建或修改自定义资源 `obtenants.oceanbase.oceanbase.com` 对 OceanBase 集群租户进行管理，具体包括创建租户、调整副本分布、管理物理主备、管理租户备份等。
* OceanBase 高可用

  ob-operator 提供自动故障恢复功能，可以在集群出现故障，且多数派仍可用时自动恢复集群，以保障集群的正常使用。

## ob-operator 版本

当前 ob-operator 为 V2.1.0 版本。

## ob-operator 文档

关于 ob-operator 的详细介绍和使用指导，可以查看 [ob-operator 文档](https://www.oceanbase.com/docs/ob-operator-doc)。