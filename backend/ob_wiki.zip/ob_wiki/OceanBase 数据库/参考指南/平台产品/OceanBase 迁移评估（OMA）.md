---
title: OceanBase 迁移评估（OMA）
description: 提供关于OceanBase 迁移评估（OMA）的相关内容，
keywords: OceanBase 迁移评估（OMA）,OceanBase 数据库,参考指南,平台产品,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 迁移评估（OMA）

OceanBase 迁移评估（OceanBase Migration Assessment，OMA）是 OceanBase 迁移服务（OceanBase Migration Service，OMS）提供的数据库兼容性评估工具。

## 兼容性评估

目前 OMA 支持评估 Oracle、MySQL、PostgreSQL、TiDB、DB2 LUW、RDS MySQL、Polar MySQL、Polar O、DRDS、MSSQL、openGauss，以及 OceanBase 实例（包括 MySQL 和 Oracle 租户）实例转换至 OceanBase 数据库的兼容性，并出具兼容性报告。对于 Oracle 和 MySQL 实例的评估，评估报告中会显示不兼容的具体原因和修改建议。对于其它类型实例的评估，仅会显示不兼容的具体原因。

OMA 支持数据库对象评估、数据库 SQL 或 PL 语句评估，以及整库评估：

* 数据库对象评估

  + 直接连接源端数据库，自动获取源端数据库对象的信息，评估源端数据库至 OceanBase 对应版本的兼容性。
  + 从 Oracle 和 MySQL 的 DDL 语句进行兼容性评估，支持对文本文件（"$$" 分隔）的 DDL 语句进行评估。
  + 支持通过轻客户端连接 Oracle，导出 DDL 语句文件进行兼容性评估。
  + 支持直接读取 MySQLDump 导出的 DDL 语句进行兼容性评估。
  + 支持通过 db2look 工具导出 DDL 语句进行兼容性评估。
* 数据库 SQL 或 PL 语句评估

  + 支持直接连接 Oracle 数据库，直接扫描 V$SQL 视图，获取对应 Schema 的 SQL 语句，并评估对应 OceanBase 数据库版本的兼容性。
  + 支持从文本文件（";"或"$$"分隔）评估 SQL 或 PL 兼容性。
  + 支持直接从 MyBatis 文件和 iBatis 文件解析 SQL 语句，评估其兼容性。
  + 支持直接连接 Oracle 数据库，长时间周期性扫描 V$SQL 视图，获取一个时间段的所有 SQL 语句并进行评估。
  + 支持连接 DB2 LUW 数据库，长时间周期性扫描 snapshot for dynmaic sql，获取一个时间段内所有的 SQL 并进行评估。
* 整库评估

  整库评估整合了对象评估、SQL 评估和画像评估等模式，让用户可以在一次评估任务中，完成对数据库上述三种模式的评估，并可以在一个报告中查看相应的评估结果。

  目前 OMA 整库评估功能对 Oracle、MySQL、TiDB、PostgreSQL 和 DB2 LUW 数据库支持的模式不同。

## 性能评估

OMA 支持 SQL 回放或压测：

* 支持连接源端数据库，采集查询类型的 SQL 语句（SELECT 语句），并且向 OceanBase 数据库进行 SQL 回放，验证 SQL 语句的兼容性和 OceanBase 数据库的性能。
* 支持 Oracle 负载采集，并且对解析出的 SQL 语句进行兼容性评估，或向 OceanBase 数据库进行回放，验证 SQL 语句的准确性和性能。
* 支持解析 MySQL 数据库的 General Log 文件并进行回放。
* 在 OceanBase 数据库升级的场景下，支持从低版本的 OceanBase 数据库拉取查询语句，在新版本的 OceanBase 数据库进行回放。

## 导出 OceanBase 数据库对象和 SQL 语句

* 支持从 OceanBase 数据库导出对应 Schema 的对象 DDL。
* 支持从 OceanBase 数据库导出对应时间段的 SQL\_AUDIT 中的 SQL 语句详情。