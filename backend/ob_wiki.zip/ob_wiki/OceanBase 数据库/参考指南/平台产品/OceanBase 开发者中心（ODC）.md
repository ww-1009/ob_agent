---
title: OceanBase 开发者中心（ODC）
description: 提供关于OceanBase 开发者中心（ODC）的相关内容，
keywords: OceanBase 开发者中心（ODC）,OceanBase 数据库,参考指南,平台产品,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 开发者中心（ODC）

OceanBase 开发者中心（OceanBase Developer Center，ODC）是为 OceanBase 数据库量身打造的企业级数据库开发平台。ODC 支持连接 OceanBase 中 MySQL 和 Oracle 模式下的数据库，同时为数据库开发者提供了数据库日常开发操作、WebSQL、SQL 诊断、会话管理和数据导入导出等功能。

ODC 采用成熟的浏览器-服务端架构，拥有跨平台、轻量化和易部署的特点。同时，ODC 还提供客户端版本，不仅能满足个人开发者快速上手使用 OceanBase 的需求，还可提升开发人员与 DBA 的协作效率。

## 产品特性

OceanBase 开发者中心（OceanBase Developer Center，ODC）作为为 OceanBase 数据库量身打造的企业级数据库开发平台，拥有编辑和管理数据库对象与资源等特性。

### 数据库对象管理

* 引导式创建和可视化修改各类数据库对象。
* 通过回收站机制快速恢复和清理已删除对象。

### 企业级特性分区支持

* 支持 OceanBase 版本 MySQL 和 Oracle 模式中完整的分区类型。
* 人性化引导式全流程设计，降低了使用分区功能的门槛。

### Web 控制台

* 支持 DDL、DML 和数据的安全变更。
* 通过 WebSQL 帮助开发人员正确使用 OceanBase 的各种特性和功能。
* 提供贴合 OceanBase 版本 MySQL 和 Oracle 的语法高亮、格式化、智能提示等贴心特性。
* 提供类似Excel的可视化数据编辑能力。

### 数据导入导出

* 为 OceanBase 量身打造的高效的数据导入导出能力。
* 支持多种文件格式的导入导出。

### 数据库变量编辑

* 支持会话变量和系统全局变量的可视化修改。
* 降低用户对变量记忆的难度。
* 提升根据业务场景定制变量的效率。

### 资源性能

* 实时进行数据库会话访问情况管控，且支持查看和终止会话。
* 支持 SQL 执行计划分析，指导 SQL 调优。