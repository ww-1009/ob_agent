---
title: OceanBase 迁移服务（OMS）
description: 提供关于OceanBase 迁移服务（OMS）的相关内容，
keywords: OceanBase 迁移服务（OMS）,OceanBase 数据库,参考指南,平台产品,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 迁移服务（OMS）

OceanBase 迁移服务（OceanBase Migration Service，OMS）是 OceanBase 数据库提供的一种支持同构或异构数据源与 OceanBase 数据库之间进行数据交互的服务，具备在线迁移存量数据和实时同步增量数据的能力。

OMS 提供可视化的集中管控平台，您只需要进行简单的配置即可实时迁移数据。OMS 旨在帮助您低风险、低成本、高效率地实现同构或异构数据库向 OceanBase 进行实时数据迁移和数据同步。

## 特性与优势

* 支持多种数据源

  OMS 支持 MySQL、Kafka 等多种类型的数据源与 OceanBase 数据库进行实时数据传输，具体功能会因为源端数据库的类型和目标端下游的终端类型不同，而有所区别。
* 在线不停服迁移，业务应用无感知

  在不停服的情况下，您可以通过 OMS 无缝迁移数据至 OceanBase。应用切换至 OceanBase 数据库后，OceanBase 数据库上所有的变更数据会实时同步至切换前的源端数据库。

  OMS 可以降低业务迁移的风险，助力企业用户构建高可用、高可靠的数据体系架构。
* 高性能的数据迁移，安全可靠

  OMS 能够准实时实现异构 IT 基础结构之间大量数据的秒级延迟复制。因此 OMS 可以应用于数据迁移、跨城异地数据灾备、应急系统、实时数据同步、容灾、数据库升级和移植等多个场景。

  OMS 能够实现在业务应用无感知和不中断的前提下，运行数据迁移和数据同步任务，并保证数据的完整性和事务的一致性。全量迁移性能可以达到 100 MB/s，20 万 TPS，数据同步性能可以达到 50000 RPS。同时，OMS 提供高可用的部署架构方案，为数据迁移和实时同步提供稳定可靠的传输项目。
* 一站式交互

  支持数据迁移的全生命周期管理。您可以在管理控制台界面操作完成数据迁移任务的创建、配置和监控，交互简便。
* 实时数据同步助力业务解耦

  OMS 支持 OceanBase 两种租户与自建 Kafka、RocketMQ 之间的数据实时同步，可以应用于实时数据仓库搭建、数据查询和报表分流等业务场景。
* 多重数据校验

  提供多种数据一致性校验方式，更加全面、省时、高效地保证数据质量。同时展示差异数据，提供快速订正的途径。
* 帮助您轻松迁移 OceanBase

  完整适配 OceanBase 数据库各版本的特性，智能化处理数据库对象的采集和转换，支持源端不停服迁移。

## 应用场景

本文为您介绍 OceanBase 迁移服务（OceanBase Migration Service，OMS）的企业级数据库迁移和数据同步功能的应用场景。

### 数据库不停服迁移

![image.png](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.1/700.reference/1400.oceanbase-tools/continuous-service-migration.jpg)

在传统的数据库迁移方案中，为了保障迁移任务的稳定性和数据的一致性，通常通过停机迁移的方式进行数据迁移。停机期间需要暂时停止写入数据至源端数据库，待迁移完成并确认数据一致性后，再切换业务数据库。

停机迁移的耗时和业务数据量、网络状况相关，在业务量巨大的情况下，数据库的停机迁移可能耗时数天，对业务影响较大。

OMS 提供的不停服数据迁移功能，不影响迁移过程中源数据库持续对外提供服务，能够最小化数据迁移对业务的影响。在完成结构迁移、全量数据迁移和增量数据迁移后，源数据库的全量和增量数据均已实时同步至目标数据库中，数据校验通过后，业务可以从源端切换至目标端。

### 实时数据同步

OMS 的数据同步功能支持实时同步 OceanBase 等数据库的增量数据至自建的 Kafka、RocketMQ 等消息队列中，提升消息处理能力，扩展业务在监控数据聚合、流式数据处理、在线和离线分析等大数据领域的全方位应用。

OMS 支持 OceanBase 物理表和自建的 Kafka 等数据源之间的数据实时同步，您可以用于云 BI、实时数据仓库搭建、数据查询和报表分流等多种业务场景。

### 高可用、灵活部署

* 单节点支持 HA 功能的组件包括 Store 和 Incr-Sync。当 Store 或 Incr-Sync 组件发生故障时，对异常进程进行重启。

  ![HA1](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.1/700.reference/1400.oceanbase-tools/HA1.png)
* 支持机房维度的容灾。

  ![HA2](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.1/700.reference/1400.oceanbase-tools/HA2.png)

  + 机器宕机情况下，本机内全部组件迁移至合适机器。
  + 机器资源指标异常情景下，尝试负载均衡部分组件。
  + Store 故障时，在机器资源充足情况下，尝试重启。在机器资源不足时，进行负载均衡，或删除冗余 Store。
  + Incr-Sync 故障时，对异常进程进行重启。
* 支持区域数据中心维度的容灾。

  OMS 支持增量日志读取和增量同步写入分开部署，通过多个传输控制协议（Transmission Control Protocol，TCP）连接并行传输、数据压缩和数据加密等优化手段，克服了远距离、劣网条件以及数据安全性等挑战（暂不支持跨地域调度）。

  ![HA3](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.1/700.reference/1400.oceanbase-tools/HA3.png)

## 产品功能

OMS 支持数据迁移和数据同步功能：

* 数据迁移：数据迁移属于一次性任务，迁移完成后即可释放项目资源。您可以通过数据迁移功能，实现同构或异构数据源之间的数据迁移，适用于数据库升级、跨实例数据迁移、数据库拆分、扩容等业务场景。

  数据迁移项目是 OMS 数据迁移功能的基本单元。创建迁移项目时，您可以指定的最大迁移范围是数据库级别，最小迁移范围是表级别。数据迁移支持的项目类型、迁移类型等详情请参见 [数据迁移](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499425) 模块的文档。
* 数据同步：数据同步属于持续性动作，项目创建后会一直同步数据，保持源端和目标端的数据一致性，实现关键业务的数据实时流动。您可以通过数据同步功能，实现数据源之间的数据实时同步，适用于数据异地多活、数据异地灾备、数据聚合和实时数据仓库等多种业务场景。详情请参见 [数据同步](https://www.oceanbase.com/docs/enterprise-oms-doc-cn-1000000000000095) 模块的文档。