---
title: OceanBase 管理者工具（OAT）
description: 提供关于OceanBase 管理者工具（OAT）的相关内容，
keywords: OceanBase 管理者工具（OAT）,OceanBase 数据库,参考指南,平台产品,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 管理者工具（OAT）

OceanBase 管理者工具（OceanBase Admin Toolkit，OAT）是一个可视化平台，用于安装和管理 OceanBase 生态产品和组件。OceanBase 生态产品包括：OceanBase 云平台（OceanBase Cloud Platform，OCP）、OceanBase 开发者中心（OceanBase Development Center，ODC）、OceanBase 访问代理（OB Sharding）以及 OceanBase 迁移服务（OceanBase Migration Service，OMS）。OceanBase 组件包括：MetaDB、OBDNS、InfluxDB 和 NLB。

OAT 功能如下：

* 管理和运维 OceanBase 服务器。
* 安装、运维和卸载 OceanBase 生态产品。
* 安装、运维和卸载 OceanBase 组件。