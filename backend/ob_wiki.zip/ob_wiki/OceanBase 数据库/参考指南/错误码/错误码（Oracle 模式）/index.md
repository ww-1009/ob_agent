# 叶子索引：错误码（Oracle 模式）

> 位置：> 位置：[ob_wiki](../../../../../index.md) / [OceanBase 数据库](../../../../index.md) / [参考指南](../../../index.md) / [错误码](../../index.md) / [错误码（Oracle 模式）](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [错误信息概述.md](./错误信息概述.md) | 提供关于错误信息概述的相关内容， | 错误信息概述,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-30000 ~ ORA-49999.md](./ORA-30000 ~ ORA-49999.md) | 提供关于ORA-30000 ~ ORA-49999的相关内容， | ORA-30000 ~ ORA-49999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-50000 ~ ORA-99999.md](./ORA-50000 ~ ORA-99999.md) | 提供关于ORA-50000 ~ ORA-99999的相关内容， | ORA-50000 ~ ORA-99999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-05000 ~ ORA-10000.md](./ORA-05000 ~ ORA-10000.md) | 提供关于ORA-05000 ~ ORA-10000的相关内容， | ORA-05000 ~ ORA-10000,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-00000 ~ ORA-00999.md](./ORA-00000 ~ ORA-00999.md) | 提供关于ORA-00000 ~ ORA-00999的相关内容， | ORA-00000 ~ ORA-00999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-01500 ~ ORA-01999.md](./ORA-01500 ~ ORA-01999.md) | 提供关于ORA-01500 ~ ORA-01999的相关内容， | ORA-01500 ~ ORA-01999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-20000 ~ ORA-29999.md](./ORA-20000 ~ ORA-29999.md) | 提供关于ORA-20000 ~ ORA-29999的相关内容， | ORA-20000 ~ ORA-29999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [PLS-00000 ~ PLS-00999.md](./PLS-00000 ~ PLS-00999.md) | 提供关于PLS-00000 ~ PLS-00999的相关内容， | PLS-00000 ~ PLS-00999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-10000 ~ ORA-19999.md](./ORA-10000 ~ ORA-19999.md) | 提供关于ORA-10000 ~ ORA-19999的相关内容， | ORA-10000 ~ ORA-19999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-02000 ~ ORA-04999.md](./ORA-02000 ~ ORA-04999.md) | 提供关于ORA-02000 ~ ORA-04999的相关内容， | ORA-02000 ~ ORA-04999,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
| [ORA-01000 ~ ORA-01499.md](./ORA-01000 ~ ORA-01499.md) | 提供关于ORA-01000 ~ ORA-01499的相关内容， | ORA-01000 ~ ORA-01499,OceanBase 数据库,参考指南,错误码,错误码（Oracle 模式）,文档,使用帮助,OceanBase,分布式,数据库 |
