---
title: OBProxy 性能监控
description: 提供关于OBProxy 性能监控的相关内容，
keywords: OBProxy 性能监控,OceanBase 数据库,参考指南,性能调优,性能诊断,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OBProxy 性能监控

本文介绍了如何查看 OBProxy 性能监控。

## OBProxy 性能监控

1. 登录 OCP，在左侧导航栏，单击 **OBProxy**。
2. 在 **OBProxy 页面** 的 **OBProxy 集群列表** 区域，选择待操作的 OBProxy 集群并单击其集群名。
3. 在显示的页面的左侧导航栏上，单击 **性能监控**。
4. 在 **性能监控** 页面打开实时性能开关，可看到性能的实时变化。

   ![monitor](https://help-static-aliyun-doc.aliyuncs.com/assets/img/zh-CN/2729721461/p347751.png)

   **监控数据筛选说明**

   | 筛选对象 | 说明 |
   | --- | --- |
   | 选择时间 | 监控展示的时间范围，支持查看近 30 天数据。 |
   | 统计周期 | 支持按分钟、10 秒对采集的监控指标进行平均值统计并展示，默认为分钟级别。 |

   更多 OBProxy 性能监控详情，请参见 [性能监控](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000001542119)。