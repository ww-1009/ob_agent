---
title: SQL 请求执行流程
description: 提供关于SQL 请求执行流程的相关内容，
keywords: SQL 请求执行流程,OceanBase 数据库,参考指南,性能调优,SQL 调优指南,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# SQL 请求执行流程

SQL 引擎从接受 SQL 请求到执行的典型流程如下图所示：

![sql-new](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.3.5/700.reference/1000.performance-tuning-guide/500.sql-optimization/SQL%E8%AF%B7%E6%B1%82%E6%89%A7%E8%A1%8C%E6%B5%81%E7%A8%8B.png)

下表为 SQL 请求执行流程的步骤说明。

| **步骤** | **说明** |
| --- | --- |
| 快速参数化模块 | 快速参数化模块将 SQL 中的常量转换为参数，然后使用参数化的 SQL 文本作为键值在 PlanCache 中获取执行计划，从而达到仅参数不同的 SQL 能够共用相同计划的目的。 |
| 执行计划缓存模块（Plan Cache） | 执行计划缓存模块会将该 SQL 第一次生成的执行计划缓存在内存中，后续的执行可以反复执行这个计划，避免了重复查询优化的过程。 |
| 词法/语法解析模块（Parser） | 在收到用户发送的 SQL 请求串后，词法/语法解析模块会将字符串分成一个个的"单词"，并根据预先设定好的语法规则解析整个请求，将 SQL 请求字符串转换成带有语法结构信息的内存数据结构，称为语法树（Syntax Tree）。 |
| 语义解析模块（Resolver） | Resolver 将生成的语法树转换为带有数据库语义信息的内部数据结构。在这一过程中，Resolver 将根据数据库元信息将 SQL 请求中的 Token 翻译成对应的对象（例如库、表、列、索引等），生成的数据结构叫做 Statement Tree。 |
| 查询改写（Query Rewrite） | 查询改写是指将一个 SQL 改写成另外一个更加容易优化的 SQL。 |
| 优化器（Optimizer） | 优化器是整个 SQL 请求优化的核心，其作用是为 SQL 请求生成最佳的执行计划。在优化过程中，优化器需要综合考虑 SQL 请求的语义、对象数据特征、对象物理分布等多方面因素，解决访问路径选择、联接顺序选择、联接算法选择、分布式计划生成等多个核心问题，最终选择一个对应该 SQL 的最佳执行计划。 |
| 代码生成器（Code Generator） | 将执行计划转换为可执行的代码，但是不做任何优化选择。 |