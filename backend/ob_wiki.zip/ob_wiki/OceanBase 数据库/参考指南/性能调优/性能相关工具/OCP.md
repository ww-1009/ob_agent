---
title: OCP
description: 提供关于OCP的相关内容，
keywords: OCP,OceanBase 数据库,参考指南,性能调优,性能相关工具,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OCP

OceanBase 数据库支持使用白屏工具 OCP 进行性能调优。主要涉及的功能如下：

* 监控告警

  OCP 支持 OceanBase 集群维度、租户维度、节点维度的监控告警，包括性能、容量、运行状态等指标的 7 \* 24 监控数据采集。监控支持图表可视化展现，帮助用户全面了解 OceanBase 集群使用状况，及时发现集群异常，及时预警，确保数据库稳定、高效的正常运行。

  详细信息请参见官网文档 [使用告警管理](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000000775898)。
* SQL 诊断

  当前关系数据库仍然是许多公司的主要数据存储引擎，系统通过 SQL 访问数据库。SQL 是 IT 系统的重要组成部分，其性能好坏极对于系统可用性、用户响应时间、系统吞吐量、IT设施成本等指标有非常大的影响，因 SQL 问题导致的各种问题层出不穷，难以根治。因此 OCP 提供 SQL 诊断的多维度功能，包括 TopSQL、SlowSQL、ParallelSQL、可疑 SQL、SQL Plan、Outline、SQLTuningAdvisor、SQL 请求分析等功能，用户可以针对不同应用场景来选择不同的工具。此外，OCP 还提供 SQL 调优建议、索引绑定、计划绑定、SQL 限流和关键词限流等调优应急功能，提供 SQL 问题发现、分析、处理等全链路功能。

  详细信息请参见官网文档 [SQL 诊断](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000000775897)。
* 性能报告

  OceanBase Analyze Report（以下简称 OBAR ）的目标是提供一款数据库性能分析产品，让用户能够在 OceanBase 数据库发生性能问题的时候，可以通过 OBAR 获取全面的，与性能相关的诊断信息。OBAR 核心目标是需要让用户了解集群或租户的负载和性能情况，同时帮助用户执行一些通用的检查项，最后以报告的形式展现出来。提供报告的形式一方面简化了用户的操作，用户一键操作即可汇总到多维度的系统状态信息，另一方面可以让用户快速了解集群状态，降低用户的使用门槛。

  详细信息请参见官网文档 [性能报告](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000000775946)。
* ASH 报告

  #### 功能适用性

  目前 OceanBase 数据库社区版暂不支持 ASH 报告。

  OceanBase Active Session History Report （以下简称 ASH 报告）是一款能够提供定位瞬时发生异常的分析报告，与性能报告相比，能提供更加细粒度的诊断信息。ASH 报告的实现包括采集和报告生成两个过程，采集过程是 OCP 在管理的 OceanBase 集群上的每台机器上部署一个 ocp\_monagent，ocp\_monagent 负责按照一定策略采集所需监控数据，然后持久化到 OCP 的监控库中；报告生成过程是用户通过在 OCP 活跃会话历史功能中输入相关信息生成对应的报告。ASH 报告整个过程的实现逻辑是利用 OCP 的任务模块来进行并发执行多个子任务，不同子任务之间通过 CONTEXT 传递信息，最终报告内容会保存到 OCP 的 OSS 服务中，以供用户多次查看。OceanBase 数据库会在 `v$session_event` 视图中记录每个用户连接的 session 上已经执行完成的 SQL 的所有等待事件，包括等待事件 ID、所等待次数和累计等待时长。在整个过程中 ocp\_monagent 会按照固定频率采集 `v$session_event`，并进行增量数据存储。

  详细信息请参见官网文档 [ASH 报告](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000000775896)。
* 事务诊断

  事务在 OceanBase 数据库执行过程中，如果长时间占有资源不释放，或者占用过多的资源，则会导致数据库系统处于一种不稳定的状态，影响数据库系统正常提供高效服务。我们把这种类型的事务称为大事务，OCP 事务诊断提供对这些大事务的监控、分析和应急能力。事务诊断功能提供大事务的详细信息，包括执行详情和已执行 SQL 详情等，可以获得事务的模型，判断事务中耗时、耗资源的具体原因，帮助用户进行业务调优。根据事务的当前状态和持续时长的不同分为长事务、悬挂事务和普通事务三种类型。长事务和悬挂事务是用户需要关注的异常事务，OCP 对于这些异常事务提供了应急的手段，可以一键关闭异常事务，也可以借助应急手册来解决问题，帮助系统快速恢复到稳定的状态。

  详细信息请参见官网文档 [事务诊断](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000000775970)。
* 死锁检测

  OceanBase 数据库支持分布式死锁自动检测功能。在打开集群分布式死锁自动检测功能开关的情况下，OceanBase 数据库能够自动发现死锁并解决死锁问题。用户需要针对 SQL 抛出的异常信息，决定提交还是回滚事务。用户通过死锁获取死锁节点数、被中断的死锁节点、节点执行的 SQL 等信息。

  详细信息请参见官网文档 [查看死锁分析](https://www.oceanbase.com/docs/enterprise-oceanbase-ocp-cn-10000000000775895)。