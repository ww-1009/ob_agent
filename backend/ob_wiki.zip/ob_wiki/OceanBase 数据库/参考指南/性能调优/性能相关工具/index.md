# 分类索引：性能相关工具

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [参考指南](../../index.md) / [性能调优](../index.md) / 性能相关工具 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **内部表** | 涵盖 GV$OB_SQL_AUDIT、GV$SYSSTAT、GV$OB_TRANSACTION_PARTICIPANTS。 | `内部表` `GV$OB_SQL_AUDIT` `GV$SYSSTAT` | [进入目录](./内部表/index.md) |
| **日志** | 涵盖 trace log、slow trans、tenant dump info。 | `日志` `trace log` `slow trans` `tenant dump info` | [进入目录](./日志/index.md) |
| **系统工具** | 涵盖 网络工具、CPU 工具、磁盘 I_O 工具、Top 通用工具 等 5 项。 | `系统工具` `网络工具` `CPU 工具` `磁盘 I_O 工具` | [进入目录](./系统工具/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OCP.md](./OCP.md) | 提供关于OCP的相关内容， | OCP,OceanBase 数据库,参考指南,性能调优,性能相关工具,文档,使用帮助,OceanBase,分布式,数据库 |
