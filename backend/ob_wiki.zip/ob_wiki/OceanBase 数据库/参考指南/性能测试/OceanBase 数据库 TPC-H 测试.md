---
title: OceanBase 数据库 TPC-H 测试
description: 提供关于OceanBase 数据库 TPC-H 测试的相关内容，
keywords: OceanBase 数据库 TPC-H 测试,OceanBase 数据库,参考指南,性能测试,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 数据库 TPC-H 测试

## 什么是 TPC-H

TPC-H（商业智能计算测试）是美国交易处理效能委员会（TPC，Transaction Processing Performance Council）组织制定的用来模拟决策支持类应用的一个测试集。目前，学术界和工业界普遍采用 TPC-H 来评价决策支持技术方面应用的性能。这种商业测试可以全方位评测系统的整体商业计算综合能力，对厂商的要求更高，同时也具有普遍的商业实用意义，目前在银行信贷分析和信用卡分析、电信运营分析、税收分析、烟草行业决策分析中都有广泛的应用。

TPC-H 基准测试由 TPC-D（由 TPC 于 1994 年制定的标准，用于决策支持系统方面的测试基准）发展而来的。TPC-H 用 3NF 实现了一个数据仓库，共包含 8 个基本关系，其主要评价指标是各个查询的响应时间，即从提交查询到结果返回所需时间。TPC-H 基准测试的度量单位是每小时执行的查询数（QphH@size），其中 H 表示每小时系统执行复杂查询的平均次数，size 表示数据库规模的大小，它能够反映出系统在处理查询时的能力。TPC-H 是根据真实的生产运行环境来建模的，这使得它可以评估一些其他测试所不能评估的关键性能参数。总而言之，TPC 组织颁布的TPC-H 标准满足了数据仓库领域的测试需求，并且促使各个厂商以及研究机构将该项技术推向极限。

## 本文概述

本文讲介绍如何基于 OceanBase 数据库进行 TPC-H 测试，本文提供 2 种方式进行 TPC-H 性能测试。

* 基于 obd 一键进行 TPC-H 测试。
* 基于 TPC 官方 tpc-h 工具手动 step by step 进行 TPC-H 测试。

#### 说明

为了提升用户体验和易用性，让每一个开发者在使用数据库时都能获得较好的性能，OceanBase 数据库在 V4.0.0 版本之后，做了大量的优化工作。本性能测试方法仅基于基础参数进行调优，让开发者获得较好的数据库性能体验。

## 环境准备

测试前请按照如下要求准备您的测试环境：

* JDK：建议使用 1.8u131 及以上版本
* make：yum install make
* gcc：yum install gcc
* mysql-devel：yum install mysql-devel
* Python 连接数据库的驱动：sudo yum install MySQL-python
* prettytable：pip install prettytable
* JDBC：建议使用mysql-connector-java-5.1.47版本
* tpch tool：点击 [下载地址](https://www.tpc.org/tpc_documents_current_versions/download_programs/tools-download-request5.asp?bm_type=TPC-H&bm_vers=3.0.0&mode=CURRENT-ONLY) 获取，如果使用 obd 一键测试，可以跳过该工具
* OBClient：详细信息，请参考 [OBClient 文档](https://github.com/oceanbase/obclient/blob/master/README.md)
* OceanBase 数据库：详细信息，请参考 [快速体验 OceanBase 数据库](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499449)
* iops：建议磁盘 iops 在 10000 以上
* 租户规格：

  ```
  CREATE RESOURCE UNIT tpch_unit max_cpu 26, memory_size '70g';
  CREATE RESOURCE POOL tpch_pool unit = 'tpch_unit', unit_num = 1, zone_list=('zone1','zone2','zone3');
  CREATE TENANT tpch_mysql resource_pool_list=('tpch_pool'),  zone_list('zone1', 'zone2', 'zone3'), primary_zone=RANDOM, locality='F@zone1,F@zone2,F@zone3' set variables ob_compatibility_mode='mysql', ob_tcp_invited_nodes='%',secure_file_priv = '';
  ```

  #### 注意

  + 上文中的租户规格是基于 [OceanBase TPC-H 性能测试报告](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499637) 中的硬件配置进行配置的，您需根据自身数据库的硬件配置进行动态调整。
  + 部署集群时，建议不要使用 `obd cluster autodeploy` 命令，该命令为了保证稳定性，不会最大化资源利用率（例如不会使用所有内存），建议单独对配置文件进行调优，最大化资源利用率。

## 部署集群

1. 本次测试需要用到 4 台机器，TPC-H 和 obd 单独部署在一台机器上，作为客户端的压力机器。通过 obd 部署 OceanBase 集群需要使用 3 台机器，OceanBase 集群规模为 1:1:1。

   #### 说明

   在 TPC-H 测试中，部署 TPC-H 和 obd 的机器只需 4 核 16G 即可。
2. 部署成功后，新建执行 TPC-H 测试的租户及用户（sys 租户是管理集群的内置系统租户，请勿直接使用 sys 租户进行测试）。将租户的 `primary_zone` 设置为 `RANDOM`。`RANDOM` 表示新建表分区的 Leader 随机到这 3 台机器。

## obd 一键测试

```
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://mirrors.aliyun.com/oceanbase/OceanBase.repo
sudo yum install obtpch
sudo ln -s /usr/tpc-h-tools/tpc-h-tools/ /usr/local/
obd test tpch obperf  --tenant=tpch_mysql -s 100 --remote-tbl-dir=/tmp/tpch100
```

### 注意

* obd 运行 tpch，详细参数介绍请参考 [obd test tpch](https://www.oceanbase.com/docs/community-obd-cn-10000000001031935)。
* 在本例中，大幅参数使用的是默认参数，在用户场景下，可以根据自己的具体情况做一些参数上的调整。例如，在本例中使用的集群名为 `obperf`，租户名是 `tpch_mysql`。
* 使用 obd 进行一键测试时，集群的部署必须是由 obd 进行安装和部署，否则无法获取集群的信息，将导致无法根据集群的配置进行性能调优。
* 如果系统租户的密码通过终端登陆并修改，非默认空值，则需要您先在终端中将密码修改为默认值，之后通过 [obd cluster edit-config](https://www.oceanbase.com/docs/community-obd-cn-10000000001031935) 命令在配置文件中为系统租户设置密码，配置项是 `# root_password: # root user password`。在 `obd cluster edit-config` 命令执行结束后，您还需执行 `obd cluster reload` 命令使修改生效。
* 运行 `obd test tpch` 后，系统会详细列出运行步骤和输出，数据量越大耗时越久。
* `remote-tbl-dir` 远程目录具备足够的容量能存储 tpch 的数据，建议单独一块盘存储加载测试数据。
* `obd test tpch` 命令会自动完成所有操作，无需其他额外任何操作，包含测试数据的生成、传送、OceanBase 参数优化、加载和测试。当中间环节出错时，您可参考 [obd test tpch](https://www.oceanbase.com/docs/community-obd-cn-10000000001031935) 进行重试。例如：跳过数据的生成和传送，直接进行加载和测试。

## 手动进行 TPC-H 测试

以下内容为基于 TPC 官方 TPC-H 工具进行手动 step by step 进行 TPC-H 测试，非使用 obd 工具一键测试。手动测试可以帮助更好的学习和了解 OceanBase，尤其是一些参数的设置。

### 进行环境调优

请在系统租户下进行环境调优。

1. OceanBase 数据库调优。

   在系统租户下执行 `obclient -h$host_ip -P$host_port -uroot@sys -A` 命令。

   ```
   ALTER SYSTEM flush plan cache GLOBAL;
   ALTER system SET enable_sql_audit=false;
   select sleep(5);
   ALTER system SET enable_perf_event=false;
   ALTER system SET syslog_level='PERF';
   alter system set enable_record_trace_log=false;
   ```
2. 设置租户。

   在测试用户下执行 `obclient -h$host_ip -P$host_port -u$user@$tenant -p$password -A` 命令。

   ```
   SET GLOBAL ob_sql_work_area_percentage = 80;
   SET GLOBAL ob_query_timeout = 36000000000;
   SET GLOBAL ob_trx_timeout = 36000000000;
   SET GLOBAL max_allowed_packet = 67108864;
   # parallel_servers_target = max_cpu * server_num * 8
   SET GLOBAL parallel_servers_target = 624;
   ```

### 安装 TPC-H Tool

1. 下载 TPC-H Tool。详细信息请参考 [TPC-H Tool 下载页面](https://www.tpc.org/tpc_documents_current_versions/download_programs/tools-download-request5.asp?bm_type=TPC-H&bm_vers=3.0.0&mode=CURRENT-ONLYY)。
2. 下载完成后解压文件，进入 TPC-H 解压后的目录。

   ```
   [wieck@localhost ~] $ unzip 7e965ead-8844-4efa-a275-34e35f8ab89b-tpc-h-tool.zip
   [wieck@localhost ~] $ cd TPC-H_Tools_v3.0.0
   ```
3. 复制 `makefile.suite`。

   ```
   [wieck@localhost TPC-H_Tools_v3.0.0] $ cd dbgen/
   [wieck@localhost dbgen] $ cp makefile.suite Makefile
   ```
4. 修改 `Makefile` 文件中的 `CC、DATABASE、MACHINE、WORKLOAD` 等参数定义。

   ```
   [wieck@localhost dbgen] $ vim Makefile
   CC      = gcc
   # Current values for DATABASE are: INFORMIX, DB2, TDAT (Teradata)
   #                                  SQLSERVER, SYBASE, ORACLE, VECTORWISE
   # Current values for MACHINE are:  ATT, DOS, HP, IBM, ICL, MVS,
   #                                  SGI, SUN, U2200, VMS, LINUX, WIN32
   # Current values for WORKLOAD are:  TPCH
   DATABASE= MYSQL
   MACHINE = LINUX
   WORKLOAD = TPCH
   ```
5. 修改 `tpcd.h` 文件，并添加新的宏定义。

   ```
   [wieck@localhost dbgen] $ vim tpcd.h

   #ifdef MYSQL
   #define GEN_QUERY_PLAN ""
   #define START_TRAN "START TRANSACTION"
   #define END_TRAN "COMMIT"
   #define SET_OUTPUT ""
   #define SET_ROWCOUNT "limit %d;\n"
   #define SET_DBASE "use %s;\n"
   #endif
   ```
6. 编译文件。

   ```
   make
   ```

### 生成数据

您可以根据实际环境生成 TPC-H 10G、100G 或者 1T 数据。本文以生成 100G 数据为例。

```
./dbgen -s 100
mkdir tpch100
mv *.tbl tpch100
```

### 生成查询 SQL

#### 说明

您可参考本节中的下述步骤生成查询 SQL 后进行调整，也可直接使用[GitHub](https://github.com/oceanbase/obdeploy/tree/master/plugins/tpch/3.1.0/queries)中给出的查询 SQL。 若您选择使用 GitHub 中的查询 SQL，您需将 SQL 语句中的 cpu\_num 修改为实际并发数。

1. 复制 `qgen` 和 `dists.dss`文件至 `queries` 目录。

   ```
   cp qgen queries
   cp dists.dss queries
   ```
2. 在 `queries` 目录下创建 `gen.sh` 脚本生成查询 SQL。

   ```
   [wieck@localhost queries] $ vim gen.sh
   #!/usr/bin/bash
   for i in {1..22}
   do  
   ./qgen -d $i -s 100 > db"$i".sql
   done
   ```
3. 执行 `gen.sh` 脚本。

   ```
   chmod +x  gen.sh
   ./gen.sh
   ```
4. 查询 SQL 进行调整。

   ```
   dos2unix *
   ```

   调整后的查询 SQL 请参考 [GitHub](https://github.com/oceanbase/obdeploy/tree/master/plugins/tpch/3.1.0/queries)。您需将 GitHub 给出的 SQL 语句中的 `cpu_num` 修改为实际并发数。建议并发数的数值与可用 CPU 总数相同，两者相等时性能最好。

   您可在 sys 租户下使用如下命令查看租户的可用 CPU 总数。

   ```
   SELECT sum(cpu_capacity_max) FROM __all_virtual_server;
   ```

   以 q1 为例，修改后的 SQL 如下：

   ```
   SELECT /*+    parallel(96) */   ---增加 parallel 并发执行
     l_returnflag,
     l_linestatus,
     sum(l_quantity) as sum_qty,
     sum(l_extendedprice) as sum_base_price,
     sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
     sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
     avg(l_quantity) as avg_qty,
     avg(l_extendedprice) as avg_price,
     avg(l_discount) as avg_disc,
     count(*) as count_order
   FROM
     lineitem
   WHERE
     l_shipdate <= date '1998-12-01' - interval '90' day 
   GROUP BY
     l_returnflag,
     l_linestatus
   ORDER BY
     l_returnflag,
     l_linestatus;
   ```

### 新建表

创建表结构文件 `create_tpch_mysql_table_part.ddl`。

```
DROP TABLE IF EXISTS lineitem;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS partsupp;
DROP TABLE IF EXISTS part;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS supplier;
DROP TABLE IF EXISTS nation;
DROP TABLE IF EXISTS region;
DROP TABLEGROUP IF EXISTS tpch_tg_lineitem_order_group;
DROP TABLEGROUP IF EXISTS tpch_tg_partsupp_part;

CREATE TABLEGROUP IF NOT EXISTS tpch_tg_lineitem_order_group binding true partition by key 1 partitions cpu_num;
CREATE TABLEGROUP IF NOT EXISTS tpch_tg_partsupp_part binding true partition by key 1 partitions cpu_num;

DROP TABLE IF EXISTS lineitem;
CREATE TABLE lineitem (
  l_orderkey BIGINT NOT NULL,
  l_partkey BIGINT NOT NULL,
  l_suppkey INTEGER NOT NULL,
  l_linenumber INTEGER NOT NULL,
  l_quantity DECIMAL(15,2) NOT NULL,
  l_extendedprice DECIMAL(15,2) NOT NULL,
  l_discount DECIMAL(15,2) NOT NULL,
  l_tax DECIMAL(15,2) NOT NULL,
  l_returnflag char(1) DEFAULT NULL,
  l_linestatus char(1) DEFAULT NULL,
  l_shipdate date NOT NULL,
  l_commitdate date DEFAULT NULL,
  l_receiptdate date DEFAULT NULL,
  l_shipinstruct char(25) DEFAULT NULL,
  l_shipmode char(10) DEFAULT NULL,
  l_comment varchar(44) DEFAULT NULL,
  PRIMARY KEY(l_orderkey, l_linenumber))row_format = condensed
  tablegroup = tpch_tg_lineitem_order_group
  partition by key (l_orderkey) partitions cpu_num;

DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  o_orderkey bigint not null,
  o_custkey bigint not null,
  o_orderstatus char(1) default null,
  o_totalprice bigint default null,
  o_orderdate date not null,
  o_orderpriority char(15) default null,
  o_clerk char(15) default null,
  o_shippriority bigint default null,
  o_comment varchar(79) default null,
  PRIMARY KEY (o_orderkey))row_format = condensed
  tablegroup = tpch_tg_lineitem_order_group
  partition by key(o_orderkey) partitions cpu_num;

DROP TABLE IF EXISTS partsupp;
CREATE TABLE partsupp (
  ps_partkey bigint not null,
  ps_suppkey bigint not null,
  ps_availqty bigint default null,
  ps_supplycost bigint default null,
  ps_comment varchar(199) default null,
  PRIMARY KEY (ps_partkey, ps_suppkey))row_format = condensed
  tablegroup tpch_tg_partsupp_part
  partition by key(ps_partkey) partitions cpu_num;

DROP TABLE IF EXISTS part;
CREATE TABLE part (
  p_partkey bigint not null,
  p_name varchar(55) default null,
  p_mfgr char(25) default null,
  p_brand char(10) default null,
  p_type varchar(25) default null,
  p_size bigint default null,
  p_container char(10) default null,
  p_retailprice bigint default null,
  p_comment varchar(23) default null,
  PRIMARY KEY (p_partkey))row_format = condensed
  tablegroup tpch_tg_partsupp_part
  partition by key(p_partkey) partitions cpu_num;

DROP TABLE IF EXISTS customer;
CREATE TABLE customer (
  c_custkey bigint not null,
  c_name varchar(25) default null,
  c_address varchar(40) default null,
  c_nationkey bigint default null,
  c_phone char(15) default null,
  c_acctbal bigint default null,
  c_mktsegment char(10) default null,
  c_comment varchar(117) default null,
  PRIMARY KEY (c_custkey))row_format = condensed
  partition by key(c_custkey) partitions cpu_num;

DROP TABLE IF EXISTS supplier;
CREATE TABLE supplier (
  s_suppkey bigint not null,
  s_name char(25) default null,
  s_address varchar(40) default null,
  s_nationkey bigint default null,
  s_phone char(15) default null,
  s_acctbal bigint default null,
  s_comment varchar(101) default null,
  PRIMARY KEY (s_suppkey))row_format = condensed
  partition by key(s_suppkey) partitions cpu_num;

DROP TABLE IF EXISTS nation;
CREATE TABLE nation (
  n_nationkey bigint not null,
  n_name char(25) default null,
  n_regionkey bigint default null,
  n_comment varchar(152) default null,
  PRIMARY KEY (n_nationkey))row_format = condensed;

DROP TABLE IF EXISTS region;
CREATE TABLE region (
  r_regionkey bigint not null,
  r_name char(25) default null,
  r_comment varchar(152) default null,
  PRIMARY KEY (r_regionkey))row_format = condensed;
```

### 加载数据

您可以根据上述步骤生成的数据和 SQL 自行编写脚本。加载数据示例操作如下：

1. 创建加载脚本目录。

   ```
   [wieck@localhost dbgen] $ mkdir load
   [wieck@localhost dbgen] $ cd load
   [wieck@localhost load] $ cp xx/create_tpch_mysql_table_part.ddl ./
   ```
2. 创建 `load.py`脚本。

   ```
   [wieck@localhost load] $ vim load.py

   #!/usr/bin/env python
   #-*- encoding:utf-8 -*-
   import os
   import sys
   import time
   import commands
   hostname='$host_ip'  # 注意！！请填写某个 observer，如 observer A 所在服务器的 IP 地址
   port='$host_port'               # observer A 的端口号
   tenant='$tenant_name'              # 租户名
   user='$user'               # 用户名
   password='$password'           # 密码
   data_path='$path'         # 注意！！请填写 observer A 所在服务器下 tbl 所在目录
   db_name='$db_name'             # 数据库名
   # 创建表
   cmd_str='obclient -h%s -P%s -u%s@%s -p%s -D%s < create_tpch_mysql_table_part.ddl'%(hostname,port,user,tenant,password,db_name)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str='obclient -h%s -P%s -u%s@%s -p%s  -D%s -e "show tables;" '%(hostname,port,user,tenant,password,db_name)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c  -D%s -e "load data /*+ parallel(80) */ infile '%s/customer.tbl' into table customer fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c  -D%s -e "load data /*+ parallel(80) */ infile '%s/lineitem.tbl' into table lineitem fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c -D%s -e "load data /*+ parallel(80) */ infile '%s/nation.tbl' into table nation fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c  -D%s -e "load data /*+ parallel(80) */ infile '%s/orders.tbl' into table orders fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s   -D%s -e "load data /*+ parallel(80) */ infile '%s/partsupp.tbl' into table partsupp fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c  -D%s -e "load data /*+ parallel(80) */ infile '%s/part.tbl' into table part fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c  -D%s -e "load data /*+ parallel(80) */ infile '%s/region.tbl' into table region fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   cmd_str=""" obclient -h%s -P%s -u%s@%s -p%s -c  -D%s -e "load data /*+ parallel(80) */ infile '%s/supplier.tbl' into table supplier fields terminated by '|';" """ %(hostname,port,user,tenant,password,db_name,data_path)
   result = commands.getstatusoutput(cmd_str)
   print result
   ```
3. 加载数据。

   #### 注意

   加载数据需要安装 OBClient 客户端。

   ```
   python load.py
   (0,'')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.\nTABLE_NAME\nT1\nLINEITEM\nORDERS\nPARTSUPP\nPART\nCUSTOMER\nSUPPLIER\nNATION\nREGION')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   (0, 'obclient: [Warning] Using a password on the command line interface can be insecure.')
   ```
4. 执行合并。

   #### 说明

   执行合并需要使用 sys 租户登录。

   ```
   MySQL [(none)]> use oceanbase
   Database changed
   MySQL [oceanbase]> ALTER SYSTEM major freeze tenant=<your tenant name>;
   Query OK, 0 rows affected
   ```
5. 查看合并是否完成。

   ```
   MySQL [oceanbase]> SELECT FROZEN_SCN, LAST_SCN FROM oceanbase.CDB_OB_MAJOR_COMPACTION;
   +---------------------+---------------------+
   | FROZEN_SCN          | LAST_SCN            |
   +---------------------+---------------------+
   | 1667239201167716767 | 1667239201167716767 |
   | 1667239200111919300 | 1667239200111919300 |
   | 1667239201167452168 | 1667239201167452168 |
   | 1667239201168053124 | 1667239201168053124 |
   | 1667239201167520213 | 1667239201167520213 |
   +---------------------+---------------------+
   ```

   所有的 `FROZEN_SCN` 和 `LAST_SCN` 的值相等即表示合并完成。
6. 手动收集统计信息

   在测试用户下执行 `obclient -h$host_ip -P$host_port -u$user@$tenant -p$password -A -D$database` 命令。

   ```
   call dbms_stats.gather_schema_stats('$db_name',degree=>96);
   ```

### 执行测试

您可以根据上述步骤生成的数据和 SQL 自行编写脚本。执行测试示例操作如下：

1. 在 `queries` 目录下编写测试脚本 `tpch.sh`。

   ```
   [wieck@localhost queries] $ vim tpch.sh

     #!/bin/bash
     TPCH_TEST="obclient -h $host_ip -P $host_port -utpch_100g_part@tpch_mysql  -D tpch_100g_part  -ptest -c"
     # warmup预热
     for i in {1..22}
     do
         sql1="source db${i}.sql"
         echo $sql1| $TPCH_TEST >db${i}.log  || ret=1
     done
     # 正式执行
     for i in {1..22}
     do
         starttime=`date +%s%N`
         echo `date  '+[%Y-%m-%d %H:%M:%S]'` "BEGIN Q${i}"
         sql1="source db${i}.sql"
         echo $sql1| $TPCH_TEST >db${i}.log  || ret=1
         stoptime=`date +%s%N`
         costtime=`echo $stoptime $starttime | awk '{printf "%0.2f\n", ($1 - $2) / 1000000000}'`
         echo `date  '+[%Y-%m-%d %H:%M:%S]'` "END,COST ${costtime}s"
     done
   ```
2. 执行测试脚本。

   ```
   sh tpch.sh
   ```

   #### 说明

   测试结果可参考 [OceanBase TPC-H 性能测试报告](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499637)。

## FAQ

* 导入数据失败。报错信息如下：

  ```
  ERROR 1017 (HY000) at line 1: File not exist
  ```

  tbl 文件必须放在所连接的 OceanBase 数据库所在机器的某个目录下，因为加载数据必须本地导入。
* 查看数据报错。报错信息如下：

  ```
  ERROR 4624 (HY000)：No memory or reach tenant memory limit
  ```

  内存不足，建议增大租户内存。
* 导入数据报错。报错信息如下：

  ```
  ERROR 1227 (42501) at line 1: Access denied
  ```

  需要授予用户访问权限。运行以下命令，授予权限：

  ```
  grant file on *.* to tpch_100g_part;
  ```
* 查询 SQL 进行调整 dos2unix \* 时报错，报错信息如下：

  ```
  -bash: dos2unix: command not found
  ```

  需要安装 dos2unix。执行以下命令，即可安装：

  ```
  yum install -y dos2unix
  ```