---
title: OceanBase TPC-C 性能测试报告
description: 提供关于OceanBase TPC-C 性能测试报告的相关内容，
keywords: OceanBase TPC-C 性能测试报告,OceanBase 数据库,参考指南,性能测试,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase TPC-C 性能测试报告

## 测试环境 (阿里云 ECS)

* 3 节点硬件配置

  | 服务类型 | ECS 类型 | 实例数 | 机器核心数 | 内存 |
  | --- | --- | --- | --- | --- |
  | OceanBase 数据库 | ecs.g7.8xlarge | 3 | 32C | 128G  每台机器系统盘 300G，再挂载两块 400G 云盘作为 clog 盘和 Data 盘，性能级别为 PL1 |
  | ODP、Benchmark SQL | ecs.c7.16xlarge | 1 | 64C | 128G |
* 3 节点租户规格

  ```
  CREATE RESOURCE UNIT tpcc_unit max_cpu 26, memory_size '100g'
  CREATE RESOURCE POOL tpcc_pool unit = 'tpcc_unit', unit_num = 1, zone_list=('zone1','zone2','zone3');
  CREATE TENANT tpcc_tenant resource_pool_list=('tpcc_pool'),  zone_list('zone1', 'zone2', 'zone3'), primary_zone=RANDOM, locality='F@zone1,F@zone2,F@zone3' set variables ob_compatibility_mode='mysql', ob_tcp_invited_nodes='%';
  ```
* 软件版本

  | 服务类型 | 软件版本 |
  | --- | --- |
  | OceanBase 数据库 | + 企业版：OceanBase 4.2.2.0 + 社区版：OceanBase\_CE 4.2.2.0 |
  | ODP | OceanBase 4.2.1 |
  | Benchmark SQL | Benchmark SQL V5.0 |
  | JDBC | mysql-connector-java-5.1.47 |
  | OS | CentOS Linux release 7.9.2009 (Core) |

## 测试方案

1. 通过 obd 部署 OceanBase 集群，ODP 和 TPC-C 单独部署在一台机器上, 防止客户端的压力不足成为性能瓶颈。
2. 3 节点的 OceanBase 集群部署规模为 1：1：1，部署成功后先新建跑 TPC-C 测试的租户及用户（sys 租户是管理集群的内置系统租户，请勿直接使用 sys 租户进行测试），设置租户的 `primary_zone` 为 RANDOM。
3. 测试步骤请详见：[OceanBase 数据库 TPC-C 测试](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499636)。

### 测试规格

```
warehouses=1000
loadWorkers=40
terminals=800
runMins=5
newOrderWeight=45
paymentWeight=43
orderStatusWeight=4
deliveryWeight=4
stockLevelWeight=4
```

## 测试结果

OceanBase 集群规模为 1：1：1 性能数据：

```
TPC-C Result
Measured tpmC (NewOrders)   : 303653.87
Measured tpmTOTAL           : 674530.08
Transaction Count           : 3395842
```