---
title: OceanBase TPC-H 性能测试报告
description: 提供关于OceanBase TPC-H 性能测试报告的相关内容，
keywords: OceanBase TPC-H 性能测试报告,OceanBase 数据库,参考指南,性能测试,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase TPC-H 性能测试报告

## 测试环境 (阿里云 ECS)

* 3 节点硬件配置

  | 服务类型 | ECS 类型 | 实例数 | 机器核心数 | 内存 |
  | --- | --- | --- | --- | --- |
  | OceanBase 数据库 | ecs.g7.8xlarge | 3 | 32C | 128G  每台机器系统盘 300G，再挂载两块 400G 云盘作为 clog 盘和 Data 盘，性能级别为 PL1 |
  | TPC-H | ecs.g7.8xlarge | 1 | 32C | 128G |
* 3 节点租户规格

  ```
  CREATE RESOURCE UNIT tpch_unit max_cpu 26, memory_size '100g'
  CREATE RESOURCE POOL tpch_pool unit = 'tpch_unit', unit_num = 1, zone_list=('zone1','zone2','zone3');
  CREATE TENANT tpch_mysql resource_pool_list=('tpch_pool'),  zone_list('zone1', 'zone2', 'zone3'), primary_zone=RANDOM, locality='F@zone1,F@zone2,F@zone3' set variables ob_compatibility_mode='mysql', ob_tcp_invited_nodes='%';
  ```
* 软件版本

  | 服务类型 | 软件版本 |
  | --- | --- |
  | OceanBase 数据库 | + 企业版：OceanBase 4.2.2.0 + 社区版：OceanBase\_CE 4.2.2.0 |
  | TPC-H | V3.0.0 |
  | OS | CentOS Linux release 7.9.2009 (Core) |

## 测试方案

* 使用 obd 部署 OceanBase 数据库集群。TPC-H 客户端需要部署在一台机器上, 作为客户端的压力机器。您无需部署 ODP，测试时直连任意一台机器即可。
* 3 节点的 OceanBase 集群部署规模为 1：1：1。部署成功后先新建跑 TPCH 测试的租户及用户（sys 租户是管理集群的内置系统租户，请勿直接使用 sys 租户进行测试），设置租户的 `primary_zone` 为 RANDOM。
* 测试数据量：100G。
* 测试步骤详见 [OceanBase 数据库 TPC-H 测试](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499634)。

## 测试结果

| **Query ID** | **3节点 OBServer V4.2.2 查询响应时间（单位：秒）** |
| --- | --- |
| Q1 | 2.26 |
| Q2 | 0.50 |
| Q3 | 1.49 |
| Q4 | 0.61 |
| Q5 | 0.97 |
| Q6 | 0.15 |
| Q7 | 1.41 |
| Q8 | 0.94 |
| Q9 | 4.42 |
| Q10 | 1.10 |
| Q11 | 0.18 |
| Q12 | 1.18 |
| Q13 | 1.93 |
| Q14 | 0.30 |
| Q15 | 0.43 |
| Q16 | 0.61 |
| Q17 | 1.63 |
| Q18 | 0.93 |
| Q19 | 0.64 |
| Q20 | 1.43 |
| Q21 | 2.70 |
| Q22 | 1.20 |
| Total | 27.01 |