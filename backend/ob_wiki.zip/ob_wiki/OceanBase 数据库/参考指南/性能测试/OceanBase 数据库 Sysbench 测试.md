---
title: OceanBase 数据库 Sysbench 测试
description: 提供关于OceanBase 数据库 Sysbench 测试的相关内容，
keywords: OceanBase 数据库 Sysbench 测试,OceanBase 数据库,参考指南,性能测试,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 数据库 Sysbench 测试

本文介绍如何使用 Sysbench 测试对 OceanBase 数据库的 OLTP 性能进行测试。在本文中使用 2 种方式，对 OceanBase 运行 Sysbench 测试：

* 通过 obd test 命令一键进行 Sysbench 测试。
* 基于官方 Sysbench 工具手动 step by step 进行测试。

#### 说明

为了提升用户体验和易用性，让每一个开发者在使用数据库时都能获得较好的性能，OceanBase 数据库在 V4.0.0 版本之后，做了大量的优化工作。本性能测试方法仅基于基础参数进行调优，让开发者获得较好的数据库性能体验。

## 什么是 Sysbench

Sysbench 是一个基于 LuaJIT 的可编写脚本的多线程基准测试工具，可以执行 CPU、内存、线程、IO 和数据库等方面的性能测试，常用于评估测试各种不同系统参数下的数据库负载情况，不需要修改源码，通过自定义 lua 脚本就可以实现不同业务类型的测试。Sysbench 主要包括以下几种测试：

* CPU 性能
* 磁盘 IO 性能
* 调度程序性能
* 内存分配及传输速度
* POSIX 线程性能
* 数据库性能（OLTP 基准测试）

## 环境准备

* JDK：建议使用 1.8u131 及以上版本
* make：yum install make
* automake：yum install automake
* autoconf：yum install autoconf
* libtool：yum install libtool
* gcc：yum install gcc
* mariadb-devel：yum install mariadb-devel mariadb
* JDBC：建议使用 mysql-connector-java-5.1.47 版本
* Sysbench：建议使用 1.0 及以上版本
* OBClient ：详细信息，参考 [OBClient 文档](https://github.com/oceanbase/obclient/blob/master/README.md)

  #### 注意

  当使用的 OBClient 版本大于等于 2.2.0 时，会默认开启 ob20 协议以及全链路追踪的能力，在 Sysbench 测试中会影响性能，建议通过设置环境变量手动关闭：`export ENABLE_PROTOCOL_OB20=0`。
* OceanBase 数据库：建议单独部署 ODP。详细信息，参考 快速体验 OceanBase。
* iops：建议磁盘 iops 在 10000 以上
* 租户规格：

  ```
  CREATE RESOURCE UNIT sysbench_unit max_cpu 26, memory_size '100g';
  CREATE RESOURCE POOL sysbench_pool unit = 'sysbench_unit', unit_num = 1, zone_list=('zone1','zone2','zone3');
  CREATE TENANT sysbench_tenant resource_pool_list=('sysbench_pool'),  zone_list('zone1', 'zone2', 'zone3'), primary_zone=RANDOM, locality='F@zone1,F@zone2,F@zone3' set variables ob_compatibility_mode='mysql', ob_tcp_invited_nodes='%';
  ```

  #### 注意

  + 上文的租户规格是基于 [OceanBase Sysbench 性能测试报告](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499640)中的硬件配置进行配置的，您需根据自身数据库的硬件配置进行动态调整。
  + 部署集群时，建议不要使用 `obd cluster autodeploy` 命令，该命令为了保证稳定性，不会最大化资源利用率（例如不会使用所有内存），建议单独对配置文件进行调优，最大化资源利用率。。

## 测试方案

1. 本次测试需要用到 5 台机器，Sysbench 和 obd 部署在一台机器上，ODP 单独部署在一台机器上。通过 obd 部署 OceanBase 集群需要使用 3 台机器，OceanBase 集群规模为 1:1:1。

   #### 说明

   在 Sysbench 测试中，部署 Sysbench、ODP 和 obd 的机器有一定的灵活性，根据 OBServer 总核数的不同分为以下三种情况：

   * 当 OBServer 总核数小于等于 47 核时，该机器仅需要 8 核 64G 即可。
   * 当 OBServer 总核数在 48 核和 72 核之间时，该机器需要 16 核 128G。
   * 当 OBServer 总核数大于等于 73 核时，该机器需要 32 核 128G。
2. 部署成功后先新建进行 Sysbench 测试的租户及用户（sys 租户是管理集群的内置系统租户，请勿直接使用 sys 租户进行测试），设置租户的 `primary_zone` 为 RANDOM，RANDOM 表示新建表分区的 Leader 随机到这 3 台机器。
3. 通过 Sysbench 导入 30 张表，每张表有 100 万行数据。
4. 启动 Sysbench 客户端，进行 `point_select`、`read_write`、`read_only` 和 `write_only` 测试。
5. 每轮测试 `--time` 设置为 60s，线程数取值可以为 `32/64/128/256/512/1024` 等。

## obd 一键测试

添加一脚本 ob\_sysbench.sh

```
#!/bin/bash
export ENABLE_PROTOCOL_OB20=0

echo "run oltp_read_only test"
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_only.lua --table-size=1000000 --threads=32 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_only.lua --table-size=1000000 --threads=64 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_only.lua --table-size=1000000 --threads=128 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_only.lua --table-size=1000000 --threads=256 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_only.lua --table-size=1000000 --threads=512 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_only.lua --table-size=1000000 --threads=1024 --rand-type=uniform

echo "run oltp_write_only test"
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_write_only.lua --table-size=1000000 --threads=32 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_write_only.lua --table-size=1000000 --threads=64 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_write_only.lua --table-size=1000000 --threads=128 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_write_only.lua --table-size=1000000 --threads=256 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_write_only.lua --table-size=1000000 --threads=512 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_write_only.lua --table-size=1000000 --threads=1024 --rand-type=uniform

echo "run oltp_read_write test"
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_write.lua --table-size=1000000 --threads=32 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_write.lua --table-size=1000000 --threads=64 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_write.lua --table-size=1000000 --threads=128 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_write.lua --table-size=1000000 --threads=256 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_write.lua --table-size=1000000 --threads=512 --rand-type=uniform
obd test sysbench <deploy_name> --tenant=<tenant_name> --script-name=oltp_read_write.lua --table-size=1000000 --threads=1024 --rand-type=uniform
```

其中 `deploy_name` 为部署集群的名称，`tenant_name` 为租户名称，您需根据实际情况进行修改。

```
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://mirrors.aliyun.com/oceanbase/OceanBase.repo
sudo yum install ob-sysbench
./ob_sysbench.sh
```

#### 注意

* 使用 obd 运行 Sysbench 的详细参数介绍请参考命令 [obd test sysbench](https://www.oceanbase.com/docs/community-obd-cn-10000000000768424)。
* 使用 obd 进行一键测试时，集群的部署必须是由 obd 进行安装和部署，否则无法获取集群的信息，将导致无法根据集群的配置进行性能调优。
* 如果系统租户的密码通过终端登陆并修改，非默认空值，则需要您先在终端中将密码修改为默认值，之后通过 [obd cluster edit-config](https://www.oceanbase.com/docs/community-obd-cn-10000000000768422) 命令在配置文件中为系统租户设置密码，配置项是 `# root_password: # root user password`。在 `obd cluster edit-config` 命令执行结束后，您还需执行 [obd cluster reload](https://www.oceanbase.com/docs/community-obd-cn-10000000000768422)
* 运行 `obd test sysbench` 后，系统会详细列出运行步骤和输出，数据量越大耗时越久。
* `obd test sysbench` 会自动完成所有操作，无需其他额外任何操作，包含测试数据的生成、OceanBase 参数优化、加载和测试。当中间环节出错时可以参考命令 [obd test sysbench](https://www.oceanbase.com/docs/community-obd-cn-10000000000768424) 进行重试，例如可以跳过数据的生成直接进行加载和测试。

## 手动进行 Sysbench 测试

### 测试规格

```
--mysql-db=test 
--table_size=1000000 
--tables=30 
--threads=32/64/128/256/512/1024 
--report-interval=10
--time=60 
--db-ps-mode=disable
--rand-type=uniform
```

### 安装 Sysbench

按照以下步骤安装 Sysbench。

1. 下载 Sysbench。

   详细信息参考 [Sysbench 下载地址](https://github.com/akopytov/sysbench/releases/tag/1.0.20)。
2. 解压 Sysbench。

   ```
   unzip ./1.0.20.zip
   ```
3. 编译 Sysbench。

   进入 Sysbench 解压后的目录，运行以下命令编译 Sysbench：

   ```
   [wieck@localhost ~] $ cd sysbench-1.0.20
   [wieck@localhost sysbench-1.0.20] $./autogen.sh
   [wieck@localhost sysbench-1.0.20] $./configure --prefix=/usr/sysbench/ --with-mysql-includes=/usr/include/mysql/ --with-mysql-libs=/usr/lib64/mysql/ --with-mysql
   [wieck@localhost sysbench-1.0.20] $make
   [wieck@localhost sysbench-1.0.20] $make install
   [wieck@localhost sysbench-1.0.20] $cp -r /usr/sysbench/share/sysbench/* /usr/sysbench/bin/
   ```

   参数说明：

   | 参数名 | 说明 |
   | --- | --- |
   | --prefix | 指定 Sysbench 的安装目录。 |
   | --with-mysql-includes | 指定 mysql 的 includes 目录。 |
   | --with-mysql-libs | 指定 mysql 的 lib 目录。 |
   | --with-mysql | Sysbench 默认支持 MySQL |
4. 运行以下命令，验证 Sysbench 是否安装成功：

   ```
   [wieck@localhost sysbench-1.0.20] $./src/sysbench --help
   ```

   如果返回以下信息，则 Sysbench 安装成功。

   ```
   Usage:
      sysbench [options]... [testname] [command]
   Commands implemented by most tests: prepare run cleanup help
   ```

### 环境调优

在执行 Sysbench 测试前，需要对 OceanBase 数据库进行简单的设置。

OBServer 调优

```
ALTER system SET enable_sql_audit=false;
ALTER system SET enable_perf_event=false;
ALTER system SET syslog_level='PERF';
alter system set enable_record_trace_log=false;
```

### 操作步骤

按照以下步骤进行 Sysbench 测试：

1. 运行以下命令，初始化数据库：

   ```
   /usr/sysbench/bin/sysbench oltp_read_write.lua --mysql-host=x.x.x.x --mysql-port=xxxx --mysql-db=test --mysql-user=$user@$tenant --mysql-password=xxx --table_size=1000000 --tables=30 --threads=150 --report-interval=10 --rand-type=uniform --time=60 cleanup
   ```
2. 运行以下命令，新建表：

   ```
   /usr/sysbench/bin/sysbench oltp_read_write.lua --mysql-host=x.x.x.x --mysql-port=xxxx --mysql-db=test --mysql-user=$user@$tenant --mysql-password=test --table_size=1000000 --tables=30 --threads=150 --report-interval=10 --rand-type=uniform --time=60 prepare
   ```
3. 运行以下命令，执行测试：

   ```
   /usr/sysbench/bin/sysbench oltp_read_write.lua --mysql-host=x.x.x.x --mysql-port=xxxx --mysql-db=test --mysql-user=$user@$tenant --mysql-password=xxx --table_size=1000000 --tables=30 --threads=150 --report-interval=10 --time=60 --rand-type=uniform --db-ps-mode=disable run
   ```

   参数说明：

   | 参数名 | 说明 |
   | --- | --- |
   | --mysql-host | 运行 OceanBase 数据库机器的 IP。如果有 ODP 建议使用 ODP 的 IP。 |
   | --mysql-port | 端口号。 |
   | --mysql-db | 待连接的数据库。 |
   | --mysql-user | 用户名。 |
   | --mysql-password | 密码。 |
   | --table\_size | 每张表初始化的数据数量。 |
   | --tables | 初始化表的数量。 |
   | --threads | 启动的线程数量。 |
   | --time | 运行时间。设置为 `0` 时表示不限制时间。 |
   | --report-interval | 运行期间日志，单位为秒。 |
   | --events | 最大请求数量，定义数量后可以不需要 --time 选项。 |
   | --rand-type | 访问数据时使用的随机生成函数。取值可以为 `special`、`uniform`、`gaussian` 或 `pareto`。 默认值为 `special`，早期值为 `uniform`。 |
   | --skip\_trx=on | 在只读测试中打开或关闭事务。默认打开。 |
   | --percentile=N | 打印百分位 rt，默认值为 `95`。 |
   | oltp\_write\_only | 在 Sysbench 的 lua 目录下，自带有针对不同场景的测试用例，比如 insert 和 point\_select 等。 |

#### 说明

测试结果可参考 [OceanBase Sysbench 性能测试报告](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499640)。

## FAQ

* 安装 Sysbench 失败。报错信息如下：

  ```
  automake 1.10.x (aclocal) wasn't found, exiting
  ```

  操作系统没有安装 Automake。运行以下命令安装 Automake：

  ```
  yum install automake.noarch
  ```
* 安装 Sysbench 失败。报错信息如下：

  ```
  libtoolize 1.4+ wasn't found, exiting
  ```

  操作系统没有安装 Libtool。运行以下命令安装 Libtool：

  ```
  yum install libtool
  ```
* 安装 Sysbench 失败。报错信息如下：

  ```
  drv_mysql.c:35:19: fatal error: mysql.h: No such file or directory
  ```

  操作系统没有安装 MySQL 的 lib 库。运行以下命令安装：

  ```
  yum install mysql-community-devel.x86_64
  ```
* 安装 Sysbench 失败。报错信息如下：

  ```
  cannot find MySQL client libraries in /usr/lib/mysql/
  ```

  执行以下命令查找 MySQL 的 lib 库。可能位于 `/usr/lib64/mysql`。

  ```
  find /usr -name mysql
  ```
* 在 Sysbench 和 OceanBase 数据库配置均合理的情况下，性能还是很差。

  1. Sysbench 是对 CPU、内存、网络非常敏感的测试。如果客户端和目标测试数据库不在一个局域网中，网络延迟可能会影响 Sysbench 性能。
  2. 与 OceanBase 数据库集群使用了 ODP 有关，可以先对单个 OceanBase 数据库进程进行高并发压力测试，将结果和使用 ODP 的场景对比。
  3. 建议将 ODP 和 Sysbench 单独部署在同一台机器上，通过 ODP 进行 Sysbench 测试。
* 在高并发压力下，为什么系统的 CPU 利用率依然很低？

  虽然整体 CPU 偏低，但是部分模块的 CPU 可能达到很高的利用率。