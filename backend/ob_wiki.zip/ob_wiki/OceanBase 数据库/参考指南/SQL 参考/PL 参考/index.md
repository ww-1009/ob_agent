# 分类索引：PL 参考

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [参考指南](../../index.md) / [SQL 参考](../index.md) / PL 参考 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **PL 参考（MySQL 模式）** | 下设 PL 存储程序、PL 数据操作语句、PL 数据定义语句、PL 数据库管理语句、PL 条件控制语句 等 9 个子分类。 | `PL 参考（MySQL 模式）` `PL 存储程序` `PL 数据操作语句` `PL 数据定义语句` | [进入目录](./PL 参考（MySQL 模式）/index.md) |
| **PL 参考（Oracle 模式）** | 下设 PL 标签安全包、PL 触发器、PL 存储过程与函数、PL 集合与记录、PL 静态 SQL 等 6 个子分类。 | `PL 参考（Oracle 模式）` `PL 标签安全包` `PL 触发器` `PL 存储过程与函数` | [进入目录](./PL 参考（Oracle 模式）/index.md) |
| **什么是 PL** | 涵盖 PL 的主要功能、PL 简介、PL 的架构。 | `什么是 PL` `PL 的主要功能` `PL 简介` `PL 的架构` | [进入目录](./什么是 PL/index.md) |
