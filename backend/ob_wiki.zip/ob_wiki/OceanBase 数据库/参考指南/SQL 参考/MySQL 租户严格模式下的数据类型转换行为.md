---
title: MySQL 租户严格模式下的数据类型转换行为
description: 详细说明 MySQL 租户在严格模式下的数据类型转换行为差异。
keywords: MySQL 租户,严格模式,sql_mode,数据类型转换,DML,SELECT,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# MySQL 租户严格模式下的数据类型转换行为

MySQL 租户在 `sql_mode` 参数中启用严格模式（通过设置 `STRICT_TRANS_TABLES` 或 `STRICT_ALL_TABLES`）后，当执行 DML 语句（如 `INSERT`、`UPDATE`、`REPLACE` 和 `DELETE`）和 `SELECT` 语句时，如果发生数据类型转换失败，系统会采取不同的处理方式。

## 核心差异

| 语句类型 | 严格模式 OFF | 严格模式 ON | 设计理念 |
| --- | --- | --- | --- |
| **DML 语句** （INSERT、UPDATE、DELETE 等） | 执行成功 用默认值 0 填充失败数据 输出警告信息 | 执行失败 整体回滚 如果 DML 语句包含SELECT子查询，则 SELECT 子查询内部的类型转换也遵守严格模式限制 | 数据一致性优先 严格模式下拒绝有风险的数据转换 确保数据完整性和事务安全 |
| **SELECT 语句** （查询操作） | 继续执行 产生警告 返回部分结果或尝试转换 | 继续执行 产生警告 返回部分结果或尝试转换 | 数据查询操作 优先保证查询可用性 通过警告提示潜在问题 |

## 严格模式为 ON 的行为

### DML 语句

当 `sql_mode` 包含严格模式时，DML 语句遇到数据类型转换失败会立即终止执行。

**行为特征：**

* 语句执行失败，返回明确的错误消息
* 整个语句所做的修改被回滚
* 数据不会被部分更新或插入不符合目标列类型的数据

**示例：**

```
INSERT INTO t (int_col) VALUES ('abc');
-- 字符串 'abc' 无法转换为整数，失败报错

UPDATE t SET date_col = '2024-02-30';
-- '2024-02-30' 是无效日期（2 月没有 30 日），失败报错

INSERT INTO t (varchar10_col) VALUES ('This string is way too long');
-- 字符串长度超过 VARCHAR(10) 定义，失败报错
```

**原理：** DML 操作直接修改持久化数据。严格模式保证数据的准确性和一致性。允许错误的类型转换可能导致数据损坏或违反业务逻辑，因此 OceanBase 数据库选择在遇到危险转换时直接失败并回滚。

### SELECT 语句

当 `sql_mode` 包含严格模式时，`SELECT` 语句遇到数据类型转换失败时，处理方式比 DML 更宽容。

**行为特征：**

* 语句执行不会因类型转换失败而整体中断
* 转换失败的值会被视为 `NULL` 或默认值
* 生成警告信息，可通过 `SHOW WARNINGS;` 查看
* 查询继续执行并返回结果集

**示例：**

```
SELECT * FROM t WHERE int_col = 'abc';
-- 'abc' 无法转为整数，产生警告，可能被视为 0 或 NULL

SELECT DATE_ADD('2024-02-30', INTERVAL 1 DAY);
-- 无效日期，产生警告，函数返回 NULL

SELECT CAST('abc' AS UNSIGNED);
-- 尝试将字符串转换为无符号整数，产生警告，返回 0
```

**原理：** `SELECT` 是查询操作，不修改持久化数据。其主要目标是尽可能返回结果供用户检查。严格模式在 `SELECT` 中更侧重于其他方面（如 `ONLY_FULL_GROUP_BY`），对于类型转换失败倾向于弹性和部分结果的可用性。

## 严格模式为 OFF 的行为

### DML 语句

非严格模式下，DML 语句遇到类型转换失败会继续执行。

**行为特征：**

* 语句执行成功，输出警告信息
* 使用对应类型的 0 值替换转换失败的数据
* 数据被写入表中

**示例：**

```
CREATE TABLE test(a INT, b INT);
INSERT INTO test VALUES('abc', 'abc');
SELECT * FROM test;
```

执行结果：

```
+------+------+
| a    | b    |
+------+------+
|    0 |    0 |
+------+------+
1 row in set (0.039 sec)
```

### SELECT 语句

非严格模式下的 `SELECT` 语句行为与严格模式 ON 时类似，都会产生警告并继续执行。

## 重要注意事项

### STRICT\_TRANS\_TABLES vs STRICT\_ALL\_TABLES

在 MySQL 中，这两个模式在 DML 行为上对于类型转换失败的处理是一致的（都会报错）。主要区别在于非事务表（如 MyISAM）的处理。由于 OceanBase 底层的事务引擎在不同的 `sql_mode` 下并没有差异，所以在 OceanBase 的 MySQL 租户中，`STRICT_TRANS_TABLES` 和 `STRICT_ALL_TABLES` 在对待类型转换失败的行为上通常没有区别。

### 隐式转换规则

即使没有转换失败，隐式转换也可能导致精度损失或语义变化。严格模式不会阻止所有隐式转换，它主要阻止那些完全无法转换或会导致数据完全丢失/无效的情况（如字符串转数字失败、无效日期、超长字符串插入）。

### 显式转换

使用 `CAST()` 函数进行显式转换时，如果转换失败，在任何语句类型和任何 `sql_mode` 下，都会返回 `NULL` 并产生警告。这是 SQL 标准行为。

### 其他模式

严格模式通常与其他模式如 `ERROR_FOR_DIVISION_BY_ZERO` 一起设置。这些模式会影响除以零、无效日期等特定错误的处理。

## 故障诊断

* **错误（`ERROR`）vs 警告（`WARNING`）：** 客户端返回 `ERROR` 则 DML 语句因完全失败。返回结果集但有警告意味着是 `SELECT` 语句中发生了转换问题。
* **检查 `sql_mode`：** 使用 `SELECT @@sql_mode;` 确认严格模式是否启用。
* **查看执行计划与日志：** 对于复杂情况，OceanBase 的执行计划输出（`EXPLAIN`）可提供更详细的线索。