# 分类索引：SQL 参考

> 位置：[ob_wiki](../../../index.md) / [OceanBase 数据库](../../index.md) / [参考指南](../index.md) / SQL 参考 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **PL 参考** | 下设 PL 参考（MySQL 模式）、PL 参考（Oracle 模式）、什么是 PL，共 3 个子分类。 | `PL 参考` `PL 参考（MySQL 模式）` `PL 参考（Oracle 模式）` `什么是 PL` | [进入目录](./PL 参考/index.md) |
| **SQL 语法** | 下设 普通租户（MySQL 模式）、普通租户（Oracle 模式）、系统租户，共 3 个子分类。 | `SQL 语法` `普通租户（MySQL 模式）` `普通租户（Oracle 模式）` `系统租户` | [进入目录](./SQL 语法/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [MySQL 租户严格模式下的数据类型转换行为.md](./MySQL 租户严格模式下的数据类型转换行为.md) | 提供关于MySQL 租户严格模式下的数据类型转换行为的相关内容， | MySQL 租户严格模式下的数据类型转换行为,OceanBase 数据库,参考指南,SQL 参考,文档,使用帮助,OceanBase,分布式,数据库 |
| [预留关键字（MySQL 模式）.md](./预留关键字（MySQL 模式）.md) | 提供关于预留关键字（MySQL 模式）的相关内容， | 预留关键字（MySQL 模式）,OceanBase 数据库,参考指南,SQL 参考,文档,使用帮助,OceanBase,分布式,数据库 |
| [预留关键字（Oracle 模式）.md](./预留关键字（Oracle 模式）.md) | 提供关于预留关键字（Oracle 模式）的相关内容， | 预留关键字（Oracle 模式）,OceanBase 数据库,参考指南,SQL 参考,文档,使用帮助,OceanBase,分布式,数据库 |
