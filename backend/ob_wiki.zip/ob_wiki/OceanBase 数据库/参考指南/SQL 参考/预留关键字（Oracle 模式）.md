---
title: 预留关键字（Oracle 模式）
description: 提供关于预留关键字（Oracle 模式）的相关内容，
keywords: 预留关键字（Oracle 模式）,OceanBase 数据库,参考指南,SQL 参考,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:56:58.000+00:00
---

# 预留关键字（Oracle 模式）

#### 功能适用性

该内容仅适用于 OceanBase 数据库企业版。OceanBase 数据库社区版仅提供了 MySQL 模式。

目前，OceanBase 数据库 Oracle 模式下的预留关键字如下所示。

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| A | | | | |
| ACCESS | ADD | ALL | ALTER | AND |
| ANY | AS | ASC | AUDIT | |
| B | | | | |
| BETWEEN | BY | | | |
| C | | | | |
| CHAR | CHECK | CLUSTER | COLUMN | COMMENT |
| COMPRESS | CONNECT | CREATE | CURRENT | CASE |
| CONNECT\_BY\_ROOT | CROSS | | | |
| D | | | | |
| DATE | DECIMAL | DEFAULT | DELETE | DESC |
| DISTINCT | DROP | DUAL | | |
| E | | | | |
| ELSE | EXCLUSIVE | EXISTS | | |
| F | | | | |
| FILE | FLOAT | FOR | FROM | FULL |
| G | | | | |
| GRANT | GROUP | | | |
| H | | | | |
| HAVING | | | | |
| I | | | | |
| IDENTIFIED | IMMEDIATE | IN | INCREMENT | INDEX |
| INITIAL | INSERT | INTEGER | INTERSECT | INTO |
| IS | INNER | | | |
| J | | | | |
| JOIN | | | | |
| L | | | | |
| LEVEL | LIKE | LOCK | LONG | LEFT |
| M | | | | |
| MAXEXTENTS | MINUS | MODE | MODIFY | |
| N | | | | |
| NOAUDIT | NOCOMPRESS | NOT | NOTFOUND | NOWAIT |
| NULL | NUMBER | NATURAL | | |
| O | | | | |
| OF | OFFLINE | ON | ONLINE | OPTION |
| OR | ORDER | | | |
| P | | | | |
| PCTFREE | PRIOR | PRIVILEGES | PUBLIC | RAW |
| R | | | | |
| RENAME | RESOURCE | REVOKE | ROW | ROWID |
| ROWLABEL | ROWNUM | ROWS | RETURN | RIGHT |
| RETURNING |  |  |  |
| S | | | | |
| START | SELECT | SESSION | SET | SHARE |
| SIZE | SMALLINT | SUCCESSFUL | SYNONYM | SYSDATE |
| SQL\_CALC\_FOUND\_ROWS | | | | |
| T | | | | |
| TABLE | THEN | TO | TRIGGER | |
| U | | | | |
| UID | UNION | UNIQUE | UPDATE | USER | |
| USING |
| V | | | | |
| VALIDATE | VALUES | VARCHAR | VARCHAR2 | VIEW |
| W | | | | |
| WHENEVER | WHERE | WITH | | |