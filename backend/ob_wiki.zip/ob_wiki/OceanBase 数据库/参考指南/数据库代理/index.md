# 分类索引：数据库代理

> 位置：[ob_wiki](../../../index.md) / [OceanBase 数据库](../../index.md) / [参考指南](../index.md) / 数据库代理 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **OBProxy** | 下设 管理 OBProxy、管理 OBProxy 集群，共 2 个子分类。 | `OBProxy` `管理 OBProxy` `管理 OBProxy 集群` | [进入目录](./OBProxy/index.md) |
| **路由管理** | 涵盖 ODP 表路由、LDC 路由。 | `路由管理` `ODP 表路由` `LDC 路由` | [进入目录](./路由管理/index.md) |
| **逻辑连接** | 涵盖 展示 Session 变量、终止 Server Session、展示 Session 详细状态、展示全部 Session 等 5 项。 | `逻辑连接` `展示 Session 变量` `终止 Server Session` `展示 Session 详细状态` | [进入目录](./逻辑连接/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OceanBase 数据库代理（ODP）.md](./OceanBase 数据库代理（ODP）.md) | 提供关于OceanBase 数据库代理（ODP）的相关内容， | OceanBase 数据库代理（ODP）,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库 |
| [查看租户会话.md](./查看租户会话.md) | 提供关于查看租户会话的相关内容， | 查看租户会话,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库 |
| [设置租户最大连接数.md](./设置租户最大连接数.md) | 提供关于设置租户最大连接数的相关内容， | 设置租户最大连接数,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库 |
| [数据库连接和路由概述.md](./数据库连接和路由概述.md) | 提供关于数据库连接和路由概述的相关内容， | 数据库连接和路由概述,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库 |
| [物理连接.md](./物理连接.md) | 提供关于物理连接的相关内容， | 物理连接,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库 |
| [终止租户会话.md](./终止租户会话.md) | 提供关于终止租户会话的相关内容， | 终止租户会话,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库 |
