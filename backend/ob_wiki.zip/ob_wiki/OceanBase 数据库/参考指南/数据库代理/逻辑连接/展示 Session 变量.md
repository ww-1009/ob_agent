---
title: 展示 Session 变量
description: 提供关于展示 Session 变量的相关内容，
keywords: 展示 Session 变量,OceanBase 数据库,参考指南,数据库代理,逻辑连接,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# 展示 Session 变量

Session 变量分为系统变量和用户变量。本文介绍了如何查看 ODP 上指定 Client Session 的 Session 变量。

## 操作步骤

`sys` 租户和用户租户可以通过 `SHOW PROXYSESSION VARIABLES` 语句查看指定 Client Session 的 Session 变量。

1. 通过 ODP 连接的方式连接 OceanBase 数据库。

   连接示例如下：

   ```
   obclient -h10.xx.xx.xx -uusername@obtenant#obdemo -P2883 -p****** -c -A oceanbase
   ```

   有关更加详细的通过 ODP 连接方式连接数据库的操作指引，请参见 [通过 OBClient 连接 OceanBase 租户（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499954) 和 [通过 OBClient 连接 OceanBase 租户（Oracle 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499914)。
2. 查看指定 Client Session 的 Session 变量。

   ```
   SHOW PROXYSESSION VARIABLES [ALL] id [LIKE 'xx'];
   ```

   参数说明：

   * 不带 `ALL` 参数时，展示指定 Client Session 的本地 Session 变量 (包括：修改过的系统变量和用户变量)。
   * 带 `ALL` 参数时，展示指定 Client Session 的全部 Session 变量 (包括：所有系统变量和用户变量)。
   * `id` 既可以是 `cs_id`，也可以是 `connection_id`，显示结果相同。

     `cs_id` 为 ODP 内部标记的每个 client 的 `id` 号，`connection_id` 为整个 OceanBase 数据库标记的每个 client 的 `id` 号。

     MySQL 模式下的 `connection_id` 通过 `SELECT CONNECTION_ID();` 语句获取，Oracle 模式下的 `connection_id` 通过 `SHOW FULL PROCESSLIST;` 语句获取。
   * `like` 模糊匹配，支持 '%' 和 '\_'。

   示例如下：

   MySQL 模式

   Oracle 模式

   1. 获取 `cs_id` 或 `connection_id`。

      执行以下语句获取 `cs_id`。

      ```
      SHOW PROXYSESSION;
      ```

      查询结果如下，返回结果中的 `Id` 即为 `cs_id`。

      ```
      +----------------------+-------+----------+----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
      | proxy_sessid         | Id    | Cluster  | Tenant   | User | Host                 | db   | trans_count | svr_session_count | state             | tid   | pid   | using_ssl |
      +----------------------+-------+----------+----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
      | 12402504630519660559 | 65149 | test420  | mysql001 | root | 100.xx.xx.xx:46069   | NULL |           0 |                 1 | MCS_ACTIVE_READER | 76286 | 76286 |         0 |
      +----------------------+-------+----------+----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
      1 row in set
      ```

      或者，执行以下语句获取 `connection_id`。

      ```
      SELECT CONNECTION_ID();
      ```

      返回如下所示结果。

      ```
      +-----------------+
      | CONNECTION_ID() |
      +-----------------+
      |      3221593149 |
      +-----------------+
      1 row in set
      ```
   2. 查看指定 Client Session 的本地 Session 变量。

      ```
      SHOW PROXYSESSION VARIABLES 65149;
      ```

      或者

      ```
      SHOW PROXYSESSION VARIABLES 3221593149;
      ```

      查询结果如下：

      ```
      +-----------------------------------+--------------+-----------------+--------------------+-----------------------------------------------+
      | variable_name                     | value        | info            | modified_type      | sys_variable_flag                             |
      +-----------------------------------+--------------+-----------------+--------------------+-----------------------------------------------+
      | ob_proxy_global_variables_version | 0            | changed sys var | cold modified vars |  && invisible && session_scope && readonly    |
      | ob_proxy_user_privilege           | 133009965054 | changed sys var | cold modified vars |  && invisible && session_scope && readonly    |
      | ob_capability_flag                | 916303       | changed sys var | cold modified vars |  && invisible && session_scope && readonly    |
      | ob_enable_transmission_checksum   | 1            | changed sys var | cold modified vars |  && global_scope && session_scope             |
      | character_set_database            | 45           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | collation_database                | 45           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | _min_cluster_version              | '4.2.0.0'    | user var        | cold modified vars |                                               |
      +-----------------------------------+--------------+-----------------+--------------------+-----------------------------------------------+
      7 rows in set
      ```
   3. 查看指定 Client Session 的所有 Session 变量。

      ```
      SHOW PROXYSESSION VARIABLES ALL 65149 LIKE '%id%';
      ```

      或者

      ```
      SHOW PROXYSESSION VARIABLES ALL 3221593149 LIKE '%id%';
      ```

      查询结果如下：

      ```
      +--------------------------------------+----------------------------------------+---------+------------------------------+--------------------------------------------+
      | variable_name                        | value                                  | info    | modified_type                | sys_variable_flag                          |
      +--------------------------------------+----------------------------------------+---------+------------------------------+--------------------------------------------+
      | last_insert_id                       | 0                                      | sys var | last insert id modified vars |  && session_scope                          |
      | identity                             | 0                                      | sys var | cold modified vars           |  && session_scope                          |
      | server_id                            | 1                                      | sys var | cold modified vars           |  &&global_scope                           |
      | query_cache_wlock_invalidate         | 0                                      | sys var | cold modified vars           |  && global_scope && session_scope          |
      | server_uuid                          | 'd72b5d0d-2c50-11ee-b1de-2646ab385e11' | sys var | cold modified vars           |  && global_scope && readonly               |
      | ob_org_cluster_id                    | 0                                      | sys var | cold modified vars           |  && session_scope                          |
      | ob_statement_trace_id                | 'Y0-0'                                 | sys var | cold modified vars           |  && invisible && session_scope && readonly |
      | ob_trx_idle_timeout                  | 86400000000                            | sys var | cold modified vars           |  && global_scope && session_scope          |
      | tracefile_identifier                 | ''                                     | sys var | cold modified vars           |  && session_scope                          |
      | validate_password_check_user_name    | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_length             | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_mixed_case_count   | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_number_count       | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_policy             | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_special_char_count | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      +--------------------------------------+----------------------------------------+---------+------------------------------+--------------------------------------------+
      15 rows in set
      ```

   1. 获取 `cs_id` 或 `connection_id`。

      执行以下语句获取 `cs_id`。

      ```
      SHOW PROXYSESSION;
      ```

      查询结果如下，返回结果中的 `Id` 即为 `cs_id`。

      ```
      +----------------------+-------+----------+-----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
      | proxy_sessid         | Id    | Cluster  | Tenant    | User | Host                 | db   | trans_count | svr_session_count | state             | tid   | pid   | using_ssl |
      +----------------------+-------+----------+-----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
      | 12402504630519660558 | 65141 | test420  | oracle001 | sys  | 100.xx.xx.xx:59648   | SYS  |           0 |                 1 | MCS_ACTIVE_READER | 76286 | 76286 |         0 |
      +----------------------+-------+----------+-----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
      1 row in set
      ```

      执行以下语句获取 `connection_id`。

      ```
      SHOW FULL PROCESSLIST;
      ```

      返回如下所示结果，返回结果中的 `id` 即为 `connection_id`。

      ```
      +------------+------+-----------+---------------------+------+---------+------+--------+-----------------------+---------------+------+
      | ID         | USER | TENANT    | HOST                | DB   | COMMAND | TIME | STATE  | INFO                  | IP            | PORT |
      +------------+------+-----------+---------------------+------+---------+------+--------+-----------------------+---------------+------+
      | 3221583071 | SYS  | oracle001 | 172.xx.xx.xx:45343  | SYS  | Query   |    0 | ACTIVE | SHOW FULL PROCESSLIST | 172.xx.xx.64  | 2881 |
      +------------+------+-----------+---------------------+------+---------+------+--------+-----------------------+---------------+------+
      1 row in set
      ```
   2. 查看指定 Client Session 的本地 Session 变量。

      ```
      SHOW PROXYSESSION VARIABLES 65141;
      ```

      或者

      ```
      SHOW PROXYSESSION VARIABLES 3221583071;
      ```

      查询结果如下：

      ```
      +-----------------------------------+--------------+-----------------+--------------------+-----------------------------------------------+
      | variable_name                     | value        | info            | modified_type      | sys_variable_flag                             |
      +-----------------------------------+--------------+-----------------+--------------------+-----------------------------------------------+
      | autocommit                        | 0            | changed sys var | hot modified vars  |  && global_scope && session_scope             |
      | character_set_connection          | 46           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | character_set_database            | 46           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | character_set_server              | 46           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | collation_connection              | 46           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | collation_database                | 46           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | collation_server                  | 46           | changed sys var | cold modified vars |  && global_scope && session_scope && nullable |
      | sql_mode                          | 2151677954   | changed sys var | cold modified vars |  && global_scope && session_scope             |
      | group_concat_max_len              | 32767        | changed sys var | cold modified vars |  && global_scope && session_scope             |
      | ob_proxy_global_variables_version | 0            | changed sys var | cold modified vars |  && invisible && session_scope && readonly    |
      | ob_proxy_user_privilege           | 133009965054 | changed sys var | cold modified vars |  && invisible && session_scope && readonly    |
      | ob_capability_flag                | 916303       | changed sys var | cold modified vars |  && invisible && session_scope && readonly    |
      | ob_enable_transmission_checksum   | 1            | changed sys var | cold modified vars |  && global_scope && session_scope             |
      | _min_cluster_version              | '4.2.0.0'    | user var        | cold modified vars |                                               |
      +-----------------------------------+--------------+-----------------+--------------------+-----------------------------------------------+
      14 rows in set
      ```
   3. 查看指定 Client Session 的所有 Session 变量。

      ```
      SHOW PROXYSESSION VARIABLES ALL 65141 LIKE '%id%';
      ```

      或者

      ```
      SHOW PROXYSESSION VARIABLES ALL 3221583071 LIKE '%id%';
      ```

      查询结果如下：

      ```
      +--------------------------------------+----------------------------------------+---------+------------------------------+--------------------------------------------+
      | variable_name                        | value                                  | info    | modified_type                | sys_variable_flag                          |
      +--------------------------------------+----------------------------------------+---------+------------------------------+--------------------------------------------+
      | last_insert_id                       | 0                                      | sys var | last insert id modified vars |  && session_scope                          |
      | identity                             | 0                                      | sys var | cold modified vars           |  && session_scope                          |
      | server_id                            | 1                                      | sys var | cold modified vars           |  &&global_scope                           |
      | query_cache_wlock_invalidate         | 0                                      | sys var | cold modified vars           |  && global_scope && session_scope          |
      | server_uuid                          | 'd72b5d0d-2c50-11ee-b1de-2646ab385e11' | sys var | cold modified vars           |  && global_scope && readonly               |
      | ob_org_cluster_id                    | 0                                      | sys var | cold modified vars           |  && session_scope                          |
      | ob_statement_trace_id                | 'Y0-0'                                 | sys var | cold modified vars           |  && invisible && session_scope && readonly |
      | ob_trx_idle_timeout                  | 86400000000                            | sys var | cold modified vars           |  && global_scope && session_scope          |
      | tracefile_identifier                 | ''                                     | sys var | cold modified vars           |  && session_scope                          |
      | validate_password_check_user_name    | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_length             | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_mixed_case_count   | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_number_count       | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_policy             | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      | validate_password_special_char_count | 0                                      | sys var | cold modified vars           |  && global_scope                           |
      +--------------------------------------+----------------------------------------+---------+------------------------------+--------------------------------------------+
      15 rows in set
      ```

   各字段含义如下表所示：

   | 字段 | 说明 |
   | --- | --- |
   | variable\_name | 变量名 |
   | value | 变量值 |
   | info | 变量类型（用户变量或系统变量） |
   | modified\_type | 变量类型（根据修改频率区分） |
   | sys\_variable\_flag | 系统变量范围 |

## 相关文档

有关系统变量的详细介绍请参见 [配置项和系统变量概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499714)。