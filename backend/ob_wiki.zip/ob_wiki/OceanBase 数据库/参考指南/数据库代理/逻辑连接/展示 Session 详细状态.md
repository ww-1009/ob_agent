---
title: 展示 Session 详细状态
description: 提供关于展示 Session 详细状态的相关内容，
keywords: 展示 Session 详细状态,OceanBase 数据库,参考指南,数据库代理,逻辑连接,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# 展示 Session 详细状态

本文介绍了如何查看 ODP 上指定 Client Session 的详细内部状态。

## 操作步骤

`sys` 租户和用户租户可以通过 `SHOW PROXYSESSION ATTRIBUTE` 语句查看指定 Client Session 的详细内部状态，包括该 Client Session 上涉及的相关 Server Session。

1. 通过 ODP 连接的方式连接 OceanBase 数据库。

   连接示例如下：

   ```
   obclient -h10.xx.xx.xx -uusername@obtenant#obdemo -P2883 -p****** -c -A oceanbase
   ```

   有关更加详细的通过 ODP 连接方式连接数据库的操作指引，请参见 [通过 OBClient 连接 OceanBase 租户（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499954) 和 [通过 OBClient 连接 OceanBase 租户（Oracle 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499914)。
2. 查看指定 Client Session 的详细内部状态。

   SQL 语句如下：

   ```
   SHOW PROXYSESSION ATTRIBUTE [id [LIKE 'xxx']]
   ```

   参数说明：

   * 不指定 `id` 时，显示当前 Session 的详细状态( ODP 1.1.0 版本起开始支持)，支持模糊查询当前 Session 指定属性名称的 value ( proxy 1.1.2 版本起开始支持)。
   * 指定 `id` 时，支持模糊查询指定属性名称的 value ( ODP 1.1.0 版本起开始支持)。
   * `id` 既可以是 `cs_id`，也可以是 `connection_id`，显示结果相同。

     `cs_id` 为 ODP 内部标记的每个 Client 的 `id` 号，`connection_id` 为整个 OceanBase 数据库标记的每个 Client 的 `id` 号。

     MySQL 模式下的 `connection_id` 通过 `SELECT CONNECTION_ID();` 语句获取，Oracle 模式下的 `connection_id` 通过 `SHOW FULL PROCESSLIST;` 语句获取。
   * `LIKE` 模糊匹配，支持 '%' 和 '\_'。

   示例如下：

   MySQL 模式

   Oracle 模式

   1. 查看 Client Session 的详细状态。

      ```
      SHOW PROXYSESSION ATTRIBUTE;
      ```

      查询结果如下：

      ```
      +----------------------------------+----------------------+----------------+
      | attribute_name                   | value                | info           |
      +----------------------------------+----------------------+----------------+
      | proxy_sessid                     | -6044239443189891054 | cs common      |
      | cs_id                            | 65160                | cs common      |
      | cluster                          | test420              | cs common      |
      | tenant                           | mysql001             | cs common      |
      | user                             | root                 | cs common      |
      | host_ip                          | 100.xx.xx.xx         | cs common      |
      | host_port                        | 48056                | cs common      |
      | db                               | NULL                 | cs common      |
      | total_trans_cnt                  | 0                    | cs common      |
      | svr_session_cnt                  | 1                    | cs common      |
      | active                           | true                 | cs common      |
      | read_state                       | MCS_ACTIVE_READER    | cs common      |
      | tid                              | 76286                | cs common      |
      | pid                              | 76286                | cs common      |
      | idc_name                         |                      | cs common      |
      | modified_time                    | 0                    | cs stat        |
      | reported_time                    | 0                    | cs stat        |
      | hot_sys_var_version              | 0                    | cs var version |
      | sys_var_version                  | 2                    | cs var version |
      | user_var_version                 | 0                    | cs var version |
      | last_insert_id_version           | 0                    | cs var version |
      | db_name_version                  | 0                    | cs var version |
      | server_ip                        | 172.xx.xx.xx         | last used ss   |
      | server_port                      | 2881                 | last used ss   |
      | server_sessid                    | 3221597019           | last used ss   |
      | ss_id                            | 22                   | last used ss   |
      | state                            | MSS_KA_CLIENT_SLAVE  | last used ss   |
      | transact_count                   | 4                    | last used ss   |
      | server_trans_stat                | 0                    | last used ss   |
      | hot_sys_var_version              | 0                    | last used ss   |
      | sys_var_version                  | 2                    | last used ss   |
      | user_var_version                 | 0                    | last used ss   |
      | last_insert_id_version           | 0                    | last used ss   |
      | db_name_version                  | 0                    | last used ss   |
      | is_checksum_supported            | 1                    | last used ss   |
      | is_safe_read_weak_supported      | 0                    | last used ss   |
      | is_checksum_switch_supported     | 1                    | last used ss   |
      | checksum_switch                  | 1                    | last used ss   |
      | enable_extra_ok_packet_for_stats | 1                    | last used ss   |
      +----------------------------------+----------------------+----------------+
      39 rows in set
      ```
   2. 通过模糊查询，查询指定属性的详细信息。

      ```
      SHOW PROXYSESSION ATTRIBUTE 65160 like '%id%';
      ```

      查询结果如下：

      ```
      +------------------------+----------------------+----------------+
      | attribute_name         | value                | info           |
      +------------------------+----------------------+----------------+
      | proxy_sessid           | -6044239443189891054 | cs common      |
      | cs_id                  | 65160                | cs common      |
      | tid                    | 76286                | cs common      |
      | pid                    | 76286                | cs common      |
      | idc_name               |                      | cs common      |
      | last_insert_id_version | 0                    | cs var version |
      | server_sessid          | 3221597019           | last used ss   |
      | ss_id                  | 22                   | last used ss   |
      | last_insert_id_version | 0                    | last used ss   |
      +------------------------+----------------------+----------------+
      9 rows in set
      ```

   1. 查看 Client Session 的详细状态。

      ```
      SHOW PROXYSESSION ATTRIBUTE;
      ```

      查询结果如下：

      ```
      +----------------------------------+----------------------+----------------+
      | attribute_name                   | value                | info           |
      +----------------------------------+----------------------+----------------+
      | proxy_sessid                     | -6044239443189891058 | cs common      |
      | cs_id                            | 65141                | cs common      |
      | cluster                          | test420              | cs common      |
      | tenant                           | oracle001            | cs common      |
      | user                             | sys                  | cs common      |
      | host_ip                          | 100.xx.xx.xx         | cs common      |
      | host_port                        | 59648                | cs common      |
      | db                               | SYS                  | cs common      |
      | total_trans_cnt                  | 0                    | cs common      |
      | svr_session_cnt                  | 1                    | cs common      |
      | active                           | true                 | cs common      |
      | read_state                       | MCS_ACTIVE_READER    | cs common      |
      | tid                              | 76286                | cs common      |
      | pid                              | 76286                | cs common      |
      | idc_name                         |                      | cs common      |
      | modified_time                    | 0                    | cs stat        |
      | reported_time                    | 0                    | cs stat        |
      | hot_sys_var_version              | 1                    | cs var version |
      | sys_var_version                  | 10                   | cs var version |
      | user_var_version                 | 0                    | cs var version |
      | last_insert_id_version           | 0                    | cs var version |
      | db_name_version                  | 1                    | cs var version |
      | server_ip                        | xx.xx.xx.xx          | last used ss   |
      | server_port                      | 2881                 | last used ss   |
      | server_sessid                    | 3221583071           | last used ss   |
      | ss_id                            | 18                   | last used ss   |
      | state                            | MSS_KA_CLIENT_SLAVE  | last used ss   |
      | transact_count                   | 4                    | last used ss   |
      | server_trans_stat                | 0                    | last used ss   |
      | hot_sys_var_version              | 1                    | last used ss   |
      | sys_var_version                  | 10                   | last used ss   |
      | user_var_version                 | 0                    | last used ss   |
      | last_insert_id_version           | 0                    | last used ss   |
      | db_name_version                  | 1                    | last used ss   |
      | is_checksum_supported            | 1                    | last used ss   |
      | is_safe_read_weak_supported      | 0                    | last used ss   |
      | is_checksum_switch_supported     | 1                    | last used ss   |
      | checksum_switch                  | 1                    | last used ss   |
      | enable_extra_ok_packet_for_stats | 1                    | last used ss   |
      +----------------------------------+----------------------+----------------+
      39 rows in set
      ```
   2. 通过模糊查询，查询指定属性的详细信息。

      ```
      SHOW PROXYSESSION ATTRIBUTE 65141 LIKE '%id%';
      ```

      查询结果如下：

      ```
      +------------------------+----------------------+----------------+
      | attribute_name         | value                | info           |
      +------------------------+----------------------+----------------+
      | proxy_sessid           | -6044239443189891058 | cs common      |
      | cs_id                  | 65141                | cs common      |
      | tid                    | 76286                | cs common      |
      | pid                    | 76286                | cs common      |
      | idc_name               |                      | cs common      |
      | last_insert_id_version | 0                    | cs var version |
      | server_sessid          | 3221583071           | last used ss   |
      | ss_id                  | 18                   | last used ss   |
      | last_insert_id_version | 0                    | last used ss   |
      +------------------------+----------------------+----------------+
      9 rows in set
      ```

   各字段含义如下表所示：

   | 字段 | 说明 |
   | --- | --- |
   | attribute\_name | 属性名称 |
   | value | 属性值 |
   | info | 基本信息 |

   常见的属性及其说明如下表所示：

   | 字段 | 字段 |
   | --- | --- |
   | proxy\_sessid | ODP 的会话 ID 号 |
   | cs\_id | ODP 内部标记每个 Client 的 `id` 号 |
   | cluster | Client Session 所属集群名 |
   | tenant | 租户 |
   | user | 用户 |
   | host\_ip | 用户 IP |
   | host\_port | 用户端口号 |
   | db | 数据库 |
   | total\_trans\_cnt | 传输事务的总数量 |
   | svr\_session\_cnt | 会话总数量 |
   | active | 是否存活 |
   | read\_state | 客户端会话的状态 |
   | tid | 线程 ID |
   | pid | 进程 ID |
   | modified\_time | 历史修改时间 |
   | reported\_time | 历史报告时间 |
   | hot\_sys\_var\_version | 热更新的系统变量版本 |
   | sys\_var\_version | 系统变量版本 |
   | user\_var\_version | 用户变量版本 |
   | last\_insert\_id\_version | 最后插入 ID 版本 |
   | db\_name\_version | 数据库名的版本 |
   | server\_ip | OBServer 节点的 IP 地址 |
   | server\_port | OBServer 节点的端口号 |
   | server\_sessid | OBServer 节点的会话 ID 号 |
   | ss\_id | ODP 标记 Server Session 的 ID 号 |
   | state | 网络连接状态 |
   | transact\_count | 当前 Server Session 执行事务的数量 |
   | server\_trans\_stat | 当前 Server Session 的执行状态，主要用于验证当前 Server Session 的请求执行情况是否准确 |
   | hot\_sys\_var\_version | ODP 保存的常用系统变量的版本 |
   | sys\_var\_version | ODP 保存的系统变量的版本 |
   | user\_var\_version | ODP 保存的用户系统变量的版本 |
   | last\_insert\_id\_version | ODP 保存的 `last_insert_id` 变量的版本 |
   | db\_name\_version | ODP 保存的当前数据库变量的版本 |
   | is\_checksum\_supported | 当前 Server Sesion 是否开启了校验和 |
   | is\_safe\_read\_weak\_supported | 是否支持安全弱读 |
   | is\_checksum\_switch\_supported | 校验和开关是否支持实时开启或关闭 |
   | checksum\_switch | 校验和的开关状态 |
   | enable\_extra\_ok\_packet\_for\_stats | 是否支持额外的返回状态确认的数据包 |