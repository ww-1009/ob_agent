---
title: 终止 Server Session
description: 提供关于终止 Server Session的相关内容，
keywords: 终止 Server Session,OceanBase 数据库,参考指南,数据库代理,逻辑连接,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# 终止 Server Session

本文介绍了如何终止 ODP 上指定 Client Session 以及指定 Client Session 上的 Server Session。

## 操作步骤

`sys` 租户可以通过 `KILL PROXYSESSION` 语句终止指定的 Session。

1. 使用 `root` 用户通过 ODP 连接的方式登录集群的 `sys` 租户。

   连接示例如下：

   ```
   obclient -h10.xx.xx.xx -uroot@sys#obdemo -P2883 -p****** -c -A oceanbase
   ```

   有关更加详细的通过 ODP 连接方式连接数据库的操作指引，请参见 [通过 OBClient 连接 OceanBase 租户（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499954) 和 [通过 OBClient 连接 OceanBase 租户（Oracle 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499914)。
2. 终止指定 Client Session。

   * 终止指定的 Client Session

     ```
     KILL PROXYSESSION {cs_id | connection_id};
     ```

     参数说明：

     + `id` 既可以是 `cs_id`，也可以是 `connection_id`，显示结果相同。

       `cs_id` 为 ODP 内部标记的每个 Client 的 `id` 号，`connection_id` 为整个 OceanBase 数据库标记的每个 Client 的 `id` 号。`connection_id` 通过 `SELECT CONNECTION_ID();` 语句获取。
     + 与 `KILL connection_id` 的作用一致。有关 `KILL` 语句的详细介绍，请参见 [KILL（MySQL 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001503258) 或 [KILL（Oracle 模式）](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504071)。

     示例如下：

     1. 查看 Client Session，获取 `cs_id` 或 `connection_id`。

        执行以下语句获取 `cs_id`。

        ```
        SHOW PROXYSESSION;
        ```

        查询结果如下，返回结果中的 `Id` 即为 `cs_id`。

        ```
        +----------------------+-------+----------+----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        | proxy_sessid         | Id    | Cluster  | Tenant   | User | Host                 | db   | trans_count | svr_session_count | state             | tid   | pid   | using_ssl |
        +----------------------+-------+----------+----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        | 12402504630519660553 | 56932 | test420  | sys      | root | 100.xx.xx.xx:63882   | NULL |           0 |                 1 | MCS_ACTIVE_READER | 76286 | 76286 |         0 |
        +----------------------+-------+----------+----------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        1 row in set
        ```

        或者，执行以下语句获取 `connection_id`。

        ```
        SELECT CONNECTION_ID ();
        ```

        返回如下所示结果。

        ```
        +------------------+
        | CONNECTION_ID () |
        +------------------+
        |       3221562906 |
        +------------------+
        1 row in set
        ```
     2. 终止 `cs_id` 为 `56392` 或 `connection_id` 为 `3221562906` 的 Client Session。

        ```
        KILL PROXYSESSION 56392;
        ```

        或者

        ```
        KILL PROXYSESSION 3221562906;
        ```

        执行成功后，提示如下所示报错信息。

        ```
        ERROR 1317 (70100): Query execution was interrupted
        ```
     3. 查询中断后，查看 Client Session，发现连接已中断。

        ```
        SHOW PROXYSESSION;
        ```

        提示以下信息：

        ```
        ERROR 2013 (HY000): Lost connection to MySQL server during query
        ```
     4. 再次查看 Client Session。

        ```
        SHOW PROXYSESSION;
        ```

        提示以下信息：

        ```
        ERROR 2006 (HY000): OceanBase server has gone away
        No connection. Trying to reconnect...
        Connection id:    57195
        Current database: *** NONE ***

        +----------------------+-------+----------+--------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        | proxy_sessid         | Id    | Cluster  | Tenant | User | Host                 | db   | trans_count | svr_session_count | state             | tid   | pid   | using_ssl |
        +----------------------+-------+----------+--------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        | 12402504630519660555 | 57195 | test420  | sys    | root | 100.xx.xx.xx:24996   | NULL |           0 |                 1 | MCS_ACTIVE_READER | 76286 | 76286 |         0 |
        +----------------------+-------+----------+--------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        1 row in set
        ```

     通过示例可知，通过指定 `cs_id` 或 `connection_id` 来 KILL 当前的 Session 时，命令执行成功后，当前的连接中断。使用 `SHOW PROXYSESSION` 查看时，OBClient 会重新建立 Session 连接，并执行 SQL 显示结果。
   * 终止指定 Client Session 上的 Server Session

     ```
     KILL PROXYSESSION {cs_id | connection_id} ss_id
     ```

     参数说明：

     + `id` 既可以是 `cs_id`，也可以是 `connection_id`，显示结果相同。

       `cs_id` 为 ODP 内部标记的每个 Client 的 `id` 号，`connection_id` 为整个 OceanBase 数据库标记的每个 Client 的 `id` 号。`connection_id` 通过 `SELECT CONNECTION_ID();` 语句获取
     + `ss_id` 表示 ODP 内部标记每个 Server 端会话（ Server Session）的 `id` 号，可以从 `SHOW PROXYSESSION ATTRIBUTE id` 中获取。详细的获取操作请参见 [展示 Session 详细状态](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499999)。

     示例如下：

     1. 查看 Client Session，获取 `cs_id`。

        ```
        SHOW PROXYSESSION;
        ```

        查询结果如下，返回结果中的 `Id` 即为 `cs_id`。

        ```
        +----------------------+-------+----------+--------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        | proxy_sessid         | Id    | Cluster  | Tenant | User | Host                 | db   | trans_count | svr_session_count | state             | tid   | pid   | using_ssl |
        +----------------------+-------+----------+--------+------+----------------------+------+-------------+-------------------+-------------------+-------+-------+-----------+
        | 12402504630519660556 | 64940 | test420  | sys    | root | 100.xx.xx.xx:63882   | NULL |           0 |                 1 | MCS_ACTIVE_READER | 76286 | 76286 |         0 |
        +----------------------+-------+----------+--------+------+----------------------+------+------------- +-------------------+-------------------+-------+-------+-----------+
        1 row in set
        ```
     2. 根据上一步得到的 `cs_id` 获取 `ss_id`。

        ```
        SHOW PROXYSESSION ATTRIBUTE 64940;
        ```

        查询结果如下：

        ```
        +----------------------------------+----------------------+----------------+
        | attribute_name                   | value                | info           |
        +----------------------------------+----------------------+----------------+
        | proxy_sessid                     | -6044239443189891060 | cs common      |
        | cs_id                            | 64940                | cs common      |
        | cluster                          | test3233             | cs common      |
        | tenant                           | sys                  | cs common      |
        | user                             | root                 | cs common      |
        | host_ip                          | 100.xx.xx.xx         | cs common      |
        | host_port                        | 63882                | cs common      |
        | db                               | NULL                 | cs common      |
        | total_trans_cnt                  | 0                    | cs common      |
        | svr_session_cnt                  | 1                    | cs common      |
        | active                           | true                 | cs common      |
        | read_state                       | MCS_ACTIVE_READER    | cs common      |
        | tid                              | 76286                | cs common      |
        | pid                              | 76286                | cs common      |
        | idc_name                         |                      | cs common      |
        | modified_time                    | 0                    | cs stat        |
        | reported_time                    | 0                    | cs stat        |
        | hot_sys_var_version              | 0                    | cs var version |
        | sys_var_version                  | 2                    | cs var version |
        | user_var_version                 | 0                    | cs var version |
        | last_insert_id_version           | 0                    | cs var version |
        | db_name_version                  | 0                    | cs var version |
        | server_ip                        | xx.xx.xx.xx          | last used ss   |
        | server_port                      | 2881                 | last used ss   |
        | server_sessid                    | 3221579563           | last used ss   |
        | ss_id                            | 16                   | last used ss   |
        | state                            | MSS_KA_CLIENT_SLAVE  | last used ss   |
        | transact_count                   | 2                    | last used ss   |
        | server_trans_stat                | 0                    | last used ss   |
        | hot_sys_var_version              | 0                    | last used ss   |
        | sys_var_version                  | 2                    | last used ss   |
        | user_var_version                 | 0                    | last used ss   |
        | last_insert_id_version           | 0                    | last used ss   |
        | db_name_version                  | 0                    | last used ss   |
        | is_checksum_supported            | 1                    | last used ss   |
        | is_safe_read_weak_supported      | 0                    | last used ss   |
        | is_checksum_switch_supported     | 1                    | last used ss   |
        | checksum_switch                  | 1                    | last used ss   |
        | enable_extra_ok_packet_for_stats | 1                    | last used ss   |
        +----------------------------------+----------------------+----------------+
        39 rows in set
        ```
     3. 终止 Client Session 上的 Server Session。

        ```
        KILL PROXYSESSION 64940 16;
        ```