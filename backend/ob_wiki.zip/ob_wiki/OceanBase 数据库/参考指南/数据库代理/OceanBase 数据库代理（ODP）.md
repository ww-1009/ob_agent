---
title: OceanBase 数据库代理（ODP）
description: 提供关于OceanBase 数据库代理（ODP）的相关内容，
keywords: OceanBase 数据库代理（ODP）,OceanBase 数据库,参考指南,数据库代理,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 数据库代理（ODP）

OceanBase 数据库代理 ODP（OceanBase Database Proxy）是 OceanBase 数据库专用的代理服务器，OceanBase 数据库用户的数据会以多副本的形式存放在各个 OBServer 节点上，ODP 接收用户发出的 SQL 请求，并将 SQL 请求转发至最佳目标 OBServer 节点，最后将执行结果返回给用户。

## 特性

作为 OceanBase 数据库的关键组件，ODP 具有以下特性：

* 连接管理

  针对一个客户端的物理连接，ODP 维持自身到后端多个 OBServer 节点的连接，采用基于版本号的增量同步方案维持了每个 OBServer 节点连接的会话状态，保证了客户端高效访问各个 OBServer 节点。
* 最佳路由

  ODP 充分考虑用户请求涉及的副本位置、用户配置的读写分离路由策略、OceanBase 多地部署的最优链路，以及 OceanBase 各机器的状态及负载情况，将用户的请求路由到最佳的 OBServer 节点，最大程度地保证了 OceanBase 整体的高性能运转。
* 高性能转发

  ODP 完整兼容 MySQL 协议，并支持 OceanBase 自研协议，采用多线程异步框架和透明流式转发的设计，保证了数据的高性能转发，同时确保了自身对机器资源的最小消耗。
* 易运维

  ODP 本身无状态，支持无限水平扩展，支持同时访问多个 OceanBase 集群。您可通过丰富的内部命令对 ODP 状态进行实时监控，这使得运维简单便利。
* 高可用

  ODP 高可用分为两部分：一方面保证自身高可用，持续提供代理服务；另一方面 ODP 是 OceanBase 高可用体系的主要组成部分，可以对用户屏蔽宕机、升级等情况，保证 OceanBase 数据库服务的稳定和快速恢复。
* 专有协议

  ODP 与 OBServer 节点默认采用了 OceanBase 专有协议，如增加报文的 CRC 校验保证与 OBServer 节点链路的正确性，增强传输协议以支持 Oracle 兼容性的数据类型和交互模型。