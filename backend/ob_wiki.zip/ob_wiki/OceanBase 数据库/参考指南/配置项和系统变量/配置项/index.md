# 分类索引：配置项

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [参考指南](../../index.md) / [配置项和系统变量](../index.md) / 配置项 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **集群级别配置项** | 涵盖 server_data_copy_out_concurrency、resource_hard_limit、data_copy_concurrency、fast_recovery_concurrency 等 264 项。 | `集群级别配置项` `resource_hard_limit` `data_copy_concurrency` `migrate_concurrency` | [进入目录](./集群级别配置项/index.md) |
| **租户级别配置项** | 涵盖 ha_high_thread_score、ha_mid_thread_score、ha_low_thread_score、log_archive_concurrency 等 117 项。 | `租户级别配置项` `ha_high_thread_score` `ha_mid_thread_score` `ha_low_thread_score` | [进入目录](./租户级别配置项/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [配置项总览.md](./配置项总览.md) | 提供关于配置项总览的相关内容， | 配置项总览,OceanBase 数据库,参考指南,配置项和系统变量,配置项,文档,使用帮助,OceanBase,分布式,数据库 |
