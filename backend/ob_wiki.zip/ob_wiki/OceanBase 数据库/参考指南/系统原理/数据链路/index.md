# 分类索引：数据链路

> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [参考指南](../../index.md) / [系统原理](../index.md) / 数据链路 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **数据库代理** | 涵盖 SQL 路由、代理概述、ODP 配置管理、日志与监控 等 5 项。 | `数据库代理` `SQL 路由` `代理概述` `ODP 配置管理` | [进入目录](./数据库代理/index.md) |
| **数据库驱动** | 先概述 数据库驱动，再分项介绍 OBCI、OceanBase Connector_J、OceanBase Connector_C。 | `数据库驱动` `OBCI` `OceanBase Connector_J` `OceanBase Connector_C` | [进入目录](./数据库驱动/index.md) |
