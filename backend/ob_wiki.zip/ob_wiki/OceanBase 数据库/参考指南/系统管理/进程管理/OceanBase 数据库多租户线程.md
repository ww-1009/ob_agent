---
title: OceanBase 数据库多租户线程
description: 提供关于OceanBase 数据库多租户线程的相关内容，
keywords: OceanBase 数据库多租户线程,OceanBase 数据库,参考指南,系统管理,进程管理,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 数据库多租户线程

本文主要介绍了 OceanBase 数据库多租户线程的实现原理。

OceanBase 数据库是一个支持多租户架构的分布式数据库。当 OBServer 节点在处理来自不同租户的请求时，需要依靠租户独有的线程进行请求处理，最终返回给客户端（例如，OBClient 或者是由应用端通过 ODP 返回的结果）。在这个过程中，OceanBase 数据库的后台系统线程运行着系统任务和多租户共享任务。所有的线程的健康运行为 OBServer 的稳定运行以及可靠高可用的数据服务提供基础支撑。为了便于解释 OceanBase 数据库是如何在多租户线程架构下进行请求处理的，我们对 OBServer 收到的三类基本的租户请求进行了详细地介绍。

## 使用场景

### 场景一

当 OBServer 节点收到客户端对租户 A（租户 ID 为 `1014`）的 SQL 请求，该 SQL 本身是一个 OLTP 型 SQL，只需要由一个租户线程的本地执行就可以完成。请求被执行过程如下：

1. 客户端发起请求 req1 至 OBServer 节点。
2. req1 进入到租户请求队列，在 OBServer 节点中，此类 SQL 请求会进入到租户请求队列的 queue4。
3. 多租户的工作线程会巡检请求队列，当租户 `1014` 的租户线程（ TNT\_1014）发现队列中有需要处理的新线程，将 req1 从队列中取出。
4. TNT\_1014 进行对 req1 的执行。
5. TNT\_1014 将执行的结果和返回值返回客户端。

OceanBase 数据库多租户线程处理本地 OLTP 型 SQL 的过程如下图所示。

![多租户线程_1_SQL请求1](https://help-static-aliyun-doc.aliyuncs.com/assets/img/zh-CN/1120089261/p311713.gif)

### 场景二

当 OBServer 节点收到来自租户 B（租户 ID 为 `1011`）的另一台 OBServer 节点发来的 RPC 请求（例如，分布式的 OLTP 型 SQL请求），该请求需要由该租户线程进行执行。这个 RPC 请求被执行的过程如下：

1. 租户中另一个 OBServer 节点作为 RPC 客户端发起 RPC 请求 req1 至当前的 OBServer 节点。
2. req1 是一个 OLTP 的 SQL请求，req1 请求进入到 OBServer 节点的租户请求队列 queue2。
3. 多租户的工作线程会巡检请求队列，当租户 `1011` 的租户线程（TNT\_1011）发现队列中有需要处理的新请求，将 req1 从队列中取出。
4. TNT\_1011 进行对 req1 的执行。
5. TNT\_1011 将执行的结果和返回值返回给远端的 OBServer 节点。

OceanBase 数据库多租户线程处理分布式 SQL RPC 请求的过程如下图所示。

![多租户线程_2_rpc](https://help-static-aliyun-doc.aliyuncs.com/assets/img/zh-CN/2960089261/p311716.gif)

### 场景三

当 OBServer 节点收到客户端对租户 C（租户 ID 为 `1013`）的 PX SQL 请求，且所有的 SQL 访问都在本地执行。请求被执行的过程如下：

1. 客户端发起请求 req1 至 OBServer 节点。
2. req1 进入到租户请求队列，在 OceanBase 数据库中，普通 SQL 会进入到租户请求队列的 queue4。
3. 多租户的工作线程会巡检请求队列，当租户 `1013` 的租户线程（TNT\_1013）发现队列中有需要处理的新请求，将 req1 从队列中取出。
4. 租户线程会作为 Local Scheduler 驱动 PX 线程执行任务。
5. 执行完后，将 req1 的执行的结果和返回值返回客户端。

OceanBase 数据库多租户线程处理本地 PX SQL 请求的过程如下图所示。

![19](https://help-static-aliyun-doc.aliyuncs.com/assets/img/zh-CN/4864220461/p361284.gif)

## 相关参数

### cpu\_quota\_concurrency

Unit 的参数 `min_cpu` 和系统配置项 `cpu_quota_concurrency` 共同决定单个租户活跃线程数。

单个租户活跃线程数 = `min_cpu` \* `cpu_quota_concurrency`

默认值为 4，取值范围为 [1,20]。该参数动态生效。

在标准生产部署下，建议保持默认值。

### workers\_per\_cpu\_quota

Unit 的参数 `max_cpu` 和系统配置项 `workers_per_cpu_quota` 共同决定单个租户可分配的线程数上限。

单个租户线程数上限 = `max_cpu` \* `workers_per_cpu_quota`

默认值为 10，取值范围为 [2, 20]。该参数动态生效。

在标准生产部署下，建议保持默认值。

## 相关视图

| 视图名或表名 | 描述 |
| --- | --- |
| GV$OB\_TENANT\_RUNTIME\_INFO | OceanBase 数据库多租户线程中队列和线程限额相关的信息。 |