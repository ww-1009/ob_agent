---
title: ORM 规约
description: 提供关于ORM 规约的相关内容，
keywords: ORM 规约,OceanBase 数据库,参考指南,数据库设计规范和约束,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# ORM 规约

ORM 是对象关系映射 (Object Relational Mapping，简称 ORM），是一种程序技术，用于实现面向对象编程语言里不同类型系统的数据之间的转换。从效果上说，它其实是创建了一个可在编程语言里使用的 "虚拟对象数据库"。

* 不用 resultClass 当返回参数，即使所有类属性名与数据库字段一一对应，也需要定义；反过来，每一个表也必然有一个与之对应。

  #### 说明

  配置映射关系，使字段与 DO 类解耦，方便维护。
* sql.xml 配置中参数注意：`#{}` 和 `#param#` 中不要使用 `${}`，此种方式容易出现 SQL 注入。
* iBATIS 自带的 `queryForList(String statementName,int start,int size)` 不推荐使用。

  #### 说明

  该方法的实现方式是在数据库取到 statementName 对应的 SQL 语句的所有记录，再通过 subList 取 start，size 的子集合，线上因为这个原因曾经出现过 OOM。解决该问题的方法，可以在 sqlmap.xml 中引入 `#start#`，`#size#`。示例如下：

  ```
    Map
         
         
          map = newHashMap
          
          
          ();
    map.put("start", start);
    map.put("size", size);
  ```
* 不允许直接拿 HashMap 与 HashTable 作为查询结果集的输出。

  反例：某开发人员为避免写一个 `<resultMap>`，直接使用 HashTable 来接收数据库返回结果，结果出现日常是把 bigint 转成 Long 值，而线上由于数据库版本不一样，解析成 BigInteger，从而导致出现生产问题。
* 更新数据表记录时，必须同时更新记录对应的 gmt\_modified 字段值为当前时间。
* 不写一个大而全的数据更新接口，传入为 POJO 类，不管是不是自己的目标更新字段，都进行 `update table set c1=value1,c2=value2,c3=value3;` 这是不对的。执行 SQL 时，不要更新无改动的字段，一是易出错；二是效率低；三是binlog增加存储。