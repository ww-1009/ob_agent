---
title: OceanBase C 语言调用接口（OBCI）
description: 提供关于OceanBase C 语言调用接口（OBCI）的相关内容，
keywords: OceanBase C 语言调用接口（OBCI）,OceanBase 数据库,参考指南,驱动,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase C 语言调用接口（OBCI）

OBCI（OceanBase Call Interface）是与 Oracle OCI 兼容的 OceanBase C 语言接口调用工具，它提供了与 Oracle OCI 完全兼容的功能特性。

OCI（Oracle Call Interface）是 Oracle 公司开发的一个应用程序开发工具，是一个通过访问 Oracle 数据库的服务器，通过控制各类 SQL 语句的执行，进而创建应用程序的的应用程序接口（API）。它支持 SQL 所有的数据定义、数据操作、查询和事务管理等操作，支持 C 和 C++ 的数据类型、调用、语法和语义。它提供了一组可对 Oracle 数据库进行存取的接口子例程（函数）。 OBCI 是参照 OCI 的接口标准，结合自身的特点，为开发人员提供向 Oracle 兼容功能的一款接口产品。

## 功能特性

OBCI 使您可以使用 C 语言来操作 OceanBase 数据库中的数据。它以动态链接库（OCI 库）的形式提供了标准数据库访问和索引功能，应用程序在运行阶段链接此库就可以使用这些功能。主要功能特性包括：

* OBCI 的 API 接口可用于支持可扩展、多线程的应用。
* 支持 SQL 访问函数。可用于管理数据库访问，处理 SQL 语句，和操作从 OceanBase 数据库服务器检索到的对象。
* 支持数据类型映射和操作函数，可用于操作 OceanBase 数据类型属性。