---
title: OceanBase Connector_C
description: 提供关于OceanBase Connector/C的相关内容，
keywords: OceanBase Connector/C,OceanBase 数据库,参考指南,驱动,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase Connector/C

OceanBase Connector/C 是一个基于 C/C++ 的 OceanBase 客户端开发组件，支持 C API Lib 库。

OceanBase Connector/C 允许 C/C++ 程序以一种较为底层的方式访问 OceanBase 分布式数据库集群，以进行数据库连接、数据访问、错误处理和 Prepared Statement 处理等操作。

OceanBase Connector/C 也称为 `libobclient`，用于应用程序作为独立的服务器进程通过网络连接与数据库服务器 OBServer 节点进行通信。客户端程序在编译时会引用 C API 头文件，同时可以连接到 C API 库文件。

#### 说明

`libobclient` 生成的 `so` 文件为 `libobclnt.so`（对应 MySQL 的 `libmysqlclient.so`），OceanBase 数据库安装后的命令行工具是 OBClient（对应 MySQL 的命令行工具）。