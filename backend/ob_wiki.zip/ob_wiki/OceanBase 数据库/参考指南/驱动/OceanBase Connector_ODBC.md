---
title: OceanBase Connector_ODBC
description: 提供关于OceanBase Connector/ODBC的相关内容，
keywords: OceanBase Connector/ODBC,OceanBase 数据库,参考指南,驱动,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase Connector/ODBC

开放数据库连接（Open Database Connectivity，ODBC）是为解决异构数据库间的数据共享而产生的，现已成为 WOSA（The Windows Open System Architecture），即 Windows 开放系统体系结构的主要部分和基于 Windows 环境的一种数据库访问接口标准。ODBC 为异构数据库访问提供统一接口，允许应用程序以 SQL 为数据存取标准，存取不同 DBMS 管理的数据；使应用程序直接操纵数据库中的数据，免除随数据库的改变而改变。用 ODBC 可以访问各类计算机上的数据库文件，也可以访问例如 Excel 表和 ASCII 数据文件等非数据库对象。

OceanBase Connector/ODBC 基于 MySQL ODBC 驱动进行定制开发，通过该驱动可以使用 OceanBase 数据库提供的新的数据模型（例如 Array 类型）。OceanBase Connector/ODBC 的应用架构如下图所示。

![1](https://obbusiness-private.oss-cn-shanghai.aliyuncs.com/doc/img/observer-enterprise/V4.2.1/700.reference/1300.drivers/odbc-architecture.png)

## Application

Application 使用标准 ODBC API 从 OBServer 节点访问数据。ODBC API 进而与驱动程序管理器通信。Application 只需要知道数据源名称（DSN），而无需了解数据存储在何处、如何存储，系统如何配置就可以访问数据。

在使用 ODBC 时，以下任务对于所有应用程序都是通用的：

* 选择 OBServer 节点并连接。
* 提交 SQL 语句以执行。
* 检索结果（如果有）。
* 处理错误。
* 提交或回滚包含 SQL 语句的事务。
* 断开与 OBServer 节点的连接。

由于大多数数据访问工作都是用 SQL 完成的，所以使用 OceanBase Connector/ODBC 的应用程序的主要任务是提交 SQL 语句并检索这些语句生成的结果。

## Driver Manager

Driver Manager 是一个库，用于管理应用程序和驱动程序之间的通信。它主要执行以下任务：

* 解析连接数据库的数据源名称（DSN），数据库连接信息由 DSN 标识。DSN 是一个配置字符串，它标识给定的数据库驱动程序、数据库、数据库主机以及可选的身份验证信息。任何 ODBC 兼容的应用程序都可以使用预先配置的、相同的 DSN 连接到数据源。
* 加载和卸载用于访问 DSN 中所定义的数据库所需的驱动程序。例如，如果您配置了一个连接到 OceanBase 数据库的 DSN，那么 Driver Manager 将加载 OceanBase Connector/ODBC 驱动程序，以使 ODBC API 能够与 OBServer 节点通信。
* 处理 ODBC 的函数调用或将其传递给驱动程序。

## OceanBase Connector/ODBC

OceanBase Connector/ODBC 驱动程序是一个实现 ODBC API 所支持函数的库。它用于处理 ODBC 函数调用，向 OBServer 节点提交 SQL 请求，并将结果返回给应用程序。还可以根据需要修改应用程序的请求，使请求符合 OceanBase 数据库的语法规范。

## ODBC.INI

ODBC.INI 配置文件存储连接到服务器所需的驱动程序和数据库信息。根据 ODBC.INI 中 DSN 的定义，Driver Manager 可以确定要加载的驱动程序，驱动程序可以读取连接参数。

## OBServer 节点

OBServer 节点存储 OceanBase 数据库的信息。查询操作可以从数据库获取数据，插入和更新操作可以作用于数据库中的数据。