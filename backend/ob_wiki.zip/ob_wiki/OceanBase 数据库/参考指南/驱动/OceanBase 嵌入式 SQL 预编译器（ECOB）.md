---
title: OceanBase 嵌入式 SQL 预编译器（ECOB）
description: 提供关于OceanBase 嵌入式 SQL 预编译器（ECOB）的相关内容，
keywords: OceanBase 嵌入式 SQL 预编译器（ECOB）,OceanBase 数据库,参考指南,驱动,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase 嵌入式 SQL 预编译器（ECOB）

ECOB 是与 Oracle Pro\*C 兼容的 OceanBase 预编译器，提供了与 Proc\*C 兼容的功能特性。

Pro\*C 是 Oracle 数据库生态提供的一种开发应用的工具。当使用 C 语言编写应用程序时，可以在程序源代码中直接嵌入 SQL 语句，这些嵌入式 SQL 语句可以使用宿主 C 程序中的 C 语言变量作为输入输出。然后，Pro\*C 预编译程序 proc 将对源代码进行预处理以进行完整的语法分析，并把嵌入式 SQL 语句和指令转换为对运行时库 sqllib 的函数调用。最后，输出一个 C 语言程序源代码文件。这个文件再通过 C 语言编译器进行编译链接后即可生成可执行程序。所以 OceanBase 数据库为了提供对 Pro\*C 的支持，开发了类似的包含预编译程序 ecob 和运行时库 ecoblib 的预编译器 ECOB。

一个 proc 项目由大量 .pc 源文件组成，并通过 Makefile 等方式构建，为了让您的迁移代价最小化，我们的预编译程序 ecob 还提供了和 proc 程序相同的命令行选项和功能。

## 功能特性

下述为 ECOB 当前版本的主要功能特性：

1. 与 OceanBase Oracle 模式完全兼容的 SQL 语法支持。
2. 支持基本嵌入式 SQL 语句，如：`COMMIT`、`CONNECT`、`DELETE`、`EXECUTE`、`EXECUTE IMMEDIATE`、`INSERT`、`SELECT`、`UPDATE`、`WHENEVER`、`CALL`、`PREPARE` 和 `ROLLBACK` 等语句。
3. 支持游标（Cursor）相关的 `DECLARE`、`OPEN`、`CLOSE` 和 `FETCH`（包括 `NEXT`、`ABSOLUTE`、`WITH HOLD`、`CURRENT OF`）等语句。
4. 支持 ANSI 标准的动态 SQL 所需要的 `DESCRIPTOR` 和与之相关的 `ALLOCATE`、`DEALLOCATE`、`GET`、`SET`、`DESCRIBE` 和 `FETCH` 等语句。
5. 宿主变量无需在 `BEGIN DECLARE SECTION` 和 `END DECLARE SECTION` 内声明即可直接使用。
6. 支持对 C 预处理器宏 #ifdef、#ifndef、#else、#endif 和 #define 的识别和处理。
7. ecoblib 库支持全部上述语句的运行时行为，不仅提供了 proc 程序兼容行为（如 CHAR\_MAP）还支持程序在 Tuxedo 环境下的运行。
8. ecob 程序识别全部 proc 程序选项和兼容语义（如 PARSE=FULL），可无缝替换 proc 程序使用。

## 产品架构

ECOB 由预编译器程序 ecob 和运行时动态链接库 ecoblib（libecob.so）组成。其产品架构如下图所示：

![ECOB 产品架构图](https://help-static-aliyun-doc.aliyuncs.com/assets/img/zh-CN/8238598061/p183960.png)