---
title: OceanBase Connector_J
description: 提供关于OceanBase Connector/J的相关内容，
keywords: OceanBase Connector/J,OceanBase 数据库,参考指南,驱动,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:59.000+00:00
---

# OceanBase Connector/J

Java 数据库连接器（Java Database Connectivity，JDBC）提供了 Java 连接关系数据库的接口，是一种 Java 标准。OceanBase Connector/J 是一种实现 JDBC API 的驱动程序，为基于 Java 开发的应用程序提供与 OceanBase 数据库的连接。

JDBC 标准由 Sun Microsystems 定义，通过标准 `java.sql` 接口实现，支持各个提供程序使用自己的 JDBC 驱动程序来实现和扩展标准。JDBC 是基于 X/Open SQL 的调用级别接口（Call Level Interface，CLI）。

## OceanBase Connector/J 驱动程序

OceanBase Connector/J 驱动程序属于 JDBC Type 4 驱动类型，可以通过本地协议直接与数据库引擎通信。OceanBase 数据库支持 OceanBase Connector/J 驱动，同时完全兼容 MySQL 原生的 JDBC 驱动（MySQL Connector Java）。OceanBase Connector/J 完全兼容 MySQL JDBC 的使用方式，可以自动识别 OceanBase 数据库的运行模式是 MySQL 还是 Oracle，并在协议层同时兼容这两种模式。

OceanBase Connector/J 驱动程序兼容 OB2.0 协议。

#### 注意

OceanBase 数据库会依据 JDBC 驱动连接时的租户名称判断运行模式为 MySQL 或者 Oracle。Oracle 模式的租户只允许使用 Oracle 兼容的 SQL 语法。

除了支持标准的 JDBC 应用程序编程接口（API），OceanBase Connector/J 还兼容 Oracle JDBC 的使用方式，OceanBase 数据库的 Oracle 模式兼容 Oracle 的大部分语法。

## 主要功能

OceanBase Connector/J 主要模块的功能如下：

* DriverManager：加载驱动程序（Driver），并根据调用请求返回相应的数据库连接（Connection）。
* Driver：驱动程序，会被加载到 DriverManager 中，负责处理请求并返回相应的数据库连接（Connection）。
* Connection：数据库连接，负责与数据库进行通讯，提供 SQL 执行以及事务处理的 Connection 环境，创建和执行 Statement。
* Statement：

  + Statement：用以单次执行 SQL 查询和更新。
  + PreparedStatement：用以执行已缓存的 Statement，其执行路径已经预先确定，支持重复执行以提高执行效率。
  + CallableStatement：用以执行数据库中的存储过程。
* SQLException：显示在与数据库创建、关闭连接，或者执行 SQL 语句时发生的错误。