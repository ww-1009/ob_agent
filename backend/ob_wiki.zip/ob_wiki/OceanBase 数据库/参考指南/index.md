# 分类索引：参考指南

> 位置：[ob_wiki](../../index.md) / [OceanBase 数据库](../index.md) / 参考指南 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **SQL 参考** | 下设 PL 参考、SQL 语法，共 2 个子分类。 | `SQL 参考` `PL 参考` `SQL 语法` | [进入目录](./SQL 参考/index.md) |
| **错误码** | 下设 错误码（MySQL 模式）、错误码（Oracle 模式），共 2 个子分类。 | `错误码` `错误码（MySQL 模式）` `错误码（Oracle 模式）` | [进入目录](./错误码/index.md) |
| **配置项和系统变量** | 下设 配置项、系统变量，共 2 个子分类。 | `配置项和系统变量` `配置项` `系统变量` | [进入目录](./配置项和系统变量/index.md) |
| **平台产品** | 涵盖 OceanBase 迁移服务（OMS）、OceanBase 开发者中心（ODC）、OceanBase 云平台（OCP）、OceanBase 管理者工具（OAT） 等 5 项。 | `平台产品` `OceanBase 迁移服务（OMS）` `OceanBase 开发者中心（ODC）` `OceanBase 云平台（OCP）` | [进入目录](./平台产品/index.md) |
| **驱动** | 涵盖 OceanBase Connector_ODBC、OceanBase C 语言调用接口（OBCI）、OceanBase Connector_J、OceanBase 嵌入式 SQL 预编译器（ECOB） 等 5 项。 | `驱动` `OceanBase Connector_J` `OceanBase Connector_C` | [进入目录](./驱动/index.md) |
| **数据库代理** | 下设 OBProxy、路由管理、逻辑连接，共 3 个子分类。 | `数据库代理` `OBProxy` `路由管理` `逻辑连接` | [进入目录](./数据库代理/index.md) |
| **数据库对象管理** | 下设 MySQL 模式、Oracle 模式，共 2 个子分类。 | `数据库对象管理` `MySQL 模式` `Oracle 模式` | [进入目录](./数据库对象管理/index.md) |
| **数据库设计规范和约束** | 下设 对象结构设计规范、对象命名规范，共 2 个子分类。 | `数据库设计规范和约束` `对象结构设计规范` `对象命名规范` | [进入目录](./数据库设计规范和约束/index.md) |
| **系统管理** | 下设 磁盘管理、存储管理、进程管理、内存管理，共 4 个子分类。 | `系统管理` `磁盘管理` `存储管理` `进程管理` | [进入目录](./系统管理/index.md) |
| **系统视图** | 下设 MySQL 租户系统视图、Oracle 租户系统视图、sys 租户系统视图，共 3 个子分类。 | `系统视图` `MySQL 租户系统视图` `Oracle 租户系统视图` `sys 租户系统视图` | [进入目录](./系统视图/index.md) |
| **系统原理** | 下设 OBServer 节点架构、存储架构、多租户架构、分布式数据库对象、事务管理 等 10 个子分类。 | `系统原理` `OBServer 节点架构` `存储架构` `多租户架构` | [进入目录](./系统原理/index.md) |
| **性能测试** | 涵盖 OceanBase Sysbench 高性能部署和问题分析、OceanBase 数据库 TPC-H 测试、OceanBase TPC-C 性能测试报告、OceanBase 数据库 TPC-C 测试 等 7 项。 | `性能测试` `OceanBase 数据库 TPC-H 测试` `OceanBase TPC-C 性能测试报告` `OceanBase 数据库 TPC-C 测试` | [进入目录](./性能测试/index.md) |
| **性能调优** | 下设 SQL 调优指南、系统调优、性能相关工具、性能诊断、业务模型调优 等 5 个子分类。 | `性能调优` `SQL 调优指南` `系统调优` `性能相关工具` | [进入目录](./性能调优/index.md) |
| **组件 & 工具** | 下设 监控诊断、数据集成、运维管理，共 3 个子分类。 | `组件 & 工具` `监控诊断` `数据集成` `运维管理` | [进入目录](./组件 & 工具/index.md) |
