---
title: 使用 DBLink 查询
description: 提供关于使用 DBLink 查询的相关内容，
keywords: 使用 DBLink 查询,OceanBase 数据库,应用开发,基于 MySQL 模式进行应用开发,数据读取,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 使用 DBLink 查询

OceanBase 数据库的 DBLink 功能实现了跨数据源访问的能力，您可以在本地数据库上访问远端数据库。DBLink 创建成功后，可以通过 DBLink 访问远端数据库的对象，对象包括表和视图等。

## 使用限制

* 当前 OceanBase 数据库 MySQL 模式 DBLink 读功能仅支持不同 MySQL 模式租户之间读取数据。
* MySQL 模式下，支持通过 DBLink 访问的数据类型如下：

  + 数值类型：`TINYINT`、`SMALLINT`、`MEDIUMINT`、`INT`、`BIGINT`、`FLOAT`、`DOUBLE`、`DECIMAL`。
  + 时间类型：`DATE`、`TIME`、`YEAR`、`DATETIME`、`TIMESTAMP`。
  + 字符类型：`CHAR`、`VARCHAR`、`TINYBLOB`、`TINYTEXT`、`BLOB`、`TEXT`、`MEDIUMBLOB`、`LONGBLOB`、`LONGTEXT`。
  + 其他类型：`ENUM`、`SET`。

    #### 注意

    受限于 OBClient，当前通过 DBLlink 读取表数据时，会将远端表中 `ENUM` 和 `SET` 类型的列当作 `VARCHAR` 类型列处理。

  有关各数据类型的详细介绍及说明，请参见 [数据类型概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504228)。

## 前提条件

已创建 DBLink。有关创建 DBLink 的详细信息，请参见 [创建 DBLink](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501880)。

## 查询远端数据库表的数据

SQL 语句如下：

```
SELECT select_expr_list FROM table_name@dblink_name WHERE where_conditions;
```

参数说明：

* `select_expr_list`：指定待查询的表达式或列名，不同的列之间用英文逗号（,）隔开，星号（\*）表示所有列。
* `table_name@dblink_name`：指定待查询的远端数据库中的表，多个数据库之间用英文逗号（,）隔开。默认访问创建 DBLink 时所指定的数据库中的表，如果需要访问其他数据库中的表，可以在 SQL 语句中指定，格式为 `database_name.table_name@dblink_name`。
* `where_conditions`：指定筛选条件，查询结果中仅包含满足条件的数据，为可选项。

## 示例

使用 DBLink 的步骤如下：

1. 使用下面 SQL 语句，创建一个连接到远端 OceanBase 数据库 MySQL 模式的 DBLink，DBLink 名称为 `my_link`，远端租户为 `mysql001`，默认访问数据库为 `test`。

   ```
   CREATE DATABASE LINK my_link CONNECT TO root@mysql001 DATABASE test IDENTIFIED BY '******' HOST '10.10.10.1:2881';
   ```
2. 使用下面 SQL 语句，通过 **步骤 1** 创建的 DBLink 查询远端数据库中的数据。

   * 通过 `my_link` 查询远端数据库中 `test` 库下表 `test_tbl1` 的数据。

     ```
     SELECT * FROM test_tbl1@my_link WHERE id = 1;
     ```

     返回结果如下：

     ```
     +------+------+
     | id   | name |
     +------+------+
     |    1 | A1   |
     +------+------+
     1 row in set
     ```
   * 通过 `my_link` 读取远端数据库中 `test` 库下表 `test_tbl1` 表，并与本地数据库的表 `tbl1` 做 Join 操作。

     ```
     SELECT a.id, b.name FROM tbl1 a, test_tbl1@my_link b WHERE a.id = b.id;
     ```

     返回结果如下：

     ```
     +------+------+
     | id   | name |
     +------+------+
     |    1 | A1   |
     |    2 | A2   |
     +------+------+
     2 rows in set
     ```
   * 通过 `my_link` 读取远端数据库中 `student_db` 库（创建 DBLink 时指定的数据库为 `test`）下表 `student` 的数据。

     ```
     SELECT * FROM student_db.student@my_link LIMIT 3;
     ```

     返回结果如下：

     ```
     +------+---------+--------+------+-------+-----------------+
     | id   | name    | gender | age  | score | enrollment_date |
     +------+---------+--------+------+-------+-----------------+
     |    1 | Emma    |      0 |   20 |    85 | 2021-09-01      |
     |    2 | William |      1 |   21 |  90.5 | 2021-09-02      |
     |    3 | Olivia  |      0 |   19 |  95.5 | 2021-09-03      |
     +------+---------+--------+------+-------+-----------------+
     3 rows in set
     ```

## 相关文档

* 更多数据类型的介绍信息，请参见 [数据类型概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504228)。
* 更多创建 DBLink 的信息，请参见 [创建 DBLink](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501880)。
* 更多使用 DBLink 的信息，请参见 [通过 DBLink 访问远端数据库中的数据](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501879)。
* 更多使用 `SELECT` 的信息，请参见 [SELECT 语句](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504234)。