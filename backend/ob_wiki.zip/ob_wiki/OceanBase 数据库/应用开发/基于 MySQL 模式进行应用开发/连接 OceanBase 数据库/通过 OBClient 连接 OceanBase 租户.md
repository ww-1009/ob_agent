---
title: 通过 OBClient 连接 OceanBase 租户
description: 提供关于通过 OBClient 连接 OceanBase 租户的相关内容，
keywords: 通过 OBClient 连接 OceanBase 租户,OceanBase 数据库,应用开发,基于 MySQL 模式进行应用开发,连接 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 通过 OBClient 连接 OceanBase 租户

本文主要介绍通过 OBClient 连接 OceanBase 数据库 MySQL 租户的前提条件、连接操作和示例。

## 前提条件

* 请确认已下载并安装了 OBClient 应用。如果未下载 OBClient 应用，您可以访问 [软件中心](https://open.oceanbase.com/softwareCenter/community) 下载对应版本的 OBClient。
* 连接租户前，请确认当前客户端在租户白名单中，租户白名单的查询及设置具体操作请参见 [查看和设置租户白名单](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499847)。

## 连接操作

### 通过 ODP 连接的方式

使用 OBClient 客户端命令通过 OceanBase 数据库代理（OceanBase Database Proxy，ODP）连接 OceanBase 数据库的格式如下：

```
obclient -h$host -P$port -u$user_name -p****** [-c] [-A] [$database_name]
```

#### 说明

支持 OceanBase 数据库到 ODP 的压缩功能，OceanBase 数据库要求 V4.2.1 BP3 或者 4.2.2 BP1 及以上版本，ODP 要求 V4.2.3 及以上版本。具体信息请参考以下文档：

* 有关控制 ODP 和 OceanBase 数据库之间是否开启 OceanBase 2.0 协议进行传输的详细信息，请参见 [enable\_ob\_protocol\_v2](https://www.oceanbase.com/docs/common-odp-doc-cn-1000000000517753)。
* 有关控制是否开启压缩协议的详细信息，请参见 [enable\_compression\_protocol](https://www.oceanbase.com/docs/common-odp-doc-cn-1000000000517630)。
* 有关控制压缩协议和 OceanBase 2.0 协议的压缩级别的详细信息，请参见 [compression\_algorithm](https://www.oceanbase.com/docs/common-odp-doc-cn-1000000000517613)。

**参数说明：**

* `-h`：指定 OceanBase 数据库的连接 IP。`$host` 应该被实际的 IP 替换，使用 ODP 连接的方式应是一个 ODP 地址。
* `-P`：指定 OceanBase 数据库连接端口。`$port` 应该被实际的端口替换，使用 ODP 连接的方式默认是 2883，在部署 ODP 时可自定义。
* `-u`：指定 OceanBase 数据库的连接账户。`$user_name` 格式有：`用户名@租户名#集群名`、`集群名:租户名:用户名`、`集群名-租户名-用户名` 或者 `集群名.租户名.用户名`。MySQL 模式租户的管理员用户名默认是 `root`。

  #### 说明

  + 当使用 ODP 连接 OceanBase 集群时，可以通过以下方式获取集群名：  
    先通过直连的方式连接 OceanBase 数据库；然后使用 `SHOW PARAMETERS LIKE 'cluster';` 命令来获取集群的名称，该命令会返回结果中 `VALUE` 的值对应 OceanBase 集群的名称。
  + 如果 ODP 代理多个集群，连接时必须指定集群名；如果 ODP 只代理一个集群，连接时则不需指定集群名。
* `-p`: 指定连接 OceanBase 数据库的密码。`******` 应该被实际的密码字符串替换。

  #### 说明

  出于安全考虑，建议不在命令行直接输入密码，尤其是在脚本或历史记录可见的环境下，可以省略此选项并在提示时输入密码。
* `-c`：可选项，表示在 OBClient 运行环境中不要忽略注释。

  #### 说明

  Hint 是特殊的注释，不受 `-c` 影响。
* `-A`: 可选项，表示在 OBClient 连接数据库时不自动获取统计信息。
* `$database_name`：可选项，指定连接 OceanBase 数据库后要使用的默认数据库。如果不提供，默认不会直接进入任何数据库，需要在连接后手动选择。

**示例如下：**

```
obclient -h10.10.10.1 -P2883 -uuser001@obtenant#obdemo -p****** -c -A oceanbase
```

#### 使用 ODP 通过 SERVICE\_NAME 连接的方式

OceanBase 数据库支持通过指定 ODP 的 `IP:PORT` 以及 `SERVICE_NAME` 进行登陆。根据指定的 `SERVICE_NAME`，ODP 将连接串转换为 `-uuser_name@主租户名#主租户所在集群`，用户不需要主备切换后手动改变连接串。有关创建 `SERVICE_NAME` 的信息，参见 [创建服务](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500297)。

#### 注意

该功能依赖于 OceanBase 云平台（OceanBase Cloud Platform, OCP）。要求 OCP 为 V4.3.1 及之后版本，并且需要 OCP 接管了 OceanBase 集群才能正常使用。

使用 ODP 通过 `SERVICE_NAME` 连接 OceanBase 数据库的格式如下：

```
obclient -h$host -P$port -u$user_name@SERVICE:$service_name -p******
```

**参数说明：**

* `$host`：ODP 的 IP 地址。
* `$port`：ODP 的端口号。
* `$user_name`：用户名。
* `$service_name`: 服务名。
* `-p`: 指定连接 OceanBase 数据库的密码。`******` 应该被实际的密码字符串替换。

**示例如下：**

```
obclient -h10.10.10.1 -P2883 -uuser001@SERVICE:service_mysql001 -p******
```

### 通过直连方式

使用 OBClient 客户端命令通过直连方式连接 OceanBase 数据库的格式如下：

```
obclient -h$host -P$port -u$user_name -p****** [-c] [-A] [$database_name]
```

**参数说明：**

* `-h`：指定 OceanBase 数据库的连接 IP。`$host` 应该被实际的 IP 替换，使用直连方式通常是一个 OBServer 节点的 IP 地址。

  #### 注意

  普通租户通过直连方式连接时，需要确保该租户的资源分布在该 OBServer 节点上，如果该租户的资源未分布在该 OBServer 节点上，则无法通过直连该 OBServer 节点连接到该租户。
* `-P`：指定 OceanBase 数据库连接端口。`$port` 应该被实际的端口替换，使用直连方式默认是 2881，在部署 OceanBase 数据库时可自定义。
* `-u`：指定 OceanBase 数据库的连接账户。`$user_name` 格式为：`用户名@租户名`。MySQL 租户的管理员用户名默认是 `root`。

  #### 注意

  在使用直连方式连接 OceanBase 数据库时，连接参数 `-u` 后应填写正确的 `用户名@租户名`，不要指定集群名。如果在 `-u` 中包含了集群名，会导致连接报错。
* `-p`: 指定连接 OceanBase 数据库的密码。`******` 应该被实际的密码字符串替换。

  #### 说明

  出于安全考虑，建议不在命令行直接输入密码，尤其是在脚本或历史记录可见的环境下，可以省略此选项并在提示时输入密码。
* `-c`：可选项，表示在 OBClient 运行环境中不要忽略注释。

  #### 说明

  Hint 是特殊的注释，不受 `-c` 影响。
* `-A`: 可选项，表示在 OBClient 连接数据库时不自动获取统计信息。
* `$database_name`：可选项，指定连接 OceanBase 数据库后要使用的默认数据库。如果不提供，默认不会直接进入任何数据库，需要在连接后手动选择。

**示例如下：**

```
obclient -h10.10.10.1 -P2881 -uuser001@obtenant -p****** -c -A oceanbase
```

## 连接示例

1. 打开一个命令行终端。
2. 使用 OBClient 客户端通过 ODP 连接 OceanBase 数据库的 MySQL 模式租户。

   ```
   obclient -hxxx.xx.xxx.xxx -P2883 -uroot@mysql001#test424 -p****** -A oceanbase
   ```

   返回结果如下：

   ```
   Welcome to the OceanBase.  Commands end with ; or \g.
   Your OceanBase connection id is 16
   Server version: OceanBase 4.2.4.0 (r200000342024061210-c4c0c18741e45a1d40889b6147c3132574d6e7ea) (Built Jun 12 2024 10:58:58)

   Copyright (c) 2000, 2018, OceanBase and/or its affiliates. All rights reserved.

   Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

   obclient [oceanbase]>
   ```
3. 如果需要退出 OBClient 命令行，输入 `exit` 后回车，或者按快捷键 **Ctrl** + **D**。

## 相关文档

通过 OBClient 连接 OceanBase 数据库 Oracle 租户的操作示例请参见 [通过 OBClient 连接 OceanBase 租户](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499914)。