---
title: 通过 MySQL 客户端连接 OceanBase 租户
description: 提供关于通过 MySQL 客户端连接 OceanBase 租户的相关内容，
keywords: 通过 MySQL 客户端连接 OceanBase 租户,OceanBase 数据库,应用开发,基于 MySQL 模式进行应用开发,连接 OceanBase 数据库,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:42:47.000+00:00
---

# 通过 MySQL 客户端连接 OceanBase 租户

需要使用 OceanBase 数据库的 MySQL 租户时，可以使用 MySQL 客户端连接该租户。本节主要介绍该连接方式的前提条件、连接操作和示例。

## 前提条件

通过 MySQL 客户端连接数据库前，需要确认以下信息：

* 确保本地已正确安装 MySQL 客户端。OceanBase 数据库当前版本支持的 MySQL 客户端版本包括 V5.5、V5.6、V5.7 和 V8.0.2。

  #### 注意

  使用 ODP 连接至 OceanBase 数据库的场景中，当前不兼容 MySQL 客户端 V8.0.2 版本。
* 确保环境变量 `PATH` 中包含了 MySQL 客户端命令所在目录。
* 连接租户前，请确认当前客户端在租户白名单中，租户白名单的查询及设置具体操作请参见 [查看和设置租户白名单](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499847)。

## 连接操作

### 通过 ODP 连接的方式

使用 MySQL 客户端命令通过 OceanBase 数据库代理（OceanBase Database Proxy，ODP）连接 OceanBase 数据库的格式如下：

```
mysql -h$host -P$port -u$user_name -p****** [-c] [-A] [$database_name]
```

#### 说明

支持 OceanBase 数据库到 ODP 的压缩功能，OceanBase 数据库要求 V4.2.1 BP3 或者 4.2.2 BP1 及以上版本，ODP 要求 V4.2.3 及以上版本。具体信息请参考以下文档：

* 有关控制 ODP 和 OceanBase 数据库之间是否开启 OceanBase 2.0 协议进行传输的详细信息，请参见 [enable\_ob\_protocol\_v2](https://www.oceanbase.com/docs/common-odp-doc-cn-1000000000517753)。
* 有关控制是否开启压缩协议的详细信息，请参见 [enable\_compression\_protocol](https://www.oceanbase.com/docs/common-odp-doc-cn-1000000000517630)。
* 有关控制压缩协议和 OceanBase 2.0 协议的压缩级别的详细信息，请参见 [compression\_algorithm](https://www.oceanbase.com/docs/common-odp-doc-cn-1000000000517613)。

**参数说明：**

* `-h`：指定 OceanBase 数据库的连接 IP。`$host` 应该被实际的 IP 替换，使用 ODP 连接的方式应是一个 ODP 地址。
* `-P`：指定 OceanBase 数据库连接端口。`$port` 应该被实际的端口替换，使用 ODP 连接的方式默认是 2883，在部署 ODP 时可自定义。
* `-u`：指定 OceanBase 数据库的连接账户。`$user_name` 格式有：`用户名@租户名#集群名`、`集群名:租户名:用户名`、`集群名-租户名-用户名` 或者 `集群名.租户名.用户名`。使用 MySQL 客户端仅支持连接 MySQL 模式租户，MySQL 模式租户的管理员用户名默认是 `root`。

  #### 说明

  + 当使用 ODP 连接 OceanBase 集群时，可以通过以下方式获取集群名：  
    先通过直连的方式连接 OceanBase 数据库；然后使用 `SHOW PARAMETERS LIKE 'cluster';` 命令来获取集群的名称，该命令会返回结果中 `VALUE` 的值对应 OceanBase 集群的名称。
  + 如果 ODP 代理多个集群，连接时必须指定集群名；如果 ODP 只代理一个集群，连接时则不需指定集群名。
* `-p`: 指定连接 OceanBase 数据库的密码。`******` 应该被实际的密码字符串替换。

  #### 说明

  出于安全考虑，建议不在命令行直接输入密码，尤其是在脚本或历史记录可见的环境下，可以省略此选项并在提示时输入密码。
* `-c`：可选项，表示在 MySQL 运行环境中不要忽略注释。

  #### 说明

  Hint 是特殊的注释，不受 `-c` 影响。
* `-A`: 可选项，表示在 MySQL 连接数据库时不自动获取统计信息。
* `$database_name`：可选项，指定连接 OceanBase 数据库后要使用的默认数据库。如果不提供，默认不会直接进入任何数据库，需要在连接后手动选择。

**示例如下：**

```
mysql -h10.10.10.1 -uuser001@obmysql#obdemo -P2883 -p****** -c -A oceanbase
```

### 通过直连方式

使用 MySQL 客户端命令通过直连方式连接 OceanBase 数据库的格式如下：

```
mysql -h$host -P$port -u$user_name -p****** [-c] [-A] [$database_name]
```

**参数说明：**

* `-h`：指定 OceanBase 数据库的连接 IP。`$host` 应该被实际的 IP 替换，使用直连方式通常是一个 OBServer 节点的 IP 地址。

  #### 注意

  普通租户通过直连方式连接时，需要确保该租户的资源分布在该 OBServer 节点上，如果该租户的资源未分布在该 OBServer 节点上，则无法通过直连该 OBServer 节点连接到该租户。
* `-P`：指定 OceanBase 数据库连接端口。`$port` 应该被实际的端口替换，使用直连方式默认是 2881，在部署 OceanBase 数据库时可自定义。
* `-u`：指定 OceanBase 数据库的连接账户。`$user_name` 格式为：`用户名@租户名`。MySQL 租户的管理员用户名默认是 `root`。

  #### 注意

  在使用直连方式连接 OceanBase 数据库时，连接参数 `-u` 后应填写正确的 `用户名@租户名`，不要指定集群名。如果在 `-u` 中包含了集群名，会导致连接报错。
* `-p`: 指定连接 OceanBase 数据库的密码。`******` 应该被实际的密码字符串替换。

  #### 说明

  出于安全考虑，建议不在命令行直接输入密码，尤其是在脚本或历史记录可见的环境下，可以省略此选项并在提示时输入密码。
* `-c`：可选项，表示在 MySQL 运行环境中不要忽略注释。

  #### 说明

  Hint 是特殊的注释，不受 `-c` 影响。
* `-A`: 可选项，表示在 MySQL 连接数据库时不自动获取统计信息。
* `$database_name`：可选项，指定连接 OceanBase 数据库后要使用的默认数据库。如果不提供，默认不会直接进入任何数据库，需要在连接后手动选择。

**示例如下：**

```
mysql -h10.10.10.1 -uuser001@obmysql -P2881 -p****** -c -A oceanbase
```

## 连接示例

1. 打开一个命令行终端。
2. 使用 MySQL 客户端通过 ODP 连接 OceanBase 数据库的 MySQL 模式租户。

   ```
   mysql -hxxx.xx.xxx.xxx -P2883 -uroot@mysql001#test424 -p****** -A oceanbase
   ```

   返回结果如下：

   ```
   Welcome to the MariaDB monitor.  Commands end with ; or \g.
   Your MySQL connection id is 15
   Server version: 5.6.25 OceanBase 4.2.4.0 (r200000342024061210-c4c0c18741e45a1d40889b6147c3132574d6e7ea) (Built Jun 12 2024 10:58:58)

   <...>

   Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

   MySQL [oceanbase]>
   ```
3. 如果需要退出 MySQL 命令行，输入 `exit` 后回车，或者按快捷键 **Ctrl** + **D**。

## 更多信息

如果在通过 MySQL 客户端连接 OceanBase 数据库的过程中遇到问题，建议您查阅 MySQL 客户端官方的使用文档。