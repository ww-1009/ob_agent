---
title: 使用 DBLink 查询
description: 提供关于使用 DBLink 查询的相关内容，
keywords: 使用 DBLink 查询,OceanBase 数据库,应用开发,基于 Oracle 模式进行应用开发,数据读取,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-07-15T12:56:58.000+00:00
---

# 使用 DBLink 查询

OceanBase 数据库的 DBLink 功能实现了跨数据源访问的能力，您可以在本地数据库上访问远端数据库。DBLink 创建成功后，可以通过 DBLink 访问远端数据库的对象，对象包括表、视图和同义词等。

## 前提条件

已创建 DBLink。有关创建 DBLink 的详细信息，请参见 [创建 DBLink](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501864)。

## 查询远端数据库中表的数据

SQL 语句如下：

```
SELECT select_expr_list FROM table_name@dblink_name WHERE where_conditions;
```

参数说明：

* `select_expr_list`：指定待查询的表达式或列名，不同的列之间用英文逗号（,）隔开，星号（\*）表示所有列。
* `table_name@dblink_name`：指定待查询的远端数据库的表，多个数据库之间用英文逗号（,）隔开。
* `where_conditions`：指定筛选条件，查询结果中仅包含满足条件的数据，为可选项。

## 示例

使用 DBLink 的步骤如下：

1. 使用下面 SQL 语句，创建一个连接到远端 OceanBase 数据库 Oracle 模式的 DBLink，DBLink 名称为 `my_link`，远端租户为 `oracle001`。

   ```
   CREATE DATABASE LINK my_link CONNECT TO sys@oracle001 IDENTIFIED BY "******" OB HOST 'xxx.xxx.xxx.xxx:2881';
   ```
2. 使用下面 SQL 语句，通过名为 `my_link` 的 DBLink 查询远端数据库中表 `test_tbl1` 的数据。

   ```
   SELECT * FROM test_tbl1@my_link;
   ```

   返回结果如下：

   ```
   +------+------+
   | COL1 | COL2 |
   +------+------+
   |    1 | a1   |
   |    2 | b2   |
   +------+------+
   2 rows in set
   ```

## 相关文档

* 更多创建 DBLink 的信息，请参见 [创建 DBLink](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501864)。
* 更多使用 DBLink 的信息，请参见 [通过 DBLink 访问远端数据库中的数据](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501860)。
* 更多使用 `SELECT` 的信息，请参见 [SIMPLE SELECT](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504437)