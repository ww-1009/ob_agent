---
title: 与 Oracle 兼容性概述
description: 提供关于与 Oracle 兼容性概述的相关内容，
keywords: 与 Oracle 兼容性概述,OceanBase 数据库,OceanBase 简介,与 Oracle 兼容性对比,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 与 Oracle 兼容性概述

本节主要介绍 OceanBase 数据库的 Oracle 模式与原生 Oracle 数据库的兼容性对比信息。

OceanBase 数据库在数据类型、SQL 功能和数据库对象等基本功能上与 Oracle 数据库兼容。在过程化程序语言（Procedural Language，PL）方面，已经基本能够兼容全部的研发功能。在数据库安全、备份恢复、高可用和优化器等高级特性上 OceanBase 数据库的兼容性也非常好，而且有些特性还要优于 Oracle 数据库。这意味着在从 Oracle 数据库迁移到 OceanBase 数据库的过程中，用户不需要消耗大量的时间去学习新知识，即可流畅地实现从 Oracle 数据库到 OceanBase 数据库的迁移。

此外，由于 OceanBase 数据库与 Oracle 数据库在底层架构、产品形态等方面的不同，有一部分功能 OceanBase 数据库暂时不会进行兼容或者会与 Oracle 数据库的表现有所差异。本节主要从以下几个方面介绍 OceanBase 数据库与 Oracle 数据库的兼容性对比信息：

* SQL 数据类型
* 内建函数
* SQL 语法
* 过程性语言
* 系统视图
* 字符集
* 字符序
* 数据库对象管理
* 安全特性
* 备份恢复
* SQL 引擎

## SQL 数据类型

OceanBase 数据库兼容大部分 Oracle 数据库中支持的数据类型，详细支持信息请参见 [SQL 数据类型](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499484)。

基于优化考虑，`LONG` 和 `LONG RAW` 数据类型过于老旧，OceanBase 数据库暂不计划支持这两种数据类型。

## 内建函数

OceanBase 数据库兼容大部分 Oracle 数据库中支持的内建函数，详细支持信息请参见 [内建函数](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499483)。

## SQL 语法

OceanBase 数据库支持 Oracle 数据库中绝大部分的 SQL 语法，少数功能性缺失会报语法不支持的错误。

支持

**SELECT**

* 支持大部分查询功能，包括支持单、多表查询；支持子查询、横向派生表（Lateral Derived Table）；支持内连接、半连接、外连接；支持分组、聚合；支持层次查询；支持常见的概率、线性回归等数据挖掘函数等。
* 支持如下集合操作：`UNION`、`UNION ALL`、`INTERSECT`、`MINUS`。
* 支持使用 `EXPLAIN` 语法查看执行计划。

**INSERT**

* 支持单行、多行插入数据，同时支持指定分区插入数据。
* 支持 `INSERT INTO ... SELECT ...` 语句。
* 支持单表和多表插入数据。

**UPDATE**

* 支持单列和多列的数据更新。
* 支持使用子查询更新数据。
* 支持集合更新数据。

**DELETE**

* 支持单表和多表的数据删除。

**TRUNCATE**

* 支持完全清空指定表的数据。

**并行查询**

* 支持类 Oracle 数据库的并行查询。

  OceanBase 数据库支持 Auto DOP 功能，也可以手动通过 `Hint/Session` 变量指定 DOP。
* 支持并行数据操作语言（DML）。

**Hint**

OceanBase 数据库支持使用 Hint 语法，有关 Hint 的详细说明，请参见 [Hint](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504397)。

## 过程性语言

OceanBase 数据库兼容了大部分 Oracle 数据库的 PL 功能。有关 PL 功能的详细信息，请参见 [PL 参考](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501937)。

支持

OceanBase 数据库主要支持的 PL 功能如下：

* 数据类型
* 流程控制
* 集合与记录
* 静态 SQL
* 动态 SQL
* 子过程
* 触发器
* 异常处理
* 程序包
* 性能优化
* 自定义数据类型
* PL 系统包，包括 DBMS\_CRYPTO、DBMS\_DEBUG、DBMS\_LOB、DBMS\_LOCK、DBMS\_METADATA、DBMS\_OUTPUT、DBMS\_RANDOM、DBMS\_SQL、DBMS\_XA、UTL\_I18N、UTL\_RAW 等。
* PL 标签安全包，包括 SA\_SYSDBA、SA\_COMPONENTS、SA\_LABEL\_ADMIN、SA\_POLICY\_ADMIN、SA\_USER\_ADMIN、SA\_SESSION 等。

## 系统视图

OceanBase 数据库兼容了部分 Oracle 数据库的系统视图，其中：

* 兼容字典视图 195 个。
* 兼容性能视图（以 v$ 开头）20 个。

关于兼容的详细视图列表，请参见 [系统视图](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499485)。

更多系统视图的字段说明信息，请参见 [系统视图](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499700)。

## 字符集

OceanBase 数据库支持的字符集如下：

* binary
* utf8mb4
* gbk
* utf16
* gb18030
* latin1
* gb18030\_2022
* ascii
* tis620
* utf16le
* sjis
* hkscs
* hkscs31
* dec8

## 字符序

OceanBase 数据库支持的排序方式如下表所示。

| 字符序 | 所属字符集 | 说明 |
| --- | --- | --- |
| utf8mb4\_general\_ci | utf8mb4 | 使用通用排序规则。 |
| utf8mb4\_bin | utf8mb4 | 使用二进制排序规则。 |
| utf8mb4\_unicode\_ci | utf8mb4 | 使用基于 Unicode Collation Algorithm (UCA) 的排序规则。 |
| binary | binary | 使用二进制排序规则。 |
| gbk\_chinese\_ci | gbk | 使用中文语言排序规则。 |
| gbk\_bin | gbk | 使用二进制排序规则。 |
| utf16\_general\_ci | utf16 | 使用通用排序规则。 |
| utf16\_bin | utf16 | 使用二进制排序规则。 |
| utf16\_unicode\_ci | utf16 | 使用基于 Unicode Collation Algorithm (UCA) 的排序规则。 |
| gb18030\_chinese\_ci | gb18030 | 使用中文语言排序规则。 |
| gb18030\_bin | gb18030 | 使用二进制排序规则。 |
| latin1\_swedish\_ci | latin1 | 使用瑞典语/芬兰语排序规则。 |
| latin1\_german1\_ci | latin1 | 用于德国（German）语言环境下的 latin1 字符集的排序规则。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_danish\_ci | latin1 | 用于丹麦（Danish）语言环境下的 latin1 字符集的排序规则。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_german2\_ci | latin1 | 用于德语环境，适用于需要按照字典顺序进行字符比较的应用场景。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_general\_ci | latin1 | 用于需要不区分大小写且支持重音符号的场景，如某些欧洲语言的数据库设计。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_general\_cs | latin1 | 用于区分大小写的通用排序规则，支持多种语言（如西欧语言）。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_spanish\_ci | latin1 | 用于西班牙（Spanish）语言环境的排序规则。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_bin | latin1 | latin1 使用二进制排序规则。 |
| gb18030\_2022\_bin | gb18030\_2022 | 使用二进制排序规则。Oracle 模式下该字符集的默认字符序。 |
| gb18030\_2022\_chinese\_ci | gb18030\_2022 | 使用拼音排序规则。不区分大小写。 |
| gb18030\_2022\_chinese\_cs | gb18030\_2022 | 使用拼音排序规则。区分大小写。 |
| gb18030\_2022\_radical\_ci | gb18030\_2022 | 使用部首笔画排序规则。不区分大小写。 |
| gb18030\_2022\_radical\_cs | gb18030\_2022 | 使用部首笔画排序规则。区分大小写。 |
| gb18030\_2022\_stroke\_ci | gb18030\_2022 | 使用笔画排序规则。不区分大小写。 |
| gb18030\_2022\_stroke\_cs | gb18030\_2022 | 使用笔画排序规则。区分大小写。 |
| ascii\_bin | ascii | 使用二进制排序规则。 |
| ascii\_general\_ci | ascii | 使用基于字母的不区分大小写的排序规则。它忽略了字符的大小写差异，将大写字母和小写字母视为相同的字符。 |
| tis620\_bin | tis620 | 使用二进制排序规则。 |
| tis620\_thai\_ci | tis620 | 使用泰语排序规则，不区分大小写。 |

## 数据库对象管理

支持

不支持

**表管理**

* 创建表：支持创建表，建表时可以指定分区、约束等信息。有关创建表的详细语法，请参见 [CREATE TABLE](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504112)。
* 修改基表：支持通过 `ALTER TABLE` 语句添加、删除、修改列；添加、删除约束；添加、删除、修改分区。有关修改表的详细语法，请参见 [ALTER TABLE](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504123)。
* 删除基表：支持删除表，并级联约束。有关删除表的详细语法，请参见 [DROP TABLE](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001504111)。

**约束**

* 支持 `CHECK`、`UNIQUE` 和 `NOT NULL` 约束。
* 支持 `PRIMARY KEY` 约束。
* 支持 `FOREIGN KEY` 约束。
* 支持使用 `ALTER TABLE` 语句添加 `CHECK` 约束、`PRIMARY KEY` 约束、`FOREIGN KEY` 约束以及 `NOT NULL` 约束。
* 支持级联操作中的 `SET NULL`。

**分区支持**

* 支持一级分区、模板化和非模板化的二级分区。
* 支持哈希（Hash）、范围（Range）、列表（List）和组合分区等分区形式。
* 支持局部索引和全局索引。
* 对于分区维护操作：

  + 一级分区表支持添加一级分区、删除一级分区、Truncate 一级分区。
  + 模板化二级分区表支持添加一级分区、删除一级分区；非模板化二级分区表支持添加一级分区、删除一级分区、Truncate 一级分区、添加二级分区、删除二级分区、Truncate 二级分区。

更多分区的详细信息，请参见 [分区概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501851)。

**索引管理**

* OceanBase 数据库仅支持 BTree 索引和函数索引。
* 支持创建和删除索引。

**视图管理**

* 支持创建简单或复杂视图。
* 支持删除视图功能。
* 支持使用 `SELECT` 语句查询视图。
* 支持 DML 语句。

**序列管理**

* 支持创建序列。
* 支持修改序列，包括序列的重置取值功能等。
* 支持删除序列。

**同义词**

* 支持对表、视图、同义词和序列等对象创建同义词。
* 支持创建公共同义词。

**触发器管理**

* 支持创建触发器。
* 支持修改触发器。
* 支持删除触发器。

**数据库链接**

* 支持 OceanBase 数据库到 OceanBase 数据库的读和写操作。
* 支持 OceanBase 数据库到 Oracle 数据库的读和写操作。

**约束**

* 不支持 `UNIQUE` 约束的 `DISABLE` 操作。

**分区支持**

* 模板化二级分区表暂不支持添加二级分区、删除二级分区。

**索引管理**

* 不支持位图和反向等索引类型。
* 在使用 UPDATE GLOBAL INDEX 重建索引期间，索引不可用。

**可更新视图**

不支持 `WITH CHECK OPTION` 子句。

## 安全特性

OceanBase 数据库实现了丰富的安全特性。

支持

不支持

**权限管理**

* 兼容 Oracle 数据库的大部分系统权限。有关 OceanBase 数据库 Oracle 模式支持的权限，请参见 [Oracle 模式下的权限分类](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001502668)。
* 支持常见的对象权限管理，例如，授权与移除权限。
* 支持白名单策略，实现网络安全访问控制。
* 支持系统预定义角色，用户自定义角色。

**身份鉴别**

* Oracle 模式兼容 Oracle 数据库的密码策略。
* 支持用户的锁定和解锁功能。

**透明加密**

兼容 Oracle 数据库的 TDE 功能，数据在写入存储设备之前自动进行加密，读取时自动解密。

**审计**

* 支持 Oracle 数据库的标准审计。
* 支持语句和对象审计类型。
* 对象审计当前仅支持表、序列、函数和包对象。
* 审计结果支持存放在文件或者内部表中。
* 支持审计相关的各类系统视图。

**标签安全**

* 兼容 Oracle 数据库中的标签安全（Label Security）功能。
* 支持 Level 维度。

**传输链路加密 SSL**

* 支持客户端与 OceanBase 数据库服务器的传输链路加密，以及 OceanBase 数据库节点之间的数据传输加密。
* 除了支持 SSL 单向认证、X509 双向认证，还支持指定加密算法、指定发行方认证、指定 SSL 主题认证等特殊的双向认证。

**审计**

* 不支持统一审计和 FGA 细粒度审计。
* 不支持权限审计和网络审计。
* 不支持修改、覆盖、删除审计数据。

**标签安全**

* 不支持 Compartment 和 Group 维度。

## 备份恢复

OceanBase 数据库也提供了备份恢复功能，更多 OceanBase 数据库物理备份恢复特性的介绍，请参见 [备份恢复概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500558)。

支持

不支持

* 支持 NFS、阿里云 OSS、AWS S3 及兼容 S3 协议的对象存储作为备份介质（例如，华为 OBS、Google GCS、腾讯云 COS）。
* 支持自动清理过期备份。
* 支持租户级别的备份与恢复。
* 支持数据库级和表级别的恢复。
* 支持指定路径的恢复。
* 支持日志归档和备份数据的校验。

* 不支持集群级别的备份与恢复。
* 不支持指定路径的备份。
* 不支持租户内部部分数据库和表级别的备份。
* 不支持日志归档压缩。
* 不支持手动清理备份。
* 不支持备份的备份。

## SQL 引擎

OceanBase 数据库的 SQL 引擎兼容了 Oracle 数据库大部分的特性。有关 SQL 引擎的详细信息，请参见 [SQL 调优指南](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500012)。

支持

不支持

* 支持查询改写功能。
* 支持预编译语句功能。
* 支持基于成本的优化器功能。
* 支持执行计划生成与展示（`EXPLAIN`）功能。
* 支持执行计划缓存功能。
* 支持执行计划快速参数化功能。
* 支持执行计划绑定功能。
* 支持 Optimizer Hint 功能。
* 支持自适应游标共享 ACS 功能。
* 支持执行计划管理 SPM 功能。

* 不支持估算器功能。
* 不支持执行计划隔离功能。
* 不支持表达式统计存储（ESS）功能。
* 不支持近似查询处理功能。