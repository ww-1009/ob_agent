---
title: SQL 数据类型
description: 提供关于SQL 数据类型的相关内容，
keywords: SQL 数据类型,OceanBase 数据库,OceanBase 简介,与 Oracle 兼容性对比,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# SQL 数据类型

本节主要介绍 OceanBase 数据库的 Oracle 模式与原生 Oracle 数据库中 SQL 数据类型的详细兼容对比信息。

Oracle 数据库中有 24 种数据类型，OceanBase 数据库目前支持 20 种，详细信息如下表所示。

| 序号 | Oracle 数据库 | OceanBase 数据库 |
| --- | --- | --- |
| 1 | CHAR (size) | 支持 |
| 2 | NCHAR[(size)] | 支持 |
| 3 | VARCHAR2(size) | 支持 |
| 4 | VARCHAR(size) | 支持 |
| 5 | NVARCHAR2(size) | 支持 |
| 6 | NUMBER [ (p [, s]) ] | 支持 |
| 7 | FLOAT [(p)] | 支持 |
| 8 | BINARY\_FLOAT | 支持 |
| 9 | BINARY\_DOUBLE | 支持 |
| 10 | LONG（Oracle 数据库已废弃类型） | 不支持 |
| 11 | DATE | 支持 |
| 12 | TIMESTAMP [(fractional\_seconds\_precision)] | 支持 |
| 13 | TIMESTAMP [(fractional\_seconds\_precision)] WITH TIME ZONE | 支持 |
| 14 | TIMESTAMP [(fractional\_seconds\_precision)] WITH LOCAL TIME ZONE | 支持 |
| 15 | INTERVAL YEAR [(year\_precision)] TO MONTH | 支持 |
| 16 | INTERVAL DAY [(day\_precision)] TO SECOND [(fractional\_seconds\_precision)] | 支持 |
| 17 | RAW(size) | 支持 |
| 18 | LONG RAW（Oracle 数据库已废弃类型） | 不支持 |
| 19 | ROWID | 支持 |
| 20 | UROWID [(size)] | 支持 |
| 21 | BFILE | 不支持 |
| 22 | BLOB | 支持 |
| 23 | CLOB | 支持 |
| 24 | NCLOB | 不支持 |