# 叶子索引：与 Oracle 兼容性对比

> 位置：> 位置：[ob_wiki](../../../../index.md) / [OceanBase 数据库](../../../index.md) / [OceanBase 简介](../../index.md) / [与 Oracle 兼容性对比](../index.md) / index.md
## 文档明细

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [内建函数.md](./内建函数.md) | 提供关于内建函数的相关内容， | 内建函数,OceanBase 数据库,OceanBase 简介,与 Oracle 兼容性对比,文档,使用帮助,OceanBase,分布式,数据库 |
| [SQL 数据类型.md](./SQL 数据类型.md) | 提供关于SQL 数据类型的相关内容， | SQL 数据类型,OceanBase 数据库,OceanBase 简介,与 Oracle 兼容性对比,文档,使用帮助,OceanBase,分布式,数据库 |
| [系统视图.md](./系统视图.md) | 提供关于系统视图的相关内容， | 系统视图,OceanBase 数据库,OceanBase 简介,与 Oracle 兼容性对比,文档,使用帮助,OceanBase,分布式,数据库 |
| [与 Oracle 兼容性概述.md](./与 Oracle 兼容性概述.md) | 提供关于与 Oracle 兼容性概述的相关内容， | 与 Oracle 兼容性概述,OceanBase 数据库,OceanBase 简介,与 Oracle 兼容性对比,文档,使用帮助,OceanBase,分布式,数据库 |
