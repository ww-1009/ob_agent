---
title: 与 MySQL 兼容性对比
description: 提供关于与 MySQL 兼容性对比的相关内容，
keywords: 与 MySQL 兼容性对比,OceanBase 数据库,OceanBase 简介,文档,使用帮助,OceanBase,分布式,数据库
updatetime: 2026-04-15T09:16:58.000+00:00
---

# 与 MySQL 兼容性对比

本节主要介绍 OceanBase 数据库的 MySQL 模式与原生 MySQL 数据库的兼容性对比信息。

OceanBase 数据库的 MySQL 模式兼容 MySQL 5.7/8.0 的绝大部分功能和语法。由于产品架构不同，或者客户需求不大，有些功能并没有被支持。本节主要从以下几方面介绍 OceanBase 数据库的 MySQL 模式与原生 MySQL 数据库的不同：

* 数据类型
* SQL 语法
* 过程性语言
* 系统视图
* 字符集
* 字符序
* 函数与表达式
* 分区支持
* 备份恢复
* 存储引擎
* 优化器

## 数据类型

OceanBase 数据库支持的数据类型如下：

* 数值类型

  + 整数类型：`BOOL`/`BOOLEAN`/`TINYINT`、`SMALLINT`、`MEDIUMINT`、`INT`/`INTEGER` 和 `BIGINT`。
  + 定点类型：`DECIMAL` 和 `NUMERIC`。
  + 浮点类型：`FLOAT` 和 `DOUBLE`。
  + Bit-Value 类型：`BIT`。
* 日期时间类型：`DATETIME`、`TIMESTAMP`、`DATE`、`TIME` 和 `YEAR`。
* 字符类型：`CHAR`、`VARCHAR`、`BINARY` 和 `VARBINARY`。
* 大对象类型：`TINYBLOB`、`BLOB`、`MEDIUMBLOB` 和 `LONGBLOB`。
* 文本类型：`TINYTEXT`、`TEXT`、`MEDIUMTEXT` 和 `LONGTEXT`。
* 枚举类型：`ENUM`。
* 集合类型：`SET`。
* JSON 数据类型
* 空间数据类型

## SQL 语法

支持

不支持

**SELECT**

* 支持大部分查询功能，包括支持单、多表查询；支持子查询、横向派生表（Lateral Derived Table）；支持内联接、半联接以及外联接；支持分组、聚合、常见的概率、线性回归等数据挖掘函数等。
* 支持对多个 `SELECT` 查询的结果进行 `UNION`、`UNION ALL`、`MINUS`、`EXCEPT` 或 `INTERSECT` 等集合操作。
* 支持通过 `EXPLAIN` 语法查看执行计划。

**INSERT**

* 支持单行和多行插入数据，同时支持指定分区插入数据。
* 支持 `INSERT INTO ... SELECT ...` 语句。

**UPDATE**

* 支持单列和多列更新。
* 支持使用子查询。
* 支持集合更新。

**DELETE**

* 支持单表和多表删除。

**TRUNCATE**

* 支持完全清空指定表。

**ROLE**

* `CREATE ROLE`
* `DROP ROLE`
* `SET DEFAULT ROLE`
* `SET ROLE`

**SELECT**

* 不支持 `SELECT ... FOR SHARE ...` 语法。

**TRUNCATE**

* 不支持在进行事务处理和表锁定的过程中操作。

## 过程性语言

OceanBase 数据库兼容了大部分 MySQL 数据库的 PL 功能。有关 PL 功能的详细信息，请参见 [PL 参考](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501937)。

OceanBase 数据库主要支持的 PL 功能如下：

* 数据类型
* 存储过程
* 自定义函数
* 触发器
* 异常处理

此外，OceanBase 数据库特有的 MySQL PL 系统包，包括 `DBMS_RESOURCE_MANAGER`、`DBMS_STATS`、`DBMS_UDR`、`DBMS_XPLAN` 和 `DBMS_WORKLOAD_REPOSITORY` 等。

## 系统视图

OceanBase 数据库实现了 `information_schema` 和 `mysql` 这两个内部数据库中的大部分视图，但是由于架构不同，OceanBase 数据库并不保证所有视图均能实现以及视图中所有的列含义与 MySQL 相同。

更多系统视图的字段说明信息，请参见 [系统视图](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001499700)。

## 字符集

OceanBase 数据库支持的字符集如下：

* binary
* utf8mb4/utf8mb3

  #### 说明

  `utf8mb3` 是 `utf8mb4` 的别名。
* gbk
* utf16
* utf16le
* gb18030
* latin1
* gb18030\_2022
* ascii
* tis620
* sjis
* big5
* dec8

## 字符序

OceanBase 数据库支持的字符序如下表所示。

| 字符序 | 所属字符集 | 说明 |
| --- | --- | --- |
| utf8mb4\_general\_ci | utf8mb4 | 使用通用排序规则。 |
| utf8mb4\_bin | utf8mb4 | 使用二进制排序规则。 |
| utf8mb4\_unicode\_ci | utf8mb4 | 使用基于 Unicode Collation Algorithm (UCA) 的排序规则。 |
| utf8mb4\_unicode\_520\_ci | utf8mb4 | 使用 Unicode 5.2.0 版本的排序规则。它遵循 Unicode 码点排序，并忽略字符的大小写差异。 |
| utf8mb4\_croatian\_ci | utf8mb4 | 使用克罗地亚文（Croatian）的排序规则。`utf8mb4_croatian_ci` 兼容 `utf8_croatian_ci`。 |
| utf8mb4\_czech\_ci | utf8mb4 | 使用捷克文（Czech）的排序规则。 |
| utf8mb4\_0900\_ai\_ci | utf8mb4 | 使用 Unicode 9.0.0 版本的字符排序规则和顺序，同时忽略了字符的大小写差异，将大写字母和小写字母视为相同的字符。 |
| binary | binary | 使用二进制排序规则。 |
| gbk\_chinese\_ci | gbk | 使用中文语言排序规则。 |
| gbk\_bin | gbk | 使用二进制排序规则。 |
| utf16\_general\_ci | utf16 | 使用通用排序规则。 |
| utf16\_bin | utf16 | 使用二进制排序规则。 |
| utf16\_unicode\_ci | utf16 | 使用基于 Unicode Collation Algorithm (UCA) 的排序规则。 |
| utf8mb4\_german2\_ci | utf16le | 使用德语排序规则。 |
| utf8mb4\_croatian\_ci | utf16le | 使用克罗地亚语排序规则。 |
| gb18030\_chinese\_ci | gb18030 | 使用中文语言排序规则。 |
| gb18030\_bin | gb18030 | 使用二进制排序规则。 |
| latin1\_swedish\_ci | latin1 | 使用瑞典语/芬兰语排序规则。 |
| latin1\_german1\_ci | latin1 | 用于德国（German）语言环境下的 latin1 字符集的排序规则。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_danish\_ci | latin1 | 用于丹麦（Danish）语言环境下的 latin1 字符集的排序规则。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_german2\_ci | latin1 | 用于德语环境，适用于需要按照字典顺序进行字符比较的应用场景。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_general\_ci | latin1 | 用于需要不区分大小写且支持重音符号的场景，如某些欧洲语言的数据库设计。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_general\_cs | latin1 | 用于区分大小写的通用排序规则，支持多种语言（如西欧语言）。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_spanish\_ci | latin1 | 用于西班牙（Spanish）语言环境的排序规则。 说明 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP1 版本开始支持该字符序。 |
| latin1\_bin | latin1 | latin1 使用二进制排序规则。 |
| gb18030\_2022\_bin | gb18030\_2022 | 使用二进制排序规则。 |
| gb18030\_2022\_chinese\_ci | gb18030\_2022 | 使用拼音排序规则。不区分大小写。MySQL 模式下该字符集的默认字符序。 |
| gb18030\_2022\_chinese\_cs | gb18030\_2022 | 使用拼音排序规则。区分大小写。 |
| gb18030\_2022\_radical\_ci | gb18030\_2022 | 使用部首笔画排序规则。不区分大小写。 |
| gb18030\_2022\_radical\_cs | gb18030\_2022 | 使用部首笔画排序规则。区分大小写。 |
| gb18030\_2022\_stroke\_ci | gb18030\_2022 | 使用笔画排序规则。不区分大小写。 |
| gb18030\_2022\_stroke\_cs | gb18030\_2022 | 使用笔画排序规则。区分大小写。 |
| ascii\_bin | ascii | 使用二进制排序规则。 |
| ascii\_general\_ci | ascii | 使用基于字母的不区分大小写的排序规则。它忽略了字符的大小写差异，将大写字母和小写字母视为相同的字符。 |
| tis620\_bin | tis620 | 使用二进制排序规则。 |
| tis620\_thai\_ci | tis620 | 使用泰语排序规则，不区分大小写。 |
| sjis\_japanese\_ci | sjis | 使用日语排序规则。 |
| dec8\_swedish\_ci | dec8 | 使用瑞典语排序规则。 |

## 函数

支持

不支持

* 分析（窗口）函数：OceanBase 数据库所支持的分析（窗口）函数是 MySQL 数据库的超集，即 MySQL 数据库的分析（窗口）函数 OceanBase 数据库都支持。
* XML 函数：`EXTRACTVALUE` 和 `UPDATEXML`。

  #### 说明

  OceanBase 数据库 MySQL 模式遵循 XML 1.0 规范和 XPath 1.0 规范进行 XML 和 XPath 的处理。在处理 XML 数据时，OceanBase 数据库 MySQL 模式与 MySQL 数据库可能会存在兼容性差异或功能支持上的差别。

与 MySQL 数据库对比，OceanBase 数据库的 MySQL 模式不支持如下函数：

* 字符串函数：`LOAD_FILE()` 和 `MATCH()`。
* 空间函数：`ST_POINTN()` 和 `ST_NumPoints()`。
* 其他函数：`MASTER_POS_WAIT()`。

## 分区支持

OceanBase 数据库与 MySQL 数据库对分区的支持差异如下：

* OceanBase 数据库支持一级分区，模板化和非模板化二级分区；MySQL 数据库不支持非模板化二级分区。
* OceanBase 数据库的二级分区支持 Hash、Key、Range、Range Columns、List 和 List Columns 分区；MySQL 数据库的二级分区仅支持 Hash 分区和 Key 分区。
* OceanBase 数据库二级分区表支持添加和删除二级分区；MySQL 数据库不支持添加和删除二级分区。

  #### 注意

  + 不支持二级分区类型是 Hash 或 Key 类型的场景新增和删除二级分区。
  + 对于 OceanBase 数据库 V4.2.5 版本，从 V4.2.5 BP4 版本开始支持新增二级分区。

更多分区的说明及使用，请参见 [分区概述](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001501921)。

## 备份恢复

OceanBase 数据库兼容了部分 MySQL 数据库的备份恢复特性。

支持

不支持

* 支持全量备份和增量备份。
* 支持热备份。
* 支持数据库级和表级恢复。
* 支持日志归档和备份数据的校验。

* 不支持集群级别的备份恢复。
* 不支持冷备份。
* 不支持表级备份。
* 不支持租户内部部分数据库和表级的备份。

## 存储引擎

与 MySQL 数据库基于数据块的 InnoDB 和 Myisam 引擎不同，OceanBase 数据库使用的是基于 LSM-Tree 架构的存储引擎。

## 优化器

OceanBase 数据库兼容了部分 MySQL 数据库的优化器功能。有关优化器的详细信息，请参见 [SQL 调优指南](https://www.oceanbase.com/docs/common-oceanbase-database-cn-1000000001500012)。

支持

不支持

* 查看执行计划的命令

  + 输出的列信息仅包含 `ID`、`OPERATOR`、`NAME`、`EST. ROWS` 和 `COST` 以及算子的详细信息。
* 查看统计信息

  + 支持执行 `ANALYZE TABLE` 语句手动查询数据字典表存储有关列值的直方图统计信息。
  + 支持通过视图自动查看表统计信息和列统计信息。
* 查询改写优化

  + 支持外联接优化。
  + 支持外联接简化。
  + 支持块嵌套循环和批量 Key 访问联接。
  + 支持条件过滤。
  + 支持常量叠算优化。
  + 支持 `IS NULL` 优化 (索引不存储 `NULL` 值)。
  + 支持 `ORDER BY` 优化。
  + 支持 `GROUP BY` 优化。
  + 支持 `DISTINCT` 消除。
  + 支持 `LIMIT` 下压。
  + 支持 Window 函数优化。
  + 支持避免全表扫描。
  + 支持谓词下压。
* Optimizer Hint 机制

  + 支持联接顺序 Optimizer Hints。
  + 支持表级别的 Optimizer Hints。
  + 支持索引级别的 Optimizer Hints。
  + 语法支持 `INDEX` Hint、`FULL` Hint、`ORDERED` Hint 和 `LEADING` Hint 等。
* 兼容 MySQL 数据库的并行执行能力包括并行查询、并行复制和并行写入等，且 OceanBase 数据库已经支持并行算子，包括并行聚集、并行联接、并行分组以及并行排序等。
* OceanBase 数据库还支持计划缓存和预编译，MySQL 数据库并不支持。

* 查看执行计划的命令

  + 不支持使用 `SHOW WARNINGS` 显示额外的信息。