# 分类索引：OceanBase 简介

> 位置：[ob_wiki](../../index.md) / [OceanBase 数据库](../index.md) / OceanBase 简介 / index.md

## 下级子分类

| 子分类 | 核心概述 | 关键词 | 链接 |
| :--- | :--- | :--- | :--- |
| **与 Oracle 兼容性对比** | 涵盖 内建函数、SQL 数据类型、系统视图、与 Oracle 兼容性概述。 | `与 Oracle 兼容性对比` `内建函数` `SQL 数据类型` `系统视图` | [进入目录](./与 Oracle 兼容性对比/index.md) |

## 叶子索引

| 文档名称 | 核心概述 | 关键词 |
| :--- | :--- | :--- |
| [OceanBase 概述.md](./OceanBase 概述.md) | 提供关于OceanBase 概述的相关内容， | OceanBase 概述,OceanBase 数据库,OceanBase 简介,文档,使用帮助,OceanBase,分布式,数据库 |
| [企业版和社区版的功能差异.md](./企业版和社区版的功能差异.md) | 提供关于企业版和社区版的功能差异的相关内容， | 企业版和社区版的功能差异,OceanBase 数据库,OceanBase 简介,文档,使用帮助,OceanBase,分布式,数据库 |
| [使用限制.md](./使用限制.md) | 提供关于使用限制的相关内容， | 使用限制,OceanBase 数据库,OceanBase 简介,文档,使用帮助,OceanBase,分布式,数据库 |
| [系统架构.md](./系统架构.md) | 提供关于系统架构的相关内容， | 系统架构,OceanBase 数据库,OceanBase 简介,文档,使用帮助,OceanBase,分布式,数据库 |
| [与 MySQL 兼容性对比.md](./与 MySQL 兼容性对比.md) | 提供关于与 MySQL 兼容性对比的相关内容， | 与 MySQL 兼容性对比,OceanBase 数据库,OceanBase 简介,文档,使用帮助,OceanBase,分布式,数据库 |
